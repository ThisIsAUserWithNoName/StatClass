"""Numerical and command-line tests for StatClass."""

from __future__ import annotations

import csv
import errno
import json
import math
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats
from scipy import optimize as scipy_optimize
from scipy import special as scipy_special

from statclass.advanced_regression import (
    isotonic_regression,
    kernel_density_estimation,
    kernel_regression,
    loess_regression,
    regression_spline,
    regularized_linear_regression,
    robust_linear_regression,
    smoothing_spline,
)
from statclass.association import correlation_tests
from statclass.bayesian import (
    BayesError,
    beta_binomial_analysis,
    gamma_poisson_analysis,
    normal_inverse_gamma_analysis,
    normal_known_variance_analysis,
)
from statclass.calculators import (
    CalculatorError,
    SUPPORTED_DISTRIBUTIONS,
    distribution_density,
    distribution_info,
    distribution_interval_probability,
    distribution_probability,
    distribution_quantile,
    mean_confidence_interval,
    poisson_rate_confidence_interval,
    proportion_confidence_interval,
    variance_confidence_interval,
)
from statclass.categorical import (
    chi_square_goodness_of_fit,
    chi_square_independence,
    contingency_table,
    fisher_exact_test,
    frequency_table,
)
from statclass.data import DataError, load_dataset
from statclass.discrete_estimation import (
    beta_binomial_estimation,
    binomial_estimation,
    discrete_uniform_estimation,
    geometric_estimation,
    hypergeometric_estimation,
    multinomial_estimation,
    negative_binomial_joint_estimation,
    negative_binomial_known_r_estimation,
    poisson_estimation,
)
from statclass.factorial import factorial_anova_ancova
from statclass.inference import paired_t_test
from statclass.logistic import (
    binary_logistic_regression,
    multinomial_logistic_regression,
)
from statclass.longitudinal import (
    random_intercept_mixed_model,
    repeated_measures_anova,
)
from statclass.multiple_regression import (
    compare_regression_models,
    multiple_linear_regression,
)
from statclass.multivariate import (
    linear_discriminant_analysis,
    one_way_manova,
    principal_component_analysis,
)
from statclass.negative_binomial import negative_binomial_regression
from statclass.nonparametric import (
    adjust_p_values,
    kruskal_wallis_test,
    mann_whitney_u_test,
    wilcoxon_signed_rank_test,
)
from statclass.numerical import (
    NumericalComputationError,
    covariance_from_information,
    delta_method_covariance,
    information_matrix_diagnostics,
    numerical_gradient,
    numerical_hessian,
    numerical_hessian_from_gradient,
    optimizer_convergence_diagnostics,
)
from statclass.poisson import poisson_mean_confidence_interval, poisson_regression
from statclass.power import (
    PowerError,
    one_proportion_detectable_effect,
    one_proportion_power,
    one_proportion_sample_size,
    one_sample_mean_detectable_effect,
    one_sample_mean_power,
    one_sample_mean_sample_size,
    one_way_anova_detectable_effect,
    one_way_anova_power,
    one_way_anova_sample_size,
    two_proportion_detectable_effect,
    two_proportion_power,
    two_proportion_sample_size,
    two_sample_mean_detectable_effect,
    two_sample_mean_power,
    two_sample_mean_sample_size,
)
from statclass.proportions import (
    binomial_likelihood_analysis,
    one_proportion_counts_test,
    one_proportion_test,
    two_proportion_counts_test,
    two_proportion_test,
)
from statclass.regression import simple_linear_regression
from statclass.resampling import (
    bootstrap_independent_difference,
    bootstrap_one_sample,
    permutation_correlation,
    permutation_paired,
    permutation_two_sample,
)
from statclass.summary_inference import (
    one_sample_summary_t_test,
    one_sample_summary_z_test,
    paired_summary_t_test,
    two_sample_summary_t_test,
)
from statclass.transformations import (
    TransformationError,
    outlier_diagnostics,
    standardize_series,
    transform_series,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
FIXTURE_ROOT = PROJECT_ROOT / "tests" / "fixtures"


class SummaryInferenceTests(unittest.TestCase):
    def test_one_sample_summary_t_matches_formula(self) -> None:
        actual = one_sample_summary_t_test(
            25, 72.4, 11.8, 70.0, "two-sided", 0.05
        )
        expected_t = (72.4 - 70.0) / (11.8 / math.sqrt(25))
        expected_p = 2.0 * scipy_stats.t.sf(abs(expected_t), 24)
        margin = scipy_stats.t.ppf(0.975, 24) * 11.8 / math.sqrt(25)
        self.assertTrue(
            math.isclose(actual["statistic"], expected_t, rel_tol=1e-14)
        )
        self.assertTrue(
            math.isclose(actual["p_value"], expected_p, rel_tol=1e-14)
        )
        self.assertTrue(
            np.allclose(
                actual["two_sided_confidence_interval_for_mean"],
                [72.4 - margin, 72.4 + margin],
                rtol=1e-14,
            )
        )

    def test_one_sample_summary_z_matches_formula(self) -> None:
        actual = one_sample_summary_z_test(
            100, 102.5, 15.0, 100.0, "greater", 0.05
        )
        expected_z = (102.5 - 100.0) / (15.0 / math.sqrt(100))
        self.assertTrue(
            math.isclose(actual["z_score"], expected_z, rel_tol=1e-14)
        )
        self.assertTrue(
            math.isclose(
                actual["p_value"],
                scipy_stats.norm.sf(expected_z),
                rel_tol=1e-14,
            )
        )

    def test_two_sample_summary_welch_matches_scipy(self) -> None:
        actual = two_sample_summary_t_test(
            50,
            10.2,
            2.1,
            45,
            9.4,
            2.3,
            False,
            "two-sided",
            0.05,
        )
        expected = scipy_stats.ttest_ind_from_stats(
            10.2,
            2.1,
            50,
            9.4,
            2.3,
            45,
            equal_var=False,
        )
        self.assertTrue(
            math.isclose(actual["statistic"], expected.statistic, rel_tol=1e-14)
        )
        self.assertTrue(
            math.isclose(actual["p_value"], expected.pvalue, rel_tol=1e-14)
        )

    def test_paired_summary_matches_difference_test_formula(self) -> None:
        actual = paired_summary_t_test(
            30, 2.4, 5.1, 0.0, "two-sided", 0.05
        )
        expected_t = 2.4 / (5.1 / math.sqrt(30))
        expected_p = 2.0 * scipy_stats.t.sf(abs(expected_t), 29)
        self.assertTrue(
            math.isclose(actual["statistic"], expected_t, rel_tol=1e-14)
        )
        self.assertTrue(
            math.isclose(actual["p_value"], expected_p, rel_tol=1e-14)
        )

    def test_one_proportion_counts_matches_scipy(self) -> None:
        actual = one_proportion_counts_test(
            30, 100, 0.25, "two-sided", 0.05
        )
        expected_z = (0.30 - 0.25) / math.sqrt(0.25 * 0.75 / 100)
        self.assertTrue(
            math.isclose(actual["z_score"], expected_z, rel_tol=1e-14)
        )
        self.assertTrue(
            math.isclose(
                actual["exact_binomial_p_value"],
                scipy_stats.binomtest(30, 100, 0.25).pvalue,
                rel_tol=1e-14,
            )
        )

    def test_two_proportion_counts_matches_formula(self) -> None:
        actual = two_proportion_counts_test(
            30, 100, 45, 120, "two-sided", 0.05
        )
        pooled = 75 / 220
        expected_z = (0.30 - 0.375) / math.sqrt(
            pooled * (1.0 - pooled) * (1.0 / 100 + 1.0 / 120)
        )
        self.assertTrue(
            math.isclose(actual["z_score"], expected_z, rel_tol=1e-14)
        )
        self.assertTrue(
            math.isclose(actual["risk_difference"], -0.075, rel_tol=1e-14)
        )


class BayesianTests(unittest.TestCase):
    def test_beta_binomial_update_and_prediction(self) -> None:
        actual = beta_binomial_analysis(30, 100, 1.0, 1.0, 0.05, 10)
        posterior = actual["posterior"]
        self.assertEqual((posterior["alpha"], posterior["beta"]), (31.0, 71.0))
        self.assertTrue(math.isclose(posterior["mean"], 31 / 102, rel_tol=1e-15))
        self.assertTrue(
            np.allclose(
                actual["credible_interval"],
                scipy_stats.beta.ppf([0.025, 0.975], 31, 71),
                rtol=1e-14,
            )
        )
        predictive = actual["posterior_predictive"]
        reference = scipy_stats.betabinom(10, 31, 71)
        self.assertTrue(
            math.isclose(predictive["mean_successes"], reference.mean(), rel_tol=1e-14)
        )
        self.assertTrue(
            math.isclose(
                predictive["variance_successes"], reference.var(), rel_tol=1e-14
            )
        )

    def test_gamma_poisson_update_and_prediction(self) -> None:
        actual = gamma_poisson_analysis(8, 2.5, 2.0, 1.5, 0.05, 3.0)
        posterior = actual["posterior"]
        self.assertEqual((posterior["shape"], posterior["rate"]), (10.0, 4.0))
        self.assertTrue(math.isclose(posterior["mean"], 2.5, rel_tol=1e-15))
        self.assertTrue(
            np.allclose(
                actual["credible_interval"],
                scipy_stats.gamma.ppf([0.025, 0.975], 10, scale=0.25),
                rtol=1e-14,
            )
        )
        predictive = actual["posterior_predictive"]
        reference = scipy_stats.nbinom(10, 4 / 7)
        self.assertTrue(
            math.isclose(predictive["mean_events"], reference.mean(), rel_tol=1e-14)
        )
        self.assertTrue(
            math.isclose(predictive["variance_events"], reference.var(), rel_tol=1e-14)
        )

    def test_normal_known_variance_update(self) -> None:
        actual = normal_known_variance_analysis(25, 72.4, 15.0, 70.0, 10.0)
        expected_variance = 1 / (1 / 100 + 25 / 225)
        expected_mean = expected_variance * (70 / 100 + 25 * 72.4 / 225)
        posterior = actual["posterior"]
        self.assertTrue(
            math.isclose(posterior["mean"], expected_mean, rel_tol=1e-15)
        )
        self.assertTrue(
            math.isclose(posterior["variance"], expected_variance, rel_tol=1e-15)
        )
        expected_predictive_variance = 225 + expected_variance
        self.assertTrue(
            math.isclose(
                actual["posterior_predictive"]["variance"],
                expected_predictive_variance,
                rel_tol=1e-15,
            )
        )

    def test_normal_inverse_gamma_update(self) -> None:
        actual = normal_inverse_gamma_analysis(
            25, 72.4, 11.8, 70.0, 1.0, 2.0, 100.0
        )
        posterior = actual["posterior"]
        expected_kappa = 26.0
        expected_mu = (70 + 25 * 72.4) / expected_kappa
        expected_alpha = 14.5
        expected_beta = 100 + 0.5 * (
            24 * 11.8**2 + 25 / 26 * (72.4 - 70) ** 2
        )
        self.assertTrue(math.isclose(posterior["mu"], expected_mu, rel_tol=1e-15))
        self.assertEqual(posterior["kappa"], expected_kappa)
        self.assertEqual(posterior["alpha"], expected_alpha)
        self.assertTrue(
            math.isclose(posterior["beta"], expected_beta, rel_tol=1e-15)
        )
        self.assertTrue(
            np.allclose(
                actual["variance_credible_interval"],
                scipy_stats.invgamma.ppf(
                    [0.025, 0.975], expected_alpha, scale=expected_beta
                ),
                rtol=1e-14,
            )
        )

    def test_invalid_conjugate_requests_are_rejected(self) -> None:
        with self.assertRaises(BayesError):
            beta_binomial_analysis(11, 10, 1, 1)
        with self.assertRaises(BayesError):
            gamma_poisson_analysis(8, 0, 1, 1)
        with self.assertRaises(BayesError):
            normal_known_variance_analysis(10, 2, -1, 0, 1)
        with self.assertRaises(BayesError):
            normal_inverse_gamma_analysis(1, 2, 1, 0, 1, 1, 1)
        with self.assertRaisesRegex(BayesError, "nonfinite"):
            normal_known_variance_analysis(
                2, 1.0, 1e308, 0.0, 1e308
            )

    def test_conjugate_numerical_status_validates_all_intervals(self) -> None:
        analyses = (
            beta_binomial_analysis(30, 100, 1.0, 1.0, 0.05, 10),
            gamma_poisson_analysis(8, 2.5, 2.0, 1.5, 0.05, 3.0),
            normal_known_variance_analysis(25, 72.4, 15.0, 70.0, 10.0),
            normal_inverse_gamma_analysis(
                25, 72.4, 11.8, 70.0, 1.0, 2.0, 100.0
            ),
        )
        for analysis in analyses:
            numerical = analysis["numerical_status"]
            self.assertEqual(numerical["status"], "completed")
            self.assertEqual(
                numerical["posterior_update_method"],
                "closed-form conjugate algebra",
            )
            self.assertFalse(numerical["derivatives_used"])
            self.assertFalse(numerical["optimization_used"])
            self.assertFalse(numerical["iterative_algorithm_used"])
            self.assertFalse(numerical["numerical_integration_used"])
            self.assertFalse(numerical["ode_solver_used"])
            self.assertFalse(numerical["mcmc_used"])
            self.assertTrue(
                numerical["posterior_parameter_validation"]["finite"]
            )
            for validation in numerical["interval_validations"]:
                self.assertTrue(validation["finite"])
                self.assertTrue(validation["ordered"])
                self.assertTrue(validation["within_support"])
                self.assertEqual(
                    validation["method"], "specialized inverse CDF (PPF)"
                )

    def test_nonfinite_or_unordered_bayesian_quantiles_are_rejected(self) -> None:
        with mock.patch(
            "statclass.bayesian.scipy_stats.beta.ppf",
            return_value=math.nan,
        ):
            with self.assertRaisesRegex(BayesError, "nonfinite endpoint"):
                beta_binomial_analysis(3, 10, 1.0, 1.0)
        with mock.patch(
            "statclass.bayesian.scipy_stats.gamma.ppf",
            side_effect=[2.0, 1.0],
        ):
            with self.assertRaisesRegex(BayesError, "decreasing order"):
                gamma_poisson_analysis(3, 2.0, 1.0, 1.0)


class TransformationTests(unittest.TestCase):
    def test_mathematical_transformations_match_numpy_and_scipy(self) -> None:
        series = pd.Series([1.0, 2.0, 4.0, 8.0, 16.0, np.nan])
        log_result, logged = transform_series(series, "x", "log")
        self.assertEqual(log_result["method"], "log")
        self.assertTrue(
            np.allclose(logged.dropna(), np.log([1, 2, 4, 8, 16]))
        )
        power_result, powered = transform_series(series, "x", "power", 2.0)
        self.assertEqual(power_result["parameter"], 2.0)
        self.assertTrue(
            np.allclose(powered.dropna(), np.asarray([1, 2, 4, 8, 16]) ** 2)
        )
        box_result, box_values = transform_series(series, "x", "box-cox")
        expected_box, expected_lambda = scipy_stats.boxcox(
            np.asarray([1, 2, 4, 8, 16], dtype=float)
        )
        self.assertTrue(np.allclose(box_values.dropna(), expected_box))
        self.assertTrue(
            math.isclose(box_result["parameter"], expected_lambda, rel_tol=1e-14)
        )

        signed = pd.Series([-3.0, -1.0, 0.0, 2.0, 5.0])
        yeo_result, yeo_values = transform_series(signed, "signed", "yeo-johnson")
        expected_yeo, expected_yeo_lambda = scipy_stats.yeojohnson(signed)
        self.assertTrue(np.allclose(yeo_values, expected_yeo))
        self.assertTrue(
            math.isclose(
                yeo_result["parameter"], expected_yeo_lambda, rel_tol=1e-14
            )
        )

    def test_standardization_methods_have_expected_locations_and_scales(self) -> None:
        series = pd.Series([1.0, 2.0, 3.0, 7.0, 10.0])
        _, z_scores = standardize_series(series, "x", "z-score")
        self.assertTrue(math.isclose(float(z_scores.mean()), 0.0, abs_tol=1e-15))
        self.assertTrue(math.isclose(float(z_scores.std(ddof=1)), 1.0, rel_tol=1e-15))

        _, min_max = standardize_series(series, "x", "min-max")
        self.assertEqual(float(min_max.min()), 0.0)
        self.assertEqual(float(min_max.max()), 1.0)

        _, robust = standardize_series(series, "x", "robust")
        self.assertEqual(float(robust.median()), 0.0)
        self.assertTrue(
            math.isclose(
                float(robust.quantile(0.75) - robust.quantile(0.25)),
                1.0,
                rel_tol=1e-15,
            )
        )

        _, centered = standardize_series(series, "x", "center")
        self.assertTrue(math.isclose(float(centered.mean()), 0.0, abs_tol=1e-15))

    def test_outlier_diagnostics_flag_extreme_values(self) -> None:
        series = pd.Series([1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 100.0])
        z_result, z_flags = outlier_diagnostics(series, "x", "z-score", 2.0)
        modified_result, modified_flags = outlier_diagnostics(
            series, "x", "modified-z-score"
        )
        iqr_result, iqr_flags = outlier_diagnostics(series, "x", "iqr")
        for result, flags in (
            (z_result, z_flags),
            (modified_result, modified_flags),
            (iqr_result, iqr_flags),
        ):
            self.assertEqual(result["status"], "completed")
            self.assertEqual(result["outlier_count"], 1)
            self.assertTrue(bool(flags.iloc[-1]))
            self.assertEqual(result["outliers"][0]["value"], 100.0)

        constant_result, constant_flags = outlier_diagnostics(
            pd.Series([3.0, 3.0, 3.0]), "constant", "modified-z-score"
        )
        self.assertEqual(constant_result["status"], "not_run")
        self.assertFalse(bool(constant_flags.any()))

    def test_invalid_transformation_requests_are_rejected(self) -> None:
        with self.assertRaises(TransformationError):
            transform_series(pd.Series([0.0, 1.0]), "x", "log")
        with self.assertRaises(TransformationError):
            transform_series(pd.Series([-1.0, 2.0]), "x", "box-cox")
        with self.assertRaises(TransformationError):
            transform_series(pd.Series([1.0, 2.0]), "x", "power")
        with self.assertRaises(TransformationError):
            standardize_series(pd.Series([2.0, 2.0]), "x", "z-score")
        with self.assertRaises(TransformationError):
            outlier_diagnostics(pd.Series([1.0, 2.0]), "x", "iqr", 0.0)


class MultivariateTests(unittest.TestCase):
    def setUp(self) -> None:
        self.frame = pd.read_csv(FIXTURE_ROOT / "multivariate_sample.csv")
        self.features = ["x1", "x2", "x3", "x4"]

    def test_pca_matches_correlation_eigendecomposition(self) -> None:
        actual = principal_component_analysis(
            self.frame, self.features, component_count=3
        )
        correlation = self.frame[self.features].corr().to_numpy()
        expected = np.linalg.eigvalsh(correlation)[::-1]
        self.assertEqual(actual["status"], "completed")
        self.assertEqual(actual["retained_component_count"], 3)
        self.assertTrue(
            np.allclose(
                [row["eigenvalue"] for row in actual["components"]],
                expected,
                rtol=1e-13,
                atol=1e-13,
            )
        )
        self.assertTrue(
            math.isclose(
                sum(
                    row["explained_variance_ratio"]
                    for row in actual["components"]
                ),
                1.0,
                rel_tol=1e-14,
            )
        )
        self.assertEqual(len(actual["score_rows"]), len(self.frame))

    def test_manova_statistics_match_sscp_identities(self) -> None:
        actual = one_way_manova(
            self.frame, "group", self.features, alpha=0.05
        )
        error = np.asarray(actual["error_sscp"])
        hypothesis = np.asarray(actual["hypothesis_sscp"])
        expected_wilks = np.linalg.det(error) / np.linalg.det(error + hypothesis)
        wilks = next(
            test
            for test in actual["multivariate_tests"]
            if test["method"] == "Wilks lambda"
        )
        self.assertTrue(
            math.isclose(wilks["statistic"], expected_wilks, rel_tol=1e-12)
        )
        self.assertLess(wilks["p_value"], 1e-10)
        self.assertEqual(len(actual["follow_up_univariate_anovas"]), 4)

    def test_discriminant_roots_and_classification(self) -> None:
        manova = one_way_manova(
            self.frame, "group", self.features, alpha=0.05
        )
        actual = linear_discriminant_analysis(
            self.frame, "group", self.features
        )
        roots = [
            dimension["eigenvalue"]
            for dimension in actual["canonical_dimensions"]
        ]
        self.assertTrue(
            np.allclose(roots, manova["canonical_roots"], rtol=1e-11)
        )
        self.assertGreaterEqual(actual["classification"]["accuracy"], 0.95)
        self.assertEqual(actual["cross_validation"]["status"], "completed")
        self.assertGreaterEqual(actual["cross_validation"]["accuracy"], 0.90)
        probabilities = [
            sum(
                value
                for key, value in row.items()
                if key.startswith("posterior_")
            )
            for row in actual["score_rows"]
        ]
        self.assertTrue(np.allclose(probabilities, 1.0, rtol=1e-13))


class NumericalUtilityTests(unittest.TestCase):
    def test_scaled_central_differences_recover_quadratic_curvature(self) -> None:
        information = np.asarray([[4.0, 1.25], [1.25, 3.0]])
        linear = np.asarray([-2.0, 0.75])

        def objective(values: np.ndarray) -> float:
            return float(0.5 * values @ information @ values + linear @ values)

        def gradient(values: np.ndarray) -> np.ndarray:
            return information @ values + linear

        point = np.asarray([1.5, -0.75])
        numerical_score, score_diagnostics = numerical_gradient(objective, point)
        value_hessian, value_diagnostics = numerical_hessian(objective, point)
        gradient_hessian, gradient_diagnostics = numerical_hessian_from_gradient(
            gradient, point
        )
        self.assertTrue(
            np.allclose(numerical_score, gradient(point), rtol=1e-7, atol=1e-7)
        )
        self.assertTrue(
            np.allclose(value_hessian, information, rtol=1e-6, atol=1e-6)
        )
        self.assertTrue(
            np.allclose(gradient_hessian, information, rtol=1e-10, atol=1e-10)
        )
        self.assertTrue(score_diagnostics["step_stable"])
        self.assertTrue(value_diagnostics["step_stable"])
        self.assertTrue(gradient_diagnostics["step_stable"])

    def test_cholesky_covariance_and_delta_method(self) -> None:
        information = np.asarray([[5.0, 1.0], [1.0, 2.0]])
        covariance, diagnostics = covariance_from_information(information)
        self.assertTrue(
            np.allclose(covariance, np.linalg.inv(information), rtol=1e-13)
        )
        self.assertEqual(diagnostics["covariance_method"], "Cholesky linear solve")
        self.assertTrue(diagnostics["positive_definite"])
        jacobian = np.asarray([[2.0, 0.0], [1.0, -1.0]])
        transformed = delta_method_covariance(covariance, jacobian)
        self.assertTrue(
            np.allclose(transformed, jacobian @ covariance @ jacobian.T)
        )
        with self.assertRaises(NumericalComputationError):
            covariance_from_information([[1.0, 1.0], [1.0, 1.0]])
        nearly_singular = information_matrix_diagnostics(
            [[1.0, 0.0], [0.0, 1e-12]]
        )
        self.assertTrue(nearly_singular["near_singular"])
        self.assertIn("ill-conditioned", " ".join(nearly_singular["warnings"]))
        with self.assertRaises(NumericalComputationError):
            covariance_from_information([[1.0, 0.0], [0.0, 1e-12]])

    def test_normal_likelihood_numerical_hessian_matches_analytic(self) -> None:
        sample = np.asarray([1.2, 0.7, 1.8, 2.1, 0.9])
        known_variance = 2.25

        def objective(parameters: np.ndarray) -> float:
            mean = parameters[0]
            return float(np.sum((sample - mean) ** 2) / (2.0 * known_variance))

        actual, diagnostics = numerical_hessian(objective, [1.3])
        expected = np.asarray([[sample.size / known_variance]])
        self.assertTrue(np.allclose(actual, expected, rtol=1e-7, atol=1e-7))
        self.assertTrue(diagnostics["step_stable"])

    def test_binomial_likelihood_numerical_hessian_matches_analytic(self) -> None:
        successes = 37
        trials = 100
        probability = 0.41

        def objective(parameters: np.ndarray) -> float:
            candidate = parameters[0]
            return -float(
                successes * math.log(candidate)
                + (trials - successes) * math.log1p(-candidate)
            )

        actual, diagnostics = numerical_hessian(objective, [probability])
        expected = np.asarray(
            [[
                successes / probability**2
                + (trials - successes) / (1.0 - probability) ** 2
            ]]
        )
        self.assertTrue(np.allclose(actual, expected, rtol=1e-6, atol=1e-6))
        self.assertTrue(diagnostics["step_stable"])

    def test_poisson_likelihood_numerical_hessian_matches_analytic(self) -> None:
        sample = np.asarray([1, 4, 2, 7, 3, 5], dtype=float)
        log_mean = math.log(3.4)

        def objective(parameters: np.ndarray) -> float:
            candidate = parameters[0]
            return float(sample.size * math.exp(candidate) - np.sum(sample) * candidate)

        actual, diagnostics = numerical_hessian(objective, [log_mean])
        expected = np.asarray([[sample.size * math.exp(log_mean)]])
        self.assertTrue(np.allclose(actual, expected, rtol=1e-6, atol=1e-6))
        self.assertTrue(diagnostics["step_stable"])

    def test_logistic_likelihood_gradient_hessian_matches_analytic(self) -> None:
        design = np.asarray(
            [
                [1.0, -1.5],
                [1.0, -0.5],
                [1.0, 0.25],
                [1.0, 0.8],
                [1.0, 1.7],
            ]
        )
        response = np.asarray([0.0, 0.0, 1.0, 1.0, 1.0])
        point = np.asarray([-0.2, 0.75])

        def gradient(parameters: np.ndarray) -> np.ndarray:
            probabilities = scipy_special.expit(design @ parameters)
            return design.T @ (probabilities - response)

        probabilities = scipy_special.expit(design @ point)
        expected = design.T @ (
            (probabilities * (1.0 - probabilities))[:, None] * design
        )
        actual, diagnostics = numerical_hessian_from_gradient(gradient, point)
        self.assertTrue(np.allclose(actual, expected, rtol=1e-9, atol=1e-9))
        self.assertTrue(diagnostics["step_stable"])

    def test_optimizer_failure_diagnostics_are_explicit(self) -> None:
        failed = scipy_optimize.OptimizeResult(
            x=np.asarray([1.0]),
            fun=2.0,
            success=False,
            message="iteration limit reached",
            nit=50,
            nfev=80,
            njev=50,
        )
        diagnostics = optimizer_convergence_diagnostics(
            failed,
            gradient=np.asarray([0.25]),
            method="test optimizer",
        )
        self.assertEqual(diagnostics["status"], "failed")
        self.assertFalse(diagnostics["converged"])
        self.assertEqual(diagnostics["iterations"], 50)
        self.assertGreater(diagnostics["gradient_infinity_norm"], 1e-5)


class CalculatorTests(unittest.TestCase):
    def test_all_requested_distribution_families_are_registered(self) -> None:
        self.assertEqual(
            set(SUPPORTED_DISTRIBUTIONS),
            {
                "bernoulli", "binomial", "discrete-uniform", "geometric",
                "hypergeometric", "negative-binomial", "poisson", "beta",
                "beta-binomial", "cauchy", "chi-square", "laplace",
                "exponential", "f", "gamma", "logistic", "lognormal",
                "normal", "pareto", "t", "uniform", "weibull",
            },
        )
        self.assertEqual(len(SUPPORTED_DISTRIBUTIONS), 22)

    def test_every_distribution_pmf_or_pdf_matches_scipy(self) -> None:
        requests = (
            ("bernoulli", 1, [0.3], scipy_stats.bernoulli(0.3).pmf(1)),
            ("binomial", 3, [10, 0.3], scipy_stats.binom(10, 0.3).pmf(3)),
            ("discrete-uniform", 4, [6], scipy_stats.randint(1, 7).pmf(4)),
            ("geometric", 3, [0.3], scipy_stats.geom(0.3).pmf(3)),
            (
                "hypergeometric", 4, [100, 30, 10],
                scipy_stats.hypergeom(100, 30, 10).pmf(4),
            ),
            (
                "negative-binomial", 4, [5, 0.3],
                scipy_stats.nbinom(5, 0.3).pmf(4),
            ),
            ("poisson", 4, [4], scipy_stats.poisson(4).pmf(4)),
            ("beta-binomial", 4, [10, 2, 5], scipy_stats.betabinom(10, 2, 5).pmf(4)),
            ("beta", 0.4, [2, 5], scipy_stats.beta(2, 5).pdf(0.4)),
            ("cauchy", 0.5, [0, 1], scipy_stats.cauchy(0, 1).pdf(0.5)),
            ("chi-square", 4, [5], scipy_stats.chi2(5).pdf(4)),
            ("laplace", 0.5, [0, 2], scipy_stats.laplace(0, 2).pdf(0.5)),
            ("exponential", 2, [2], scipy_stats.expon(scale=2).pdf(2)),
            ("f", 1.2, [5, 10], scipy_stats.f(5, 10).pdf(1.2)),
            ("gamma", 4, [3, 2], scipy_stats.gamma(3, scale=2).pdf(4)),
            ("logistic", 0.5, [0, 2], scipy_stats.logistic(0, 2).pdf(0.5)),
            ("lognormal", 2, [0, 1], scipy_stats.lognorm(1, scale=1).pdf(2)),
            ("normal", 0.5, [0, 1], scipy_stats.norm(0, 1).pdf(0.5)),
            ("pareto", 2, [1, 3], scipy_stats.pareto(3, scale=1).pdf(2)),
            ("t", 0.5, [10], scipy_stats.t(10).pdf(0.5)),
            ("uniform", 0.5, [0, 1], scipy_stats.uniform(0, 1).pdf(0.5)),
            (
                "weibull", 1.5, [2, 4],
                scipy_stats.weibull_min(2, scale=2).pdf(1.5),
            ),
        )
        for name, value, parameters, expected in requests:
            actual = distribution_density(name, value, parameters)
            self.assertEqual(actual["result_status"], "finite", name)
            self.assertTrue(
                math.isclose(actual["result"], expected, rel_tol=1e-13),
                name,
            )

    def test_distribution_information_matches_textbook_parameterizations(self) -> None:
        geometric = distribution_info("geometric", [0.25])
        self.assertEqual(geometric["support"], "integers 1, 2, 3, ...")
        self.assertTrue(math.isclose(geometric["mean"], 4.0, rel_tol=1e-14))
        self.assertTrue(math.isclose(geometric["variance"], 12.0, rel_tol=1e-14))

        hypergeometric = distribution_info("hypergeometric", [100, 30, 10])
        self.assertTrue(math.isclose(hypergeometric["mean"], 3.0, rel_tol=1e-14))
        self.assertEqual(hypergeometric["support"], "integers 0 through 10")

        negative_binomial = distribution_info("negative-binomial", [5, 0.25])
        self.assertTrue(math.isclose(negative_binomial["mean"], 15.0, rel_tol=1e-14))
        self.assertTrue(math.isclose(negative_binomial["variance"], 60.0, rel_tol=1e-14))

        gamma = distribution_info("gamma", [3, 2])
        self.assertTrue(math.isclose(gamma["mean"], 6.0, rel_tol=1e-14))
        self.assertTrue(math.isclose(gamma["variance"], 12.0, rel_tol=1e-14))

        weibull = distribution_info("weibull", [2, 4])
        expected_mean = 4 ** 0.5 * scipy_special.gamma(1.5)
        self.assertTrue(math.isclose(weibull["mean"], expected_mean, rel_tol=1e-14))
        self.assertIn("exp(-x^GAMMA/BETA)", weibull["parameterization"])

        cauchy = distribution_info("cauchy", [0, 1])
        self.assertIsNone(cauchy["mean"])
        self.assertEqual(cauchy["mean_status"], "undefined")
        self.assertEqual(cauchy["variance_status"], "undefined")
        self.assertIn("does not exist", cauchy["mgf"])

        pareto = distribution_info("pareto", [1, 1.5])
        self.assertTrue(math.isclose(pareto["mean"], 3.0, rel_tol=1e-14))
        self.assertEqual(pareto["variance_status"], "infinite")

        self.assertEqual(
            distribution_info("double-exponential", [0, 2])["distribution"],
            "laplace",
        )
        self.assertEqual(
            distribution_info("continuous-uniform", [0, 1])["distribution"],
            "uniform",
        )

    def test_all_discrete_moment_formulas_match_scipy(self) -> None:
        requests = (
            ("bernoulli", [0.3], scipy_stats.bernoulli(0.3)),
            ("binomial", [12, 0.3], scipy_stats.binom(12, 0.3)),
            ("discrete-uniform", [7], scipy_stats.randint(1, 8)),
            ("geometric", [0.3], scipy_stats.geom(0.3)),
            (
                "hypergeometric",
                [100, 30, 10],
                scipy_stats.hypergeom(100, 30, 10),
            ),
            (
                "negative-binomial",
                [5, 0.3],
                scipy_stats.nbinom(5, 0.3),
            ),
            ("poisson", [4.2], scipy_stats.poisson(4.2)),
            (
                "beta-binomial",
                [12, 2.5, 4.0],
                scipy_stats.betabinom(12, 2.5, 4.0),
            ),
        )
        for name, parameters, reference in requests:
            actual = distribution_info(name, parameters)
            expected_mean = float(reference.mean())
            expected_variance = float(reference.var())
            expected_second_raw = expected_variance + expected_mean**2
            self.assertEqual(
                set(actual["moment_formulas"]),
                {"first_raw", "second_raw", "second_central"},
                name,
            )
            self.assertTrue(
                math.isclose(
                    actual["first_raw_moment"], expected_mean, rel_tol=1e-12
                ),
                name,
            )
            self.assertTrue(
                math.isclose(
                    actual["second_central_moment"],
                    expected_variance,
                    rel_tol=1e-12,
                ),
                name,
            )
            self.assertTrue(
                math.isclose(
                    actual["second_raw_moment"],
                    expected_second_raw,
                    rel_tol=1e-12,
                ),
                name,
            )
            self.assertTrue(
                math.isclose(
                    actual["second_raw_moment"],
                    actual["second_central_moment"]
                    + actual["first_raw_moment"] ** 2,
                    rel_tol=1e-12,
                ),
                name,
            )

    def test_point_and_tail_probabilities_match_scipy(self) -> None:
        requests = (
            (
                distribution_probability("binomial", "eq", 8.0, [20.0, 0.3]),
                scipy_stats.binom.pmf(8, 20, 0.3),
            ),
            (
                distribution_probability("poisson", "ge", 8.0, [5.0]),
                scipy_stats.poisson.sf(7, 5.0),
            ),
            (
                distribution_probability("normal", "le", 1.96, [0.0, 1.0]),
                scipy_stats.norm.cdf(1.96),
            ),
            (
                distribution_probability("t", "gt", 2.1, [20.0]),
                scipy_stats.t.sf(2.1, 20),
            ),
            (
                distribution_probability("chi-square", "gt", 12.6, [6.0]),
                scipy_stats.chi2.sf(12.6, 6),
            ),
            (
                distribution_probability("f", "le", 3.2, [4.0, 20.0]),
                scipy_stats.f.cdf(3.2, 4, 20),
            ),
        )
        for actual, expected in requests:
            self.assertTrue(
                math.isclose(actual["result"], expected, rel_tol=1e-14)
            )
            self.assertEqual(
                actual["numerical_validation"]["status"], "validated"
            )
            self.assertTrue(
                actual["numerical_validation"]["valid_probability_range"]
            )

    def test_interval_probabilities_and_quantiles_match_scipy(self) -> None:
        binomial = distribution_interval_probability(
            "binomial", 4.0, 8.0, [20.0, 0.3]
        )
        self.assertTrue(
            math.isclose(
                binomial["result"],
                scipy_stats.binom.cdf(8, 20, 0.3)
                - scipy_stats.binom.cdf(3, 20, 0.3),
                rel_tol=1e-14,
            )
        )
        normal = distribution_interval_probability(
            "normal", -1.96, 1.96, [0.0, 1.0]
        )
        self.assertTrue(
            math.isclose(
                normal["result"],
                scipy_stats.norm.cdf(1.96) - scipy_stats.norm.cdf(-1.96),
                rel_tol=1e-14,
            )
        )
        quantile_requests = (
            ("t", 0.975, [20.0], scipy_stats.t.ppf(0.975, 20)),
            ("chi-square", 0.95, [6.0], scipy_stats.chi2.ppf(0.95, 6)),
            ("f", 0.95, [4.0, 20.0], scipy_stats.f.ppf(0.95, 4, 20)),
            ("poisson", 0.9, [5.0], scipy_stats.poisson.ppf(0.9, 5)),
        )
        for name, probability, parameters, expected in quantile_requests:
            actual = distribution_quantile(name, probability, parameters)
            self.assertTrue(
                math.isclose(actual["result"], expected, rel_tol=1e-14)
            )
            self.assertEqual(
                actual["numerical_validation"]["status"], "validated"
            )

    def test_continuous_interval_probabilities_are_tail_stable(self) -> None:
        upper_tail = distribution_interval_probability(
            "normal", 10.0, 11.0, [0.0, 1.0]
        )
        expected_upper = float(
            scipy_stats.norm.sf(10.0) - scipy_stats.norm.sf(11.0)
        )
        self.assertGreater(upper_tail["result"], 0.0)
        self.assertTrue(
            math.isclose(upper_tail["result"], expected_upper, rel_tol=1e-14)
        )
        self.assertEqual(
            upper_tail["evaluation_method"], "survival-function difference"
        )

        lower_tail = distribution_interval_probability(
            "normal", -11.0, -10.0, [0.0, 1.0]
        )
        expected_lower = float(
            scipy_stats.norm.cdf(-10.0) - scipy_stats.norm.cdf(-11.0)
        )
        self.assertTrue(
            math.isclose(lower_tail["result"], expected_lower, rel_tol=1e-14)
        )
        self.assertEqual(lower_tail["evaluation_method"], "CDF difference")

        upper_tail_cases = (
            ("t", 20.0, 30.0, [10.0], scipy_stats.t(10)),
            ("gamma", 50.0, 60.0, [3.0, 2.0], scipy_stats.gamma(3, scale=2)),
            (
                "lognormal",
                100.0,
                200.0,
                [0.0, 1.0],
                scipy_stats.lognorm(1, scale=1),
            ),
            (
                "weibull",
                5.0,
                6.0,
                [2.0, 2.0],
                scipy_stats.weibull_min(2, scale=math.sqrt(2)),
            ),
        )
        for name, lower, upper, parameters, reference in upper_tail_cases:
            actual = distribution_interval_probability(
                name, lower, upper, parameters
            )
            expected = float(reference.sf(lower) - reference.sf(upper))
            self.assertEqual(
                actual["evaluation_method"],
                "survival-function difference",
                name,
            )
            self.assertTrue(
                math.isclose(actual["result"], expected, rel_tol=1e-13),
                name,
            )

        underflow = distribution_interval_probability(
            "normal", 40.0, 41.0, [0.0, 1.0]
        )
        self.assertEqual(underflow["result"], 0.0)
        self.assertEqual(
            underflow["numerical_validation"]["status"], "underflow_to_zero"
        )
        self.assertLess(
            underflow["numerical_validation"]["log_probability"], -700.0
        )
        self.assertTrue(underflow["numerical_validation"]["warnings"])

    def test_cdf_and_pdf_endpoint_semantics_are_explicit(self) -> None:
        less = distribution_probability("normal", "lt", 0.0, [0.0, 1.0])
        less_equal = distribution_probability(
            "normal", "le", 0.0, [0.0, 1.0]
        )
        self.assertEqual(less["result"], less_equal["result"])
        self.assertIn("continuous CDF", less["endpoint_semantics"])

        discrete_less = distribution_probability(
            "binomial", "lt", 3.0, [10.0, 0.3]
        )
        discrete_less_equal = distribution_probability(
            "binomial", "le", 3.0, [10.0, 0.3]
        )
        self.assertLess(discrete_less["result"], discrete_less_equal["result"])
        self.assertIn("right-continuous", discrete_less["endpoint_semantics"])

        lower_density = distribution_density("exponential", 0.0, [2.0])
        self.assertEqual(lower_density["support_boundary"], "lower")
        self.assertEqual(lower_density["density_derivative_side"], "right")
        upper_density = distribution_density("uniform", 1.0, [0.0, 1.0])
        self.assertEqual(upper_density["support_boundary"], "upper")
        self.assertEqual(upper_density["density_derivative_side"], "left")

        zero_width = distribution_interval_probability(
            "normal", 2.0, 2.0, [0.0, 1.0]
        )
        self.assertEqual(zero_width["result"], 0.0)
        self.assertIn("open and closed", zero_width["endpoint_semantics"])

    def test_direct_confidence_intervals_match_formulas(self) -> None:
        mean_t = mean_confidence_interval(25, 72.4, 11.8, 0.05, False)
        t_margin = scipy_stats.t.ppf(0.975, 24) * 11.8 / math.sqrt(25)
        self.assertTrue(
            np.allclose(
                mean_t["confidence_interval"],
                [72.4 - t_margin, 72.4 + t_margin],
                rtol=1e-14,
            )
        )
        mean_z = mean_confidence_interval(100, 102.5, 15.0, 0.05, True)
        z_margin = scipy_stats.norm.ppf(0.975) * 15.0 / math.sqrt(100)
        self.assertTrue(
            np.allclose(
                mean_z["confidence_interval"],
                [102.5 - z_margin, 102.5 + z_margin],
                rtol=1e-14,
            )
        )
        proportion = proportion_confidence_interval(30, 100, 0.05)
        exact = scipy_stats.binomtest(30, 100).proportion_ci(method="exact")
        self.assertTrue(
            np.allclose(
                proportion["exact_clopper_pearson_interval"],
                [exact.low, exact.high],
                rtol=1e-14,
            )
        )
        variance = variance_confidence_interval(25, 139.24, 0.05)
        expected_variance = [
            24 * 139.24 / scipy_stats.chi2.ppf(0.975, 24),
            24 * 139.24 / scipy_stats.chi2.ppf(0.025, 24),
        ]
        self.assertTrue(
            np.allclose(
                variance["variance_confidence_interval"],
                expected_variance,
                rtol=1e-14,
            )
        )
        rate = poisson_rate_confidence_interval(8, 1000.0, 0.05)
        expected_rate = [
            0.5 * scipy_stats.chi2.ppf(0.025, 16) / 1000.0,
            0.5 * scipy_stats.chi2.ppf(0.975, 18) / 1000.0,
        ]
        self.assertTrue(
            np.allclose(rate["confidence_interval"], expected_rate, rtol=1e-14)
        )

    def test_invalid_calculator_requests_are_rejected(self) -> None:
        with self.assertRaises(CalculatorError):
            distribution_probability("normal", "eq", 0.0, [0.0, 1.0])
        with self.assertRaises(CalculatorError):
            distribution_quantile("t", 1.0, [10.0])
        with self.assertRaises(CalculatorError):
            proportion_confidence_interval(101, 100, 0.05)
        with self.assertRaises(CalculatorError):
            poisson_rate_confidence_interval(8, 0.0, 0.05)
        with self.assertRaises(CalculatorError):
            distribution_info("hypergeometric", [10, 11, 3])
        with self.assertRaises(CalculatorError):
            distribution_info("geometric", [0])
        with self.assertRaises(CalculatorError):
            distribution_info("uniform", [2, 1])


class PowerAnalysisTests(unittest.TestCase):
    def test_mean_power_matches_noncentral_t_formulas(self) -> None:
        one_sample = one_sample_mean_power(50, 0.5, 0.05, "two-sided")
        critical = scipy_stats.t.ppf(0.975, 49)
        expected = scipy_stats.nct.cdf(-critical, 49, 0.5 * math.sqrt(50))
        expected += scipy_stats.nct.sf(critical, 49, 0.5 * math.sqrt(50))
        self.assertTrue(
            math.isclose(one_sample["power"], expected, rel_tol=1e-14)
        )

        two_sample = two_sample_mean_power(
            40, 50, 0.6, 0.05, "greater"
        )
        degrees_of_freedom = 88
        noncentrality = 0.6 / math.sqrt(1 / 40 + 1 / 50)
        critical = scipy_stats.t.ppf(0.95, degrees_of_freedom)
        expected = scipy_stats.nct.sf(
            critical, degrees_of_freedom, noncentrality
        )
        self.assertTrue(
            math.isclose(two_sample["power"], expected, rel_tol=1e-14)
        )

    def test_proportion_and_anova_power_match_reference_formulas(self) -> None:
        one = one_proportion_power(100, 0.30, 0.20, 0.05, "two-sided")
        critical = scipy_stats.norm.ppf(0.975)
        null_se = math.sqrt(0.20 * 0.80 / 100)
        actual_se = math.sqrt(0.30 * 0.70 / 100)
        lower = 0.20 - critical * null_se
        upper = 0.20 + critical * null_se
        expected = scipy_stats.norm.cdf((lower - 0.30) / actual_se)
        expected += scipy_stats.norm.sf((upper - 0.30) / actual_se)
        self.assertTrue(math.isclose(one["power"], expected, rel_tol=1e-14))

        two = two_proportion_power(
            100, 120, 0.30, 0.45, 0.05, "two-sided"
        )
        pooled = (100 * 0.30 + 120 * 0.45) / 220
        null_se = math.sqrt(pooled * (1 - pooled) * (1 / 100 + 1 / 120))
        actual_se = math.sqrt(0.30 * 0.70 / 100 + 0.45 * 0.55 / 120)
        expected = scipy_stats.norm.cdf(
            (-critical * null_se - (0.30 - 0.45)) / actual_se
        )
        expected += scipy_stats.norm.sf(
            (critical * null_se - (0.30 - 0.45)) / actual_se
        )
        self.assertTrue(math.isclose(two["power"], expected, rel_tol=1e-14))

        anova = one_way_anova_power(4, 25, 0.25, 0.05)
        f_critical = scipy_stats.f.ppf(0.95, 3, 96)
        expected = scipy_stats.ncf.sf(f_critical, 3, 96, 100 * 0.25**2)
        self.assertTrue(math.isclose(anova["power"], expected, rel_tol=1e-14))

    def test_sample_sizes_are_minimal_and_detectable_effects_hit_target(self) -> None:
        mean = one_sample_mean_sample_size(0.5, 0.8, 0.05, "two-sided")
        self.assertGreaterEqual(mean["achieved_power"], 0.8)
        self.assertLess(
            one_sample_mean_power(
                mean["sample_size"] - 1, 0.5, 0.05, "two-sided"
            )["power"],
            0.8,
        )
        two_mean = two_sample_mean_sample_size(
            0.6, 0.8, 0.05, "two-sided", 1.5
        )
        previous_n_1 = two_mean["sample_size_1"] - 1
        previous_n_2 = math.ceil(1.5 * previous_n_1)
        self.assertLess(
            two_sample_mean_power(
                previous_n_1,
                previous_n_2,
                0.6,
                0.05,
                "two-sided",
            )["power"],
            0.8,
        )
        one_prop = one_proportion_sample_size(
            0.30, 0.20, 0.8, 0.05, "two-sided"
        )
        self.assertGreaterEqual(one_prop["achieved_power"], 0.8)
        two_prop = two_proportion_sample_size(
            0.30, 0.45, 0.8, 0.05, "two-sided"
        )
        self.assertGreaterEqual(two_prop["achieved_power"], 0.8)
        anova = one_way_anova_sample_size(4, 0.25, 0.8, 0.05)
        self.assertGreaterEqual(anova["achieved_power"], 0.8)
        self.assertLess(
            one_way_anova_power(
                4, anova["sample_size_per_group"] - 1, 0.25, 0.05
            )["power"],
            0.8,
        )

        detectable_results = (
            one_sample_mean_detectable_effect(50, 0.8, 0.05, "two-sided"),
            two_sample_mean_detectable_effect(
                40, 40, 0.8, 0.05, "two-sided"
            ),
            one_proportion_detectable_effect(
                100, 0.20, 0.8, 0.05, "two-sided"
            ),
            two_proportion_detectable_effect(
                100, 100, 0.30, 0.8, 0.05, "two-sided"
            ),
            one_way_anova_detectable_effect(4, 25, 0.8, 0.05),
        )
        for result in detectable_results:
            self.assertTrue(
                math.isclose(
                    result["achieved_power"], 0.8, rel_tol=1e-9, abs_tol=1e-9
                )
            )
            self.assertEqual(result["numerical_status"]["status"], "converged")
            self.assertLessEqual(
                abs(result["numerical_status"]["residual"]), 1e-8
            )

        for result in (mean, two_mean, one_prop, two_prop, anova):
            self.assertEqual(result["numerical_status"]["status"], "converged")
            self.assertGreater(
                result["numerical_status"]["function_evaluations"], 0
            )

    def test_power_special_function_endpoint_limits_are_validated(self) -> None:
        self.assertEqual(
            one_sample_mean_power(50, 2.0, 0.05, "two-sided")["power"],
            1.0,
        )
        self.assertTrue(
            math.isclose(
                one_way_anova_power(4, 25, 0.0, 0.05)["power"],
                0.05,
                rel_tol=1e-13,
            )
        )

    def test_invalid_power_requests_are_rejected(self) -> None:
        with self.assertRaises(PowerError):
            one_sample_mean_power(1, 0.5, 0.05, "two-sided")
        with self.assertRaises(PowerError):
            one_sample_mean_sample_size(0.0, 0.8, 0.05, "two-sided")
        with self.assertRaises(PowerError):
            one_proportion_power(100, 0.3, 1.0, 0.05, "two-sided")
        with self.assertRaises(PowerError):
            two_proportion_sample_size(0.3, 0.3, 0.8, 0.05, "two-sided")
        with self.assertRaises(PowerError):
            one_way_anova_power(1, 25, 0.25, 0.05)


class StatisticalTests(unittest.TestCase):
    def test_paired_t_test_matches_scipy(self) -> None:
        before = pd.Series([10.0, 12.0, 9.0, 14.0, np.nan, 11.0, 13.0])
        after = pd.Series([9.0, 11.0, 8.5, 12.0, 10.0, 10.5, 12.0])
        mask = before.notna() & after.notna()
        expected = scipy_stats.ttest_rel(before[mask], after[mask])
        actual = paired_t_test(
            before,
            after,
            "Before",
            "After",
            "two-sided",
            0.05,
        )
        self.assertEqual(actual["status"], "completed")
        self.assertEqual(actual["n_pairs"], 6)
        self.assertTrue(
            math.isclose(actual["statistic"], expected.statistic, rel_tol=1e-13)
        )
        self.assertTrue(
            math.isclose(actual["p_value"], expected.pvalue, rel_tol=1e-13)
        )

    def test_all_correlations_match_scipy(self) -> None:
        x = pd.Series([1.0, 2.0, 3.0, 4.0, np.nan, 6.0, 7.0, 8.0])
        y = pd.Series([2.0, 1.0, 4.0, 3.0, 5.0, 7.0, 6.0, 9.0])
        mask = x.notna() & y.notna()
        actual = correlation_tests(
            x,
            y,
            "X",
            "Y",
            ["pearson", "spearman", "kendall"],
            0.05,
        )
        expected = [
            scipy_stats.pearsonr(x[mask], y[mask]),
            scipy_stats.spearmanr(x[mask], y[mask]),
            scipy_stats.kendalltau(x[mask], y[mask]),
        ]
        self.assertEqual(actual["n_complete_pairs"], 7)
        for result, reference in zip(actual["tests"], expected):
            self.assertEqual(result["status"], "completed")
            self.assertTrue(
                math.isclose(
                    result["coefficient"], reference.statistic, rel_tol=1e-13
                )
            )
            self.assertTrue(
                math.isclose(result["p_value"], reference.pvalue, rel_tol=1e-13)
            )

    def test_simple_regression_matches_scipy(self) -> None:
        x = np.arange(1.0, 16.0)
        noise = np.array(
            [0.2, -0.1, 0.4, -0.5, 0.1, 0.0, 0.3, -0.2, 0.5, -0.3, 0.1, 0.2, -0.4, 0.0, 0.2]
        )
        y = 2.0 + 3.0 * x + noise
        reference = scipy_stats.linregress(x, y)
        actual = simple_linear_regression(
            pd.Series(y),
            pd.Series(x),
            "Y",
            "X",
            0.05,
        )
        self.assertEqual(actual["status"], "completed")
        intercept = actual["coefficients"][0]
        slope = actual["coefficients"][1]
        self.assertTrue(
            math.isclose(slope["estimate"], reference.slope, rel_tol=1e-13)
        )
        self.assertTrue(
            math.isclose(intercept["estimate"], reference.intercept, rel_tol=1e-13)
        )
        self.assertTrue(
            math.isclose(slope["standard_error"], reference.stderr, rel_tol=1e-12)
        )
        self.assertTrue(
            math.isclose(slope["p_value"], reference.pvalue, rel_tol=1e-10)
        )
        self.assertTrue(
            math.isclose(actual["r_squared"], reference.rvalue**2, rel_tol=1e-13)
        )


class NonparametricTests(unittest.TestCase):
    def test_mann_whitney_matches_scipy(self) -> None:
        first = pd.Series([1.0, 2.0, 2.0, 4.0, 5.0, 7.0, np.nan])
        second = pd.Series([3.0, 4.0, 4.0, 6.0, 8.0, 9.0])
        actual = mann_whitney_u_test(
            first, second, "First", "Second", "two-sided", 0.05
        )
        expected = scipy_stats.mannwhitneyu(
            first.dropna(), second, alternative="two-sided", method="auto"
        )
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(
            math.isclose(actual["statistic"], expected.statistic, rel_tol=1e-13)
        )
        self.assertTrue(
            math.isclose(actual["p_value"], expected.pvalue, rel_tol=1e-13)
        )
        expected_effect = 2.0 * expected.statistic / (6 * 6) - 1.0
        self.assertTrue(
            math.isclose(
                actual["rank_biserial_correlation"],
                expected_effect,
                rel_tol=1e-13,
            )
        )

    def test_wilcoxon_matches_scipy(self) -> None:
        before = pd.Series([10, 12, 14, 13, 15, 18, 17, 16, 20, 19], dtype=float)
        after = pd.Series([9, 13, 12, 14, 14, 16, 18, 13, 21, 17], dtype=float)
        differences = before - after
        actual = wilcoxon_signed_rank_test(
            before, after, "Before", "After", "two-sided", 0.05
        )
        expected = scipy_stats.wilcoxon(
            differences,
            zero_method="wilcox",
            alternative="two-sided",
            method="auto",
        )
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(
            math.isclose(actual["statistic"], expected.statistic, rel_tol=1e-13)
        )
        self.assertTrue(
            math.isclose(actual["p_value"], expected.pvalue, rel_tol=1e-13)
        )

    def test_kruskal_wallis_and_dunn_posthoc(self) -> None:
        groups = [
            pd.Series([1, 2, 2, 3, 4, 5], dtype=float),
            pd.Series([4, 5, 5, 6, 7, 8], dtype=float),
            pd.Series([7, 8, 8, 9, 10, 11], dtype=float),
        ]
        actual = kruskal_wallis_test(
            groups,
            ["Low", "Middle", "High"],
            0.05,
            run_posthoc=True,
            posthoc_adjustment="holm",
        )
        expected = scipy_stats.kruskal(*groups)
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(
            math.isclose(actual["statistic"], expected.statistic, rel_tol=1e-13)
        )
        self.assertTrue(
            math.isclose(actual["p_value"], expected.pvalue, rel_tol=1e-13)
        )
        self.assertEqual(len(actual["posthoc_comparisons"]), 3)
        raw = [item["raw_p_value"] for item in actual["posthoc_comparisons"]]
        adjusted = [
            item["adjusted_p_value"]
            for item in actual["posthoc_comparisons"]
        ]
        self.assertEqual(adjusted, adjust_p_values(raw, "holm"))
        self.assertTrue(
            all(adjusted_value >= raw_value for raw_value, adjusted_value in zip(raw, adjusted))
        )

    def test_p_value_adjustments(self) -> None:
        p_values = [0.01, 0.04, 0.03]
        self.assertEqual(adjust_p_values(p_values, "bonferroni"), [0.03, 0.12, 0.09])
        self.assertEqual(adjust_p_values(p_values, "holm"), [0.03, 0.06, 0.06])


class MultipleRegressionTests(unittest.TestCase):
    def _regression_frame(self) -> pd.DataFrame:
        x_1 = np.linspace(-3.0, 4.0, 80)
        x_2 = np.sin(np.arange(80) * 0.7) + (np.arange(80) % 5) * 0.15
        noise = np.cos(np.arange(80) * 1.3) * 0.18
        group = np.asarray(["A", "B", "C", "A"] * 20)
        group_effect = np.select(
            [group == "B", group == "C"], [2.5, -1.75], default=0.0
        )
        outcome = 4.0 + 1.8 * x_1 - 1.3 * x_2 + group_effect + noise
        return pd.DataFrame(
            {"Outcome": outcome, "X1": x_1, "X2": x_2, "Group": group}
        )

    def test_numeric_multiple_regression_matches_least_squares(self) -> None:
        frame = self._regression_frame()
        actual = multiple_linear_regression(
            frame, "Outcome", ["X1", "X2"], set(), 0.05, "Numeric model"
        )
        design = np.column_stack(
            [np.ones(len(frame)), frame["X1"], frame["X2"]]
        )
        expected = np.linalg.lstsq(design, frame["Outcome"], rcond=None)[0]
        estimates = np.asarray(
            [coefficient["estimate"] for coefficient in actual["coefficients"]]
        )
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(np.allclose(estimates, expected, rtol=1e-12, atol=1e-12))
        self.assertEqual(len(actual["variance_inflation_factors"]), 2)
        self.assertIn("breusch_pagan_test", actual)
        self.assertIn("influence_diagnostics", actual)

    def test_categorical_reference_coding_matches_least_squares(self) -> None:
        frame = self._regression_frame()
        actual = multiple_linear_regression(
            frame,
            "Outcome",
            ["X1", "X2", "Group"],
            {"Group"},
            0.05,
            "Categorical model",
        )
        group_b = (frame["Group"] == "B").astype(float)
        group_c = (frame["Group"] == "C").astype(float)
        design = np.column_stack(
            [np.ones(len(frame)), frame["X1"], frame["X2"], group_b, group_c]
        )
        expected = np.linalg.lstsq(design, frame["Outcome"], rcond=None)[0]
        estimates = np.asarray(
            [coefficient["estimate"] for coefficient in actual["coefficients"]]
        )
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(np.allclose(estimates, expected, rtol=1e-12, atol=1e-12))
        coding = actual["categorical_codings"][0]
        self.assertEqual(coding["reference_category"], "A")
        self.assertEqual(coding["dummy_terms"], ["Group[T.B]", "Group[T.C]"])

    def test_nested_model_comparison_partial_f(self) -> None:
        frame = self._regression_frame()
        frame.loc[0, "X2"] = np.nan
        actual = compare_regression_models(
            frame,
            "Outcome",
            ["X1"],
            ["X1", "X2", "Group"],
            {"Group"},
            0.05,
            "Reduced versus full",
        )
        partial = actual["partial_f_test"]
        reduced = actual["reduced_model"]
        full = actual["full_model"]
        numerator_df = full["parameter_count"] - reduced["parameter_count"]
        denominator_df = actual["n_common_cases"] - full["parameter_count"]
        expected_f = (
            (reduced["residual_sum_squares"] - full["residual_sum_squares"])
            / numerator_df
        ) / (full["residual_sum_squares"] / denominator_df)
        expected_p = scipy_stats.f.sf(expected_f, numerator_df, denominator_df)
        self.assertEqual(actual["status"], "completed")
        self.assertEqual(actual["n_common_cases"], len(frame) - 1)
        self.assertEqual(partial["status"], "completed")
        self.assertTrue(
            math.isclose(partial["statistic"], expected_f, rel_tol=1e-12)
        )
        self.assertTrue(
            math.isclose(partial["p_value"], expected_p, rel_tol=1e-12)
        )

    def test_polynomial_and_interaction_terms_match_least_squares(self) -> None:
        random = np.random.default_rng(5731)
        x_value = random.uniform(-2.0, 2.0, 120)
        group = np.where(np.arange(120) % 2, "B", "A")
        group_b = (group == "B").astype(float)
        outcome = (
            1.5
            + 0.8 * x_value
            - 0.4 * group_b
            + 0.6 * x_value**2
            + 1.1 * x_value * group_b
            + random.normal(0.0, 0.1, 120)
        )
        frame = pd.DataFrame(
            {"Outcome": outcome, "X": x_value, "Group": group}
        )
        actual = multiple_linear_regression(
            frame,
            "Outcome",
            ["X", "Group"],
            {"Group"},
            0.05,
            "Engineered model",
            {"X": 2},
            [("X", "Group")],
        )
        design = np.column_stack(
            [
                np.ones(120),
                x_value,
                group_b,
                x_value**2,
                x_value * group_b,
            ]
        )
        expected = np.linalg.lstsq(design, outcome, rcond=None)[0]
        estimates = np.asarray(
            [coefficient["estimate"] for coefficient in actual["coefficients"]]
        )
        self.assertEqual(actual["status"], "completed")
        self.assertEqual(
            actual["terms"],
            ["Intercept", "X", "Group[T.B]", "X^2", "X:Group[T.B]"],
        )
        self.assertTrue(np.allclose(estimates, expected, rtol=1e-12, atol=1e-12))


class LogisticRegressionTests(unittest.TestCase):
    def test_binary_logistic_matches_independent_optimization(self) -> None:
        random = np.random.default_rng(20260808)
        observation_count = 320
        x_1 = random.normal(size=observation_count)
        x_2 = random.normal(size=observation_count)
        probabilities = scipy_special.expit(-0.35 + 0.9 * x_1 - 0.7 * x_2)
        outcome = np.where(
            random.random(observation_count) < probabilities, "Yes", "No"
        )
        frame = pd.DataFrame({"Outcome": outcome, "X1": x_1, "X2": x_2})
        actual = binary_logistic_regression(
            frame,
            "Outcome",
            ["X1", "X2"],
            set(),
            "Yes",
            0.05,
            0.5,
            "Binary model",
        )
        response = (outcome == "Yes").astype(float)
        design = np.column_stack([np.ones(observation_count), x_1, x_2])

        def objective(estimates: np.ndarray) -> float:
            linear_predictor = design @ estimates
            return float(
                np.sum(
                    np.logaddexp(0.0, linear_predictor)
                    - response * linear_predictor
                )
            )

        expected = scipy_optimize.minimize(
            objective, np.zeros(3), method="BFGS", options={"gtol": 1e-9}
        ).x
        estimates = np.asarray(
            [coefficient["estimate"] for coefficient in actual["coefficients"]]
        )
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(np.allclose(estimates, expected, rtol=1e-6, atol=1e-6))
        self.assertGreater(actual["classification"]["roc_auc"], 0.70)
        self.assertEqual(actual["event_category"], "Yes")
        self.assertTrue(
            actual["information_matrix_diagnostics"]["positive_definite"]
        )
        self.assertEqual(
            actual["information_matrix_diagnostics"]["covariance_method"],
            "Cholesky linear solve",
        )
        self.assertEqual(actual["numerical_status"]["status"], "completed")
        self.assertTrue(actual["convergence"]["converged"])
        self.assertIn("not sandwich", actual["covariance_type"])

    def test_binary_logistic_categorical_reference_coding(self) -> None:
        random = np.random.default_rng(7654)
        observation_count = 300
        x_value = random.normal(size=observation_count)
        group = np.asarray(["A", "B", "C"] * 100)
        probability = scipy_special.expit(
            -0.2
            + 0.6 * x_value
            + 0.7 * (group == "B")
            - 0.5 * (group == "C")
        )
        outcome = np.where(
            random.random(observation_count) < probability, "Yes", "No"
        )
        frame = pd.DataFrame(
            {"Outcome": outcome, "X": x_value, "Group": group}
        )
        actual = binary_logistic_regression(
            frame,
            "Outcome",
            ["X", "Group"],
            {"Group"},
            "Yes",
            0.05,
        )
        self.assertEqual(actual["status"], "completed")
        self.assertEqual(
            actual["categorical_codings"][0]["reference_category"], "A"
        )
        self.assertEqual(
            actual["terms"], ["Intercept", "X", "Group[T.B]", "Group[T.C]"]
        )

    def test_multinomial_logistic_matches_independent_optimization(self) -> None:
        random = np.random.default_rng(86420)
        observation_count = 420
        x_1 = random.normal(size=observation_count)
        x_2 = random.normal(size=observation_count)
        medium_logit = 0.25 + 0.75 * x_1 - 0.35 * x_2
        high_logit = -0.45 - 0.25 * x_1 + 0.85 * x_2
        logits = np.column_stack(
            [np.zeros(observation_count), medium_logit, high_logit]
        )
        probabilities = scipy_special.softmax(logits, axis=1)
        outcome_index = np.asarray(
            [random.choice(3, p=row) for row in probabilities]
        )
        outcome = np.asarray(["Low", "Medium", "High"])[outcome_index]
        frame = pd.DataFrame({"Risk": outcome, "X1": x_1, "X2": x_2})
        actual = multinomial_logistic_regression(
            frame,
            "Risk",
            ["X1", "X2"],
            set(),
            "Low",
            0.05,
            "Multinomial model",
        )
        category_names = actual["outcome_categories"]
        actual_indices = np.asarray(
            [category_names.index(value) for value in outcome], dtype=int
        )
        design = np.column_stack([np.ones(observation_count), x_1, x_2])

        def objective(parameters: np.ndarray) -> float:
            matrix = parameters.reshape(2, 3)
            model_logits = np.column_stack(
                [np.zeros(observation_count), design @ matrix.T]
            )
            log_probabilities = model_logits - scipy_special.logsumexp(
                model_logits, axis=1
            )[:, None]
            return -float(
                np.sum(log_probabilities[np.arange(observation_count), actual_indices])
            )

        expected = scipy_optimize.minimize(
            objective, np.zeros(6), method="BFGS", options={"gtol": 1e-8}
        ).x
        estimates = np.asarray(
            [coefficient["estimate"] for coefficient in actual["coefficients"]]
        )
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(np.allclose(estimates, expected, rtol=1e-5, atol=1e-5))
        self.assertEqual(actual["reference_category"], "Low")
        self.assertEqual(len(actual["classification"]["confusion_matrix"]), 3)
        self.assertTrue(
            actual["information_matrix_diagnostics"]["positive_definite"]
        )
        self.assertEqual(actual["numerical_status"]["status"], "completed")
        self.assertTrue(actual["convergence"]["converged"])


class PoissonRegressionTests(unittest.TestCase):
    def test_exact_poisson_mean_interval_matches_chi_square_formula(self) -> None:
        actual = poisson_mean_confidence_interval(8, 0.05)
        expected_lower = 0.5 * scipy_stats.chi2.ppf(0.025, 16)
        expected_upper = 0.5 * scipy_stats.chi2.ppf(0.975, 18)
        self.assertEqual(actual["events"], 8)
        self.assertEqual(actual["mle_mean"], 8.0)
        self.assertTrue(
            math.isclose(
                actual["confidence_interval"][0],
                expected_lower,
                rel_tol=1e-14,
            )
        )
        self.assertTrue(
            math.isclose(
                actual["confidence_interval"][1],
                expected_upper,
                rel_tol=1e-14,
            )
        )

    def test_exact_poisson_mean_interval_handles_zero_events(self) -> None:
        actual = poisson_mean_confidence_interval(0, 0.05)
        self.assertEqual(actual["confidence_interval"][0], 0.0)
        self.assertTrue(
            math.isclose(
                actual["confidence_interval"][1],
                0.5 * scipy_stats.chi2.ppf(0.975, 2),
                rel_tol=1e-14,
            )
        )

    def test_poisson_with_engineered_terms_matches_independent_optimization(
        self,
    ) -> None:
        random = np.random.default_rng(24680)
        observation_count = 500
        x_value = random.normal(0.0, 0.8, observation_count)
        group = np.where(np.arange(observation_count) % 2, "B", "A")
        group_b = (group == "B").astype(float)
        design = np.column_stack(
            [
                np.ones(observation_count),
                x_value,
                group_b,
                x_value**2,
                x_value * group_b,
            ]
        )
        true_coefficients = np.asarray([0.5, 0.35, -0.25, 0.12, 0.3])
        counts = random.poisson(np.exp(design @ true_coefficients))
        frame = pd.DataFrame(
            {"Visits": counts, "X": x_value, "Group": group}
        )
        actual = poisson_regression(
            frame,
            "Visits",
            ["X", "Group"],
            {"Group"},
            0.05,
            "Count model",
            {"X": 2},
            [("X", "Group")],
        )

        def objective(estimates: np.ndarray) -> float:
            linear_predictor = design @ estimates
            return float(
                np.sum(
                    np.exp(linear_predictor)
                    - counts * linear_predictor
                    + scipy_special.gammaln(counts + 1.0)
                )
            )

        expected = scipy_optimize.minimize(
            objective, np.zeros(5), method="BFGS", options={"gtol": 1e-9}
        ).x
        estimates = np.asarray(
            [coefficient["estimate"] for coefficient in actual["coefficients"]]
        )
        self.assertEqual(actual["status"], "completed")
        self.assertEqual(
            actual["terms"],
            ["Intercept", "X", "Group[T.B]", "X^2", "X:Group[T.B]"],
        )
        self.assertTrue(np.allclose(estimates, expected, rtol=1e-6, atol=1e-6))
        self.assertTrue(
            math.isclose(
                actual["prediction_metrics"]["mean_observed_count"],
                actual["prediction_metrics"]["mean_fitted_count"],
                rel_tol=1e-9,
            )
        )
        self.assertGreater(actual["coefficients"][1]["incidence_rate_ratio"], 1.0)
        self.assertTrue(
            actual["information_matrix_diagnostics"]["positive_definite"]
        )
        self.assertEqual(actual["numerical_status"]["status"], "completed")
        self.assertTrue(actual["convergence"]["converged"])

    def test_poisson_exposure_and_log_offset_match_reference(self) -> None:
        random = np.random.default_rng(13579)
        observation_count = 350
        x_value = random.normal(size=observation_count)
        exposure = random.uniform(0.25, 3.5, observation_count)
        offset = np.log(exposure)
        counts = random.poisson(exposure * np.exp(0.25 + 0.55 * x_value))
        frame = pd.DataFrame(
            {
                "Counts": counts,
                "X": x_value,
                "Exposure": exposure,
                "LogExposure": offset,
            }
        )
        exposure_model = poisson_regression(
            frame,
            "Counts",
            ["X"],
            set(),
            0.05,
            exposure_name="Exposure",
        )
        offset_model = poisson_regression(
            frame,
            "Counts",
            ["X"],
            set(),
            0.05,
            offset_name="LogExposure",
        )
        design = np.column_stack([np.ones(observation_count), x_value])

        def objective(estimates: np.ndarray) -> float:
            linear_predictor = offset + design @ estimates
            return float(np.sum(np.exp(linear_predictor) - counts * linear_predictor))

        expected = scipy_optimize.minimize(
            objective, np.zeros(2), method="BFGS", options={"gtol": 1e-9}
        ).x
        exposure_estimates = np.asarray(
            [item["estimate"] for item in exposure_model["coefficients"]]
        )
        offset_estimates = np.asarray(
            [item["estimate"] for item in offset_model["coefficients"]]
        )
        self.assertEqual(exposure_model["status"], "completed")
        self.assertEqual(offset_model["status"], "completed")
        self.assertTrue(
            np.allclose(exposure_estimates, expected, rtol=1e-7, atol=1e-7)
        )
        self.assertTrue(
            np.allclose(exposure_estimates, offset_estimates, rtol=1e-12, atol=1e-12)
        )


class NegativeBinomialRegressionTests(unittest.TestCase):
    def test_nb2_with_exposure_matches_independent_optimization(self) -> None:
        random = np.random.default_rng(97531)
        observation_count = 600
        x_value = random.normal(size=observation_count)
        exposure = random.uniform(0.3, 3.0, observation_count)
        group = np.where(np.arange(observation_count) % 2, "B", "A")
        group_b = (group == "B").astype(float)
        design = np.column_stack(
            [np.ones(observation_count), x_value, group_b]
        )
        true_coefficients = np.asarray([0.2, 0.5, -0.3])
        true_dispersion = 0.75
        expected_mean = exposure * np.exp(design @ true_coefficients)
        size = 1.0 / true_dispersion
        latent_rate = random.gamma(size, expected_mean / size)
        counts = random.poisson(latent_rate)
        frame = pd.DataFrame(
            {
                "Counts": counts,
                "X": x_value,
                "Group": group,
                "Exposure": exposure,
            }
        )
        actual = negative_binomial_regression(
            frame,
            "Counts",
            ["X", "Group"],
            {"Group"},
            0.05,
            "NB2 model",
            exposure_name="Exposure",
        )
        offset = np.log(exposure)

        def objective(parameters: np.ndarray) -> float:
            coefficients = parameters[:3]
            dispersion = math.exp(parameters[3])
            reference_size = 1.0 / dispersion
            linear_predictor = offset + design @ coefficients
            mean = np.exp(linear_predictor)
            return -float(
                np.sum(
                    scipy_special.gammaln(counts + reference_size)
                    - scipy_special.gammaln(reference_size)
                    - scipy_special.gammaln(counts + 1.0)
                    + reference_size
                    * (
                        math.log(reference_size)
                        - np.log(reference_size + mean)
                    )
                    + counts
                    * (linear_predictor - np.log(reference_size + mean))
                )
            )

        expected = scipy_optimize.minimize(
            objective,
            np.asarray([0.0, 0.0, 0.0, math.log(0.5)]),
            method="BFGS",
            options={"gtol": 1e-8},
        ).x
        estimates = np.asarray(
            [item["estimate"] for item in actual["coefficients"]]
            + [math.log(actual["dispersion_parameter"])]
        )
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(np.allclose(estimates, expected, rtol=1e-5, atol=1e-5))
        self.assertEqual(actual["exposure_variable"], "Exposure")
        self.assertEqual(actual["poisson_comparison"]["status"], "completed")
        self.assertLess(
            actual["poisson_comparison"]["mixture_chi_square_p_value"], 0.05
        )
        self.assertTrue(
            actual["information_matrix_diagnostics"]["positive_definite"]
        )
        self.assertTrue(actual["numerical_hessian_diagnostics"]["step_stable"])
        self.assertGreater(actual["dispersion_standard_error"], 0.0)
        self.assertGreater(actual["negative_binomial_size_standard_error"], 0.0)
        self.assertEqual(actual["numerical_status"]["status"], "completed")
        self.assertTrue(actual["convergence"]["converged"])


class FactorialAndLongitudinalTests(unittest.TestCase):
    def test_balanced_factorial_emmeans_match_cell_means(self) -> None:
        random = np.random.default_rng(8181)
        rows = []
        for first in ("A", "B"):
            for second in ("Low", "Medium", "High"):
                for _ in range(12):
                    mean = (
                        10.0
                        + 2.0 * (first == "B")
                        + {"Low": 0.0, "Medium": 1.0, "High": 3.0}[second]
                        + 1.5 * (first == "B" and second == "High")
                    )
                    rows.append(
                        (mean + random.normal(0.0, 0.7), first, second)
                    )
        frame = pd.DataFrame(rows, columns=["Outcome", "First", "Second"])
        actual = factorial_anova_ancova(
            frame,
            "Outcome",
            "First",
            "Second",
            [],
            0.05,
            "holm",
            "Factorial model",
        )
        observed_means = frame.groupby(["First", "Second"])["Outcome"].mean()
        cell_means = actual["estimated_marginal_means"]["cell_marginal_means"]
        self.assertEqual(actual["status"], "completed")
        for cell in cell_means:
            expected = observed_means.loc[(cell["First"], cell["Second"])]
            self.assertTrue(
                math.isclose(cell["estimate"], expected, rel_tol=1e-12)
            )
        interaction = next(
            item
            for item in actual["type_iii_effect_tests"]
            if item["effect"] == "First:Second"
        )
        self.assertLess(interaction["p_value"], 0.05)
        self.assertEqual(
            actual["estimated_marginal_means"]["pairwise_adjustment"],
            "holm",
        )

    def test_repeated_measures_matches_manual_anova(self) -> None:
        matrix = np.asarray(
            [
                [10.0, 12.0, 14.0],
                [8.0, 11.0, 13.0],
                [12.0, 13.0, 16.0],
                [9.0, 12.0, 15.0],
                [11.0, 12.5, 15.5],
            ]
        )
        rows = [
            (subject + 1, time, matrix[subject, time_index])
            for subject in range(matrix.shape[0])
            for time_index, time in enumerate(("T1", "T2", "T3"))
        ]
        frame = pd.DataFrame(rows, columns=["Subject", "Time", "Outcome"])
        actual = repeated_measures_anova(
            frame, "Subject", "Outcome", "Time", 0.05
        )
        grand = float(np.mean(matrix))
        total_ss = float(np.sum((matrix - grand) ** 2))
        subject_ss = matrix.shape[1] * float(
            np.sum((np.mean(matrix, axis=1) - grand) ** 2)
        )
        condition_ss = matrix.shape[0] * float(
            np.sum((np.mean(matrix, axis=0) - grand) ** 2)
        )
        error_ss = total_ss - subject_ss - condition_ss
        expected_f = (condition_ss / 2.0) / (error_ss / 8.0)
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(
            math.isclose(actual["f_statistic"], expected_f, rel_tol=1e-12)
        )
        self.assertEqual(len(actual["pairwise_comparisons"]), 3)

    def test_random_intercept_ml_matches_dense_reference(self) -> None:
        random = np.random.default_rng(9191)
        group_count = 14
        observations_per_group = 5
        groups = np.repeat(np.arange(group_count), observations_per_group)
        x_value = random.normal(size=groups.size)
        random_intercepts = random.normal(0.0, 1.1, group_count)
        outcome = (
            1.8
            + 0.65 * x_value
            + random_intercepts[groups]
            + random.normal(0.0, 0.6, groups.size)
        )
        frame = pd.DataFrame(
            {"Outcome": outcome, "Group": groups, "X": x_value}
        )
        actual = random_intercept_mixed_model(
            frame,
            "Outcome",
            "Group",
            ["X"],
            set(),
            0.05,
            "ml",
            "Mixed model",
        )
        design = np.column_stack([np.ones(groups.size), x_value])
        same_group = (groups[:, None] == groups[None, :]).astype(float)

        def objective(log_variances: np.ndarray) -> float:
            residual_variance, random_variance = np.exp(log_variances)
            covariance = (
                residual_variance * np.eye(groups.size)
                + random_variance * same_group
            )
            sign, log_determinant = np.linalg.slogdet(covariance)
            self.assertGreater(sign, 0)
            inverse = np.linalg.inv(covariance)
            beta = np.linalg.solve(
                design.T @ inverse @ design,
                design.T @ inverse @ outcome,
            )
            residuals = outcome - design @ beta
            return 0.5 * (
                groups.size * math.log(2.0 * math.pi)
                + log_determinant
                + residuals @ inverse @ residuals
            )

        expected_optimization = scipy_optimize.minimize(
            objective,
            np.log([0.5, 1.0]),
            method="BFGS",
            options={"gtol": 1e-8},
        )
        expected_variances = np.exp(expected_optimization.x)
        covariance = (
            expected_variances[0] * np.eye(groups.size)
            + expected_variances[1] * same_group
        )
        inverse = np.linalg.inv(covariance)
        expected_beta = np.linalg.solve(
            design.T @ inverse @ design,
            design.T @ inverse @ outcome,
        )
        actual_beta = np.asarray(
            [item["estimate"] for item in actual["coefficients"]]
        )
        components = actual["variance_components"]
        actual_variances = np.asarray(
            [
                components["residual_variance"],
                components["random_intercept_variance"],
            ]
        )
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(
            np.allclose(actual_beta, expected_beta, rtol=1e-5, atol=1e-5)
        )
        self.assertTrue(
            np.allclose(
                actual_variances,
                expected_variances,
                rtol=1e-4,
                atol=1e-4,
            )
        )
        self.assertTrue(
            actual["fixed_effect_information_diagnostics"]["positive_definite"]
        )
        self.assertEqual(
            actual["variance_component_inference"]["status"], "completed"
        )
        self.assertEqual(actual["numerical_status"]["status"], "completed")
        self.assertTrue(actual["convergence"]["converged"])

    def test_random_intercept_boundary_suppresses_wald_interval(self) -> None:
        random = np.random.default_rng(123)
        groups = np.repeat(np.arange(20), 8)
        x_value = random.normal(size=groups.size)
        outcome = 2.0 + 0.7 * x_value + random.normal(size=groups.size)
        actual = random_intercept_mixed_model(
            pd.DataFrame(
                {"Outcome": outcome, "Group": groups, "X": x_value}
            ),
            "Outcome",
            "Group",
            ["X"],
            set(),
            0.05,
            "ml",
        )
        self.assertEqual(actual["status"], "completed")
        self.assertEqual(
            actual["variance_component_inference"]["status"], "boundary"
        )
        self.assertNotIn(
            "random_intercept_variance_confidence_interval",
            actual["variance_component_inference"],
        )
        self.assertEqual(
            actual["random_intercept_likelihood_ratio_test"]["status"],
            "completed",
        )


class ResamplingTests(unittest.TestCase):
    def test_percentile_bootstrap_matches_seeded_reference_draws(self) -> None:
        values = np.asarray([1.0, 2.0, 3.0, 5.0, 8.0, 13.0])
        resamples = 500
        seed = 31415
        actual = bootstrap_one_sample(
            pd.Series(values),
            "Values",
            "mean",
            resamples,
            0.05,
            "percentile",
            seed,
        )
        generator = np.random.default_rng(seed)
        indices = generator.integers(
            0, values.size, size=(resamples, values.size)
        )
        estimates = np.mean(values[indices], axis=1)
        expected_interval = np.quantile(estimates, [0.025, 0.975])
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(
            np.allclose(actual["confidence_interval"], expected_interval)
        )
        self.assertTrue(
            math.isclose(
                actual["bootstrap_standard_error"],
                float(np.std(estimates, ddof=1)),
                rel_tol=1e-12,
            )
        )

    def test_bca_difference_is_reproducible(self) -> None:
        first = pd.Series([4.0, 5.0, 7.0, 9.0, 12.0, 14.0])
        second = pd.Series([1.0, 2.0, 3.0, 5.0, 6.0, 7.0])
        first_result = bootstrap_independent_difference(
            first, second, "First", "Second", "median", 1000, 0.05, "bca", 99
        )
        second_result = bootstrap_independent_difference(
            first, second, "First", "Second", "median", 1000, 0.05, "bca", 99
        )
        self.assertEqual(first_result["status"], "completed")
        self.assertEqual(first_result["confidence_interval"], second_result["confidence_interval"])
        self.assertEqual(first_result["interval_method_used"], "bca")
        self.assertTrue(
            first_result["confidence_interval"][0]
            <= first_result["observed_difference"]
            <= first_result["confidence_interval"][1]
        )

    def test_exact_two_sample_and_paired_permutation_tests(self) -> None:
        first = pd.Series([1.0, 2.0, 3.0])
        second = pd.Series([4.0, 5.0, 6.0])
        independent = permutation_two_sample(
            first, second, "First", "Second", "mean", 100, "two-sided", 0.05, 7
        )
        self.assertEqual(independent["enumeration"], "exact")
        self.assertEqual(independent["possible_permutations"], 20)
        self.assertTrue(math.isclose(independent["p_value"], 0.1))

        paired = permutation_paired(
            pd.Series([1.0, 2.0, 3.0, 4.0]),
            pd.Series([0.0, 0.0, 0.0, 0.0]),
            "After",
            "Before",
            "mean",
            100,
            "two-sided",
            0.05,
            8,
        )
        self.assertEqual(paired["enumeration"], "exact")
        self.assertEqual(paired["possible_permutations"], 16)
        self.assertTrue(math.isclose(paired["p_value"], 0.125))

    def test_exact_correlation_permutation_matches_exhaustive_reference(self) -> None:
        first = np.asarray([1.0, 2.0, 3.0, 4.0, 5.0])
        second = np.asarray([2.0, 1.0, 4.0, 5.0, 3.0])
        actual = permutation_correlation(
            pd.Series(first),
            pd.Series(second),
            "First",
            "Second",
            "pearson",
            200,
            "two-sided",
            0.05,
            11,
        )
        observed = float(np.corrcoef(first, second)[0, 1])
        exhaustive = np.asarray(
            [
                np.corrcoef(first, second[list(order)])[0, 1]
                for order in __import__("itertools").permutations(range(5))
            ]
        )
        expected = float(
            np.mean(np.abs(exhaustive) >= abs(observed) - 1e-12)
        )
        self.assertEqual(actual["enumeration"], "exact")
        self.assertEqual(actual["possible_permutations"], 120)
        self.assertTrue(math.isclose(actual["p_value"], expected, rel_tol=1e-12))


class DiscreteEstimationTests(unittest.TestCase):
    def test_binomial_estimation_reports_wald_score_exact_and_lr(self) -> None:
        result = binomial_estimation(
            [3, 4, 5], [10, 10, 10], "Successes", 0.05, "two-sided", 0.3
        )
        self.assertTrue(math.isclose(result["mle_probability"], 0.4))
        self.assertEqual(result["total_successes"], 12)
        self.assertEqual(result["total_trials"], 30)
        self.assertEqual(
            [test["method"] for test in result["tests"]],
            [
                "Wald z-test",
                "score z-test",
                "exact binomial test",
                "likelihood-ratio test",
            ],
        )
        self.assertLess(
            result["exact_clopper_pearson_interval"][0],
            result["mle_probability"],
        )

        boundary = binomial_estimation(
            [1], [2], "Successes", 0.05, "two-sided", 0.0
        )
        self.assertEqual(boundary["tests"][0]["status"], "not_run")
        self.assertEqual(boundary["tests"][1]["status"], "not_run")
        self.assertEqual(boundary["tests"][2]["p_value"], 0.0)
        self.assertIsNone(boundary["tests"][3]["p_value"])

    def test_geometric_and_known_r_negative_binomial_estimators(self) -> None:
        geometric = geometric_estimation(
            [1, 2, 3, 4], "Wait", 0.05, "two-sided", 0.3
        )
        self.assertTrue(math.isclose(geometric["mle_probability"], 0.4))
        self.assertEqual(geometric["total_failures"], 6)
        self.assertEqual(len(geometric["tests"]), 4)

        negative_binomial = negative_binomial_known_r_estimation(
            [2, 5, 1, 4], "Failures", 3, 0.05, "two-sided", 0.4
        )
        self.assertTrue(
            math.isclose(negative_binomial["mle_probability"], 0.5)
        )
        self.assertEqual(negative_binomial["total_successes"], 12)
        self.assertEqual(negative_binomial["total_failures"], 12)

    def test_joint_negative_binomial_estimation_and_poisson_boundary(self) -> None:
        fitted = negative_binomial_joint_estimation(
            [0, 1, 0, 8, 2, 10, 0, 5], "Counts", 0.05
        )
        self.assertEqual(fitted["status"], "completed")
        self.assertGreater(fitted["mle_size"], 0.0)
        self.assertGreater(fitted["mle_probability"], 0.0)
        self.assertLess(fitted["mle_probability"], 1.0)
        self.assertTrue(
            fitted["information_matrix_diagnostics"]["positive_definite"]
        )
        self.assertEqual(
            set(fitted["transformed_parameter_standard_errors"]),
            {"mean", "size", "probability", "dispersion"},
        )
        self.assertEqual(fitted["numerical_status"]["status"], "completed")
        self.assertTrue(fitted["convergence"]["converged"])
        self.assertEqual(
            fitted["size_profile_likelihood_convergence"]["lower"]["status"],
            "converged",
        )
        self.assertEqual(
            fitted["size_profile_likelihood_convergence"]["upper"]["status"],
            "converged",
        )

        boundary = negative_binomial_joint_estimation(
            [2, 2, 2, 2], "Counts", 0.05
        )
        self.assertEqual(boundary["status"], "poisson_boundary")
        self.assertIsNone(boundary["mle_size"])

    def test_poisson_estimation_reports_wald_score_exact_lr_and_garwood(self) -> None:
        result = poisson_estimation(
            [2, 3, 4, 5], "Events", 0.05, "two-sided", 3.0
        )
        self.assertTrue(math.isclose(result["mle_mean"], 3.5))
        self.assertEqual(result["total_events"], 14)
        self.assertEqual(len(result["tests"]), 5)
        self.assertEqual(result["tests"][0]["method"], "index-of-dispersion test")
        lower, upper = result["exact_garwood_confidence_interval"]
        self.assertLess(lower, 3.5)
        self.assertGreater(upper, 3.5)

    def test_discrete_uniform_and_hypergeometric_use_integer_inference(self) -> None:
        uniform = discrete_uniform_estimation(
            [1, 2, 4, 3], "Uniform", 0.05, 6
        )
        self.assertEqual(uniform["mle_maximum"], 4)
        self.assertEqual(uniform["exact_one_sided_confidence_set"], [4, 8])
        self.assertIn("integer", uniform["warnings"][0])

        hypergeometric = hypergeometric_estimation(
            [2], "Successes", 100, 10, 0.05, 20
        )
        self.assertIn(20, hypergeometric["mle_population_successes"])
        self.assertEqual(
            hypergeometric["confidence_set_method"],
            "exact likelihood-ratio inversion",
        )
        self.assertEqual(len(hypergeometric["tests"]), 1)

    def test_beta_binomial_estimation_and_multinomial_intervals(self) -> None:
        beta_binomial = beta_binomial_estimation(
            [1, 3, 8, 12, 18, 2, 15, 7],
            [20] * 8,
            "GroupedSuccesses",
            0.05,
            "fixed trials = 20",
        )
        self.assertEqual(beta_binomial["status"], "completed")
        self.assertGreater(beta_binomial["mle_alpha"], 0.0)
        self.assertGreater(beta_binomial["mle_beta"], 0.0)
        self.assertTrue(
            0.0 < beta_binomial["mle_mean_probability"] < 1.0
        )
        self.assertTrue(
            beta_binomial["information_matrix_diagnostics"]["positive_definite"]
        )
        self.assertEqual(
            len(beta_binomial["transformed_parameter_standard_errors"]), 5
        )

        multinomial = multinomial_estimation(
            pd.Series(["A", "B", "A", "C", "A"]), "Category", 0.05
        )
        self.assertEqual(multinomial["categories"], 3)
        estimates = {
            item["category"]: item for item in multinomial["category_estimates"]
        }
        self.assertTrue(math.isclose(estimates["A"]["mle_probability"], 0.6))
        self.assertEqual(len(multinomial["covariance_matrix"]), 3)
        self.assertEqual(
            len(multinomial["multinomial_count_covariance_matrix"]), 3
        )


class AdvancedRegressionTests(unittest.TestCase):
    def setUp(self) -> None:
        generator = np.random.default_rng(8241)
        x = np.linspace(-3.0, 3.0, 60)
        z = generator.normal(size=x.size)
        y = 4.0 + 1.8 * x - 0.7 * z + generator.normal(scale=0.35, size=x.size)
        self.frame = pd.DataFrame({"Y": y, "X": x, "Z": z})

    def test_robust_regression_downweights_outlier_and_reports_covariance(self) -> None:
        contaminated = self.frame.copy()
        contaminated.loc[20, "Y"] += 35.0
        result = robust_linear_regression(
            contaminated, "Y", ["X", "Z"], 0.0345159
        )
        self.assertIn(result["status"], {"completed", "completed_with_warnings"})
        self.assertTrue(result["converged"])
        self.assertGreaterEqual(result["downweighted_case_count"], 1)
        self.assertTrue(result["numerical_status"]["covariance_available"])
        slope = next(row for row in result["coefficients"] if row["term"] == "X")
        self.assertTrue(math.isclose(slope["estimate"], 1.8, rel_tol=0.12))
        self.assertLess(slope["confidence_interval"][0], slope["estimate"])
        self.assertGreater(slope["confidence_interval"][1], slope["estimate"])

    def test_regularized_methods_and_cross_validation(self) -> None:
        for penalty in ("ridge", "lasso", "elastic-net"):
            result = regularized_linear_regression(
                self.frame,
                "Y",
                ["X", "Z"],
                penalty,
                None,
                0.5,
                5,
                12345,
            )
            self.assertIn(
                result["status"], {"completed", "completed_with_warnings"}
            )
            self.assertGreater(result["penalty_strength"], 0.0)
            self.assertEqual(result["cross_validation"]["status"], "completed")
            self.assertEqual(len(result["cross_validation"]["candidates"]), 41)
            self.assertFalse(result["numerical_status"]["inference_available"])
            self.assertEqual(len(result["prediction_rows"]), len(self.frame))

    def test_splines_loess_kernel_and_isotonic(self) -> None:
        y = self.frame["Y"]
        x = self.frame["X"]
        results = [
            regression_spline(y, x, "Y", "X", 0.05, 4),
            smoothing_spline(y, x, "Y", "X", 0.05, 7, None),
            loess_regression(y, x, "Y", "X", 0.65, 1, 2),
            kernel_regression(y, x, "Y", "X", None),
            isotonic_regression(y, x, "Y", "X", "increasing"),
        ]
        for result in results:
            self.assertIn(
                result["status"], {"completed", "completed_with_warnings"}
            )
            self.assertTrue(math.isfinite(result["root_mean_squared_error"]))
            self.assertEqual(len(result["prediction_rows"]), len(self.frame))
            self.assertIn("numerical_status", result)
        spline = results[0]
        self.assertEqual(len(spline["interior_knots"]), 4)
        self.assertIn("mean_ci_lower", spline["prediction_rows"][0])
        smoother = results[1]
        self.assertEqual(
            smoother["smoothing_parameter_selection"],
            "generalized cross-validation",
        )
        isotonic = results[-1]
        fitted = np.asarray([row["predicted"] for row in isotonic["prediction_rows"]])
        self.assertTrue(np.all(np.diff(fitted) >= -1.0e-12))

    def test_kde_bandwidth_and_density_validation(self) -> None:
        result = kernel_density_estimation(self.frame["Y"], "Y", "cv", 250)
        self.assertIn(result["status"], {"completed", "completed_with_warnings"})
        self.assertGreater(result["bandwidth"], 0.0)
        self.assertEqual(len(result["bandwidth_search"]), 31)
        self.assertEqual(len(result["density_grid"]), 250)
        validation = result["density_validation"]
        self.assertTrue(validation["all_grid_values_finite"])
        self.assertTrue(validation["all_grid_densities_nonnegative"])
        self.assertTrue(
            math.isclose(
                validation["trapezoidal_integral_over_reported_grid"],
                1.0,
                abs_tol=2.0e-3,
            )
        )

    def test_singular_and_constant_inputs_return_explicit_failure(self) -> None:
        singular = self.frame.assign(X_copy=self.frame["X"])
        robust = robust_linear_regression(
            singular, "Y", ["X", "X_copy"], 0.05
        )
        self.assertEqual(robust["status"], "not_run")
        self.assertIn("singular", robust["reason"])
        self.assertEqual(robust["numerical_status"]["status"], "failed")
        density = kernel_density_estimation(
            pd.Series(np.ones(12)), "constant", "scott", 100
        )
        self.assertEqual(density["status"], "not_run")
        self.assertIn("nonconstant", density["reason"])

    def test_combined_advanced_cli_json_and_prediction_export(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            data_path = directory / "advanced.csv"
            json_path = directory / "advanced.json"
            prediction_path = directory / "predictions.csv"
            self.frame.to_csv(data_path, index=False)
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    str(data_path),
                    "--robust-regression",
                    "Y",
                    "X",
                    "Z",
                    "--regularized-regression",
                    "elastic-net",
                    "Y",
                    "X",
                    "Z",
                    "--smoothing-spline",
                    "Y",
                    "X",
                    "--loess",
                    "Y",
                    "X",
                    "--kernel-regression",
                    "Y",
                    "X",
                    "--isotonic-regression",
                    "Y",
                    "X",
                    "--kernel-density",
                    "Y",
                    "--kde-grid-size",
                    "100",
                    "--save-predictions",
                    str(prediction_path),
                    "--json",
                    str(json_path),
                    "--no-normality",
                ],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertIn("ROBUST LINEAR REGRESSION", completed.stdout)
            self.assertIn("KERNEL-DENSITY ESTIMATION", completed.stdout)
            self.assertEqual(len(result["robust_regression_analyses"]), 1)
            self.assertEqual(len(result["regularized_regression_analyses"]), 1)
            self.assertEqual(len(result["smoothing_spline_analyses"]), 1)
            self.assertEqual(len(result["kernel_density_analyses"]), 1)
            exported = pd.read_csv(prediction_path)
            self.assertEqual(len(exported), 6 * len(self.frame))


class DataAndCliTests(unittest.TestCase):
    def _write_test_csv(self, directory: Path) -> Path:
        path = directory / "test_data.csv"
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(
                [
                    "Before",
                    "After",
                    "X",
                    "Y",
                    "Category",
                    "Purchased",
                    "Risk",
                ]
            )
            for index in range(1, 21):
                writer.writerow(
                    [
                        10.0 + index,
                        9.0 + index + (index % 3) * 0.2,
                        index,
                        5.0 + 2.5 * index + (index % 4) * 0.1,
                        "A" if index % 2 else "B",
                        "No" if index % 3 == 0 else "Yes",
                        ("Low", "Medium", "High")[index % 3],
                    ]
                )
        return path

    def test_loader_preserves_categorical_columns(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = self._write_test_csv(Path(temporary))
            with mock.patch(
                "statclass.data.available_memory_bytes",
                return_value=1024**3,
            ):
                dataset = load_dataset(path)
            self.assertIn("Category", dataset.raw.columns)
            self.assertNotIn("Category", dataset.numeric.columns)
            self.assertEqual(len(dataset.numeric_names), 4)
            resource = dataset.input_resource_preflight
            self.assertEqual(resource["status"], "within_available_memory")
            self.assertGreater(resource["estimated_rows"], 0)
            self.assertEqual(resource["estimated_columns"], 7)
            self.assertGreater(
                resource["estimated_peak_load_memory_bytes"],
                resource["file_size_bytes"],
            )

    def test_loader_resource_preflight_stops_before_pandas_parse(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = self._write_test_csv(Path(temporary))
            with (
                mock.patch(
                    "statclass.data.available_memory_bytes",
                    return_value=1,
                ),
                mock.patch("statclass.data.pd.read_csv") as read_csv,
                self.assertRaisesRegex(
                    DataError,
                    "stopped before input inspection.*No data rows were read, "
                    "parsed, truncated, or silently discarded",
                ),
            ):
                load_dataset(path)
            read_csv.assert_not_called()

    def test_loader_detailed_preflight_stops_before_pandas_parse(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = self._write_test_csv(Path(temporary))
            with (
                mock.patch(
                    "statclass.data.available_memory_bytes",
                    side_effect=(1024**3, 1),
                ),
                mock.patch("statclass.data.pd.read_csv") as read_csv,
                self.assertRaisesRegex(
                    DataError,
                    "stopped before table parsing.*No data rows were loaded, "
                    "truncated, or silently discarded",
                ),
            ):
                load_dataset(path)
            read_csv.assert_not_called()

    def test_loader_reports_unexpected_memory_exhaustion_explicitly(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = self._write_test_csv(Path(temporary))
            with (
                mock.patch(
                    "statclass.data.available_memory_bytes",
                    return_value=None,
                ),
                mock.patch(
                    "statclass.data.pd.read_csv",
                    side_effect=MemoryError,
                ),
                self.assertRaisesRegex(
                    DataError,
                    "exhausted available memory despite the preflight estimate",
                ),
            ):
                load_dataset(path)

    def test_loader_reports_operating_system_memory_exhaustion(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = self._write_test_csv(Path(temporary))
            with (
                mock.patch(
                    "statclass.data.available_memory_bytes",
                    return_value=None,
                ),
                mock.patch(
                    "statclass.data.pd.read_csv",
                    side_effect=OSError(errno.ENOMEM, "Cannot allocate memory"),
                ),
                self.assertRaisesRegex(
                    DataError,
                    "operating system reported insufficient memory during input parsing",
                ),
            ):
                load_dataset(path)

    def test_cli_reports_input_resource_preflight(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            path = self._write_test_csv(directory)
            json_path = directory / "result.json"
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    str(path),
                    "--no-normality",
                    "--json",
                    str(json_path),
                ],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            self.assertIn("Input resource preflight:", completed.stdout)
            self.assertIn("estimated peak load memory", completed.stdout)
            metadata = json.loads(json_path.read_text(encoding="utf-8"))["metadata"]
            resource = metadata["input_resource_preflight"]
            self.assertIn(
                resource["status"],
                {"within_available_memory", "available_memory_unknown"},
            )
            self.assertGreater(resource["required_available_memory_bytes"], 0)

    def test_dependency_commands_do_not_require_input_file(self) -> None:
        for option in ("--dependencies", "--requirements"):
            completed = subprocess.run(
                [sys.executable, str(PROJECT_ROOT / "stats.py"), option],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            self.assertIn("statclass=3.17.0", completed.stdout)
            self.assertIn(f"python={sys.version_info.major}.", completed.stdout)
            self.assertIn(f"numpy={np.__version__}", completed.stdout)
            self.assertIn(f"pandas={pd.__version__}", completed.stdout)
            self.assertRegex(completed.stdout, r"(?m)^scipy=\S+$")
            self.assertRegex(completed.stdout, r"(?m)^matplotlib=\S+$")

    def test_distribution_catalog_does_not_require_input_file(self) -> None:
        completed = subprocess.run(
            [sys.executable, str(PROJECT_ROOT / "stats.py"), "--distributions"],
            cwd=PROJECT_ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        self.assertIn("StatClass supported distributions", completed.stdout)
        self.assertIn("Discrete:", completed.stdout)
        self.assertIn("Continuous:", completed.stdout)
        for name in SUPPORTED_DISTRIBUTIONS:
            self.assertRegex(completed.stdout, rf"(?m)^  {name}: ")

    def test_combined_discrete_estimation_cli(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            data_path = directory / "discrete.csv"
            json_path = directory / "discrete.json"
            rows = {
                "Bernoulli": ["Yes", "No"] * 6,
                "Binomial": [2, 3, 4, 5, 6, 7, 3, 4, 5, 6, 2, 8],
                "Geometric": [1, 2, 3, 1, 4, 2, 5, 1, 3, 2, 4, 1],
                "Poisson": [2, 3, 4, 2, 5, 3, 1, 4, 3, 2, 6, 1],
                "NegBin": [0, 0, 1, 2, 0, 8, 12, 3, 0, 5, 10, 1],
                "Uniform": [1, 4, 7, 2, 6, 5, 3, 7, 4, 6, 2, 5],
                "Hyper": [1, 2, 3, 2, 4, 1, 3, 2, 2, 3, 1, 4],
                "BetaBin": [0, 1, 2, 4, 8, 12, 16, 18, 19, 20, 3, 15],
                "Trials": [20] * 12,
                "Category": ["A", "B", "A", "C"] * 3,
            }
            pd.DataFrame(rows).to_csv(data_path, index=False)
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    str(data_path),
                    "--estimate-bernoulli",
                    "Bernoulli",
                    "Yes",
                    ".4",
                    "--estimate-binomial",
                    "Binomial",
                    "10",
                    ".4",
                    "--estimate-geometric",
                    "Geometric",
                    ".4",
                    "--estimate-poisson",
                    "Poisson",
                    "3",
                    "--estimate-negative-binomial",
                    "NegBin",
                    "3",
                    ".5",
                    "--estimate-negative-binomial",
                    "NegBin",
                    "auto",
                    "--estimate-discrete-uniform",
                    "Uniform",
                    "10",
                    "--estimate-hypergeometric",
                    "Hyper",
                    "100",
                    "10",
                    "30",
                    "--estimate-beta-binomial",
                    "BetaBin",
                    "Trials",
                    "--estimate-multinomial",
                    "Category",
                    "--no-normality",
                    "--json",
                    str(json_path),
                ],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            estimates = result["discrete_distribution_estimates"]
            self.assertEqual(len(estimates), 10)
            self.assertEqual(
                {estimate["distribution"] for estimate in estimates},
                {
                    "bernoulli",
                    "binomial",
                    "geometric",
                    "poisson",
                    "negative-binomial-known-r",
                    "negative-binomial",
                    "discrete-uniform",
                    "hypergeometric",
                    "beta-binomial",
                    "multinomial",
                },
            )
            self.assertIn("DISCRETE DISTRIBUTION ESTIMATION", completed.stdout)
            self.assertIn("Wald z-test", completed.stdout)
            self.assertIn("Exact Garwood CI", completed.stdout)
            self.assertIn("Information matrix diagnostics", completed.stdout)
            self.assertIn("ordinary Wald inference is not used", completed.stdout)
            joint_nb = next(
                item
                for item in estimates
                if item["distribution"] == "negative-binomial"
            )
            self.assertTrue(
                joint_nb["information_matrix_diagnostics"]["positive_definite"]
            )

    def test_summary_discrete_estimation_cli_requires_no_input_file(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "summary_discrete.json"
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    "--estimate-binomial-summary",
                    "37",
                    "100",
                    ".4",
                    "--estimate-geometric-summary",
                    "20",
                    "73",
                    ".25",
                    "--estimate-poisson-summary",
                    "25",
                    "119",
                    "5",
                    "--estimate-negative-binomial-summary",
                    "20",
                    "93",
                    "2",
                    ".3",
                    "--estimate-discrete-uniform-summary",
                    "30",
                    "17",
                    "20",
                    "--estimate-hypergeometric-count",
                    "7",
                    "100",
                    "20",
                    "30",
                    "--estimate-multinomial-counts",
                    "red=12",
                    "blue=9",
                    "green=4",
                    "--alpha",
                    ".0345159",
                    "--json",
                    str(json_path),
                ],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            estimates = result["discrete_distribution_estimates"]
            self.assertEqual(len(estimates), 7)
            self.assertEqual(result["metadata"]["analysis_source"], "summary_data")
            self.assertTrue(
                math.isclose(estimates[0]["confidence_level"], 0.9654841)
            )
            self.assertEqual(estimates[-1]["observations"], 25)
            self.assertIn("Expected Fisher information at MLE", completed.stdout)

    def test_discrete_estimation_cli_rejects_invalid_requests(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            data_path = Path(temporary) / "invalid_discrete.csv"
            pd.DataFrame(
                {
                    "Count": [0, 1, 2],
                    "Wait": [1, 0, 2],
                    "Successes": [2, 3, 4],
                }
            ).to_csv(data_path, index=False)
            invalid_commands = (
                (["--estimate-geometric", "Wait"], "integers of at least 1"),
                (
                    ["--estimate-binomial", "Successes", "2"],
                    "0 <= successes <= trials",
                ),
                (
                    ["--estimate-negative-binomial", "Count", "auto", ".5"],
                    "does not use P0",
                ),
                (
                    ["--estimate-hypergeometric", "Count", "10", "11"],
                    "1 <= DRAWS <= POPULATION_SIZE",
                ),
            )
            for arguments, expected_error in invalid_commands:
                completed = subprocess.run(
                    [
                        sys.executable,
                        str(PROJECT_ROOT / "stats.py"),
                        str(data_path),
                        *arguments,
                    ],
                    cwd=PROJECT_ROOT,
                    capture_output=True,
                    text=True,
                )
                self.assertEqual(completed.returncode, 2)
                self.assertIn(expected_error, completed.stderr)

    def test_arbitrary_alpha_and_output_precision(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "alpha.json"
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    "--mean-ci",
                    "25",
                    "72.4",
                    "11.8",
                    "--alpha",
                    "0.0345159",
                    "--precision",
                    "4",
                    "--json",
                    str(json_path),
                ],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertIn("96.5484% CI for mean", completed.stdout)
            self.assertIn("Critical value = 2.2414", completed.stdout)
            self.assertEqual(result["metadata"]["alpha"], 0.0345159)
            self.assertEqual(result["metadata"]["output_precision"], 4)
            interval = result["mean_confidence_intervals"][0]
            self.assertEqual(interval["confidence_level"], 1.0 - 0.0345159)
            self.assertGreater(
                len(str(interval["confidence_interval"][0]).split(".")[1]),
                4,
            )

    def test_alpha_accepts_scientific_notation(self) -> None:
        completed = subprocess.run(
            [
                sys.executable,
                str(PROJECT_ROOT / "stats.py"),
                "--mean-ci",
                "25",
                "72.4",
                "11.8",
                "--alpha",
                "1e-4",
            ],
            cwd=PROJECT_ROOT,
            check=True,
            capture_output=True,
            text=True,
        )
        self.assertIn("99.99% CI for mean", completed.stdout)

    def test_alpha_rejects_invalid_values(self) -> None:
        for value in ("0", "1", "-0.1", "nan", "inf", "not-a-number"):
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    "--mean-ci",
                    "25",
                    "72.4",
                    "11.8",
                    "--alpha",
                    value,
                ],
                cwd=PROJECT_ROOT,
                capture_output=True,
                text=True,
            )
            self.assertEqual(completed.returncode, 2)
            self.assertIn(
                "--alpha must be a finite number strictly between 0 and 1",
                completed.stderr,
            )

    def test_precision_rejects_invalid_values(self) -> None:
        for value in ("0", "16", "2.5", "many"):
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    "--mean-ci",
                    "25",
                    "72.4",
                    "11.8",
                    "--precision",
                    value,
                ],
                cwd=PROJECT_ROOT,
                capture_output=True,
                text=True,
            )
            self.assertEqual(completed.returncode, 2)
            self.assertIn(
                "--precision must be an integer from 1 through 15",
                completed.stderr,
            )

    def test_conjugate_bayesian_cli_and_plots_require_no_input_file(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            json_path = directory / "bayesian.json"
            plot_directory = directory / "plots"
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    "--bayes-binomial",
                    "30",
                    "100",
                    "1",
                    "1",
                    "--bayes-poisson",
                    "8",
                    "1",
                    "1",
                    "1",
                    "--bayes-normal-known",
                    "25",
                    "72.4",
                    "15",
                    "70",
                    "10",
                    "--bayes-normal-unknown",
                    "25",
                    "72.4",
                    "11.8",
                    "70",
                    "1",
                    "2",
                    "100",
                    "--bayes-future-trials",
                    "10",
                    "--bayes-future-exposure",
                    "2.5",
                    "--bayes-plots",
                    "--plot-dir",
                    str(plot_directory),
                    "--plot-dpi",
                    "80",
                    "--json",
                    str(json_path),
                ],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            analyses = result["bayesian_analyses"]
            self.assertEqual(len(analyses), 4)
            self.assertEqual(
                {analysis["model"] for analysis in analyses},
                {
                    "beta-binomial",
                    "gamma-poisson",
                    "normal-normal-known-variance",
                    "normal-inverse-gamma",
                },
            )
            self.assertEqual(result["metadata"]["aggregate_analysis_count"], 4)
            self.assertEqual(len(result["generated_plots"]), 5)
            self.assertEqual(len(list(plot_directory.glob("*.png"))), 5)
            self.assertIn("BAYESIAN CONJUGATE ANALYSES", completed.stdout)
            self.assertIn("95% credible interval for p", completed.stdout)
            self.assertIn("Posterior predictive", completed.stdout)
            self.assertEqual(
                {analysis["numerical_status"]["status"] for analysis in analyses},
                {"completed"},
            )
            self.assertIn("Bayesian numerical status = completed", completed.stdout)
            self.assertIn("Posterior update = closed-form conjugate algebra", completed.stdout)
            self.assertIn(
                "Derivatives, optimization, iteration, quadrature, ODE solving, and MCMC = not used",
                completed.stdout,
            )
            self.assertIn("finite = True; ordered = True", completed.stdout)
            self.assertNotIn("STATCLASS STATISTICAL ANALYSIS REPORT", completed.stdout)

    def test_conjugate_bayesian_column_cli(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            input_path = directory / "bayesian_data.csv"
            input_path.write_text(
                "outcome,events,exposure,value\n"
                "Yes,1,1,10\n"
                "No,0,2,12\n"
                "Yes,2,1,11\n"
                "Yes,1,0.5,13\n"
                ",0,1,14\n",
                encoding="utf-8",
            )
            json_path = directory / "bayesian_columns.json"
            subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    str(input_path),
                    "--bayes-binomial-column",
                    "outcome",
                    "Yes",
                    "1",
                    "1",
                    "--bayes-poisson-column",
                    "events",
                    "1",
                    "1",
                    "--bayes-poisson-exposure-column",
                    "exposure",
                    "--bayes-normal-known-column",
                    "value",
                    "3",
                    "10",
                    "5",
                    "--bayes-normal-unknown-column",
                    "value",
                    "10",
                    "1",
                    "2",
                    "4",
                    "--no-normality",
                    "--json",
                    str(json_path),
                ],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            analyses = json.loads(json_path.read_text(encoding="utf-8"))[
                "bayesian_analyses"
            ]
            self.assertEqual(len(analyses), 4)
            beta = analyses[0]
            self.assertEqual((beta["successes"], beta["trials"]), (3, 4))
            poisson = analyses[1]
            self.assertEqual(poisson["events"], 4)
            self.assertTrue(math.isclose(poisson["exposure"], 5.5))
            self.assertTrue(all(item["source"] == "data_column" for item in analyses))

    def test_transform_standardize_outlier_cli_and_export(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            input_path = directory / "processing.csv"
            input_path.write_text(
                "value,group\n"
                "1,A\n2,A\n3,A\n4,B\n5,B\n6,B\n7,B\n100,B\n",
                encoding="utf-8",
            )
            export_path = directory / "processed.csv"
            json_path = directory / "processing.json"
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    str(input_path),
                    "--transform",
                    "value",
                    "log",
                    "--transform",
                    "value",
                    "box-cox",
                    "--transform",
                    "value",
                    "power",
                    "2",
                    "--transform",
                    "value",
                    "yeo-johnson",
                    "--standardize",
                    "value",
                    "z-score",
                    "--standardize",
                    "value",
                    "min-max",
                    "--standardize",
                    "value",
                    "robust",
                    "--standardize",
                    "value",
                    "center",
                    "--outliers",
                    "value",
                    "all",
                    "--outlier-z-threshold",
                    "2",
                    "--save-transformed",
                    str(export_path),
                    "--no-normality",
                    "--json",
                    str(json_path),
                ],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertEqual(len(result["transformations"]), 4)
            self.assertEqual(len(result["standardizations"]), 4)
            self.assertEqual(len(result["outlier_diagnostics"]), 3)
            self.assertEqual(
                result["transformed_data_export"]["derived_column_count"], 11
            )
            self.assertNotIn("_transformed_export_frame", result)
            exported = pd.read_csv(export_path)
            self.assertEqual(exported.shape, (8, 13))
            self.assertEqual(exported["group"].tolist(), list("AAABBBBB"))
            self.assertTrue(bool(exported["value_outlier_z_score"].iloc[-1]))
            self.assertTrue(bool(exported["value_outlier_modified_z_score"].iloc[-1]))
            self.assertTrue(bool(exported["value_outlier_iqr"].iloc[-1]))
            self.assertIn("TRANSFORMATIONS AND STANDARDIZATION", completed.stdout)
            self.assertIn("OUTLIER DIAGNOSTICS", completed.stdout)
            self.assertIn("TRANSFORMED DATA EXPORT", completed.stdout)

    def test_transformation_cli_rejects_invalid_domain(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            input_path = Path(temporary) / "nonpositive.csv"
            input_path.write_text("value\n0\n1\n2\n", encoding="utf-8")
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    str(input_path),
                    "--transform",
                    "value",
                    "log",
                ],
                cwd=PROJECT_ROOT,
                capture_output=True,
                text=True,
            )
            self.assertEqual(completed.returncode, 2)
            self.assertIn(
                "log transformation requires values greater than 0",
                completed.stderr,
            )

    def test_multivariate_cli_exports_and_model_plots(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            json_path = directory / "multivariate.json"
            pca_path = directory / "pca_scores.csv"
            discriminant_path = directory / "discriminant.csv"
            plot_directory = directory / "plots"
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    str(FIXTURE_ROOT / "multivariate_sample.csv"),
                    "--pca",
                    "x1",
                    "x2",
                    "x3",
                    "x4",
                    "--pca-components",
                    "3",
                    "--manova",
                    "group",
                    "x1",
                    "x2",
                    "x3",
                    "x4",
                    "--discriminant",
                    "group",
                    "x1",
                    "x2",
                    "x3",
                    "x4",
                    "--save-pca-scores",
                    str(pca_path),
                    "--save-discriminant",
                    str(discriminant_path),
                    "--model-plots",
                    "--plot-dir",
                    str(plot_directory),
                    "--json",
                    str(json_path),
                ],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertIn("PRINCIPAL COMPONENT ANALYSIS", completed.stdout)
            self.assertIn("ONE-WAY MANOVA", completed.stdout)
            self.assertIn("LINEAR DISCRIMINANT ANALYSIS", completed.stdout)
            self.assertEqual(len(result["principal_component_analyses"]), 1)
            self.assertEqual(len(result["manova_analyses"]), 1)
            self.assertEqual(len(result["discriminant_analyses"]), 1)
            self.assertEqual(pd.read_csv(pca_path).shape, (36, 5))
            discriminant = pd.read_csv(discriminant_path)
            self.assertEqual(discriminant.shape[0], 36)
            self.assertIn("predicted_class", discriminant.columns)
            self.assertIn("posterior_A", discriminant.columns)
            self.assertEqual(result["plot_count"], 5)
            self.assertEqual(len(list(plot_directory.glob("*.png"))), 5)

    def test_aggregate_binomial_likelihood_requires_no_input_file(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "aggregate_likelihood.json"
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    "--binomial-likelihood-counts",
                    "30",
                    "100",
                    "--likelihood-p",
                    "0.20",
                    "0.30",
                    "0.50",
                    "--json",
                    str(json_path),
                ],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            analysis = result["binomial_likelihood_analyses"][0]
            self.assertNotIn("STATCLASS STATISTICAL ANALYSIS REPORT", completed.stdout)
            self.assertNotIn("Program version:", completed.stdout)
            self.assertNotIn("Input: aggregate counts", completed.stdout)
            self.assertNotIn("Aggregate analyses requested:", completed.stdout)
            self.assertIn("Aggregate counts: 30 successes in 100 trials", completed.stdout)
            self.assertIsNone(result["metadata"]["input_file"])
            self.assertEqual(analysis["successes"], 30)
            self.assertEqual(analysis["n"], 100)
            self.assertEqual(
                analysis["likelihood_formula"],
                "L(p) = C(100, 30) * p^30 * (1 - p)^70",
            )
            self.assertTrue(
                math.isclose(
                    analysis["mle_probability"],
                    0.30,
                    rel_tol=1e-15,
                )
            )
            self.assertTrue(
                math.isclose(
                    analysis["evaluations"][1]["likelihood"],
                    scipy_stats.binom.pmf(30, 100, 0.30),
                    rel_tol=1e-12,
                )
            )

    def test_aggregate_poisson_interval_requires_no_input_file(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "poisson_interval.json"
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    "--poisson-count",
                    "8",
                    "--json",
                    str(json_path),
                ],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            analysis = result["poisson_mean_analyses"][0]
            interval = analysis["confidence_interval"]
            self.assertNotIn("STATCLASS STATISTICAL ANALYSIS REPORT", completed.stdout)
            self.assertNotIn("Program version:", completed.stdout)
            self.assertNotIn("Input: aggregate counts", completed.stdout)
            self.assertNotIn("Aggregate analyses requested:", completed.stdout)
            self.assertIn("POISSON MEAN CONFIDENCE INTERVALS", completed.stdout)
            self.assertIn("Exact 95% CI for M", completed.stdout)
            self.assertEqual(analysis["events"], 8)
            self.assertTrue(
                math.isclose(
                    interval[0],
                    3.4538321767485014,
                    rel_tol=1e-14,
                )
            )
            self.assertTrue(
                math.isclose(
                    interval[1],
                    15.763189220193313,
                    rel_tol=1e-14,
                )
            )

    def test_combined_summary_data_cli_requires_no_input_file(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "summary_data.json"
            command = [
                sys.executable,
                str(PROJECT_ROOT / "stats.py"),
                "--one-proportion-counts",
                "30",
                "100",
                "--p0",
                "0.25",
                "--two-proportion-counts",
                "30",
                "100",
                "45",
                "120",
                "--one-sample-summary",
                "25",
                "2.4",
                "11.8",
                "--z-summary",
                "100",
                "2.5",
                "15",
                "--two-sample-summary",
                "50",
                "10.2",
                "2.1",
                "45",
                "9.4",
                "2.3",
                "--paired-summary",
                "30",
                "2.4",
                "5.1",
                "--equal-variance",
                "--json",
                str(json_path),
            ]
            completed = subprocess.run(
                command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            expected_sections = (
                "SUMMARY-DATA ONE-SAMPLE T-TESTS",
                "SUMMARY-DATA POPULATION-MEAN Z-TESTS",
                "SUMMARY-DATA INDEPENDENT TWO-SAMPLE TESTS",
                "SUMMARY-DATA PAIRED-DIFFERENCE TESTS",
                "AGGREGATE ONE-PROPORTION TESTS",
                "AGGREGATE TWO-PROPORTION TESTS",
            )
            for section in expected_sections:
                self.assertIn(section, completed.stdout)
            result_keys = (
                "summary_one_sample_tests",
                "summary_z_tests",
                "summary_two_sample_tests",
                "summary_paired_tests",
                "one_proportion_count_tests",
                "two_proportion_count_tests",
            )
            self.assertEqual(result["metadata"]["aggregate_analysis_count"], 6)
            for key in result_keys:
                self.assertEqual(len(result[key]), 1)
                self.assertEqual(result[key][0]["status"], "completed")
            self.assertTrue(
                result["summary_two_sample_tests"][0]["equal_variance"]
            )

    def test_combined_distribution_and_confidence_interval_cli(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "calculators.json"
            command = [
                sys.executable,
                str(PROJECT_ROOT / "stats.py"),
                "--distribution-probability",
                "binomial",
                "eq",
                "8",
                "20",
                ".3",
                "--distribution-probability",
                "poisson",
                "ge",
                "8",
                "5",
                "--distribution-interval",
                "normal",
                "-1.96",
                "1.96",
                "0",
                "1",
                "--distribution-quantile",
                "t",
                ".975",
                "20",
                "--mean-ci",
                "25",
                "72.4",
                "11.8",
                "--mean-ci-z",
                "100",
                "102.5",
                "15",
                "--proportion-ci",
                "30",
                "100",
                "--variance-ci",
                "25",
                "139.24",
                "--poisson-rate-ci",
                "8",
                "1000",
                "--json",
                str(json_path),
            ]
            completed = subprocess.run(
                command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertIn("DISTRIBUTION CALCULATOR", completed.stdout)
            self.assertIn("DIRECT CONFIDENCE INTERVALS", completed.stdout)
            self.assertIn("Evaluation method = central CDF difference", completed.stdout)
            self.assertIn(
                "Endpoint convention = continuous CDF", completed.stdout
            )
            self.assertIn("Numerical validation = validated", completed.stdout)
            self.assertEqual(
                result["metadata"]["analysis_source"], "direct_calculations"
            )
            self.assertEqual(result["metadata"]["aggregate_analysis_count"], 9)
            self.assertEqual(len(result["distribution_calculations"]), 4)
            self.assertEqual(len(result["mean_confidence_intervals"]), 2)
            self.assertEqual(len(result["proportion_confidence_intervals"]), 1)
            self.assertEqual(len(result["variance_confidence_intervals"]), 1)
            self.assertEqual(
                len(result["poisson_rate_confidence_intervals"]), 1
            )
            self.assertTrue(
                math.isclose(
                    result["distribution_calculations"][1]["result"],
                    scipy_stats.poisson.sf(7, 5),
                    rel_tol=1e-14,
                )
            )

    def test_all_distribution_information_is_available_from_cli(self) -> None:
        parameter_sets = {
            "bernoulli": [0.3],
            "binomial": [10, 0.3],
            "discrete-uniform": [6],
            "geometric": [0.3],
            "hypergeometric": [100, 30, 10],
            "negative-binomial": [5, 0.3],
            "poisson": [4],
            "beta": [2, 5],
            "beta-binomial": [10, 2, 5],
            "cauchy": [0, 1],
            "chi-square": [5],
            "laplace": [0, 2],
            "exponential": [2],
            "f": [5, 10],
            "gamma": [3, 2],
            "logistic": [0, 2],
            "lognormal": [0, 1],
            "normal": [0, 1],
            "pareto": [1, 3],
            "t": [10],
            "uniform": [0, 1],
            "weibull": [2, 4],
        }
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "all_distributions.json"
            command = [sys.executable, str(PROJECT_ROOT / "stats.py")]
            for name in SUPPORTED_DISTRIBUTIONS:
                command.extend(
                    [
                        "--distribution-info",
                        name,
                        *(str(value) for value in parameter_sets[name]),
                    ]
                )
            command.extend(
                [
                    "--distribution-density", "gamma", "4", "3", "2",
                    "--json", str(json_path),
                ]
            )
            completed = subprocess.run(
                command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            calculations = result["distribution_calculations"]
            information = [
                item for item in calculations
                if item["calculation_type"] == "information"
            ]
            self.assertIn("DISTRIBUTION CALCULATOR", completed.stdout)
            self.assertIn("MGF:", completed.stdout)
            self.assertIn("First raw moment", completed.stdout)
            self.assertIn("Second raw moment", completed.stdout)
            self.assertEqual(len(calculations), 23)
            self.assertEqual(len(information), 22)
            self.assertEqual(
                {item["distribution"] for item in information},
                set(SUPPORTED_DISTRIBUTIONS),
            )
            self.assertEqual(result["metadata"]["aggregate_analysis_count"], 23)

    def test_combined_power_analysis_cli(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "power.json"
            command = [
                sys.executable,
                str(PROJECT_ROOT / "stats.py"),
                "--power-one-mean", "50", ".5",
                "--sample-size-one-mean", ".5", ".8",
                "--detectable-effect-paired-mean", "30", ".8",
                "--power-two-means", "40", "40", ".6",
                "--sample-size-two-means", ".6", ".8",
                "--detectable-effect-two-means", "40", "40", ".8",
                "--power-one-proportion", "100", ".30", ".20",
                "--sample-size-one-proportion", ".30", ".20", ".8",
                "--detectable-effect-one-proportion", "100", ".20", ".8",
                "--power-two-proportions", "100", "100", ".30", ".45",
                "--sample-size-two-proportions", ".30", ".45", ".8",
                "--detectable-effect-two-proportions",
                "100", "100", ".30", ".8",
                "--power-anova", "4", "25", ".25",
                "--sample-size-anova", "4", ".25", ".8",
                "--detectable-effect-anova", "4", "25", ".8",
                "--allocation-ratio", "1.5",
                "--json", str(json_path),
            ]
            completed = subprocess.run(
                command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            analyses = result["power_analyses"]
            self.assertIn("POWER AND SAMPLE-SIZE ANALYSES", completed.stdout)
            self.assertEqual(result["metadata"]["aggregate_analysis_count"], 15)
            self.assertEqual(len(analyses), 15)
            self.assertEqual(
                {analysis["calculation_type"] for analysis in analyses},
                {"power", "required_sample_size", "detectable_effect"},
            )
            self.assertEqual(
                {analysis["design"] for analysis in analyses},
                {
                    "one-sample mean",
                    "paired mean",
                    "two independent means",
                    "one proportion",
                    "two independent proportions",
                    "balanced one-way ANOVA",
                },
            )
            sample_size_result = next(
                analysis
                for analysis in analyses
                if analysis["design"] == "two independent means"
                and analysis["calculation_type"] == "required_sample_size"
            )
            self.assertEqual(
                sample_size_result["allocation_ratio_n2_to_n1"], 1.5
            )
            self.assertGreaterEqual(sample_size_result["achieved_power"], 0.8)

    def test_summary_data_cli_rejects_invalid_inputs(self) -> None:
        invalid_commands = (
            (
                ["--one-sample-summary", "1", "2", "3"],
                "integer of at least 2",
            ),
            (
                ["--z-summary", "2.5", "2", "3"],
                "integer of at least 1",
            ),
            (
                ["--one-proportion-counts", "30", "100"],
                "requires --p0",
            ),
            (
                ["--two-proportion-counts", "101", "100", "1", "10"],
                "SUCCESSES must be from 0 through TRIALS",
            ),
        )
        for arguments, expected_error in invalid_commands:
            completed = subprocess.run(
                [sys.executable, str(PROJECT_ROOT / "stats.py"), *arguments],
                cwd=PROJECT_ROOT,
                capture_output=True,
                text=True,
            )
            self.assertEqual(completed.returncode, 2)
            self.assertIn(expected_error, completed.stderr)

    def test_distribution_cli_rejects_invalid_requests(self) -> None:
        invalid_commands = (
            (
                ["--distribution-probability", "normal", "eq", "0", "0", "1"],
                "relation for normal",
            ),
            (
                ["--distribution-quantile", "t", "1", "20"],
                "strictly between 0 and 1",
            ),
            (
                ["--distribution-probability", "binomial", "eq", "2", "10"],
                "binomial requires parameters N P",
            ),
        )
        for arguments, expected_error in invalid_commands:
            completed = subprocess.run(
                [sys.executable, str(PROJECT_ROOT / "stats.py"), *arguments],
                cwd=PROJECT_ROOT,
                capture_output=True,
                text=True,
            )
            self.assertEqual(completed.returncode, 2)
            self.assertIn(expected_error, completed.stderr)

    def test_continuous_interval_underflow_is_reported(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "underflow.json"
            completed = subprocess.run(
                [
                    sys.executable,
                    str(PROJECT_ROOT / "stats.py"),
                    "--distribution-interval",
                    "normal",
                    "40",
                    "41",
                    "0",
                    "1",
                    "--json",
                    str(json_path),
                ],
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            calculation = json.loads(
                json_path.read_text(encoding="utf-8")
            )["distribution_calculations"][0]
            self.assertIn("Numerical validation = underflow_to_zero", completed.stdout)
            self.assertIn("zero is an underflow result", completed.stdout)
            self.assertEqual(calculation["result"], 0.0)
            self.assertEqual(
                calculation["numerical_validation"]["status"],
                "underflow_to_zero",
            )
            self.assertLess(
                calculation["numerical_validation"]["log_probability"],
                -700.0,
            )

    def test_power_cli_rejects_invalid_requests(self) -> None:
        invalid_commands = (
            (["--power-one-mean", "1", ".5"], "integer of at least 2"),
            (
                ["--sample-size-one-mean", "0", ".8"],
                "must be nonzero",
            ),
            (
                ["--sample-size-two-proportions", ".3", ".3", ".8"],
                "must differ",
            ),
            (
                ["--power-anova", "4", "25", ".25", "--allocation-ratio", "2"],
                "--allocation-ratio requires",
            ),
        )
        for arguments, expected_error in invalid_commands:
            completed = subprocess.run(
                [sys.executable, str(PROJECT_ROOT / "stats.py"), *arguments],
                cwd=PROJECT_ROOT,
                capture_output=True,
                text=True,
            )
            self.assertEqual(completed.returncode, 2)
            self.assertIn(expected_error, completed.stderr)

    def test_explicit_and_model_plots_are_saved_headlessly(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            plot_directory = directory / "plots"
            json_path = directory / "plot_results.json"
            command = [
                sys.executable,
                str(PROJECT_ROOT / "stats.py"),
                str(FIXTURE_ROOT / "regression_sample.csv"),
                "--plot",
                "histogram",
                "Outcome",
                "--plot",
                "qq",
                "Outcome",
                "--plot",
                "boxplot",
                "Outcome",
                "--plot",
                "grouped-boxplot",
                "Outcome",
                "Group",
                "--plot",
                "scatter",
                "X1",
                "Outcome",
                "--plot",
                "correlation",
                "Outcome",
                "X1",
                "X2",
                "--multiple-regression",
                "Outcome",
                "X1",
                "X2",
                "Group",
                "--model-plots",
                "--plot-dir",
                str(plot_directory),
                "--plot-dpi",
                "90",
                "--no-normality",
                "--json",
                str(json_path),
            ]
            completed = subprocess.run(
                command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            plots = result["generated_plots"]
            self.assertEqual(result["plot_count"], 7)
            self.assertEqual(
                {plot["plot_type"] for plot in plots},
                {
                    "histogram",
                    "qq",
                    "boxplot",
                    "grouped-boxplot",
                    "scatter",
                    "correlation",
                    "model-diagnostics",
                },
            )
            for plot in plots:
                path = Path(plot["file"])
                self.assertTrue(path.is_file())
                self.assertEqual(path.suffix, ".png")
                self.assertEqual(path.read_bytes()[:8], b"\x89PNG\r\n\x1a\n")
            self.assertIn("GENERATED PLOTS", completed.stdout)
            self.assertIn(str(plot_directory.resolve()), completed.stdout)

    def test_combined_resampling_cli_is_reproducible(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "resampling.json"
            command = [
                sys.executable,
                str(PROJECT_ROOT / "stats.py"),
                str(FIXTURE_ROOT / "nonparametric_sample.csv"),
                "--bootstrap",
                "Control",
                "mean",
                "--bootstrap-difference",
                "Control",
                "Treatment_1",
                "median",
                "--bootstrap-method",
                "bca",
                "--permutation-two-sample",
                "Control",
                "Treatment_1",
                "mean",
                "--permutation-paired",
                "Before",
                "After",
                "mean",
                "--permutation-correlation",
                "Before",
                "After",
                "spearman",
                "--resamples",
                "500",
                "--seed",
                "2026",
                "--no-normality",
                "--json",
                str(json_path),
            ]
            first = subprocess.run(
                command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            first_result = json.loads(json_path.read_text(encoding="utf-8"))
            second = subprocess.run(
                command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            second_result = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertEqual(
                first_result["bootstrap_analyses"],
                second_result["bootstrap_analyses"],
            )
            self.assertEqual(
                first_result["permutation_tests"],
                second_result["permutation_tests"],
            )
            self.assertEqual(len(first_result["bootstrap_analyses"]), 2)
            self.assertEqual(len(first_result["permutation_tests"]), 3)
            seeds = [
                analysis["random_seed"]
                for analysis in [
                    *first_result["bootstrap_analyses"],
                    *first_result["permutation_tests"],
                ]
            ]
            self.assertEqual(seeds, [2026, 2027, 2028, 2029, 2030])
            self.assertTrue(
                all(
                    test["enumeration"] == "monte_carlo"
                    for test in first_result["permutation_tests"]
                )
            )
            self.assertIn("BOOTSTRAP CONFIDENCE INTERVALS", first.stdout)
            self.assertIn("PERMUTATION TESTS", second.stdout)

    def test_combined_cli_analysis(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            data_path = self._write_test_csv(directory)
            json_path = directory / "result.json"
            command = [
                sys.executable,
                str(PROJECT_ROOT / "stats.py"),
                str(data_path),
                "--paired",
                "Before",
                "After",
                "--correlation",
                "X",
                "Y",
                "--regression",
                "Y",
                "X",
                "--multiple-regression",
                "Y",
                "X",
                "--multiple-regression",
                "Y",
                "X",
                "Category",
                "--categorical-predictors",
                "Category",
                "--compare-models",
                "--logistic",
                "Purchased",
                "X",
                "Category",
                "--event",
                "Yes",
                "--multinomial-logistic",
                "Risk",
                "X",
                "Category",
                "--outcome-reference",
                "Low",
                "--mann-whitney",
                "X",
                "Y",
                "--wilcoxon",
                "Before",
                "After",
                "--kruskal",
                "Before",
                "After",
                "X",
                "--posthoc",
                "--json",
                str(json_path),
            ]
            completed = subprocess.run(
                command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertIn("PAIRED-SAMPLE TESTS", completed.stdout)
            self.assertIn("CORRELATION ANALYSES", completed.stdout)
            self.assertIn("SIMPLE LINEAR REGRESSION", completed.stdout)
            self.assertIn("MULTIPLE LINEAR REGRESSION", completed.stdout)
            self.assertIn("REGRESSION MODEL COMPARISONS", completed.stdout)
            self.assertIn("BINARY LOGISTIC REGRESSION", completed.stdout)
            self.assertIn("MULTINOMIAL LOGISTIC REGRESSION", completed.stdout)
            self.assertIn("MANN-WHITNEY U TESTS", completed.stdout)
            self.assertIn("WILCOXON SIGNED-RANK TESTS", completed.stdout)
            self.assertIn("KRUSKAL-WALLIS TESTS", completed.stdout)
            self.assertEqual(result["paired_tests"][0]["status"], "completed")
            self.assertEqual(
                len(result["correlation_analyses"][0]["tests"]), 3
            )
            self.assertEqual(
                result["regression_analyses"][0]["status"], "completed"
            )
            self.assertEqual(len(result["multiple_regression_analyses"]), 2)
            self.assertEqual(
                result["multiple_regression_analyses"][1]["status"],
                "completed",
            )
            self.assertEqual(
                result["multiple_regression_analyses"][1][
                    "categorical_codings"
                ][0]["reference_category"],
                "A",
            )
            self.assertEqual(result["model_comparisons"][0]["status"], "completed")
            self.assertEqual(
                result["binary_logistic_regression_analyses"][0]["status"],
                "completed",
            )
            self.assertEqual(
                result["multinomial_logistic_regression_analyses"][0]["status"],
                "completed",
            )
            self.assertEqual(
                result["mann_whitney_tests"][0]["status"], "completed"
            )
            self.assertEqual(result["wilcoxon_tests"][0]["status"], "completed")
            self.assertEqual(
                result["kruskal_wallis_tests"][0]["status"], "completed"
            )
            self.assertEqual(
                len(result["kruskal_wallis_tests"][0]["posthoc_comparisons"]),
                3,
            )

    def test_poisson_cli_with_polynomial_and_interaction(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "count_result.json"
            command = [
                sys.executable,
                str(PROJECT_ROOT / "stats.py"),
                str(FIXTURE_ROOT / "count_sample.csv"),
                "--poisson",
                "visits",
                "exposure",
                "age",
                "group",
                "--categorical-predictors",
                "group",
                "--polynomial",
                "exposure",
                "2",
                "--interaction",
                "exposure",
                "group",
                "--json",
                str(json_path),
            ]
            completed = subprocess.run(
                command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            model = result["poisson_regression_analyses"][0]
            self.assertIn("POISSON COUNT REGRESSION", completed.stdout)
            self.assertEqual(model["status"], "completed")
            self.assertIn("exposure^2", model["terms"])
            self.assertIn("exposure:group[T.B]", model["terms"])
            self.assertIn("incidence_rate_ratio", model["coefficients"][1])

    def test_negative_binomial_cli_with_exposure(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            json_path = Path(temporary) / "negative_binomial_result.json"
            command = [
                sys.executable,
                str(PROJECT_ROOT / "stats.py"),
                str(FIXTURE_ROOT / "overdispersed_count_sample.csv"),
                "--negative-binomial",
                "claims",
                "age",
                "risk_score",
                "group",
                "--categorical-predictors",
                "group",
                "--exposure",
                "insured_years",
                "--json",
                str(json_path),
            ]
            completed = subprocess.run(
                command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            model = result["negative_binomial_regression_analyses"][0]
            self.assertIn(
                "NEGATIVE-BINOMIAL COUNT REGRESSION", completed.stdout
            )
            self.assertIn("Poisson comparison", completed.stdout)
            self.assertEqual(model["status"], "completed")
            self.assertEqual(model["exposure_variable"], "insured_years")
            self.assertGreater(model["dispersion_parameter"], 0.0)
            self.assertEqual(model["poisson_comparison"]["status"], "completed")
            self.assertTrue(
                model["information_matrix_diagnostics"]["positive_definite"]
            )
            self.assertIn("Numerical Hessian", completed.stdout)

    def test_factorial_longitudinal_cli_and_casewise_exports(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            factorial_json = directory / "factorial.json"
            factorial_predictions = directory / "factorial_predictions.csv"
            factorial_residuals = directory / "factorial_residuals.csv"
            factorial_command = [
                sys.executable,
                str(PROJECT_ROOT / "stats.py"),
                str(FIXTURE_ROOT / "factorial_sample.csv"),
                "--two-way-anova",
                "score",
                "method",
                "setting",
                "--ancova",
                "score",
                "method",
                "setting",
                "baseline",
                "--save-predictions",
                str(factorial_predictions),
                "--save-residuals",
                str(factorial_residuals),
                "--json",
                str(factorial_json),
            ]
            factorial_completed = subprocess.run(
                factorial_command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            factorial_result = json.loads(
                factorial_json.read_text(encoding="utf-8")
            )
            self.assertIn(
                "TWO-WAY ANOVA AND ANCOVA", factorial_completed.stdout
            )
            self.assertEqual(len(factorial_result["factorial_analyses"]), 2)
            self.assertTrue(
                all(
                    model["status"] == "completed"
                    for model in factorial_result["factorial_analyses"]
                )
            )
            self.assertIn(
                "estimated_marginal_means",
                factorial_result["factorial_analyses"][1],
            )
            factorial_export = pd.read_csv(factorial_predictions)
            self.assertIn("mean_ci_lower", factorial_export.columns)
            self.assertIn("prediction_interval_upper", factorial_export.columns)
            self.assertIn(
                "residual", pd.read_csv(factorial_residuals).columns
            )

            longitudinal_json = directory / "longitudinal.json"
            longitudinal_predictions = directory / "longitudinal_predictions.csv"
            longitudinal_command = [
                sys.executable,
                str(PROJECT_ROOT / "stats.py"),
                str(FIXTURE_ROOT / "longitudinal_sample.csv"),
                "--repeated-measures",
                "outcome",
                "subject",
                "time",
                "--mixed-effects",
                "outcome",
                "subject",
                "time_index",
                "treatment",
                "age",
                "--categorical-predictors",
                "treatment",
                "--interaction",
                "time_index",
                "treatment",
                "--save-predictions",
                str(longitudinal_predictions),
                "--json",
                str(longitudinal_json),
            ]
            longitudinal_completed = subprocess.run(
                longitudinal_command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            longitudinal_result = json.loads(
                longitudinal_json.read_text(encoding="utf-8")
            )
            self.assertIn(
                "REPEATED-MEASURES ANOVA", longitudinal_completed.stdout
            )
            self.assertIn(
                "LINEAR MIXED-EFFECTS MODELS", longitudinal_completed.stdout
            )
            self.assertEqual(
                longitudinal_result["repeated_measures_analyses"][0]["status"],
                "completed",
            )
            mixed = longitudinal_result["mixed_effects_analyses"][0]
            self.assertEqual(mixed["status"], "completed")
            self.assertIn("intraclass_correlation", mixed["variance_components"])
            self.assertIn("variance_component_inference", mixed)
            self.assertIn("Variance-component information matrix", longitudinal_completed.stdout)
            longitudinal_export = pd.read_csv(longitudinal_predictions)
            self.assertEqual(
                set(longitudinal_export["model_family"]),
                {"repeated_measures_anova", "mixed_effects"},
            )


class CategoricalTests(unittest.TestCase):
    def setUp(self) -> None:
        self.group = pd.Series(["A"] * 50 + ["B"] * 50)
        self.outcome = pd.Series(
            ["Yes"] * 30
            + ["No"] * 20
            + ["Yes"] * 15
            + ["No"] * 35
        )

    def test_frequency_and_contingency_tables(self) -> None:
        frequency = frequency_table(self.outcome, "Outcome")
        self.assertEqual(frequency["nonmissing"], 100)
        self.assertEqual(frequency["distinct_categories"], 2)
        counts = {
            item["category"]: item["count"]
            for item in frequency["categories"]
        }
        self.assertEqual(counts, {"Yes": 45, "No": 55})

        table = contingency_table(
            self.group, self.outcome, "Treatment", "Outcome"
        )
        actual = pd.DataFrame(
            table["observed_counts"],
            index=table["row_categories"],
            columns=table["column_categories"],
        )
        self.assertEqual(int(actual.loc["A", "Yes"]), 30)
        self.assertEqual(int(actual.loc["A", "No"]), 20)
        self.assertEqual(int(actual.loc["B", "Yes"]), 15)
        self.assertEqual(int(actual.loc["B", "No"]), 35)

    def test_chi_square_independence_matches_scipy(self) -> None:
        actual = chi_square_independence(
            self.group,
            self.outcome,
            "Treatment",
            "Outcome",
            0.05,
        )
        observed = np.asarray(actual["table"]["observed_counts"])
        expected = scipy_stats.chi2_contingency(observed, correction=False)
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(
            math.isclose(actual["statistic"], expected.statistic, rel_tol=1e-13)
        )
        self.assertTrue(
            math.isclose(actual["p_value"], expected.pvalue, rel_tol=1e-13)
        )

    def test_goodness_of_fit_matches_scipy(self) -> None:
        colors = pd.Series(["Red"] * 40 + ["Blue"] * 35 + ["Green"] * 25)
        probabilities = [0.30, 0.40, 0.30]
        actual = chi_square_goodness_of_fit(
            colors, "Color", probabilities, 0.05
        )
        expected = scipy_stats.chisquare(
            [40, 35, 25], f_exp=np.asarray(probabilities) * 100
        )
        self.assertTrue(
            math.isclose(actual["statistic"], expected.statistic, rel_tol=1e-13)
        )
        self.assertTrue(
            math.isclose(actual["p_value"], expected.pvalue, rel_tol=1e-13)
        )

    def test_fisher_exact_matches_scipy(self) -> None:
        actual = fisher_exact_test(
            self.group,
            self.outcome,
            "Treatment",
            "Outcome",
            "two-sided",
            0.05,
        )
        observed = np.asarray(actual["table"]["observed_counts"])
        expected = scipy_stats.fisher_exact(observed, alternative="two-sided")
        self.assertEqual(actual["status"], "completed")
        self.assertTrue(
            math.isclose(actual["odds_ratio"], expected.statistic, rel_tol=1e-13)
        )
        self.assertTrue(
            math.isclose(actual["p_value"], expected.pvalue, rel_tol=1e-13)
        )

    def test_one_proportion_matches_reference_calculations(self) -> None:
        actual = one_proportion_test(
            self.outcome,
            "Outcome",
            "Yes",
            0.50,
            "two-sided",
            0.05,
        )
        expected_z = (0.45 - 0.50) / math.sqrt(0.50 * 0.50 / 100)
        expected_z_p = 2.0 * scipy_stats.norm.sf(abs(expected_z))
        expected_exact = scipy_stats.binomtest(45, 100, 0.50)
        self.assertTrue(math.isclose(actual["z_score"], expected_z, rel_tol=1e-13))
        self.assertTrue(
            math.isclose(actual["z_p_value"], expected_z_p, rel_tol=1e-13)
        )
        self.assertTrue(
            math.isclose(
                actual["exact_binomial_p_value"],
                expected_exact.pvalue,
                rel_tol=1e-13,
            )
        )
        likelihood = actual["likelihood_analysis"]
        evaluation = likelihood["evaluations"][0]
        self.assertTrue(
            math.isclose(
                evaluation["log_likelihood"],
                scipy_stats.binom.logpmf(45, 100, 0.50),
                rel_tol=1e-13,
            )
        )

    def test_binomial_likelihood_matches_scipy_and_finds_mle(self) -> None:
        outcomes = pd.Series(["Yes"] * 30 + ["No"] * 70)
        actual = binomial_likelihood_analysis(
            outcomes,
            "Diabetes",
            "Yes",
            [0.20, 0.30, 0.50],
        )
        self.assertEqual(actual["status"], "completed")
        self.assertEqual(actual["n"], 100)
        self.assertEqual(actual["successes"], 30)
        self.assertEqual(actual["failures"], 70)
        self.assertEqual(actual["binomial_coefficient"], math.comb(100, 30))
        self.assertEqual(
            actual["likelihood_formula"],
            "L(p) = C(100, 30) * p^30 * (1 - p)^70",
        )
        self.assertTrue(
            math.isclose(actual["mle_probability"], 0.30, rel_tol=1e-15)
        )
        for evaluation in actual["evaluations"]:
            probability = evaluation["probability"]
            self.assertTrue(
                math.isclose(
                    evaluation["likelihood"],
                    scipy_stats.binom.pmf(30, 100, probability),
                    rel_tol=1e-12,
                )
            )
            self.assertTrue(
                math.isclose(
                    evaluation["log_likelihood"],
                    scipy_stats.binom.logpmf(30, 100, probability),
                    rel_tol=1e-12,
                )
            )
        self.assertTrue(
            math.isclose(
                actual["maximized_likelihood"],
                scipy_stats.binom.pmf(30, 100, 0.30),
                rel_tol=1e-12,
            )
        )

    def test_binomial_likelihood_handles_boundary_probabilities(self) -> None:
        actual = binomial_likelihood_analysis(
            pd.Series(["Yes"] * 5),
            "Outcome",
            "Yes",
            [0.0, 1.0],
        )
        at_zero, at_one = actual["evaluations"]
        self.assertEqual(actual["mle_probability"], 1.0)
        self.assertEqual(at_zero["likelihood"], 0.0)
        self.assertIsNone(at_zero["log_likelihood"])
        self.assertEqual(at_zero["relative_likelihood"], 0.0)
        self.assertEqual(at_one["likelihood"], 1.0)
        self.assertEqual(at_one["log_likelihood"], 0.0)
        self.assertEqual(at_one["relative_likelihood"], 1.0)

    def test_two_proportion_matches_reference_calculations(self) -> None:
        actual = two_proportion_test(
            self.group,
            self.outcome,
            "Treatment",
            "Outcome",
            "Yes",
            "two-sided",
            0.05,
        )
        pooled = 45 / 100
        expected_z = (0.60 - 0.30) / math.sqrt(
            pooled * (1.0 - pooled) * (1.0 / 50 + 1.0 / 50)
        )
        expected_p = 2.0 * scipy_stats.norm.sf(abs(expected_z))
        self.assertTrue(math.isclose(actual["z_score"], expected_z, rel_tol=1e-13))
        self.assertTrue(
            math.isclose(actual["p_value"], expected_p, rel_tol=1e-13)
        )
        self.assertTrue(
            math.isclose(actual["risk_difference"], 0.30, rel_tol=1e-13)
        )


class CategoricalCliTests(unittest.TestCase):
    def _write_categorical_csv(self, directory: Path) -> Path:
        path = directory / "categorical_data.csv"
        colors = ["Red"] * 40 + ["Blue"] * 35 + ["Green"] * 25
        groups = ["A"] * 50 + ["B"] * 50
        outcomes = (
            ["Yes"] * 30
            + ["No"] * 20
            + ["Yes"] * 15
            + ["No"] * 35
        )
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            writer.writerow(["Treatment", "Outcome", "Color"])
            writer.writerows(zip(groups, outcomes, colors))
        return path

    def test_categorical_only_loader_and_combined_cli(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            data_path = self._write_categorical_csv(directory)
            dataset = load_dataset(data_path)
            self.assertEqual(dataset.numeric_names, [])
            json_path = directory / "categorical_result.json"
            command = [
                sys.executable,
                str(PROJECT_ROOT / "stats.py"),
                str(data_path),
                "--frequency",
                "Outcome",
                "--crosstab",
                "Treatment",
                "Outcome",
                "--chi-square",
                "Treatment",
                "Outcome",
                "--fisher-exact",
                "Treatment",
                "Outcome",
                "--one-proportion",
                "Outcome",
                "--binomial-likelihood",
                "Outcome",
                "--likelihood-p",
                "0.3",
                "0.5",
                "--two-proportion",
                "Treatment",
                "Outcome",
                "--success",
                "Yes",
                "--p0",
                "0.5",
                "--goodness-of-fit",
                "Color",
                "--expected",
                "0.30",
                "0.40",
                "0.30",
                "--json",
                str(json_path),
            ]
            completed = subprocess.run(
                command,
                cwd=PROJECT_ROOT,
                check=True,
                capture_output=True,
                text=True,
            )
            result = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertIn("FREQUENCY TABLES", completed.stdout)
            self.assertIn("CHI-SQUARE TESTS OF INDEPENDENCE", completed.stdout)
            self.assertIn("ONE-PROPORTION TESTS", completed.stdout)
            self.assertIn("BINOMIAL LIKELIHOOD ANALYSES", completed.stdout)
            self.assertIn("TWO-PROPORTION TESTS", completed.stdout)
            self.assertEqual(result["metadata"]["numeric_columns_found"], 0)
            self.assertEqual(result["chi_square_tests"][0]["status"], "completed")
            self.assertEqual(result["fisher_exact_tests"][0]["status"], "completed")
            self.assertEqual(result["one_proportion_tests"][0]["successes"], 45)
            likelihood = result["binomial_likelihood_analyses"][0]
            self.assertEqual(likelihood["successes"], 45)
            self.assertEqual(len(likelihood["evaluations"]), 2)
            self.assertEqual(result["two_proportion_tests"][0]["status"], "completed")


if __name__ == "__main__":
    unittest.main()
