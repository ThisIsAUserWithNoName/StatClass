#!/usr/bin/env python3
"""Command-line launcher for StatClass."""

import sys


def launch() -> int:
    dependency_options = {"--dependencies", "--requirements"}
    if len(sys.argv) == 2 and sys.argv[1] in dependency_options:
        from statclass.dependencies import dependency_report

        sys.stdout.write(dependency_report())
        return 0

    from statclass.cli import main

    return main()


if __name__ == "__main__":
    raise SystemExit(launch())
