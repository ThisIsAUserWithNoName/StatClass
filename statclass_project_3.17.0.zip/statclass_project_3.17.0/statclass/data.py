"""Input parsing, column resolution, and missing-value handling."""

from __future__ import annotations

import errno
import math
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


MISSING_TOKENS = {"", "na", "n/a", "nan", "null", "none", "."}
RESOURCE_SAMPLE_ROWS = 128
PARSER_BASELINE_BYTES = 64 * 1024**2
ESTIMATED_BYTES_PER_CELL = 128
FILE_WORKING_COPY_FACTOR = 2
MEMORY_SAFETY_FACTOR = 1.5


class DataError(ValueError):
    """Raised when input data or a requested analysis is invalid."""


@dataclass
class DataSet:
    """Loaded table with both original and numeric representations."""

    raw: pd.DataFrame
    numeric: pd.DataFrame
    numeric_names: list[str]
    delimiter: str
    header_detected: bool
    input_resource_preflight: dict[str, int | float | str | None]


def _format_bytes(value: int) -> str:
    amount = float(value)
    units = ("bytes", "KiB", "MiB", "GiB", "TiB")
    for unit in units:
        if amount < 1024.0 or unit == units[-1]:
            if unit == "bytes":
                return f"{int(amount)} {unit}"
            return f"{amount:.1f} {unit}"
        amount /= 1024.0
    return f"{amount:.1f} TiB"


def _read_nonnegative_integer(path: Path) -> int | None:
    try:
        value = path.read_text(encoding="ascii").strip()
    except (OSError, UnicodeError):
        return None
    if not value.isdigit():
        return None
    parsed = int(value)
    return parsed if parsed >= 0 else None


def available_memory_bytes() -> int | None:
    """Return a conservative estimate of memory available to this process."""
    candidates: list[int] = []
    try:
        pages = int(os.sysconf("SC_AVPHYS_PAGES"))
        page_size = int(os.sysconf("SC_PAGE_SIZE"))
        if pages > 0 and page_size > 0:
            candidates.append(pages * page_size)
    except (AttributeError, OSError, TypeError, ValueError):
        pass

    cgroup_pairs = (
        (
            Path("/sys/fs/cgroup/memory.max"),
            Path("/sys/fs/cgroup/memory.current"),
        ),
        (
            Path("/sys/fs/cgroup/memory/memory.limit_in_bytes"),
            Path("/sys/fs/cgroup/memory/memory.usage_in_bytes"),
        ),
    )
    for limit_path, usage_path in cgroup_pairs:
        limit = _read_nonnegative_integer(limit_path)
        usage = _read_nonnegative_integer(usage_path)
        if limit is None or usage is None or limit <= 0 or limit >= 2**60:
            continue
        candidates.append(max(0, limit - usage))

    return min(candidates) if candidates else None


def _check_file_size_resource_floor(path: Path) -> None:
    """Reject a file that is unsafe even before its rows are sampled."""
    if not path.is_file():
        raise DataError(f"input file not found: {path}")
    file_size = path.stat().st_size
    minimum_peak = PARSER_BASELINE_BYTES + FILE_WORKING_COPY_FACTOR * file_size
    required_available = int(math.ceil(minimum_peak * MEMORY_SAFETY_FACTOR))
    available = available_memory_bytes()
    if available is not None and required_available > available:
        raise DataError(
            "input resource preflight stopped before input inspection: "
            f"the {_format_bytes(file_size)} file has a conservative minimum "
            f"load-memory estimate of {_format_bytes(minimum_peak)}, and "
            f"StatClass requires {_format_bytes(required_available)} available "
            f"after applying its {MEMORY_SAFETY_FACTOR:g}x safety factor; "
            f"only {_format_bytes(available)} is currently available. No data "
            "rows were read, parsed, truncated, or silently discarded. Free "
            "memory or intentionally divide the input, then retry. The full "
            "row-and-column estimate was not attempted because the file-size "
            "lower bound was already unsafe."
        )


def estimate_input_resources(
    path: Path,
    delimiter: str,
    encoding: str,
) -> dict[str, int | float | str | None]:
    """Estimate parser memory from file size and a bounded line sample."""
    file_size = path.stat().st_size
    sampled_rows = 0
    sampled_bytes = 0
    estimated_columns = 1
    try:
        with path.open("r", encoding=encoding) as handle:
            for raw_line in handle:
                stripped = raw_line.strip()
                if not stripped or stripped.startswith("#"):
                    continue
                sampled_rows += 1
                sampled_bytes += len(raw_line.encode(encoding))
                estimated_columns = max(
                    estimated_columns,
                    len(split_data_line(raw_line, delimiter)),
                )
                if sampled_rows >= RESOURCE_SAMPLE_ROWS:
                    break
    except UnicodeError as exc:
        raise DataError(
            f"could not decode {path} using {encoding}; choose another --encoding"
        ) from exc

    average_row_bytes = max(1.0, sampled_bytes / max(1, sampled_rows))
    estimated_rows = max(
        sampled_rows,
        int(math.ceil(file_size / average_row_bytes)),
    )
    estimated_cells = estimated_rows * estimated_columns
    estimated_peak = int(
        math.ceil(
            PARSER_BASELINE_BYTES
            + FILE_WORKING_COPY_FACTOR * file_size
            + ESTIMATED_BYTES_PER_CELL * estimated_cells
        )
    )
    required_available = int(math.ceil(estimated_peak * MEMORY_SAFETY_FACTOR))
    available = available_memory_bytes()
    status = (
        "available_memory_unknown"
        if available is None
        else "within_available_memory"
    )
    result: dict[str, int | float | str | None] = {
        "status": status,
        "file_size_bytes": file_size,
        "sampled_data_rows": sampled_rows,
        "estimated_rows": estimated_rows,
        "estimated_columns": estimated_columns,
        "estimated_cells": estimated_cells,
        "estimated_peak_load_memory_bytes": estimated_peak,
        "memory_safety_factor": MEMORY_SAFETY_FACTOR,
        "required_available_memory_bytes": required_available,
        "available_memory_bytes_at_load": available,
        "estimate_method": (
            "file size plus a bounded 128-row sample; includes parser, raw-table, "
            "and numeric-copy overhead"
        ),
    }
    if available is not None and required_available > available:
        result["status"] = "stopped_before_parse"
        raise DataError(
            "input resource preflight stopped before table parsing: "
            f"the {_format_bytes(file_size)} file is estimated to require "
            f"about {_format_bytes(estimated_peak)} of peak load memory, and "
            f"StatClass requires {_format_bytes(required_available)} available "
            f"after applying its {MEMORY_SAFETY_FACTOR:g}x safety factor; "
            f"only {_format_bytes(available)} is currently available. No data "
            "rows were loaded, truncated, or silently discarded. Free memory or "
            "intentionally divide the input, then retry. This is a planning "
            "estimate based on file size and a bounded row sample."
        )
    return result


def delimiter_from_option(option: str, first_line: str) -> str:
    named = {
        "comma": ",",
        "tab": "\t",
        "semicolon": ";",
        "space": r"\s+",
    }
    lowered = option.lower()
    if lowered in named:
        return named[lowered]
    if lowered != "auto":
        if len(option) != 1:
            raise DataError(
                "--delimiter must be auto, comma, tab, semicolon, space, "
                "or one literal character"
            )
        return option

    counts = {
        ",": first_line.count(","),
        "\t": first_line.count("\t"),
        ";": first_line.count(";"),
    }
    best = max(counts, key=counts.get)
    return best if counts[best] > 0 else r"\s+"


def split_data_line(line: str, delimiter: str) -> list[str]:
    if delimiter == r"\s+":
        return re.split(r"\s+", line.strip())
    return [part.strip() for part in line.rstrip("\r\n").split(delimiter)]


def is_number_or_missing(value: str) -> bool:
    if value.strip().lower() in MISSING_TOKENS:
        return True
    try:
        float(value)
        return True
    except ValueError:
        return False


def inspect_input(
    path: Path,
    delimiter_option: str,
    header_option: str,
    encoding: str,
) -> tuple[str, int | None]:
    if not path.is_file():
        raise DataError(f"input file not found: {path}")

    first_line = None
    try:
        with path.open("r", encoding=encoding) as handle:
            for raw_line in handle:
                stripped = raw_line.strip()
                if stripped and not stripped.startswith("#"):
                    first_line = raw_line
                    break
    except UnicodeError as exc:
        raise DataError(
            f"could not decode {path} using {encoding}; choose another --encoding"
        ) from exc

    if first_line is None:
        raise DataError("input file contains no data rows")

    delimiter = delimiter_from_option(delimiter_option, first_line)
    if header_option == "yes":
        header_row = 0
    elif header_option == "no":
        header_row = None
    else:
        fields = split_data_line(first_line, delimiter)
        header_row = None if all(is_number_or_missing(field) for field in fields) else 0
    return delimiter, header_row


def load_dataset(
    path: Path,
    delimiter_option: str = "auto",
    header_option: str = "auto",
    encoding: str = "utf-8",
) -> DataSet:
    _check_file_size_resource_floor(path)
    delimiter, header_row = inspect_input(
        path, delimiter_option, header_option, encoding
    )
    resource_preflight = estimate_input_resources(path, delimiter, encoding)
    try:
        frame = pd.read_csv(
            path,
            sep=delimiter,
            engine="python",
            header=header_row,
            comment="#",
            encoding=encoding,
            na_values=["NA", "N/A", "NaN", "nan", "NULL", "null", "None", "."],
            keep_default_na=True,
            skip_blank_lines=True,
        )
    except MemoryError as exc:
        estimate = resource_preflight["estimated_peak_load_memory_bytes"]
        available = resource_preflight["available_memory_bytes_at_load"]
        available_text = (
            _format_bytes(int(available))
            if available is not None
            else "an unknown amount"
        )
        raise DataError(
            "input parsing exhausted available memory despite the preflight "
            f"estimate of about {_format_bytes(int(estimate))}; "
            f"{available_text} was available before loading. No deliberate row "
            "truncation was applied; reduce the input intentionally or make more "
            "memory available."
        ) from exc
    except OSError as exc:
        if exc.errno == errno.ENOMEM:
            estimate = resource_preflight["estimated_peak_load_memory_bytes"]
            available = resource_preflight["available_memory_bytes_at_load"]
            available_text = (
                _format_bytes(int(available))
                if available is not None
                else "an unknown amount"
            )
            raise DataError(
                "the operating system reported insufficient memory during "
                f"input parsing despite the preflight estimate of about "
                f"{_format_bytes(int(estimate))}; {available_text} was "
                "available before loading. No deliberate row truncation was "
                "applied; reduce the input intentionally or make more memory "
                "available."
            ) from exc
        raise DataError(f"could not parse input data: {exc}") from exc
    except Exception as exc:
        raise DataError(f"could not parse input data: {exc}") from exc

    if frame.empty:
        raise DataError("input file contains no usable data rows")
    frame = frame.dropna(axis=1, how="all")
    if frame.shape[1] == 0:
        raise DataError("input file contains no usable columns")

    if header_row is None:
        frame.columns = [f"Series_{index}" for index in range(1, frame.shape[1] + 1)]
    else:
        frame.columns = [str(name).strip() for name in frame.columns]

    numeric = pd.DataFrame(index=frame.index)
    numeric_names: list[str] = []
    for name in frame.columns:
        converted = pd.to_numeric(frame[name], errors="coerce")
        if converted.notna().any():
            numeric[name] = converted.astype(float)
            numeric_names.append(name)

    return DataSet(
        raw=frame,
        numeric=numeric,
        numeric_names=numeric_names,
        delimiter=delimiter,
        header_detected=header_row == 0,
        input_resource_preflight=resource_preflight,
    )


def flatten_column_arguments(arguments: Iterable[str] | None) -> list[str]:
    if not arguments:
        return []
    flattened: list[str] = []
    for argument in arguments:
        flattened.extend(
            piece.strip() for piece in argument.split(",") if piece.strip()
        )
    return flattened


def resolve_column(reference: str, names: list[str]) -> str:
    if reference.startswith("name:"):
        literal_name = reference[5:]
        if literal_name in names:
            return literal_name
        raise DataError(f"unknown column name: {literal_name!r}")
    if reference.isdigit():
        index = int(reference)
        if 1 <= index <= len(names):
            return names[index - 1]
        raise DataError(
            f"column number {index} is out of range; "
            f"the selected column set has {len(names)} columns"
        )
    if reference in names:
        return reference
    available = ", ".join(
        f"{index}: {name}" for index, name in enumerate(names, 1)
    )
    raise DataError(
        f"unknown column {reference!r}. Available columns: {available}"
    )


def resolve_columns(references: Iterable[str], names: list[str]) -> list[str]:
    resolved: list[str] = []
    for reference in references:
        name = resolve_column(reference, names)
        if name not in resolved:
            resolved.append(name)
    return resolved


def clean_sample(series: pd.Series) -> np.ndarray:
    values = series.to_numpy(dtype=float)
    return values[np.isfinite(values)]


def paired_samples(first: pd.Series, second: pd.Series) -> tuple[np.ndarray, np.ndarray]:
    first_values = first.to_numpy(dtype=float)
    second_values = second.to_numpy(dtype=float)
    mask = np.isfinite(first_values) & np.isfinite(second_values)
    return first_values[mask], second_values[mask]


def delimiter_label(delimiter: str) -> str:
    return {
        r"\s+": "whitespace",
        "\t": "tab",
        ",": "comma",
        ";": "semicolon",
    }.get(delimiter, repr(delimiter))
