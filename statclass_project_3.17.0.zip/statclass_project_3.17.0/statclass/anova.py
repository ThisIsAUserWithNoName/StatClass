"""Classical and Welch one-way analysis of variance."""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .data import clean_sample
from .utils import decision_from_pvalue, finite_or_none


def one_way_anova(
    series_list: list[pd.Series],
    column_names: list[str],
    equal_variance: bool,
    alpha: float,
) -> dict[str, Any]:
    samples = [clean_sample(series) for series in series_list]
    group_count = len(samples)
    counts = np.asarray([sample.size for sample in samples], dtype=float)
    method = "Classical one-way ANOVA" if equal_variance else "Welch one-way ANOVA"
    result: dict[str, Any] = {
        "method": method,
        "columns": column_names,
        "group_count": group_count,
        "group_statistics": [],
    }

    for name, sample in zip(column_names, samples):
        result["group_statistics"].append(
            {
                "column": name,
                "n": int(sample.size),
                "mean": finite_or_none(np.mean(sample)) if sample.size else None,
                "variance": (
                    finite_or_none(np.var(sample, ddof=1))
                    if sample.size >= 2
                    else None
                ),
            }
        )

    if group_count < 3:
        result.update(status="not_run", reason="ANOVA requires at least 3 columns")
        return result
    if np.any(counts < 2):
        result.update(
            status="not_run",
            reason="each independent sample requires at least 2 observations",
        )
        return result

    means = np.asarray([np.mean(sample) for sample in samples], dtype=float)
    variances = np.asarray(
        [np.var(sample, ddof=1) for sample in samples], dtype=float
    )
    numerator_df = float(group_count - 1)

    if equal_variance:
        total_n = int(np.sum(counts))
        denominator_df = float(total_n - group_count)
        grand_mean = float(np.sum(counts * means) / total_n)
        between_sum_squares = float(
            np.sum(counts * (means - grand_mean) ** 2)
        )
        within_sum_squares = float(np.sum((counts - 1.0) * variances))
        if within_sum_squares <= 0:
            result.update(status="not_run", reason="within-group variance is zero")
            return result

        between_mean_square = between_sum_squares / numerator_df
        within_mean_square = within_sum_squares / denominator_df
        statistic = between_mean_square / within_mean_square
        p_value = float(
            scipy_stats.f.sf(statistic, numerator_df, denominator_df)
        )
        total_sum_squares = between_sum_squares + within_sum_squares
        eta_squared = between_sum_squares / total_sum_squares
        omega_squared = (
            between_sum_squares - numerator_df * within_mean_square
        ) / (total_sum_squares + within_mean_square)
        result.update(
            {
                "eta_squared": finite_or_none(eta_squared),
                "omega_squared": finite_or_none(omega_squared),
            }
        )
    else:
        if np.any(variances <= 0):
            result.update(
                status="not_run",
                reason="Welch's ANOVA requires positive variance in every group",
            )
            return result

        weights = counts / variances
        weight_sum = float(np.sum(weights))
        weighted_mean = float(np.sum(weights * means) / weight_sum)
        weighted_between = float(
            np.sum(weights * (means - weighted_mean) ** 2) / numerator_df
        )
        adjustment_sum = float(
            np.sum((1.0 - weights / weight_sum) ** 2 / (counts - 1.0))
        )
        correction = 1.0 + (
            2.0 * (group_count - 2.0) / (group_count**2 - 1.0)
        ) * adjustment_sum
        statistic = weighted_between / correction
        denominator_df = float(
            (group_count**2 - 1.0) / (3.0 * adjustment_sum)
        )
        p_value = float(
            scipy_stats.f.sf(statistic, numerator_df, denominator_df)
        )

    result.update(
        {
            "status": "completed",
            "null_hypothesis": "all group means are equal",
            "statistic": finite_or_none(statistic),
            "degrees_of_freedom_numerator": finite_or_none(numerator_df),
            "degrees_of_freedom_denominator": finite_or_none(denominator_df),
            "p_value": finite_or_none(p_value),
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result

