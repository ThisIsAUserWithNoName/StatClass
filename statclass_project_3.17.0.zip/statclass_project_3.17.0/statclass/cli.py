"""Command-line interface and analysis orchestration."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from . import __version__
from .anova import one_way_anova
from .advanced_regression import (
    AdvancedRegressionError,
    isotonic_regression,
    kernel_density_estimation,
    kernel_regression,
    loess_regression,
    regression_spline,
    regularized_linear_regression,
    robust_linear_regression,
    smoothing_spline,
)
from .association import CORRELATION_METHODS, correlation_tests
from .bayesian import (
    BayesError,
    beta_binomial_analysis,
    gamma_poisson_analysis,
    normal_inverse_gamma_analysis,
    normal_known_variance_analysis,
)
from .calculators import (
    CalculatorError,
    DISTRIBUTION_PARAMETER_GUIDE,
    SUPPORTED_DISTRIBUTIONS,
    distribution_density,
    distribution_info,
    distribution_interval_probability,
    distribution_probability,
    distribution_quantile,
    mean_confidence_interval,
    poisson_rate_confidence_interval,
    proportion_confidence_interval,
    variance_confidence_interval,
)
from .categorical import (
    chi_square_goodness_of_fit,
    chi_square_independence,
    contingency_table,
    fisher_exact_test,
    frequency_table,
)
from .data import (
    DataError,
    delimiter_label,
    flatten_column_arguments,
    load_dataset,
    resolve_column,
    resolve_columns,
)
from .descriptives import normality_tests, summary_statistics
from .dependencies import dependency_report
from .discrete_estimation import (
    DiscreteEstimationError,
    beta_binomial_estimation,
    binomial_estimation,
    discrete_uniform_estimation,
    geometric_estimation,
    geometric_summary_estimation,
    hypergeometric_estimation,
    multinomial_count_estimation,
    multinomial_estimation,
    negative_binomial_joint_estimation,
    negative_binomial_known_r_estimation,
    negative_binomial_known_r_summary_estimation,
    poisson_estimation,
    poisson_summary_estimation,
)
from .factorial import factorial_anova_ancova
from .inference import (
    one_sample_t_test,
    one_sample_z_test,
    paired_t_test,
    two_sample_t_test,
)
from .logistic import (
    binary_logistic_regression,
    multinomial_logistic_regression,
)
from .longitudinal import (
    random_intercept_mixed_model,
    repeated_measures_anova,
)
from .multiple_regression import (
    compare_regression_models,
    multiple_linear_regression,
)
from .multivariate import (
    linear_discriminant_analysis,
    one_way_manova,
    principal_component_analysis,
)
from .negative_binomial import negative_binomial_regression
from .nonparametric import (
    P_VALUE_ADJUSTMENTS,
    kruskal_wallis_test,
    mann_whitney_u_test,
    wilcoxon_signed_rank_test,
)
from .poisson import poisson_mean_confidence_interval, poisson_regression
from .plotting import PLOT_TYPES, generate_bayesian_plots, generate_plots
from .power import (
    PowerError,
    one_proportion_detectable_effect,
    one_proportion_power,
    one_proportion_sample_size,
    one_sample_mean_detectable_effect,
    one_sample_mean_power,
    one_sample_mean_sample_size,
    one_way_anova_detectable_effect,
    one_way_anova_power,
    one_way_anova_sample_size,
    two_proportion_detectable_effect,
    two_proportion_power,
    two_proportion_sample_size,
    two_sample_mean_detectable_effect,
    two_sample_mean_power,
    two_sample_mean_sample_size,
)
from .proportions import (
    binomial_likelihood_analysis,
    binomial_likelihood_counts_analysis,
    category_matches,
    one_proportion_counts_test,
    one_proportion_test,
    two_proportion_counts_test,
    two_proportion_test,
)
from .regression import simple_linear_regression
from .resampling import (
    BOOTSTRAP_INTERVAL_METHODS,
    BOOTSTRAP_STATISTICS,
    PERMUTATION_CORRELATIONS,
    PERMUTATION_STATISTICS,
    bootstrap_independent_difference,
    bootstrap_one_sample,
    permutation_correlation,
    permutation_paired,
    permutation_two_sample,
)
from .reporting import build_text_report
from .summary_inference import (
    one_sample_summary_t_test,
    one_sample_summary_z_test,
    paired_summary_t_test,
    two_sample_summary_t_test,
)
from .transformations import (
    OUTLIER_METHODS,
    STANDARDIZATION_METHODS,
    TRANSFORMATION_METHODS,
    TransformationError,
    outlier_diagnostics,
    standardize_series,
    transform_series,
)
from .utils import (
    MAX_OUTPUT_PRECISION,
    MIN_OUTPUT_PRECISION,
    make_json_safe,
    set_output_precision,
)


def _alpha_value(value: str) -> float:
    """Parse a finite significance level strictly between zero and one."""
    try:
        alpha = float(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            "--alpha must be a finite number strictly between 0 and 1"
        ) from exc
    if not math.isfinite(alpha) or not 0.0 < alpha < 1.0:
        raise argparse.ArgumentTypeError(
            "--alpha must be a finite number strictly between 0 and 1"
        )
    return alpha


def _precision_value(value: str) -> int:
    """Parse the number of decimal places used in text reports."""
    try:
        precision = int(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            f"--precision must be an integer from {MIN_OUTPUT_PRECISION} "
            f"through {MAX_OUTPUT_PRECISION}"
        ) from exc
    if not MIN_OUTPUT_PRECISION <= precision <= MAX_OUTPUT_PRECISION:
        raise argparse.ArgumentTypeError(
            f"--precision must be an integer from {MIN_OUTPUT_PRECISION} "
            f"through {MAX_OUTPUT_PRECISION}"
        )
    return precision


class _ShowDependencies(argparse.Action):
    """Print installed dependency versions and exit successfully."""

    def __call__(
        self,
        parser: argparse.ArgumentParser,
        namespace: argparse.Namespace,
        values: Any,
        option_string: str | None = None,
    ) -> None:
        parser.exit(message=dependency_report())


class _ShowDistributions(argparse.Action):
    """Print supported distribution names and parameter order, then exit."""

    def __call__(
        self,
        parser: argparse.ArgumentParser,
        namespace: argparse.Namespace,
        values: Any,
        option_string: str | None = None,
    ) -> None:
        discrete = {
            "bernoulli",
            "binomial",
            "discrete-uniform",
            "geometric",
            "hypergeometric",
            "negative-binomial",
            "poisson",
            "beta-binomial",
        }
        lines = ["StatClass supported distributions", "", "Discrete:"]
        lines.extend(
            f"  {name}: {DISTRIBUTION_PARAMETER_GUIDE[name]}"
            for name in SUPPORTED_DISTRIBUTIONS
            if name in discrete
        )
        lines.extend(["", "Continuous:"])
        lines.extend(
            f"  {name}: {DISTRIBUTION_PARAMETER_GUIDE[name]}"
            for name in SUPPORTED_DISTRIBUTIONS
            if name not in discrete
        )
        sys.stdout.write("\n".join(lines) + "\n")
        parser.exit()


def build_parser() -> argparse.ArgumentParser:
    examples = """examples:
  %(prog)s --dependencies
  %(prog)s --distributions
  %(prog)s --binomial-likelihood-counts 30 100 --likelihood-p .3
  %(prog)s --poisson-count 8
  %(prog)s --one-proportion-counts 30 100 --p0 .25
  %(prog)s --two-proportion-counts 30 100 45 120
  %(prog)s --one-sample-summary 25 72.4 11.8 --mu 70
  %(prog)s --z-summary 100 102.5 15 --mu 100
  %(prog)s --two-sample-summary 50 10.2 2.1 45 9.4 2.3
  %(prog)s --paired-summary 30 2.4 5.1 --mu 0
  %(prog)s --estimate-binomial-summary 37 100 .4
  %(prog)s --estimate-poisson-summary 25 119 5
  %(prog)s --estimate-multinomial-counts red=12 blue=9 green=4
  %(prog)s --distribution-probability binomial eq 8 20 .3
  %(prog)s --distribution-probability poisson ge 8 5
  %(prog)s --distribution-probability normal le 1.96 0 1
  %(prog)s --distribution-interval normal -1.96 1.96 0 1
  %(prog)s --distribution-quantile t .975 20
  %(prog)s --distribution-quantile chi-square .95 6
  %(prog)s --distribution-density gamma 4 2 3
  %(prog)s --distribution-info geometric .25
  %(prog)s --distribution-probability hypergeometric eq 4 100 30 10
  %(prog)s --distribution-quantile beta .95 2 5
  %(prog)s --mean-ci 25 72.4 11.8
  %(prog)s --mean-ci-z 100 102.5 15
  %(prog)s --proportion-ci 30 100
  %(prog)s --variance-ci 25 139.24
  %(prog)s --poisson-rate-ci 8 1000
  %(prog)s --power-one-mean 50 .5
  %(prog)s --sample-size-one-mean .5 .80
  %(prog)s --power-paired-mean 30 .5
  %(prog)s --power-two-means 40 40 .6
  %(prog)s --sample-size-two-means .6 .80 --allocation-ratio 1.5
  %(prog)s --power-one-proportion 100 .30 .20
  %(prog)s --sample-size-two-proportions .30 .45 .80
  %(prog)s --power-anova 4 25 .25
  %(prog)s --detectable-effect-anova 4 25 .80
  %(prog)s --bayes-binomial 30 100 1 1
  %(prog)s --bayes-poisson 8 1 1 1
  %(prog)s --bayes-normal-known 25 72.4 15 70 10
  %(prog)s --bayes-normal-unknown 25 72.4 11.8 70 1 2 100
  %(prog)s data.csv
  %(prog)s data.csv --columns 1 3
  %(prog)s data.csv --one-sample pressure --mu 100
  %(prog)s data.csv --z-test pressure 15 --mu 100
  %(prog)s data.csv --two-sample control treatment
  %(prog)s data.csv --paired before after
  %(prog)s data.csv --anova control treatment_1 treatment_2
  %(prog)s data.csv --mann-whitney control treatment
  %(prog)s data.csv --wilcoxon before after
  %(prog)s data.csv --kruskal control treatment_1 treatment_2 --posthoc
  %(prog)s data.csv --bootstrap pressure mean --bootstrap-method bca
  %(prog)s data.csv --bootstrap-difference control treatment median
  %(prog)s data.csv --permutation-two-sample control treatment mean
  %(prog)s data.csv --permutation-paired before after mean
  %(prog)s data.csv --permutation-correlation height weight spearman
  %(prog)s data.csv --correlation height weight
  %(prog)s data.csv --correlation x y --correlation-method spearman
  %(prog)s data.csv --regression outcome predictor
  %(prog)s data.csv --multiple-regression outcome age baseline group
  %(prog)s data.csv --multiple-regression outcome age group --categorical-predictors group
  %(prog)s data.csv --multiple-regression y x1 --multiple-regression y x1 x2 --compare-models
  %(prog)s data.csv --logistic purchased income age group --event Yes
  %(prog)s data.csv --multinomial-logistic risk income age group --outcome-reference Low
  %(prog)s data.csv --poisson visits exposure group
  %(prog)s data.csv --negative-binomial claims age group --exposure insured_years
  %(prog)s diabetes.csv --bayes-binomial-column diabetes Yes 1 1
  %(prog)s counts.csv --bayes-poisson-column events 1 1
  %(prog)s data.csv --bayes-normal-known-column pressure 15 100 20
  %(prog)s data.csv --bayes-normal-unknown-column pressure 100 1 2 100
  %(prog)s data.csv --transform pressure log --save-transformed transformed.csv
  %(prog)s data.csv --transform pressure box-cox --transform temperature power 2
  %(prog)s data.csv --standardize pressure z-score --standardize age robust
  %(prog)s data.csv --outliers pressure all --save-transformed diagnostics.csv
  %(prog)s multivariate_sample.csv --pca x1 x2 x3 x4
  %(prog)s multivariate_sample.csv --manova group x1 x2 x3 x4
  %(prog)s multivariate_sample.csv --discriminant group x1 x2 x3 x4
  %(prog)s data.csv --multiple-regression y x group --polynomial x 2 --interaction x group
  %(prog)s factorial_sample.csv --two-way-anova score method setting
  %(prog)s factorial_sample.csv --ancova score method setting baseline
  %(prog)s longitudinal_sample.csv --repeated-measures outcome subject time
  %(prog)s longitudinal_sample.csv --mixed-effects outcome subject time_index treatment --categorical-predictors treatment
  %(prog)s data.csv --multiple-regression y x1 x2 --save-predictions fitted.csv --save-residuals residuals.csv
  %(prog)s data.csv --plot histogram pressure --plot qq pressure --plot-dir plots
  %(prog)s data.csv --plot scatter height weight --plot correlation height weight age
  %(prog)s regression_sample.csv --multiple-regression Outcome X1 X2 Group --model-plots --plot-dir plots
  %(prog)s survey.csv --frequency response
  %(prog)s survey.csv --crosstab treatment outcome
  %(prog)s survey.csv --chi-square treatment outcome
  %(prog)s survey.csv --goodness-of-fit color --expected .4 .35 .25
  %(prog)s survey.csv --fisher-exact treatment outcome
  %(prog)s survey.csv --binomial-likelihood outcome --success Yes --likelihood-p .3 .5
  %(prog)s survey.csv --one-proportion outcome --success Yes --p0 .5
  %(prog)s survey.csv --two-proportion treatment outcome --success Yes
  %(prog)s survey.csv --estimate-bernoulli outcome Yes .5
  %(prog)s grouped.csv --estimate-binomial successes trials .4
  %(prog)s counts.csv --estimate-poisson events 5
  %(prog)s counts.csv --estimate-negative-binomial failures auto
  %(prog)s survey.csv --estimate-multinomial response
  %(prog)s data.csv --paired before after --correlation before after --json report.json

Column references may be 1-based positions or header names. Numerical procedures
use positions among numeric columns; categorical procedures use all columns.
Missing values are removed separately for independent samples and rowwise for
paired tests, Wilcoxon tests, correlations, and regression. For --z-test,
SIGMA is the known population standard deviation. One --mu value applies to
every requested one-sample t-test, z-test, and paired-summary test. --success
identifies the outcome
counted as a success for binomial likelihood and proportion analyses. --posthoc
adds Dunn pairwise tests to each Kruskal-Wallis analysis. In
--multiple-regression, the dependent
variable is first. Text predictors are coded categorically automatically;
--categorical-predictors can also mark numeric codes as categorical. Binary
logistic regression requires --event. Multinomial logistic regression uses the
first observed outcome category as its reference unless --outcome-reference is
specified. --polynomial adds raw powers through DEGREE (2-5), and --interaction
adds all cross-products between two included predictors. These terms apply to
compatible multiple, logistic, multinomial, Poisson, and negative-binomial
models, as well as Gaussian random-intercept mixed models. --two-way-anova and
--ancova include the factor interaction, Type III partial tests, estimated
marginal means, and adjusted pairwise comparisons. --repeated-measures expects
one row per subject and within-factor level. --mixed-effects fits a Gaussian
random-intercept model, with the grouping column listed after the outcome.
Count outcomes must be nonnegative integers. --offset supplies a known log
exposure; --exposure supplies a positive exposure that is logged automatically.
Discrete-estimation commands report model-specific MLEs, standard errors,
likelihood information, and exact, score, profile, or Wald inference where
mathematically appropriate. Discrete support parameters are not given Wald
intervals. Summary forms use sufficient statistics and require no input file.
No-file distribution commands support 22 discrete and continuous families;
use --distributions to show their parameter order. Relations are eq, le, lt,
ge, and gt; eq is available only for discrete distributions. Quantiles use
lower-tail cumulative probabilities. --distribution-density evaluates a PMF
or PDF. --distribution-info reports parameterization, support, mean, variance,
standard deviation, and MGF information. Distribution and direct confidence-
interval commands may be repeated and combined in one calculation report.
No-file power commands use noncentral t distributions for one-sample, paired,
and equal-variance independent means; normal approximations for proportions;
and a noncentral F distribution for balanced one-way ANOVA. They calculate
power, minimum integer sample sizes, or detectable effects. Mean effect sizes
are Cohen's d (or dz for pairs); ANOVA uses Cohen's f. --allocation-ratio is
N2/N1 for two-group sample-size calculations.
Bayesian conjugate commands support beta-binomial, shape-rate gamma-Poisson,
normal-normal with known variance, and normal-inverse-gamma models. They report
posterior parameters, equal-tail credible intervals, and posterior predictive
distributions. The corresponding --bayes-*-column commands analyze CSV data.
--bayes-plots saves prior-versus-posterior density plots without opening a window.
--transform supports log, log10, square root, reciprocal, power, Box-Cox, and
Yeo-Johnson transformations. --standardize supports z-score, min-max, robust
median/IQR scaling, and mean centering. --outliers supports ordinary z-scores,
modified z-scores, Tukey IQR fences, or all three. Derived values and outlier
flags can be appended to the original data with --save-transformed.
--pca analyzes two or more numeric variables using the correlation matrix by
default; --pca-no-standardize uses the covariance matrix. --manova performs a
one-way multivariate test of group mean vectors. --discriminant fits linear
discriminant analysis with empirical or equal class priors and leave-one-out
cross-validation. PCA scores and discriminant predictions can be exported.
--plot may be repeated for histograms, Q-Q plots, boxplots, grouped boxplots,
scatterplots, and correlation heatmaps. --model-plots creates plots appropriate
to each successfully fitted model. Plots are saved without opening windows.
Bootstrap confidence intervals support mean, median, and standard-deviation
statistics with percentile, basic, or BCa limits. Permutation tests support
independent samples, paired sign flips, and Pearson or Spearman correlation.
The default random seed makes Monte Carlo results reproducible.
"""
    parser = argparse.ArgumentParser(
        description=(
            "Compute descriptive statistics, mean tests, ANOVA, correlations, "
            "regression, categorical tables, chi-square tests, Fisher's exact "
            "test, binomial likelihood, summary-data inference, distribution "
            "probabilities and quantiles, discrete-distribution estimation, "
            "direct confidence intervals, power "
            "and sample-size analysis, Bayesian conjugate models, proportion "
            "tests, rank-based tests, "
            "data transformations, standardization, outlier diagnostics, "
            "principal component analysis, MANOVA, discriminant analysis, "
            "model comparisons, factorial ANOVA and ANCOVA, "
            "estimated marginal means, logistic and count regression, "
            "repeated-measures ANOVA, random-intercept mixed models, and "
            "file-based statistical graphics, bootstrap confidence intervals, "
            "and permutation tests."
        ),
        epilog=examples,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "input_file",
        nargs="?",
        type=Path,
        help=(
            "tabular input data file; omit with a no-file summary, "
            "aggregate-count, distribution, discrete-estimation, confidence-"
            "interval, power, or Bayesian command"
        ),
    )
    parser.add_argument(
        "--columns",
        nargs="+",
        metavar="COLUMN",
        help=(
            "columns to summarize and test for normality; use 1-based numbers "
            "or names (default: every numeric column)"
        ),
    )
    parser.add_argument(
        "--one-sample",
        action="append",
        default=[],
        metavar="COLUMN",
        help="run a one-sample t-test for COLUMN; may be repeated",
    )
    parser.add_argument(
        "--one-sample-summary",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("N", "MEAN", "SD"),
        help=(
            "run a one-sample t-test from sample size, mean, and sample "
            "standard deviation without an input file; may be repeated"
        ),
    )
    parser.add_argument(
        "--mu",
        type=float,
        default=0.0,
        help=(
            "null mean or paired difference for one-sample, z, and paired "
            "summary tests (default: 0)"
        ),
    )
    parser.add_argument(
        "--z-test",
        action="append",
        nargs=2,
        default=[],
        metavar=("COLUMN", "SIGMA"),
        help=(
            "run a one-sample population-mean z-test using known positive "
            "population standard deviation SIGMA; may be repeated"
        ),
    )
    parser.add_argument(
        "--z-summary",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("N", "MEAN", "SIGMA"),
        help=(
            "run a population-mean z-test from sample size, mean, and known "
            "population standard deviation without an input file; may be repeated"
        ),
    )
    parser.add_argument(
        "--two-sample",
        action="append",
        nargs=2,
        default=[],
        metavar=("COLUMN_1", "COLUMN_2"),
        help=(
            "compare two independent-sample columns; may be repeated "
            "(default: Welch's t-test)"
        ),
    )
    parser.add_argument(
        "--two-sample-summary",
        action="append",
        nargs=6,
        type=float,
        default=[],
        metavar=("N1", "MEAN1", "SD1", "N2", "MEAN2", "SD2"),
        help=(
            "compare two independent samples from their sizes, means, and "
            "sample standard deviations; may be repeated"
        ),
    )
    parser.add_argument(
        "--paired",
        action="append",
        nargs=2,
        default=[],
        metavar=("COLUMN_1", "COLUMN_2"),
        help="run a paired-sample t-test; may be repeated",
    )
    parser.add_argument(
        "--paired-summary",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("N", "MEAN_DIFFERENCE", "SD_DIFFERENCE"),
        help=(
            "run a paired t-test from the size, mean, and sample standard "
            "deviation of the pairwise differences; may be repeated"
        ),
    )
    parser.add_argument(
        "--anova",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "compare three or more independent columns with one-way ANOVA; "
            "may be repeated (default: Welch's ANOVA)"
        ),
    )
    parser.add_argument(
        "--equal-variance",
        action="store_true",
        help=(
            "use Student's independent t-test and classical one-way ANOVA "
            "instead of the corresponding Welch tests, including summary data"
        ),
    )
    parser.add_argument(
        "--mann-whitney",
        action="append",
        nargs=2,
        default=[],
        metavar=("COLUMN_1", "COLUMN_2"),
        help=(
            "compare two independent columns with the Mann-Whitney U test; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--wilcoxon",
        action="append",
        nargs=2,
        default=[],
        metavar=("COLUMN_1", "COLUMN_2"),
        help="compare paired columns with the Wilcoxon signed-rank test; may be repeated",
    )
    parser.add_argument(
        "--kruskal",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "compare three or more independent columns with the Kruskal-Wallis "
            "test; may be repeated"
        ),
    )
    parser.add_argument(
        "--posthoc",
        action="store_true",
        help="add pairwise Dunn tests after each requested Kruskal-Wallis test",
    )
    parser.add_argument(
        "--posthoc-adjust",
        choices=P_VALUE_ADJUSTMENTS,
        default="holm",
        help="multiple-testing adjustment for Dunn tests (default: holm)",
    )
    parser.add_argument(
        "--bootstrap",
        action="append",
        nargs=2,
        default=[],
        metavar=("COLUMN", "STATISTIC"),
        help=(
            "bootstrap a mean, median, or standard-deviation confidence interval; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--bootstrap-difference",
        action="append",
        nargs=3,
        default=[],
        metavar=("COLUMN_1", "COLUMN_2", "STATISTIC"),
        help=(
            "bootstrap the independent-sample difference in means, medians, or "
            "standard deviations; may be repeated"
        ),
    )
    parser.add_argument(
        "--bootstrap-method",
        choices=BOOTSTRAP_INTERVAL_METHODS,
        default="bca",
        help="bootstrap confidence-interval method (default: bca)",
    )
    parser.add_argument(
        "--permutation-two-sample",
        action="append",
        nargs=3,
        default=[],
        metavar=("COLUMN_1", "COLUMN_2", "STATISTIC"),
        help=(
            "permutation test for an independent difference in means or medians; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--permutation-paired",
        action="append",
        nargs=3,
        default=[],
        metavar=("COLUMN_1", "COLUMN_2", "STATISTIC"),
        help=(
            "paired sign-flip permutation test for a mean or median difference; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--permutation-correlation",
        action="append",
        nargs=3,
        default=[],
        metavar=("COLUMN_1", "COLUMN_2", "METHOD"),
        help=(
            "permutation test for Pearson or Spearman correlation; may be repeated"
        ),
    )
    parser.add_argument(
        "--resamples",
        type=int,
        default=10000,
        metavar="NUMBER",
        help=(
            "bootstrap resamples or requested permutations, from 100 through "
            "1000000 (default: 10000)"
        ),
    )
    parser.add_argument(
        "--random-seed",
        "--seed",
        type=int,
        default=12345,
        metavar="INTEGER",
        help="nonnegative seed for reproducible resampling (default: 12345)",
    )
    parser.add_argument(
        "--correlation",
        action="append",
        nargs=2,
        default=[],
        metavar=("COLUMN_1", "COLUMN_2"),
        help="analyze association between two columns; may be repeated",
    )
    parser.add_argument(
        "--correlation-method",
        choices=("all",) + CORRELATION_METHODS,
        default="all",
        help="correlation method to run (default: all three methods)",
    )
    parser.add_argument(
        "--regression",
        action="append",
        nargs=2,
        default=[],
        metavar=("DEPENDENT", "INDEPENDENT"),
        help="fit simple linear regression DEPENDENT = f(INDEPENDENT); may be repeated",
    )
    parser.add_argument(
        "--multiple-regression",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "fit DEPENDENT using one or more PREDICTOR columns, with the "
            "dependent variable listed first; may be repeated"
        ),
    )
    parser.add_argument(
        "--robust-regression",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "fit Huber robust regression with DEPENDENT first and one or more "
            "numeric PREDICTOR columns; may be repeated"
        ),
    )
    parser.add_argument(
        "--robust-tuning",
        type=float,
        default=1.345,
        metavar="POSITIVE_NUMBER",
        help="Huber tuning constant (default: 1.345)",
    )
    parser.add_argument(
        "--robust-max-iterations",
        type=int,
        default=100,
        metavar="INTEGER",
        help="maximum Huber IRLS iterations (default: 100)",
    )
    parser.add_argument(
        "--regularized-regression",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "fit METHOD DEPENDENT PREDICTOR... where METHOD is ridge, lasso, "
            "or elastic-net; may be repeated"
        ),
    )
    parser.add_argument(
        "--regularization-strength",
        "--regularization-alpha",
        dest="regularization_strength",
        type=float,
        metavar="POSITIVE_NUMBER",
        help=(
            "penalty strength for regularized regression; default selects it "
            "by cross-validation"
        ),
    )
    parser.add_argument(
        "--elastic-net-l1-ratio",
        type=float,
        default=0.5,
        metavar="PROPORTION",
        help="elastic-net L1 fraction strictly between 0 and 1 (default: .5)",
    )
    parser.add_argument(
        "--cv-folds",
        type=int,
        default=5,
        metavar="INTEGER",
        help="cross-validation folds for regularized regression (default: 5)",
    )
    parser.add_argument(
        "--regression-spline",
        action="append",
        nargs=2,
        default=[],
        metavar=("DEPENDENT", "INDEPENDENT"),
        help="fit a cubic regression spline; may be repeated",
    )
    parser.add_argument(
        "--smoothing-spline",
        action="append",
        nargs=2,
        default=[],
        metavar=("DEPENDENT", "INDEPENDENT"),
        help="fit a roughness-penalized cubic smoothing spline; may be repeated",
    )
    parser.add_argument(
        "--spline-knots",
        type=int,
        default=5,
        metavar="INTEGER",
        help="requested interior knots for regression and smoothing splines (default: 5)",
    )
    parser.add_argument(
        "--smoothing-lambda",
        type=float,
        metavar="NONNEGATIVE_NUMBER",
        help="smoothing-spline penalty strength; default selects it by GCV",
    )
    parser.add_argument(
        "--loess",
        action="append",
        nargs=2,
        default=[],
        metavar=("DEPENDENT", "INDEPENDENT"),
        help="fit one-dimensional LOESS; may be repeated",
    )
    parser.add_argument(
        "--loess-span",
        type=float,
        default=0.75,
        metavar="PROPORTION",
        help="LOESS neighborhood fraction strictly between 0 and 1 (default: .75)",
    )
    parser.add_argument(
        "--loess-degree",
        type=int,
        choices=(1, 2),
        default=1,
        help="LOESS local polynomial degree (default: 1)",
    )
    parser.add_argument(
        "--loess-robust-iterations",
        type=int,
        default=2,
        metavar="INTEGER",
        help="LOESS robust bisquare reweighting iterations (default: 2)",
    )
    parser.add_argument(
        "--kernel-regression",
        action="append",
        nargs=2,
        default=[],
        metavar=("DEPENDENT", "INDEPENDENT"),
        help="fit Gaussian Nadaraya-Watson kernel regression; may be repeated",
    )
    parser.add_argument(
        "--kernel-bandwidth",
        type=float,
        metavar="POSITIVE_NUMBER",
        help="kernel-regression bandwidth; default selects it by leave-one-out CV",
    )
    parser.add_argument(
        "--isotonic-regression",
        action="append",
        nargs=2,
        default=[],
        metavar=("DEPENDENT", "INDEPENDENT"),
        help="fit least-squares monotone regression; may be repeated",
    )
    parser.add_argument(
        "--isotonic-direction",
        choices=("auto", "increasing", "decreasing"),
        default="auto",
        help="isotonic direction; auto chooses the smaller training RSS (default: auto)",
    )
    parser.add_argument(
        "--kernel-density",
        action="append",
        default=[],
        metavar="COLUMN",
        help="estimate a univariate Gaussian kernel density; may be repeated",
    )
    parser.add_argument(
        "--kde-bandwidth",
        choices=("cv", "scott", "silverman"),
        default="cv",
        help="KDE bandwidth selection method (default: cv)",
    )
    parser.add_argument(
        "--kde-grid-size",
        type=int,
        default=200,
        metavar="INTEGER",
        help="number of reported KDE grid points, from 50 through 2000 (default: 200)",
    )
    parser.add_argument(
        "--categorical-predictors",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "predictors to reference-code as categorical; text predictors are "
            "detected automatically"
        ),
    )
    parser.add_argument(
        "--compare-models",
        action="store_true",
        help=(
            "compare adjacent --multiple-regression models on common cases; "
            "nested models also receive a partial F-test"
        ),
    )
    parser.add_argument(
        "--logistic",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "fit binary logistic regression with OUTCOME first and one or more "
            "predictors after it; requires --event; may be repeated"
        ),
    )
    parser.add_argument(
        "--event",
        metavar="VALUE",
        help="outcome category modeled as the event by --logistic",
    )
    parser.add_argument(
        "--classification-threshold",
        type=float,
        default=0.5,
        metavar="PROBABILITY",
        help="event-probability cutoff for binary classification (default: 0.5)",
    )
    parser.add_argument(
        "--multinomial-logistic",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "fit multinomial logistic regression with OUTCOME first and one "
            "or more predictors after it; may be repeated"
        ),
    )
    parser.add_argument(
        "--outcome-reference",
        metavar="VALUE",
        help=(
            "baseline outcome category for --multinomial-logistic "
            "(default: first observed category)"
        ),
    )
    parser.add_argument(
        "--poisson",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "fit Poisson count regression with OUTCOME first and one or more "
            "predictors after it; may be repeated"
        ),
    )
    parser.add_argument(
        "--negative-binomial",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "fit NB2 negative-binomial count regression with OUTCOME first "
            "and one or more predictors after it; may be repeated"
        ),
    )
    parser.add_argument(
        "--offset",
        metavar="COLUMN",
        help=(
            "known log-exposure column for every requested Poisson and "
            "negative-binomial model"
        ),
    )
    parser.add_argument(
        "--exposure",
        metavar="COLUMN",
        help=(
            "positive exposure column for every requested Poisson and "
            "negative-binomial model; its natural logarithm is used as an offset"
        ),
    )
    parser.add_argument(
        "--polynomial",
        action="append",
        nargs=2,
        default=[],
        metavar=("COLUMN", "DEGREE"),
        help=(
            "add raw powers COLUMN^2 through COLUMN^DEGREE to compatible "
            "regression models; DEGREE must be 2-5; may be repeated"
        ),
    )
    parser.add_argument(
        "--interaction",
        action="append",
        nargs=2,
        default=[],
        metavar=("COLUMN_1", "COLUMN_2"),
        help=(
            "add the interaction between two included predictors to compatible "
            "regression models; may be repeated"
        ),
    )
    parser.add_argument(
        "--two-way-anova",
        action="append",
        nargs=3,
        default=[],
        metavar=("OUTCOME", "FACTOR_1", "FACTOR_2"),
        help=(
            "fit a two-factor ANOVA with interaction, Type III tests, marginal "
            "means, and adjusted comparisons; may be repeated"
        ),
    )
    parser.add_argument(
        "--ancova",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "fit OUTCOME using FACTOR_1, FACTOR_2, and one or more numeric "
            "COVARIATES; may be repeated"
        ),
    )
    parser.add_argument(
        "--emmeans-adjust",
        choices=P_VALUE_ADJUSTMENTS,
        default="holm",
        help="pairwise marginal-mean p-value adjustment (default: holm)",
    )
    parser.add_argument(
        "--repeated-measures",
        action="append",
        nargs=3,
        default=[],
        metavar=("OUTCOME", "SUBJECT", "WITHIN_FACTOR"),
        help=(
            "fit one-factor repeated-measures ANOVA to long-format data; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--mixed-effects",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "fit a Gaussian random-intercept model with OUTCOME first, GROUP "
            "second, and one or more fixed predictors after it; may be repeated"
        ),
    )
    parser.add_argument(
        "--mixed-method",
        choices=("reml", "ml"),
        default="reml",
        help="mixed-model variance estimation method (default: reml)",
    )
    parser.add_argument(
        "--frequency",
        action="append",
        default=[],
        metavar="COLUMN",
        help="create a one-way frequency table for COLUMN; may be repeated",
    )
    parser.add_argument(
        "--crosstab",
        action="append",
        nargs=2,
        default=[],
        metavar=("ROW", "COLUMN"),
        help="create a two-way contingency table; may be repeated",
    )
    parser.add_argument(
        "--chi-square",
        action="append",
        nargs=2,
        default=[],
        metavar=("ROW", "COLUMN"),
        help="run a Pearson chi-square test of independence; may be repeated",
    )
    parser.add_argument(
        "--goodness-of-fit",
        metavar="COLUMN",
        help="run a Pearson chi-square goodness-of-fit test for COLUMN",
    )
    parser.add_argument(
        "--expected",
        nargs="+",
        type=float,
        metavar="PROBABILITY",
        help=(
            "expected category probabilities for --goodness-of-fit, in the "
            "frequency-table order; values must be positive and sum to 1"
        ),
    )
    parser.add_argument(
        "--fisher-exact",
        action="append",
        nargs=2,
        default=[],
        metavar=("ROW", "COLUMN"),
        help="run Fisher's exact test on an observed 2-by-2 table; may be repeated",
    )
    parser.add_argument(
        "--one-proportion-counts",
        action="append",
        nargs=2,
        type=int,
        default=[],
        metavar=("SUCCESSES", "TRIALS"),
        help=(
            "run a one-proportion z-test and exact binomial test from "
            "aggregate counts; requires --p0; may be repeated"
        ),
    )
    parser.add_argument(
        "--two-proportion-counts",
        action="append",
        nargs=4,
        type=int,
        default=[],
        metavar=("SUCCESSES1", "TRIALS1", "SUCCESSES2", "TRIALS2"),
        help=(
            "compare two independent proportions from aggregate counts; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--poisson-count",
        "--poisson-mean-count",
        action="append",
        type=int,
        default=[],
        metavar="EVENTS",
        help=(
            "compute an exact confidence interval for a Poisson mean from "
            "an observed event count, without an input file; may be repeated"
        ),
    )
    parser.add_argument(
        "--binomial-likelihood-counts",
        action="append",
        nargs=2,
        type=int,
        default=[],
        metavar=("SUCCESSES", "TRIALS"),
        help=(
            "analyze aggregate binomial counts without an input file; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-binomial-summary",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate binomial p without a file from SUCCESSES TRIALS [P0]; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-geometric-summary",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate geometric p without a file from OBSERVATIONS "
            "TOTAL_TRIALS [P0]; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-poisson-summary",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate a Poisson mean without a file from OBSERVATIONS "
            "TOTAL_EVENTS [MEAN0]; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-negative-binomial-summary",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate negative-binomial p without a file from OBSERVATIONS "
            "TOTAL_FAILURES R [P0], with known R; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-discrete-uniform-summary",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate the discrete-uniform endpoint without a file from "
            "OBSERVATIONS SAMPLE_MAX [N0]; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-hypergeometric-count",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate population successes from one hypergeometric count: "
            "OBSERVED POPULATION_SIZE DRAWS [M0]; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-multinomial-counts",
        action="append",
        nargs="+",
        default=[],
        metavar="LABEL=COUNT",
        help=(
            "estimate multinomial probabilities without a file from two or "
            "more LABEL=COUNT values; may be repeated"
        ),
    )
    parser.add_argument(
        "--distribution-probability",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "calculate P(X RELATION VALUE) without a file: supply DISTRIBUTION, "
            "RELATION, VALUE, then distribution parameters; may be repeated"
        ),
    )
    parser.add_argument(
        "--distribution-interval",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "calculate P(LOWER <= X <= UPPER) without a file: supply "
            "DISTRIBUTION, LOWER, UPPER, then parameters; may be repeated"
        ),
    )
    parser.add_argument(
        "--distribution-quantile",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "calculate a lower-tail quantile without a file: supply "
            "DISTRIBUTION, CUMULATIVE_PROBABILITY, then parameters; may be repeated"
        ),
    )
    parser.add_argument(
        "--distribution-density",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "evaluate a PMF or PDF without a file: supply DISTRIBUTION, X, "
            "then distribution parameters; may be repeated"
        ),
    )
    parser.add_argument(
        "--distribution-info",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "show support, moments, and MGF information: supply DISTRIBUTION "
            "then parameters; may be repeated"
        ),
    )
    parser.add_argument(
        "--bayes-binomial",
        action="append",
        nargs=4,
        type=float,
        default=[],
        metavar=("SUCCESSES", "TRIALS", "PRIOR_ALPHA", "PRIOR_BETA"),
        help=(
            "beta-binomial update from counts without a file; may be repeated"
        ),
    )
    parser.add_argument(
        "--bayes-poisson",
        action="append",
        nargs=4,
        type=float,
        default=[],
        metavar=("EVENTS", "EXPOSURE", "PRIOR_SHAPE", "PRIOR_RATE"),
        help=(
            "shape-rate gamma-Poisson update from aggregate events and exposure; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--bayes-normal-known",
        action="append",
        nargs=5,
        type=float,
        default=[],
        metavar=("N", "MEAN", "SIGMA", "PRIOR_MEAN", "PRIOR_SD"),
        help=(
            "normal-normal update for a mean with known population SD; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--bayes-normal-unknown",
        action="append",
        nargs=7,
        type=float,
        default=[],
        metavar=(
            "N",
            "MEAN",
            "SD",
            "PRIOR_MEAN",
            "PRIOR_KAPPA",
            "PRIOR_ALPHA",
            "PRIOR_BETA",
        ),
        help=(
            "normal-inverse-gamma update for an unknown mean and variance; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--bayes-binomial-column",
        action="append",
        nargs=4,
        default=[],
        metavar=("COLUMN", "SUCCESS", "PRIOR_ALPHA", "PRIOR_BETA"),
        help="beta-binomial update from a categorical data column; may be repeated",
    )
    parser.add_argument(
        "--bayes-poisson-column",
        action="append",
        nargs=3,
        default=[],
        metavar=("COUNT_COLUMN", "PRIOR_SHAPE", "PRIOR_RATE"),
        help="gamma-Poisson update from a count column; may be repeated",
    )
    parser.add_argument(
        "--bayes-poisson-exposure-column",
        metavar="COLUMN",
        help=(
            "positive exposure column used by every --bayes-poisson-column "
            "analysis (default: one unit per row)"
        ),
    )
    parser.add_argument(
        "--bayes-normal-known-column",
        action="append",
        nargs=4,
        default=[],
        metavar=("COLUMN", "SIGMA", "PRIOR_MEAN", "PRIOR_SD"),
        help="normal-normal update from a numeric column; may be repeated",
    )
    parser.add_argument(
        "--bayes-normal-unknown-column",
        action="append",
        nargs=5,
        default=[],
        metavar=(
            "COLUMN",
            "PRIOR_MEAN",
            "PRIOR_KAPPA",
            "PRIOR_ALPHA",
            "PRIOR_BETA",
        ),
        help="normal-inverse-gamma update from a numeric column; may be repeated",
    )
    parser.add_argument(
        "--bayes-future-trials",
        type=int,
        default=1,
        metavar="NUMBER",
        help="future binomial trials for posterior prediction (default: 1)",
    )
    parser.add_argument(
        "--bayes-future-exposure",
        type=float,
        default=1.0,
        metavar="AMOUNT",
        help="future Poisson exposure for posterior prediction (default: 1)",
    )
    parser.add_argument(
        "--bayes-plots",
        action="store_true",
        help="save prior-versus-posterior density plots for Bayesian analyses",
    )
    parser.add_argument(
        "--transform",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "transform COLUMN using METHOD and an optional parameter; methods "
            "are log, log10, sqrt, reciprocal, power, box-cox, and yeo-johnson; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--standardize",
        action="append",
        nargs=2,
        default=[],
        metavar=("COLUMN", "METHOD"),
        help=(
            "standardize COLUMN using z-score, min-max, robust, or center; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--outliers",
        action="append",
        nargs=2,
        default=[],
        metavar=("COLUMN", "METHOD"),
        help=(
            "diagnose COLUMN using z-score, modified-z-score, iqr, or all; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--outlier-z-threshold",
        type=float,
        default=3.0,
        metavar="NUMBER",
        help="absolute z-score outlier threshold (default: 3.0)",
    )
    parser.add_argument(
        "--outlier-modified-z-threshold",
        type=float,
        default=3.5,
        metavar="NUMBER",
        help="absolute modified-z outlier threshold (default: 3.5)",
    )
    parser.add_argument(
        "--outlier-iqr-multiplier",
        type=float,
        default=1.5,
        metavar="NUMBER",
        help="Tukey IQR fence multiplier (default: 1.5)",
    )
    parser.add_argument(
        "--save-transformed",
        type=Path,
        metavar="FILE",
        help=(
            "save the original data with requested transformed, standardized, "
            "and outlier-flag columns appended"
        ),
    )
    parser.add_argument(
        "--pca",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "run principal component analysis on two or more numeric columns; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--pca-components",
        type=int,
        metavar="NUMBER",
        help="number of principal components to retain (default: all available)",
    )
    parser.add_argument(
        "--pca-no-standardize",
        action="store_true",
        help="use the covariance matrix instead of standardized PCA",
    )
    parser.add_argument(
        "--save-pca-scores",
        type=Path,
        metavar="FILE",
        help="write complete-case principal component scores to a CSV file",
    )
    parser.add_argument(
        "--manova",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "run one-way MANOVA with GROUP first and at least two numeric "
            "responses after it; may be repeated"
        ),
    )
    parser.add_argument(
        "--discriminant",
        "--lda",
        action="append",
        nargs="+",
        default=[],
        metavar="COLUMN",
        help=(
            "fit linear discriminant analysis with CLASS first and at least "
            "two numeric features after it; may be repeated"
        ),
    )
    parser.add_argument(
        "--discriminant-priors",
        choices=("empirical", "equal"),
        default="empirical",
        help="class priors for discriminant analysis (default: empirical)",
    )
    parser.add_argument(
        "--save-discriminant",
        type=Path,
        metavar="FILE",
        help=(
            "write discriminant predictions, posterior probabilities, and "
            "canonical scores to a CSV file"
        ),
    )
    parser.add_argument(
        "--mean-ci",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("N", "MEAN", "SD"),
        help="calculate a t confidence interval for a mean; may be repeated",
    )
    parser.add_argument(
        "--mean-ci-z",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("N", "MEAN", "SIGMA"),
        help=(
            "calculate a z confidence interval for a mean with known population "
            "SD; may be repeated"
        ),
    )
    parser.add_argument(
        "--proportion-ci",
        action="append",
        nargs=2,
        type=int,
        default=[],
        metavar=("SUCCESSES", "TRIALS"),
        help="calculate Wilson and exact binomial proportion CIs; may be repeated",
    )
    parser.add_argument(
        "--variance-ci",
        action="append",
        nargs=2,
        type=float,
        default=[],
        metavar=("N", "SAMPLE_VARIANCE"),
        help="calculate chi-square CIs for variance and SD; may be repeated",
    )
    parser.add_argument(
        "--poisson-rate-ci",
        action="append",
        nargs=2,
        type=float,
        default=[],
        metavar=("EVENTS", "EXPOSURE"),
        help="calculate an exact Poisson event-rate CI; may be repeated",
    )
    parser.add_argument(
        "--power-one-mean",
        action="append",
        nargs=2,
        type=float,
        default=[],
        metavar=("N", "COHEN_D"),
        help="calculate power for a one-sample t-test; may be repeated",
    )
    parser.add_argument(
        "--sample-size-one-mean",
        action="append",
        nargs=2,
        type=float,
        default=[],
        metavar=("COHEN_D", "POWER"),
        help="find the minimum N for a one-sample t-test; may be repeated",
    )
    parser.add_argument(
        "--detectable-effect-one-mean",
        action="append",
        nargs=2,
        type=float,
        default=[],
        metavar=("N", "POWER"),
        help="find detectable Cohen's d for a one-sample t-test; may be repeated",
    )
    parser.add_argument(
        "--power-paired-mean",
        action="append",
        nargs=2,
        type=float,
        default=[],
        metavar=("PAIRS", "COHEN_DZ"),
        help="calculate power for a paired t-test; may be repeated",
    )
    parser.add_argument(
        "--sample-size-paired-mean",
        action="append",
        nargs=2,
        type=float,
        default=[],
        metavar=("COHEN_DZ", "POWER"),
        help="find the minimum number of pairs for a paired t-test; may be repeated",
    )
    parser.add_argument(
        "--detectable-effect-paired-mean",
        action="append",
        nargs=2,
        type=float,
        default=[],
        metavar=("PAIRS", "POWER"),
        help="find detectable Cohen's dz for a paired t-test; may be repeated",
    )
    parser.add_argument(
        "--power-two-means",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("N1", "N2", "COHEN_D"),
        help="calculate power for two independent means; may be repeated",
    )
    parser.add_argument(
        "--sample-size-two-means",
        action="append",
        nargs=2,
        type=float,
        default=[],
        metavar=("COHEN_D", "POWER"),
        help="find group sizes for two independent means; may be repeated",
    )
    parser.add_argument(
        "--detectable-effect-two-means",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("N1", "N2", "POWER"),
        help="find detectable Cohen's d for two independent means; may be repeated",
    )
    parser.add_argument(
        "--power-one-proportion",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("N", "ACTUAL_P", "NULL_P"),
        help="calculate approximate power for one proportion; may be repeated",
    )
    parser.add_argument(
        "--sample-size-one-proportion",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("ACTUAL_P", "NULL_P", "POWER"),
        help="find the minimum N for one proportion; may be repeated",
    )
    parser.add_argument(
        "--detectable-effect-one-proportion",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("N", "NULL_P", "POWER"),
        help="find a detectable probability difference; may be repeated",
    )
    parser.add_argument(
        "--power-two-proportions",
        action="append",
        nargs=4,
        type=float,
        default=[],
        metavar=("N1", "N2", "P1", "P2"),
        help="calculate approximate power for two proportions; may be repeated",
    )
    parser.add_argument(
        "--sample-size-two-proportions",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("P1", "P2", "POWER"),
        help="find group sizes for two proportions; may be repeated",
    )
    parser.add_argument(
        "--detectable-effect-two-proportions",
        action="append",
        nargs=4,
        type=float,
        default=[],
        metavar=("N1", "N2", "BASELINE_P", "POWER"),
        help="find a detectable difference from P2 = BASELINE_P; may be repeated",
    )
    parser.add_argument(
        "--power-anova",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("GROUPS", "N_PER_GROUP", "COHEN_F"),
        help="calculate power for balanced one-way ANOVA; may be repeated",
    )
    parser.add_argument(
        "--sample-size-anova",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("GROUPS", "COHEN_F", "POWER"),
        help="find equal group size for one-way ANOVA; may be repeated",
    )
    parser.add_argument(
        "--detectable-effect-anova",
        action="append",
        nargs=3,
        type=float,
        default=[],
        metavar=("GROUPS", "N_PER_GROUP", "POWER"),
        help="find detectable Cohen's f for one-way ANOVA; may be repeated",
    )
    parser.add_argument(
        "--allocation-ratio",
        type=float,
        default=1.0,
        metavar="N2_OVER_N1",
        help=(
            "N2/N1 for two-mean or two-proportion sample-size calculations "
            "(default: 1)"
        ),
    )
    parser.add_argument(
        "--binomial-likelihood",
        action="append",
        default=[],
        metavar="COLUMN",
        help=(
            "report the binomial likelihood, log-likelihood, and MLE for "
            "COLUMN; requires --success; may be repeated"
        ),
    )
    parser.add_argument(
        "--likelihood-p",
        nargs="+",
        type=float,
        default=[],
        metavar="PROBABILITY",
        help=(
            "evaluate binomial likelihood analyses at one or more "
            "probabilities between 0 and 1"
        ),
    )
    parser.add_argument(
        "--one-proportion",
        action="append",
        default=[],
        metavar="COLUMN",
        help=(
            "run a one-proportion z-test and exact binomial test; requires "
            "--success and --p0; may be repeated"
        ),
    )
    parser.add_argument(
        "--two-proportion",
        action="append",
        nargs=2,
        default=[],
        metavar=("GROUP", "OUTCOME"),
        help=(
            "compare success proportions in the two categories of GROUP; "
            "requires --success; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-bernoulli",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate a Bernoulli probability from COLUMN SUCCESS [P0]; "
            "P0 requests Wald, score, exact, and likelihood-ratio tests; "
            "may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-binomial",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate a common binomial probability from COLUMN TRIALS [P0]; "
            "TRIALS is a positive integer or a trials-column name; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-geometric",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate geometric p from COLUMN [P0] using the trials-through-first-"
            "success parameterization; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-poisson",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate a Poisson mean from COLUMN [MEAN0], with Wald and exact "
            "Garwood intervals and optional tests; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-negative-binomial",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate a negative-binomial model from COLUMN R [P0], where R is "
            "known, or COLUMN auto to estimate R and p jointly; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-discrete-uniform",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate integer endpoint N from COLUMN [N0] for a uniform model "
            "on 1,...,N; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-hypergeometric",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "estimate population successes from COLUMN POPULATION_SIZE DRAWS "
            "[M0] by discrete likelihood; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-beta-binomial",
        action="append",
        nargs=2,
        default=[],
        metavar=("COLUMN", "TRIALS"),
        help=(
            "estimate beta-binomial alpha and beta from grouped successes; "
            "TRIALS is a positive integer or a trials-column name; may be repeated"
        ),
    )
    parser.add_argument(
        "--estimate-multinomial",
        action="append",
        default=[],
        metavar="COLUMN",
        help=(
            "estimate multinomial category probabilities with marginal and "
            "simultaneous intervals; may be repeated"
        ),
    )
    parser.add_argument(
        "--success",
        metavar="VALUE",
        help="category value counted as success in likelihood and proportion analyses",
    )
    parser.add_argument(
        "--p0",
        type=float,
        metavar="PROBABILITY",
        help=(
            "null population proportion for --one-proportion or "
            "--one-proportion-counts"
        ),
    )
    parser.add_argument(
        "--alternative",
        choices=("two-sided", "less", "greater"),
        default="two-sided",
        help=(
            "alternative hypothesis for t-tests, z-tests, proportion, discrete-"
            "estimation and power tests, Mann-Whitney, Wilcoxon, permutation "
            "tests, and Fisher's exact test (default: two-sided)"
        ),
    )
    parser.add_argument(
        "--alpha",
        type=_alpha_value,
        default=0.05,
        metavar="VALUE",
        help=(
            "finite significance level strictly between 0 and 1; confidence "
            "and credible levels equal 1 - alpha (default: 0.05)"
        ),
    )
    parser.add_argument(
        "--precision",
        type=_precision_value,
        default=6,
        metavar="INTEGER",
        help=(
            f"maximum decimal places in human-readable output, from "
            f"{MIN_OUTPUT_PRECISION} through {MAX_OUTPUT_PRECISION}; calculations "
            "and numeric JSON retain full floating-point precision (default: 6)"
        ),
    )
    parser.add_argument(
        "--no-normality",
        action="store_true",
        help="do not run normality tests",
    )
    parser.add_argument(
        "--delimiter",
        default="auto",
        help=(
            "input delimiter: auto, comma, tab, semicolon, space, or a literal "
            "single character (default: auto)"
        ),
    )
    parser.add_argument(
        "--header",
        choices=("auto", "yes", "no"),
        default="auto",
        help="whether the first data row contains column names (default: auto)",
    )
    parser.add_argument(
        "--encoding",
        default="utf-8",
        help="input text encoding (default: utf-8)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="also write the human-readable report to this file",
    )
    parser.add_argument(
        "--save-predictions",
        type=Path,
        metavar="FILE",
        help=(
            "write casewise fitted values, confidence limits, and residuals "
            "from supported models to a CSV file"
        ),
    )
    parser.add_argument(
        "--save-residuals",
        type=Path,
        metavar="FILE",
        help="write a compact casewise residual CSV from supported models",
    )
    parser.add_argument(
        "--plot",
        action="append",
        nargs="+",
        default=[],
        metavar="VALUE",
        help=(
            "create TYPE using the following column name(s); TYPE is histogram, "
            "qq, boxplot, grouped-boxplot, scatter, or correlation; may be repeated"
        ),
    )
    parser.add_argument(
        "--model-plots",
        action="store_true",
        help="create analysis-appropriate plots for every successfully fitted model",
    )
    parser.add_argument(
        "--plot-dir",
        type=Path,
        default=Path("plots"),
        metavar="DIRECTORY",
        help="directory for generated plot files (default: plots)",
    )
    parser.add_argument(
        "--plot-format",
        choices=("png", "pdf", "svg"),
        default="png",
        help="generated plot file format (default: png)",
    )
    parser.add_argument(
        "--plot-dpi",
        type=int,
        default=150,
        metavar="NUMBER",
        help="plot resolution from 50 through 600 DPI (default: 150)",
    )
    parser.add_argument(
        "--json",
        type=Path,
        dest="json_output",
        help="also write all results as JSON to this file",
    )
    parser.add_argument(
        "--dependencies",
        "--requirements",
        action=_ShowDependencies,
        nargs=0,
        help=(
            "show the installed StatClass, Python, NumPy, pandas, SciPy, and "
            "Matplotlib "
            "versions, then exit"
        ),
    )
    parser.add_argument(
        "--distributions",
        action=_ShowDistributions,
        nargs=0,
        help="show supported distributions and parameter order, then exit",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def _different_columns(first_name: str, second_name: str, option: str) -> None:
    if first_name == second_name:
        raise DataError(f"{option} requires two different columns")


def _unique_derived_name(existing: set[str], base: str) -> str:
    """Return a stable non-colliding name for an appended data column."""
    candidate = base
    suffix = 2
    while candidate in existing:
        candidate = f"{base}_{suffix}"
        suffix += 1
    existing.add(candidate)
    return candidate


def _resolve_plot_requests(
    requests: list[list[str]],
    numeric_names: list[str],
    all_names: list[str],
) -> list[dict[str, Any]]:
    aliases = {
        "hist": "histogram",
        "qq-plot": "qq",
        "box": "boxplot",
        "grouped_boxplot": "grouped-boxplot",
        "correlation-heatmap": "correlation",
        "heatmap": "correlation",
    }
    resolved = []
    for values in requests:
        if len(values) < 2:
            raise DataError("--plot requires TYPE followed by column name(s)")
        requested_type = values[0].strip().lower()
        plot_type = aliases.get(requested_type, requested_type)
        if plot_type not in PLOT_TYPES:
            allowed = ", ".join(PLOT_TYPES)
            raise DataError(f"unknown --plot type {values[0]!r}; choose {allowed}")
        references = values[1:]
        if plot_type in {"histogram", "qq", "boxplot"}:
            if len(references) != 1:
                raise DataError(f"--plot {plot_type} requires exactly one numeric column")
            columns = [resolve_column(references[0], numeric_names)]
        elif plot_type == "grouped-boxplot":
            if len(references) != 2:
                raise DataError(
                    "--plot grouped-boxplot requires numeric OUTCOME and categorical GROUP"
                )
            columns = [
                resolve_column(references[0], numeric_names),
                resolve_column(references[1], all_names),
            ]
            _different_columns(columns[0], columns[1], "--plot grouped-boxplot")
        elif plot_type == "scatter":
            if len(references) != 2:
                raise DataError("--plot scatter requires numeric X and Y columns")
            columns = resolve_columns(references, numeric_names)
            _different_columns(columns[0], columns[1], "--plot scatter")
        else:
            if len(references) < 2:
                raise DataError("--plot correlation requires at least 2 numeric columns")
            columns = resolve_columns(references, numeric_names)
            if len(set(columns)) != len(columns):
                raise DataError("--plot correlation requires different columns")
        resolved.append({"plot_type": plot_type, "columns": columns})
    return resolved


def _normalize_resampling_choice(
    value: str,
    allowed: tuple[str, ...],
    option: str,
) -> str:
    aliases = {
        "average": "mean",
        "sd": "standard-deviation",
        "std": "standard-deviation",
        "standard_deviation": "standard-deviation",
        "standard deviation": "standard-deviation",
    }
    normalized = aliases.get(value.strip().lower(), value.strip().lower())
    if normalized not in allowed:
        choices = ", ".join(allowed)
        raise DataError(f"{option} choice must be one of: {choices}")
    return normalized


def _empty_results(metadata: dict[str, Any]) -> dict[str, Any]:
    return {
        "metadata": metadata,
        "summary_statistics": {},
        "normality_tests": {},
        "one_sample_tests": [],
        "one_sample_z_tests": [],
        "two_sample_tests": [],
        "paired_tests": [],
        "summary_one_sample_tests": [],
        "summary_z_tests": [],
        "summary_two_sample_tests": [],
        "summary_paired_tests": [],
        "distribution_calculations": [],
        "bayesian_analyses": [],
        "transformations": [],
        "standardizations": [],
        "outlier_diagnostics": [],
        "principal_component_analyses": [],
        "manova_analyses": [],
        "discriminant_analyses": [],
        "mean_confidence_intervals": [],
        "proportion_confidence_intervals": [],
        "variance_confidence_intervals": [],
        "poisson_rate_confidence_intervals": [],
        "power_analyses": [],
        "anova_tests": [],
        "mann_whitney_tests": [],
        "wilcoxon_tests": [],
        "kruskal_wallis_tests": [],
        "bootstrap_analyses": [],
        "permutation_tests": [],
        "correlation_analyses": [],
        "regression_analyses": [],
        "multiple_regression_analyses": [],
        "robust_regression_analyses": [],
        "regularized_regression_analyses": [],
        "regression_spline_analyses": [],
        "smoothing_spline_analyses": [],
        "loess_analyses": [],
        "kernel_regression_analyses": [],
        "isotonic_regression_analyses": [],
        "kernel_density_analyses": [],
        "model_comparisons": [],
        "binary_logistic_regression_analyses": [],
        "multinomial_logistic_regression_analyses": [],
        "poisson_regression_analyses": [],
        "negative_binomial_regression_analyses": [],
        "factorial_analyses": [],
        "repeated_measures_analyses": [],
        "mixed_effects_analyses": [],
        "generated_plots": [],
        "frequency_tables": [],
        "contingency_tables": [],
        "chi_square_tests": [],
        "goodness_of_fit_tests": [],
        "fisher_exact_tests": [],
        "poisson_mean_analyses": [],
        "binomial_likelihood_analyses": [],
        "one_proportion_count_tests": [],
        "two_proportion_count_tests": [],
        "one_proportion_tests": [],
        "two_proportion_tests": [],
        "discrete_distribution_estimates": [],
    }


def _estimation_request_length(
    values: list[str],
    option: str,
    allowed: tuple[int, ...],
    syntax: str,
) -> None:
    if len(values) not in allowed:
        raise DataError(f"{option} requires {syntax}")


def _estimation_float(value: str, label: str) -> float:
    try:
        result = float(value)
    except ValueError as exc:
        raise DataError(f"{label} must be a finite number") from exc
    if not math.isfinite(result):
        raise DataError(f"{label} must be a finite number")
    return result


def _estimation_integer(value: str, label: str, minimum: int = 0) -> int:
    number = _estimation_float(value, label)
    if not number.is_integer() or number < minimum:
        raise DataError(f"{label} must be an integer of at least {minimum}")
    return int(number)


def _estimation_numeric_series(
    frame: pd.DataFrame,
    column: str,
    option: str,
) -> pd.Series:
    converted = pd.to_numeric(frame[column], errors="coerce")
    invalid = frame[column].notna() & converted.isna()
    if bool(invalid.any()):
        raise DataError(f"{option} column {column!r} contains nonnumeric values")
    return converted


def _estimation_trials(
    frame: pd.DataFrame,
    all_names: list[str],
    token: str,
    option: str,
) -> tuple[pd.Series, str]:
    try:
        fixed = float(token)
    except ValueError:
        fixed = None
    if fixed is not None:
        if not math.isfinite(fixed) or not fixed.is_integer() or fixed < 1:
            raise DataError(
                f"{option} TRIALS must be a positive integer or a column name"
            )
        return pd.Series(float(fixed), index=frame.index), f"fixed trials = {int(fixed)}"
    trial_name = resolve_column(token, all_names)
    return (
        _estimation_numeric_series(frame, trial_name, option),
        f"column {trial_name}",
    )


def _run_discrete_estimations(
    args: argparse.Namespace,
    frame: pd.DataFrame,
    all_names: list[str],
) -> list[dict[str, Any]]:
    analyses: list[dict[str, Any]] = []
    for request in args.estimate_bernoulli:
        _estimation_request_length(
            request,
            "--estimate-bernoulli",
            (2, 3),
            "COLUMN SUCCESS [P0]",
        )
        name = resolve_column(request[0], all_names)
        usable = frame[name].dropna()
        successes = np.asarray(
            [1 if category_matches(value, request[1]) else 0 for value in usable],
            dtype=float,
        )
        trials = np.ones(successes.size, dtype=float)
        null = (
            _estimation_float(request[2], "Bernoulli P0")
            if len(request) == 3
            else None
        )
        analyses.append(
            binomial_estimation(
                successes,
                trials,
                name,
                args.alpha,
                args.alternative,
                null,
                distribution="bernoulli",
                success_value=request[1],
            )
        )

    for request in args.estimate_binomial:
        _estimation_request_length(
            request,
            "--estimate-binomial",
            (2, 3),
            "COLUMN TRIALS [P0]",
        )
        name = resolve_column(request[0], all_names)
        success_values = _estimation_numeric_series(
            frame, name, "--estimate-binomial"
        )
        trial_values, trial_source = _estimation_trials(
            frame, all_names, request[1], "--estimate-binomial"
        )
        null = (
            _estimation_float(request[2], "binomial P0")
            if len(request) == 3
            else None
        )
        analysis = binomial_estimation(
            success_values,
            trial_values,
            name,
            args.alpha,
            args.alternative,
            null,
        )
        analysis["trials_source"] = trial_source
        analyses.append(analysis)

    for request in args.estimate_geometric:
        _estimation_request_length(
            request,
            "--estimate-geometric",
            (1, 2),
            "COLUMN [P0]",
        )
        name = resolve_column(request[0], all_names)
        null = (
            _estimation_float(request[1], "geometric P0")
            if len(request) == 2
            else None
        )
        analyses.append(
            geometric_estimation(
                _estimation_numeric_series(frame, name, "--estimate-geometric"),
                name,
                args.alpha,
                args.alternative,
                null,
            )
        )

    for request in args.estimate_poisson:
        _estimation_request_length(
            request,
            "--estimate-poisson",
            (1, 2),
            "COLUMN [MEAN0]",
        )
        name = resolve_column(request[0], all_names)
        null = (
            _estimation_float(request[1], "Poisson MEAN0")
            if len(request) == 2
            else None
        )
        analyses.append(
            poisson_estimation(
                _estimation_numeric_series(frame, name, "--estimate-poisson"),
                name,
                args.alpha,
                args.alternative,
                null,
            )
        )

    for request in args.estimate_negative_binomial:
        _estimation_request_length(
            request,
            "--estimate-negative-binomial",
            (2, 3),
            "COLUMN R [P0] or COLUMN auto",
        )
        name = resolve_column(request[0], all_names)
        sample = _estimation_numeric_series(
            frame, name, "--estimate-negative-binomial"
        )
        if request[1].strip().lower() == "auto":
            if len(request) != 2:
                raise DataError(
                    "--estimate-negative-binomial COLUMN auto does not use P0"
                )
            analyses.append(
                negative_binomial_joint_estimation(sample, name, args.alpha)
            )
        else:
            known_r = _estimation_integer(
                request[1], "negative-binomial R", 1
            )
            null = (
                _estimation_float(request[2], "negative-binomial P0")
                if len(request) == 3
                else None
            )
            analyses.append(
                negative_binomial_known_r_estimation(
                    sample,
                    name,
                    known_r,
                    args.alpha,
                    args.alternative,
                    null,
                )
            )

    for request in args.estimate_discrete_uniform:
        _estimation_request_length(
            request,
            "--estimate-discrete-uniform",
            (1, 2),
            "COLUMN [N0]",
        )
        name = resolve_column(request[0], all_names)
        null = (
            _estimation_integer(request[1], "discrete-uniform N0", 1)
            if len(request) == 2
            else None
        )
        analyses.append(
            discrete_uniform_estimation(
                _estimation_numeric_series(
                    frame, name, "--estimate-discrete-uniform"
                ),
                name,
                args.alpha,
                null,
            )
        )

    for request in args.estimate_hypergeometric:
        _estimation_request_length(
            request,
            "--estimate-hypergeometric",
            (3, 4),
            "COLUMN POPULATION_SIZE DRAWS [M0]",
        )
        name = resolve_column(request[0], all_names)
        population = _estimation_integer(
            request[1], "hypergeometric POPULATION_SIZE", 1
        )
        draws = _estimation_integer(request[2], "hypergeometric DRAWS", 1)
        null = (
            _estimation_integer(request[3], "hypergeometric M0", 0)
            if len(request) == 4
            else None
        )
        analyses.append(
            hypergeometric_estimation(
                _estimation_numeric_series(
                    frame, name, "--estimate-hypergeometric"
                ),
                name,
                population,
                draws,
                args.alpha,
                null,
            )
        )

    for column_reference, trial_token in args.estimate_beta_binomial:
        name = resolve_column(column_reference, all_names)
        trial_values, trial_source = _estimation_trials(
            frame, all_names, trial_token, "--estimate-beta-binomial"
        )
        analyses.append(
            beta_binomial_estimation(
                _estimation_numeric_series(
                    frame, name, "--estimate-beta-binomial"
                ),
                trial_values,
                name,
                args.alpha,
                trial_source,
            )
        )

    for reference in args.estimate_multinomial:
        name = resolve_column(reference, all_names)
        analyses.append(multinomial_estimation(frame[name], name, args.alpha))
    return analyses


def run_analysis(args: argparse.Namespace) -> dict[str, Any]:
    if not 0.0 < args.alpha < 1.0:
        raise DataError("--alpha must be strictly between 0 and 1")
    if args.posthoc and not args.kruskal:
        raise DataError("--posthoc requires at least one --kruskal analysis")
    resampling_requested = bool(
        args.bootstrap
        or args.bootstrap_difference
        or args.permutation_two_sample
        or args.permutation_paired
        or args.permutation_correlation
    )
    if resampling_requested and not 100 <= args.resamples <= 1_000_000:
        raise DataError("--resamples must be an integer from 100 through 1000000")
    if resampling_requested and not 0 <= args.random_seed < 2**32:
        raise DataError("--random-seed must be from 0 through 4294967295")
    if args.robust_regression:
        if not math.isfinite(args.robust_tuning) or args.robust_tuning <= 0.0:
            raise DataError("--robust-tuning must be a finite positive number")
        if not 1 <= args.robust_max_iterations <= 10000:
            raise DataError("--robust-max-iterations must be from 1 through 10000")
    if args.regularized_regression:
        if args.regularization_strength is not None and (
            not math.isfinite(args.regularization_strength)
            or args.regularization_strength <= 0.0
        ):
            raise DataError("--regularization-strength must be a finite positive number")
        if not math.isfinite(args.elastic_net_l1_ratio) or not 0.0 < args.elastic_net_l1_ratio < 1.0:
            raise DataError("--elastic-net-l1-ratio must be strictly between 0 and 1")
        if not 2 <= args.cv_folds <= 20:
            raise DataError("--cv-folds must be from 2 through 20")
        if not 0 <= args.random_seed < 2**32:
            raise DataError("--random-seed must be from 0 through 4294967295")
    if args.regression_spline or args.smoothing_spline:
        if not 1 <= args.spline_knots <= 50:
            raise DataError("--spline-knots must be from 1 through 50")
    if args.smoothing_lambda is not None:
        if not args.smoothing_spline:
            raise DataError("--smoothing-lambda requires --smoothing-spline")
        if not math.isfinite(args.smoothing_lambda) or args.smoothing_lambda < 0.0:
            raise DataError("--smoothing-lambda must be a finite nonnegative number")
    if args.loess:
        if not math.isfinite(args.loess_span) or not 0.0 < args.loess_span <= 1.0:
            raise DataError("--loess-span must be greater than 0 and at most 1")
        if not 0 <= args.loess_robust_iterations <= 20:
            raise DataError("--loess-robust-iterations must be from 0 through 20")
    if args.kernel_bandwidth is not None:
        if not args.kernel_regression:
            raise DataError("--kernel-bandwidth requires --kernel-regression")
        if not math.isfinite(args.kernel_bandwidth) or args.kernel_bandwidth <= 0.0:
            raise DataError("--kernel-bandwidth must be a finite positive number")
    if args.kernel_density and not 50 <= args.kde_grid_size <= 2000:
        raise DataError("--kde-grid-size must be from 50 through 2000")
    regression_requests = (
        args.multiple_regression
        or args.logistic
        or args.multinomial_logistic
        or args.poisson
        or args.negative_binomial
        or args.mixed_effects
    )
    count_regression_requests = args.poisson or args.negative_binomial
    if args.categorical_predictors and not regression_requests:
        raise DataError(
            "--categorical-predictors requires a multiple, logistic, count, or mixed-effects regression"
        )
    if (args.polynomial or args.interaction) and not regression_requests:
        raise DataError(
            "--polynomial and --interaction require a multiple, logistic, count, or mixed-effects regression"
        )
    if args.offset is not None and args.exposure is not None:
        raise DataError("use either --offset or --exposure, not both")
    if (args.offset is not None or args.exposure is not None) and not count_regression_requests:
        raise DataError(
            "--offset and --exposure require a Poisson or negative-binomial regression"
        )
    if args.compare_models and len(args.multiple_regression) < 2:
        raise DataError(
            "--compare-models requires at least two --multiple-regression models"
        )
    if args.logistic and args.event is None:
        raise DataError("--logistic requires --event VALUE")
    if args.event is not None and not args.logistic:
        raise DataError("--event may only be used with --logistic")
    if args.outcome_reference is not None and not args.multinomial_logistic:
        raise DataError(
            "--outcome-reference may only be used with --multinomial-logistic"
        )
    if not 0.0 < args.classification_threshold < 1.0:
        raise DataError(
            "--classification-threshold must be strictly between 0 and 1"
        )
    bayesian_file_requested = bool(
        args.bayes_binomial_column
        or args.bayes_poisson_column
        or args.bayes_normal_known_column
        or args.bayes_normal_unknown_column
    )
    if args.bayes_poisson_exposure_column and not args.bayes_poisson_column:
        raise DataError(
            "--bayes-poisson-exposure-column requires --bayes-poisson-column"
        )
    if args.bayes_plots and not bayesian_file_requested:
        raise DataError("--bayes-plots requires at least one Bayesian analysis")
    if args.bayes_future_trials != 1 and not args.bayes_binomial_column:
        raise DataError(
            "--bayes-future-trials requires --bayes-binomial-column"
        )
    if args.bayes_future_exposure != 1.0 and not args.bayes_poisson_column:
        raise DataError(
            "--bayes-future-exposure requires --bayes-poisson-column"
        )
    data_processing_requested = bool(
        args.transform or args.standardize or args.outliers
    )
    if args.save_transformed and not data_processing_requested:
        raise DataError(
            "--save-transformed requires --transform, --standardize, or --outliers"
        )
    custom_outlier_settings = (
        args.outlier_z_threshold != 3.0
        or args.outlier_modified_z_threshold != 3.5
        or args.outlier_iqr_multiplier != 1.5
    )
    if custom_outlier_settings and not args.outliers:
        raise DataError("outlier thresholds require at least one --outliers request")
    if args.outliers and not all(
        math.isfinite(value) and value > 0.0
        for value in (
            args.outlier_z_threshold,
            args.outlier_modified_z_threshold,
            args.outlier_iqr_multiplier,
        )
    ):
        raise DataError("outlier thresholds and the IQR multiplier must be positive")
    if args.pca_components is not None and not args.pca:
        raise DataError("--pca-components requires at least one --pca analysis")
    if args.pca_no_standardize and not args.pca:
        raise DataError("--pca-no-standardize requires at least one --pca analysis")
    if args.save_pca_scores and not args.pca:
        raise DataError("--save-pca-scores requires at least one --pca analysis")
    if args.save_discriminant and not args.discriminant:
        raise DataError(
            "--save-discriminant requires at least one --discriminant analysis"
        )
    if args.discriminant_priors != "empirical" and not args.discriminant:
        raise DataError(
            "--discriminant-priors requires at least one --discriminant analysis"
        )

    dataset = load_dataset(
        args.input_file,
        args.delimiter,
        args.header,
        args.encoding,
    )
    frame = dataset.numeric
    names = dataset.numeric_names
    raw_frame = dataset.raw
    raw_names = [str(name) for name in raw_frame.columns]
    plotting_requested = bool(args.plot or args.model_plots or args.bayes_plots)
    if plotting_requested and not 50 <= args.plot_dpi <= 600:
        raise DataError("--plot-dpi must be an integer from 50 through 600")
    plot_requests = _resolve_plot_requests(args.plot, names, raw_names)
    offset_name = (
        resolve_column(args.offset, names) if args.offset is not None else None
    )
    exposure_name = (
        resolve_column(args.exposure, names)
        if args.exposure is not None
        else None
    )
    polynomial_terms: dict[str, int] = {}
    for column_reference, degree_text in args.polynomial:
        name = resolve_column(column_reference, raw_names)
        if name not in names:
            raise DataError(
                f"--polynomial requires a numeric column; {name!r} is not numeric"
            )
        try:
            degree = int(degree_text)
        except ValueError as exc:
            raise DataError("--polynomial DEGREE must be an integer from 2 to 5") from exc
        if str(degree) != degree_text.strip() or not 2 <= degree <= 5:
            raise DataError("--polynomial DEGREE must be an integer from 2 to 5")
        polynomial_terms[name] = max(degree, polynomial_terms.get(name, 1))

    interaction_terms: list[tuple[str, str]] = []
    interaction_keys: set[tuple[str, str]] = set()
    for first_reference, second_reference in args.interaction:
        first_name = resolve_column(first_reference, raw_names)
        second_name = resolve_column(second_reference, raw_names)
        _different_columns(first_name, second_name, "--interaction")
        key = tuple(sorted((first_name, second_name)))
        if key not in interaction_keys:
            interaction_keys.add(key)
            interaction_terms.append((first_name, second_name))

    used_polynomials: set[str] = set()
    used_interactions: set[tuple[str, str]] = set()

    def engineering_for_model(
        predictor_names: list[str], categorical_names: set[str]
    ) -> tuple[dict[str, int], list[tuple[str, str]]]:
        model_polynomials = {
            name: degree
            for name, degree in polynomial_terms.items()
            if name in predictor_names and name not in categorical_names
        }
        model_interactions = [
            pair
            for pair in interaction_terms
            if pair[0] in predictor_names and pair[1] in predictor_names
        ]
        used_polynomials.update(model_polynomials)
        used_interactions.update(tuple(sorted(pair)) for pair in model_interactions)
        return model_polynomials, model_interactions
    requested = flatten_column_arguments(args.columns)
    selected_names = resolve_columns(requested, names) if requested else names

    results = _empty_results(
        {
            "program_version": __version__,
            "analysis_source": "data_file",
            "input_file": str(args.input_file),
            "rows": int(frame.shape[0]),
            "columns_found": int(dataset.raw.shape[1]),
            "column_names": [str(name) for name in dataset.raw.columns],
            "numeric_columns_found": len(names),
            "numeric_column_names": names,
            "analyzed_columns": selected_names,
            "header_detected": dataset.header_detected,
            "delimiter": delimiter_label(dataset.delimiter),
            "input_resource_preflight": dataset.input_resource_preflight,
            "alpha": args.alpha,
            "output_precision": args.precision,
            "alternative": args.alternative,
        }
    )
    results["discrete_distribution_estimates"] = _run_discrete_estimations(
        args, raw_frame, raw_names
    )
    results["summary_statistics"] = {
        name: summary_statistics(frame[name]) for name in selected_names
    }

    if not args.no_normality:
        results["normality_tests"] = {
            name: normality_tests(frame[name], args.alpha)
            for name in selected_names
        }

    derived_frame = raw_frame.copy()
    derived_column_names = {str(name) for name in derived_frame.columns}

    for request in args.transform:
        if len(request) not in {2, 3}:
            raise TransformationError(
                "--transform requires COLUMN METHOD and, only when needed, PARAMETER"
            )
        name = resolve_column(request[0], names)
        parameter: float | None = None
        if len(request) == 3:
            try:
                parameter = float(request[2])
            except ValueError as exc:
                raise TransformationError(
                    "--transform PARAMETER must be numeric"
                ) from exc
        analysis, transformed = transform_series(
            frame[name], name, request[1], parameter
        )
        output_name = _unique_derived_name(
            derived_column_names,
            f"{name}_{analysis['method'].replace('-', '_')}",
        )
        analysis["output_column"] = output_name
        derived_frame[output_name] = transformed
        results["transformations"].append(analysis)

    for reference, method in args.standardize:
        name = resolve_column(reference, names)
        analysis, standardized = standardize_series(frame[name], name, method)
        output_name = _unique_derived_name(
            derived_column_names,
            f"{name}_{analysis['method'].replace('-', '_')}",
        )
        analysis["output_column"] = output_name
        derived_frame[output_name] = standardized
        results["standardizations"].append(analysis)

    outlier_thresholds = {
        "z-score": args.outlier_z_threshold,
        "modified-z-score": args.outlier_modified_z_threshold,
        "iqr": args.outlier_iqr_multiplier,
    }
    for reference, requested_method in args.outliers:
        name = resolve_column(reference, names)
        normalized_request = requested_method.strip().lower().replace("_", "-")
        methods = OUTLIER_METHODS if normalized_request == "all" else (requested_method,)
        for method in methods:
            normalized_method = method.strip().lower().replace("_", "-")
            aliases = {
                "z": "z-score",
                "zscore": "z-score",
                "modified-z": "modified-z-score",
                "modified-zscore": "modified-z-score",
                "tukey": "iqr",
            }
            normalized_method = aliases.get(normalized_method, normalized_method)
            threshold = outlier_thresholds.get(normalized_method)
            analysis, flags = outlier_diagnostics(
                frame[name], name, method, threshold
            )
            output_name = _unique_derived_name(
                derived_column_names,
                f"{name}_outlier_{analysis['method'].replace('-', '_')}",
            )
            analysis["flag_column"] = output_name
            derived_frame[output_name] = flags
            results["outlier_diagnostics"].append(analysis)

    if args.save_transformed:
        derived_columns = [
            analysis["output_column"]
            for analysis in results["transformations"]
        ] + [
            analysis["output_column"]
            for analysis in results["standardizations"]
        ] + [
            analysis["flag_column"]
            for analysis in results["outlier_diagnostics"]
        ]
        results["transformed_data_export"] = {
            "file": str(args.save_transformed),
            "rows": int(derived_frame.shape[0]),
            "original_columns": int(raw_frame.shape[1]),
            "derived_columns": derived_columns,
            "derived_column_count": len(derived_columns),
        }
        results["_transformed_export_frame"] = derived_frame

    for analysis_index, references in enumerate(args.pca, 1):
        variable_names = resolve_columns(
            flatten_column_arguments(references), names
        )
        if len(variable_names) < 2:
            raise DataError("--pca requires at least two different numeric columns")
        results["principal_component_analyses"].append(
            principal_component_analysis(
                frame,
                variable_names,
                args.pca_components,
                not args.pca_no_standardize,
                f"PCA {analysis_index}",
            )
        )

    for analysis_index, references in enumerate(args.manova, 1):
        flattened = flatten_column_arguments(references)
        if len(flattened) < 3:
            raise DataError(
                "--manova requires GROUP followed by at least two numeric responses"
            )
        group_name = resolve_column(flattened[0], raw_names)
        response_names = resolve_columns(flattened[1:], names)
        if len(response_names) < 2:
            raise DataError(
                "--manova requires at least two different numeric responses"
            )
        results["manova_analyses"].append(
            one_way_manova(
                raw_frame,
                group_name,
                response_names,
                args.alpha,
                f"MANOVA {analysis_index}",
            )
        )

    for analysis_index, references in enumerate(args.discriminant, 1):
        flattened = flatten_column_arguments(references)
        if len(flattened) < 3:
            raise DataError(
                "--discriminant requires CLASS followed by at least two numeric features"
            )
        class_name = resolve_column(flattened[0], raw_names)
        feature_names = resolve_columns(flattened[1:], names)
        if len(feature_names) < 2:
            raise DataError(
                "--discriminant requires at least two different numeric features"
            )
        results["discriminant_analyses"].append(
            linear_discriminant_analysis(
                raw_frame,
                class_name,
                feature_names,
                args.discriminant_priors,
                f"LDA {analysis_index}",
            )
        )

    for reference, success_value, alpha_text, beta_text in args.bayes_binomial_column:
        name = resolve_column(reference, raw_names)
        prior_alpha, prior_beta = _bayes_numbers(
            [alpha_text, beta_text], "--bayes-binomial-column"
        )
        valid = raw_frame[name].dropna()
        if valid.empty:
            raise BayesError(
                f"--bayes-binomial-column {name!r} requires at least one nonmissing value"
            )
        successes = sum(
            category_matches(value, success_value) for value in valid
        )
        results["bayesian_analyses"].append(
            beta_binomial_analysis(
                successes,
                int(valid.size),
                prior_alpha,
                prior_beta,
                args.alpha,
                args.bayes_future_trials,
                source="data_column",
                column=name,
                success_value=success_value,
                missing=int(raw_frame[name].isna().sum()),
            )
        )

    bayes_exposure_name = (
        resolve_column(args.bayes_poisson_exposure_column, names)
        if args.bayes_poisson_exposure_column
        else None
    )
    for reference, shape_text, rate_text in args.bayes_poisson_column:
        name = resolve_column(reference, names)
        prior_shape, prior_rate = _bayes_numbers(
            [shape_text, rate_text], "--bayes-poisson-column"
        )
        columns = [name] + ([bayes_exposure_name] if bayes_exposure_name else [])
        paired = frame[columns].dropna()
        if not paired.empty:
            finite_mask = paired.apply(
                lambda column: column.map(lambda value: math.isfinite(float(value)))
            ).all(axis=1)
            paired = paired.loc[finite_mask]
        if paired.empty:
            raise BayesError(
                f"--bayes-poisson-column {name!r} requires at least one usable row"
            )
        counts = paired[name]
        if any(value < 0.0 or not float(value).is_integer() for value in counts):
            raise BayesError(
                f"--bayes-poisson-column {name!r} requires nonnegative integer counts"
            )
        if bayes_exposure_name:
            exposures = paired[bayes_exposure_name]
            if any(value <= 0.0 for value in exposures):
                raise BayesError(
                    "--bayes-poisson-exposure-column requires positive exposures"
                )
            total_exposure = float(exposures.sum())
        else:
            total_exposure = float(paired.shape[0])
        results["bayesian_analyses"].append(
            gamma_poisson_analysis(
                int(counts.sum()),
                total_exposure,
                prior_shape,
                prior_rate,
                args.alpha,
                args.bayes_future_exposure,
                source="data_column",
                column=name,
                exposure_column=bayes_exposure_name,
                observations=int(paired.shape[0]),
                missing=int(raw_frame.shape[0] - paired.shape[0]),
            )
        )

    for reference, sigma_text, mean_text, sd_text in args.bayes_normal_known_column:
        name = resolve_column(reference, names)
        population_sd, prior_mean, prior_sd = _bayes_numbers(
            [sigma_text, mean_text, sd_text], "--bayes-normal-known-column"
        )
        valid = frame[name].dropna()
        valid = valid[valid.map(lambda value: math.isfinite(float(value)))]
        if valid.empty:
            raise BayesError(
                f"--bayes-normal-known-column {name!r} requires at least one usable value"
            )
        results["bayesian_analyses"].append(
            normal_known_variance_analysis(
                int(valid.size),
                float(valid.mean()),
                population_sd,
                prior_mean,
                prior_sd,
                args.alpha,
                source="data_column",
                column=name,
                missing=int(frame.shape[0] - valid.size),
            )
        )

    for request in args.bayes_normal_unknown_column:
        reference = request[0]
        name = resolve_column(reference, names)
        prior_mean, prior_kappa, prior_alpha, prior_beta = _bayes_numbers(
            request[1:], "--bayes-normal-unknown-column"
        )
        valid = frame[name].dropna()
        valid = valid[valid.map(lambda value: math.isfinite(float(value)))]
        if valid.size < 2:
            raise BayesError(
                f"--bayes-normal-unknown-column {name!r} requires at least two usable values"
            )
        results["bayesian_analyses"].append(
            normal_inverse_gamma_analysis(
                int(valid.size),
                float(valid.mean()),
                float(valid.std(ddof=1)),
                prior_mean,
                prior_kappa,
                prior_alpha,
                prior_beta,
                args.alpha,
                source="data_column",
                column=name,
                missing=int(frame.shape[0] - valid.size),
            )
        )

    resampling_index = 0

    def next_resampling_seed() -> int:
        nonlocal resampling_index
        seed = (args.random_seed + resampling_index) % (2**32)
        resampling_index += 1
        return seed

    for reference, statistic_text in args.bootstrap:
        name = resolve_column(reference, names)
        statistic = _normalize_resampling_choice(
            statistic_text, BOOTSTRAP_STATISTICS, "--bootstrap"
        )
        results["bootstrap_analyses"].append(
            bootstrap_one_sample(
                frame[name],
                name,
                statistic,
                args.resamples,
                args.alpha,
                args.bootstrap_method,
                next_resampling_seed(),
            )
        )

    for first_reference, second_reference, statistic_text in args.bootstrap_difference:
        first_name = resolve_column(first_reference, names)
        second_name = resolve_column(second_reference, names)
        _different_columns(first_name, second_name, "--bootstrap-difference")
        statistic = _normalize_resampling_choice(
            statistic_text,
            BOOTSTRAP_STATISTICS,
            "--bootstrap-difference",
        )
        results["bootstrap_analyses"].append(
            bootstrap_independent_difference(
                frame[first_name],
                frame[second_name],
                first_name,
                second_name,
                statistic,
                args.resamples,
                args.alpha,
                args.bootstrap_method,
                next_resampling_seed(),
            )
        )

    for first_reference, second_reference, statistic_text in args.permutation_two_sample:
        first_name = resolve_column(first_reference, names)
        second_name = resolve_column(second_reference, names)
        _different_columns(first_name, second_name, "--permutation-two-sample")
        statistic = _normalize_resampling_choice(
            statistic_text,
            PERMUTATION_STATISTICS,
            "--permutation-two-sample",
        )
        results["permutation_tests"].append(
            permutation_two_sample(
                frame[first_name],
                frame[second_name],
                first_name,
                second_name,
                statistic,
                args.resamples,
                args.alternative,
                args.alpha,
                next_resampling_seed(),
            )
        )

    for first_reference, second_reference, statistic_text in args.permutation_paired:
        first_name = resolve_column(first_reference, names)
        second_name = resolve_column(second_reference, names)
        _different_columns(first_name, second_name, "--permutation-paired")
        statistic = _normalize_resampling_choice(
            statistic_text,
            PERMUTATION_STATISTICS,
            "--permutation-paired",
        )
        results["permutation_tests"].append(
            permutation_paired(
                frame[first_name],
                frame[second_name],
                first_name,
                second_name,
                statistic,
                args.resamples,
                args.alternative,
                args.alpha,
                next_resampling_seed(),
            )
        )

    for first_reference, second_reference, method_text in args.permutation_correlation:
        first_name = resolve_column(first_reference, names)
        second_name = resolve_column(second_reference, names)
        _different_columns(first_name, second_name, "--permutation-correlation")
        method = _normalize_resampling_choice(
            method_text,
            PERMUTATION_CORRELATIONS,
            "--permutation-correlation",
        )
        results["permutation_tests"].append(
            permutation_correlation(
                frame[first_name],
                frame[second_name],
                first_name,
                second_name,
                method,
                args.resamples,
                args.alternative,
                args.alpha,
                next_resampling_seed(),
            )
        )

    for reference in args.one_sample:
        name = resolve_column(reference, names)
        results["one_sample_tests"].append(
            one_sample_t_test(
                frame[name], name, args.mu, args.alternative, args.alpha
            )
        )

    for reference, sigma_text in args.z_test:
        name = resolve_column(reference, names)
        try:
            population_standard_deviation = float(sigma_text)
        except ValueError as exc:
            raise DataError(
                f"population standard deviation must be numeric: {sigma_text!r}"
            ) from exc
        if (
            not math.isfinite(population_standard_deviation)
            or population_standard_deviation <= 0
        ):
            raise DataError(
                "population standard deviation for --z-test must be positive and finite"
            )
        results["one_sample_z_tests"].append(
            one_sample_z_test(
                frame[name],
                name,
                args.mu,
                population_standard_deviation,
                args.alternative,
                args.alpha,
            )
        )

    for first_reference, second_reference in args.two_sample:
        first_name = resolve_column(first_reference, names)
        second_name = resolve_column(second_reference, names)
        _different_columns(first_name, second_name, "--two-sample")
        results["two_sample_tests"].append(
            two_sample_t_test(
                frame[first_name],
                frame[second_name],
                first_name,
                second_name,
                args.equal_variance,
                args.alternative,
                args.alpha,
            )
        )

    for first_reference, second_reference in args.paired:
        first_name = resolve_column(first_reference, names)
        second_name = resolve_column(second_reference, names)
        _different_columns(first_name, second_name, "--paired")
        results["paired_tests"].append(
            paired_t_test(
                frame[first_name],
                frame[second_name],
                first_name,
                second_name,
                args.alternative,
                args.alpha,
            )
        )

    for references in args.anova:
        anova_names = resolve_columns(
            flatten_column_arguments(references), names
        )
        if len(anova_names) < 3:
            raise DataError("--anova requires at least 3 different numeric columns")
        results["anova_tests"].append(
            one_way_anova(
                [frame[name] for name in anova_names],
                anova_names,
                args.equal_variance,
                args.alpha,
            )
        )

    for first_reference, second_reference in args.mann_whitney:
        first_name = resolve_column(first_reference, names)
        second_name = resolve_column(second_reference, names)
        _different_columns(first_name, second_name, "--mann-whitney")
        results["mann_whitney_tests"].append(
            mann_whitney_u_test(
                frame[first_name],
                frame[second_name],
                first_name,
                second_name,
                args.alternative,
                args.alpha,
            )
        )

    for first_reference, second_reference in args.wilcoxon:
        first_name = resolve_column(first_reference, names)
        second_name = resolve_column(second_reference, names)
        _different_columns(first_name, second_name, "--wilcoxon")
        results["wilcoxon_tests"].append(
            wilcoxon_signed_rank_test(
                frame[first_name],
                frame[second_name],
                first_name,
                second_name,
                args.alternative,
                args.alpha,
            )
        )

    for references in args.kruskal:
        kruskal_names = resolve_columns(
            flatten_column_arguments(references), names
        )
        if len(kruskal_names) < 3:
            raise DataError(
                "--kruskal requires at least 3 different numeric columns"
            )
        results["kruskal_wallis_tests"].append(
            kruskal_wallis_test(
                [frame[name] for name in kruskal_names],
                kruskal_names,
                args.alpha,
                args.posthoc,
                args.posthoc_adjust,
            )
        )

    methods = (
        list(CORRELATION_METHODS)
        if args.correlation_method == "all"
        else [args.correlation_method]
    )
    for first_reference, second_reference in args.correlation:
        first_name = resolve_column(first_reference, names)
        second_name = resolve_column(second_reference, names)
        _different_columns(first_name, second_name, "--correlation")
        results["correlation_analyses"].append(
            correlation_tests(
                frame[first_name],
                frame[second_name],
                first_name,
                second_name,
                methods,
                args.alpha,
            )
        )

    for dependent_reference, independent_reference in args.regression:
        dependent_name = resolve_column(dependent_reference, names)
        independent_name = resolve_column(independent_reference, names)
        _different_columns(dependent_name, independent_name, "--regression")
        results["regression_analyses"].append(
            simple_linear_regression(
                frame[dependent_name],
                frame[independent_name],
                dependent_name,
                independent_name,
                args.alpha,
            )
        )

    for references in args.robust_regression:
        flattened = flatten_column_arguments(references)
        if len(flattened) < 2:
            raise DataError(
                "--robust-regression requires a dependent column followed by "
                "at least one numeric predictor"
            )
        dependent_name = resolve_column(flattened[0], names)
        predictor_names = resolve_columns(flattened[1:], names)
        if dependent_name in predictor_names:
            raise DataError(
                "--robust-regression cannot use the dependent variable as a predictor"
            )
        results["robust_regression_analyses"].append(
            robust_linear_regression(
                frame,
                dependent_name,
                predictor_names,
                args.alpha,
                args.robust_tuning,
                args.robust_max_iterations,
            )
        )

    for references in args.regularized_regression:
        flattened = flatten_column_arguments(references)
        if len(flattened) < 3:
            raise DataError(
                "--regularized-regression requires METHOD, DEPENDENT, and at "
                "least one numeric PREDICTOR"
            )
        penalty = flattened[0].strip().lower().replace("_", "-")
        if penalty not in {"ridge", "lasso", "elastic-net"}:
            raise DataError(
                "--regularized-regression METHOD must be ridge, lasso, or elastic-net"
            )
        dependent_name = resolve_column(flattened[1], names)
        predictor_names = resolve_columns(flattened[2:], names)
        if dependent_name in predictor_names:
            raise DataError(
                "--regularized-regression cannot use the dependent variable as a predictor"
            )
        results["regularized_regression_analyses"].append(
            regularized_linear_regression(
                frame,
                dependent_name,
                predictor_names,
                penalty,
                args.regularization_strength,
                args.elastic_net_l1_ratio,
                args.cv_folds,
                args.random_seed,
            )
        )

    for dependent_reference, independent_reference in args.regression_spline:
        dependent_name = resolve_column(dependent_reference, names)
        independent_name = resolve_column(independent_reference, names)
        _different_columns(dependent_name, independent_name, "--regression-spline")
        results["regression_spline_analyses"].append(
            regression_spline(
                frame[dependent_name],
                frame[independent_name],
                dependent_name,
                independent_name,
                args.alpha,
                args.spline_knots,
            )
        )

    for dependent_reference, independent_reference in args.smoothing_spline:
        dependent_name = resolve_column(dependent_reference, names)
        independent_name = resolve_column(independent_reference, names)
        _different_columns(dependent_name, independent_name, "--smoothing-spline")
        results["smoothing_spline_analyses"].append(
            smoothing_spline(
                frame[dependent_name],
                frame[independent_name],
                dependent_name,
                independent_name,
                args.alpha,
                args.spline_knots,
                args.smoothing_lambda,
            )
        )

    for dependent_reference, independent_reference in args.loess:
        dependent_name = resolve_column(dependent_reference, names)
        independent_name = resolve_column(independent_reference, names)
        _different_columns(dependent_name, independent_name, "--loess")
        results["loess_analyses"].append(
            loess_regression(
                frame[dependent_name],
                frame[independent_name],
                dependent_name,
                independent_name,
                args.loess_span,
                args.loess_degree,
                args.loess_robust_iterations,
            )
        )

    for dependent_reference, independent_reference in args.kernel_regression:
        dependent_name = resolve_column(dependent_reference, names)
        independent_name = resolve_column(independent_reference, names)
        _different_columns(dependent_name, independent_name, "--kernel-regression")
        results["kernel_regression_analyses"].append(
            kernel_regression(
                frame[dependent_name],
                frame[independent_name],
                dependent_name,
                independent_name,
                args.kernel_bandwidth,
            )
        )

    for dependent_reference, independent_reference in args.isotonic_regression:
        dependent_name = resolve_column(dependent_reference, names)
        independent_name = resolve_column(independent_reference, names)
        _different_columns(dependent_name, independent_name, "--isotonic-regression")
        results["isotonic_regression_analyses"].append(
            isotonic_regression(
                frame[dependent_name],
                frame[independent_name],
                dependent_name,
                independent_name,
                args.isotonic_direction,
            )
        )

    for reference in args.kernel_density:
        column_name = resolve_column(reference, names)
        results["kernel_density_analyses"].append(
            kernel_density_estimation(
                frame[column_name],
                column_name,
                args.kde_bandwidth,
                args.kde_grid_size,
            )
        )

    explicit_categorical = set(
        resolve_columns(
            flatten_column_arguments(args.categorical_predictors), raw_names
        )
    )
    model_specs: list[dict[str, Any]] = []
    for model_index, references in enumerate(args.multiple_regression, 1):
        flattened = flatten_column_arguments(references)
        if len(flattened) < 2:
            raise DataError(
                "--multiple-regression requires a dependent column followed "
                "by at least one predictor"
            )
        dependent_name = resolve_column(flattened[0], names)
        predictor_names = resolve_columns(flattened[1:], raw_names)
        if dependent_name in predictor_names:
            raise DataError(
                "--multiple-regression cannot use the dependent variable as "
                "a predictor"
            )
        categorical_names = {
            name
            for name in predictor_names
            if name in explicit_categorical or name not in names
        }
        model_polynomials, model_interactions = engineering_for_model(
            predictor_names, categorical_names
        )
        model_name = f"Model {model_index}"
        results["multiple_regression_analyses"].append(
            multiple_linear_regression(
                raw_frame,
                dependent_name,
                predictor_names,
                categorical_names,
                args.alpha,
                model_name,
                model_polynomials,
                model_interactions,
            )
        )
        model_specs.append(
            {
                "model_name": model_name,
                "dependent": dependent_name,
                "predictors": predictor_names,
                "categorical": categorical_names,
                "polynomial_terms": model_polynomials,
                "interactions": model_interactions,
            }
        )

    if args.compare_models:
        for reduced_spec, full_spec in zip(model_specs, model_specs[1:]):
            if reduced_spec["dependent"] != full_spec["dependent"]:
                raise DataError(
                    "--compare-models requires adjacent models to have the "
                    "same dependent variable"
                )
            comparison_name = (
                f"{reduced_spec['model_name']} versus "
                f"{full_spec['model_name']}"
            )
            union_predictors = set(reduced_spec["predictors"]) | set(
                full_spec["predictors"]
            )
            union_categorical = reduced_spec["categorical"] | full_spec[
                "categorical"
            ]
            comparison_polynomials = {
                name: degree
                for name, degree in polynomial_terms.items()
                if name in union_predictors and name not in union_categorical
            }
            comparison_interactions = [
                pair
                for pair in interaction_terms
                if pair[0] in union_predictors and pair[1] in union_predictors
            ]
            results["model_comparisons"].append(
                compare_regression_models(
                    raw_frame,
                    reduced_spec["dependent"],
                    reduced_spec["predictors"],
                    full_spec["predictors"],
                    union_categorical,
                    args.alpha,
                    comparison_name,
                    comparison_polynomials,
                    comparison_interactions,
                )
            )

    for model_index, references in enumerate(args.logistic, 1):
        flattened = flatten_column_arguments(references)
        if len(flattened) < 2:
            raise DataError(
                "--logistic requires an outcome column followed by at least "
                "one predictor"
            )
        outcome_name = resolve_column(flattened[0], raw_names)
        predictor_names = resolve_columns(flattened[1:], raw_names)
        if outcome_name in predictor_names:
            raise DataError(
                "--logistic cannot use the outcome variable as a predictor"
            )
        categorical_names = {
            name
            for name in predictor_names
            if name in explicit_categorical or name not in names
        }
        model_polynomials, model_interactions = engineering_for_model(
            predictor_names, categorical_names
        )
        results["binary_logistic_regression_analyses"].append(
            binary_logistic_regression(
                raw_frame,
                outcome_name,
                predictor_names,
                categorical_names,
                args.event,
                args.alpha,
                args.classification_threshold,
                f"Binary logistic model {model_index}",
                model_polynomials,
                model_interactions,
            )
        )

    for model_index, references in enumerate(args.multinomial_logistic, 1):
        flattened = flatten_column_arguments(references)
        if len(flattened) < 2:
            raise DataError(
                "--multinomial-logistic requires an outcome column followed "
                "by at least one predictor"
            )
        outcome_name = resolve_column(flattened[0], raw_names)
        predictor_names = resolve_columns(flattened[1:], raw_names)
        if outcome_name in predictor_names:
            raise DataError(
                "--multinomial-logistic cannot use the outcome variable as a "
                "predictor"
            )
        categorical_names = {
            name
            for name in predictor_names
            if name in explicit_categorical or name not in names
        }
        model_polynomials, model_interactions = engineering_for_model(
            predictor_names, categorical_names
        )
        results["multinomial_logistic_regression_analyses"].append(
            multinomial_logistic_regression(
                raw_frame,
                outcome_name,
                predictor_names,
                categorical_names,
                args.outcome_reference,
                args.alpha,
                f"Multinomial logistic model {model_index}",
                model_polynomials,
                model_interactions,
            )
        )

    for model_index, references in enumerate(args.poisson, 1):
        flattened = flatten_column_arguments(references)
        if len(flattened) < 2:
            raise DataError(
                "--poisson requires an outcome column followed by at least one predictor"
            )
        outcome_name = resolve_column(flattened[0], names)
        predictor_names = resolve_columns(flattened[1:], raw_names)
        if outcome_name in predictor_names:
            raise DataError(
                "--poisson cannot use the outcome variable as a predictor"
            )
        if outcome_name in {offset_name, exposure_name}:
            raise DataError(
                "--poisson cannot use its outcome as the offset or exposure variable"
            )
        categorical_names = {
            name
            for name in predictor_names
            if name in explicit_categorical or name not in names
        }
        model_polynomials, model_interactions = engineering_for_model(
            predictor_names, categorical_names
        )
        results["poisson_regression_analyses"].append(
            poisson_regression(
                raw_frame,
                outcome_name,
                predictor_names,
                categorical_names,
                args.alpha,
                f"Poisson model {model_index}",
                model_polynomials,
                model_interactions,
                offset_name,
                exposure_name,
            )
        )

    for model_index, references in enumerate(args.negative_binomial, 1):
        flattened = flatten_column_arguments(references)
        if len(flattened) < 2:
            raise DataError(
                "--negative-binomial requires an outcome column followed by at least one predictor"
            )
        outcome_name = resolve_column(flattened[0], names)
        predictor_names = resolve_columns(flattened[1:], raw_names)
        if outcome_name in predictor_names:
            raise DataError(
                "--negative-binomial cannot use the outcome variable as a predictor"
            )
        if outcome_name in {offset_name, exposure_name}:
            raise DataError(
                "--negative-binomial cannot use its outcome as the offset or exposure variable"
            )
        categorical_names = {
            name
            for name in predictor_names
            if name in explicit_categorical or name not in names
        }
        model_polynomials, model_interactions = engineering_for_model(
            predictor_names, categorical_names
        )
        results["negative_binomial_regression_analyses"].append(
            negative_binomial_regression(
                raw_frame,
                outcome_name,
                predictor_names,
                categorical_names,
                args.alpha,
                f"Negative-binomial model {model_index}",
                model_polynomials,
                model_interactions,
                offset_name,
                exposure_name,
            )
        )

    for model_index, references in enumerate(args.two_way_anova, 1):
        outcome_name = resolve_column(references[0], names)
        first_factor = resolve_column(references[1], raw_names)
        second_factor = resolve_column(references[2], raw_names)
        if len({outcome_name, first_factor, second_factor}) != 3:
            raise DataError(
                "--two-way-anova requires three different columns"
            )
        results["factorial_analyses"].append(
            factorial_anova_ancova(
                raw_frame,
                outcome_name,
                first_factor,
                second_factor,
                [],
                args.alpha,
                args.emmeans_adjust,
                f"Two-way ANOVA model {model_index}",
            )
        )

    for model_index, references in enumerate(args.ancova, 1):
        flattened = flatten_column_arguments(references)
        if len(flattened) < 4:
            raise DataError(
                "--ancova requires OUTCOME, two FACTORS, and at least one COVARIATE"
            )
        outcome_name = resolve_column(flattened[0], names)
        first_factor = resolve_column(flattened[1], raw_names)
        second_factor = resolve_column(flattened[2], raw_names)
        covariate_names = resolve_columns(flattened[3:], names)
        all_names = [outcome_name, first_factor, second_factor, *covariate_names]
        if len(set(all_names)) != len(all_names):
            raise DataError("--ancova requires different outcome, factor, and covariate columns")
        results["factorial_analyses"].append(
            factorial_anova_ancova(
                raw_frame,
                outcome_name,
                first_factor,
                second_factor,
                covariate_names,
                args.alpha,
                args.emmeans_adjust,
                f"ANCOVA model {model_index}",
            )
        )

    for model_index, references in enumerate(args.repeated_measures, 1):
        outcome_name = resolve_column(references[0], names)
        subject_name = resolve_column(references[1], raw_names)
        within_factor = resolve_column(references[2], raw_names)
        if len({outcome_name, subject_name, within_factor}) != 3:
            raise DataError(
                "--repeated-measures requires different outcome, subject, and within-factor columns"
            )
        results["repeated_measures_analyses"].append(
            repeated_measures_anova(
                raw_frame,
                subject_name,
                outcome_name,
                within_factor,
                args.alpha,
                args.emmeans_adjust,
                f"Repeated-measures model {model_index}",
            )
        )

    for model_index, references in enumerate(args.mixed_effects, 1):
        flattened = flatten_column_arguments(references)
        if len(flattened) < 3:
            raise DataError(
                "--mixed-effects requires OUTCOME, GROUP, and at least one fixed predictor"
            )
        outcome_name = resolve_column(flattened[0], names)
        group_name = resolve_column(flattened[1], raw_names)
        predictor_names = resolve_columns(flattened[2:], raw_names)
        if outcome_name == group_name or outcome_name in predictor_names or group_name in predictor_names:
            raise DataError(
                "--mixed-effects requires distinct outcome, grouping, and predictor columns"
            )
        categorical_names = {
            name
            for name in predictor_names
            if name in explicit_categorical or name not in names
        }
        model_polynomials, model_interactions = engineering_for_model(
            predictor_names, categorical_names
        )
        results["mixed_effects_analyses"].append(
            random_intercept_mixed_model(
                raw_frame,
                outcome_name,
                group_name,
                predictor_names,
                categorical_names,
                args.alpha,
                args.mixed_method,
                f"Mixed-effects model {model_index}",
                model_polynomials,
                model_interactions,
            )
        )

    unused_polynomials = set(polynomial_terms) - used_polynomials
    if unused_polynomials:
        names_text = ", ".join(sorted(unused_polynomials))
        raise DataError(
            "--polynomial columns must be numeric predictors in at least one requested model; "
            f"unused: {names_text}"
        )
    unused_interactions = interaction_keys - used_interactions
    if unused_interactions:
        names_text = ", ".join(
            f"{first}:{second}" for first, second in sorted(unused_interactions)
        )
        raise DataError(
            "both --interaction columns must be predictors in at least one requested model; "
            f"unused: {names_text}"
        )

    for reference in args.frequency:
        name = resolve_column(reference, raw_names)
        results["frequency_tables"].append(
            frequency_table(raw_frame[name], name)
        )

    for row_reference, column_reference in args.crosstab:
        row_name = resolve_column(row_reference, raw_names)
        column_name = resolve_column(column_reference, raw_names)
        _different_columns(row_name, column_name, "--crosstab")
        results["contingency_tables"].append(
            contingency_table(
                raw_frame[row_name],
                raw_frame[column_name],
                row_name,
                column_name,
            )
        )

    for row_reference, column_reference in args.chi_square:
        row_name = resolve_column(row_reference, raw_names)
        column_name = resolve_column(column_reference, raw_names)
        _different_columns(row_name, column_name, "--chi-square")
        results["chi_square_tests"].append(
            chi_square_independence(
                raw_frame[row_name],
                raw_frame[column_name],
                row_name,
                column_name,
                args.alpha,
            )
        )

    if args.expected and not args.goodness_of_fit:
        raise DataError("--expected may only be used with --goodness-of-fit")
    if args.goodness_of_fit:
        if not args.expected:
            raise DataError("--goodness-of-fit requires --expected probabilities")
        name = resolve_column(args.goodness_of_fit, raw_names)
        results["goodness_of_fit_tests"].append(
            chi_square_goodness_of_fit(
                raw_frame[name], name, args.expected, args.alpha
            )
        )

    for row_reference, column_reference in args.fisher_exact:
        row_name = resolve_column(row_reference, raw_names)
        column_name = resolve_column(column_reference, raw_names)
        _different_columns(row_name, column_name, "--fisher-exact")
        results["fisher_exact_tests"].append(
            fisher_exact_test(
                raw_frame[row_name],
                raw_frame[column_name],
                row_name,
                column_name,
                args.alternative,
                args.alpha,
            )
        )

    proportion_requested = (
        args.binomial_likelihood or args.one_proportion or args.two_proportion
    )
    if proportion_requested and args.success is None:
        raise DataError(
            "binomial likelihood and proportion analyses require --success VALUE"
        )
    if args.likelihood_p and not args.binomial_likelihood:
        raise DataError("--likelihood-p requires --binomial-likelihood COLUMN")
    if any(
        not math.isfinite(probability) or not 0.0 <= probability <= 1.0
        for probability in args.likelihood_p
    ):
        raise DataError("--likelihood-p values must be between 0 and 1")
    for reference in args.binomial_likelihood:
        name = resolve_column(reference, raw_names)
        results["binomial_likelihood_analyses"].append(
            binomial_likelihood_analysis(
                raw_frame[name],
                name,
                args.success,
                args.likelihood_p,
            )
        )
    if args.p0 is not None and not args.one_proportion:
        raise DataError("--p0 may only be used with --one-proportion")
    if args.one_proportion:
        if args.p0 is None:
            raise DataError("--one-proportion requires --p0 PROBABILITY")
        if not math.isfinite(args.p0) or not 0.0 < args.p0 < 1.0:
            raise DataError("--p0 must be strictly between 0 and 1")
        for reference in args.one_proportion:
            name = resolve_column(reference, raw_names)
            results["one_proportion_tests"].append(
                one_proportion_test(
                    raw_frame[name],
                    name,
                    args.success,
                    args.p0,
                    args.alternative,
                    args.alpha,
                )
            )

    for group_reference, outcome_reference in args.two_proportion:
        group_name = resolve_column(group_reference, raw_names)
        outcome_name = resolve_column(outcome_reference, raw_names)
        _different_columns(group_name, outcome_name, "--two-proportion")
        results["two_proportion_tests"].append(
            two_proportion_test(
                raw_frame[group_name],
                raw_frame[outcome_name],
                group_name,
                outcome_name,
                args.success,
                args.alternative,
                args.alpha,
            )
        )
    if plotting_requested:
        generated_plots: list[dict[str, Any]] = []
        if args.model_plots:
            model_keys = (
                "regression_analyses",
                "multiple_regression_analyses",
                "robust_regression_analyses",
                "regularized_regression_analyses",
                "regression_spline_analyses",
                "smoothing_spline_analyses",
                "loess_analyses",
                "kernel_regression_analyses",
                "isotonic_regression_analyses",
                "binary_logistic_regression_analyses",
                "multinomial_logistic_regression_analyses",
                "poisson_regression_analyses",
                "negative_binomial_regression_analyses",
                "factorial_analyses",
                "repeated_measures_analyses",
                "mixed_effects_analyses",
                "principal_component_analyses",
                "manova_analyses",
                "discriminant_analyses",
            )
            if not any(
                model.get("status") in {"completed", "completed_with_warnings"}
                for key in model_keys
                for model in results[key]
            ):
                raise DataError(
                    "--model-plots requires at least one successfully fitted supported model"
                )
        if args.plot or args.model_plots:
            generated_plots.extend(
                generate_plots(
                    raw_frame,
                    results,
                    plot_requests,
                    args.model_plots,
                    args.plot_dir,
                    args.plot_format,
                    args.plot_dpi,
                )
            )
        if args.bayes_plots:
            generated_plots.extend(
                generate_bayesian_plots(
                    results["bayesian_analyses"],
                    args.plot_dir,
                    args.plot_format,
                    args.plot_dpi,
                )
            )
        results["generated_plots"] = generated_plots
        results["plot_count"] = len(results["generated_plots"])
        results["plot_settings"] = {
            "directory": str(args.plot_dir.resolve()),
            "format": args.plot_format,
            "dpi": args.plot_dpi,
        }
    pca_score_rows: list[dict[str, Any]] = []
    for analysis in results["principal_component_analyses"]:
        rows = analysis.pop("score_rows", [])
        if args.save_pca_scores:
            pca_score_rows.extend(rows)
    if args.save_pca_scores:
        if not pca_score_rows:
            raise DataError("--save-pca-scores requires a completed PCA analysis")
        results["pca_score_rows"] = pca_score_rows
        results["pca_score_export"] = {
            "file": str(args.save_pca_scores),
            "rows": len(pca_score_rows),
            "analyses": len(results["principal_component_analyses"]),
        }

    discriminant_rows: list[dict[str, Any]] = []
    for analysis in results["discriminant_analyses"]:
        rows = analysis.pop("score_rows", [])
        if args.save_discriminant:
            discriminant_rows.extend(rows)
    if args.save_discriminant:
        if not discriminant_rows:
            raise DataError(
                "--save-discriminant requires a completed discriminant analysis"
            )
        results["discriminant_prediction_rows"] = discriminant_rows
        results["discriminant_export"] = {
            "file": str(args.save_discriminant),
            "rows": len(discriminant_rows),
            "analyses": len(results["discriminant_analyses"]),
        }
    prediction_rows: list[dict[str, Any]] = []
    prediction_model_keys = (
        "regression_analyses",
        "multiple_regression_analyses",
        "robust_regression_analyses",
        "regularized_regression_analyses",
        "regression_spline_analyses",
        "smoothing_spline_analyses",
        "loess_analyses",
        "kernel_regression_analyses",
        "isotonic_regression_analyses",
        "binary_logistic_regression_analyses",
        "multinomial_logistic_regression_analyses",
        "poisson_regression_analyses",
        "negative_binomial_regression_analyses",
        "factorial_analyses",
        "repeated_measures_analyses",
        "mixed_effects_analyses",
    )
    for key in prediction_model_keys:
        for model in results[key]:
            rows = model.pop("prediction_rows", [])
            if args.save_predictions or args.save_residuals:
                prediction_rows.extend(rows)
    if (args.save_predictions or args.save_residuals) and not prediction_rows:
        raise DataError(
            "prediction or residual export requires at least one successfully fitted supported model"
        )
    if args.save_predictions or args.save_residuals:
        results["casewise_predictions"] = prediction_rows
        results["casewise_prediction_count"] = len(prediction_rows)
        results["casewise_export_files"] = {
            "predictions": (
                str(args.save_predictions) if args.save_predictions else None
            ),
            "residuals": (
                str(args.save_residuals) if args.save_residuals else None
            ),
        }
    return results


def _validate_aggregate_mode_options(
    parser: argparse.ArgumentParser,
    args: argparse.Namespace,
) -> None:
    allowed = {
        "help",
        "input_file",
        "poisson_count",
        "binomial_likelihood_counts",
        "estimate_binomial_summary",
        "estimate_geometric_summary",
        "estimate_poisson_summary",
        "estimate_negative_binomial_summary",
        "estimate_discrete_uniform_summary",
        "estimate_hypergeometric_count",
        "estimate_multinomial_counts",
        "one_proportion_counts",
        "two_proportion_counts",
        "one_sample_summary",
        "z_summary",
        "two_sample_summary",
        "paired_summary",
        "distribution_probability",
        "distribution_interval",
        "distribution_quantile",
        "distribution_density",
        "distribution_info",
        "bayes_binomial",
        "bayes_poisson",
        "bayes_normal_known",
        "bayes_normal_unknown",
        "bayes_future_trials",
        "bayes_future_exposure",
        "bayes_plots",
        "mean_ci",
        "mean_ci_z",
        "proportion_ci",
        "variance_ci",
        "poisson_rate_ci",
        "power_one_mean",
        "sample_size_one_mean",
        "detectable_effect_one_mean",
        "power_paired_mean",
        "sample_size_paired_mean",
        "detectable_effect_paired_mean",
        "power_two_means",
        "sample_size_two_means",
        "detectable_effect_two_means",
        "power_one_proportion",
        "sample_size_one_proportion",
        "detectable_effect_one_proportion",
        "power_two_proportions",
        "sample_size_two_proportions",
        "detectable_effect_two_proportions",
        "power_anova",
        "sample_size_anova",
        "detectable_effect_anova",
        "allocation_ratio",
        "likelihood_p",
        "p0",
        "mu",
        "alternative",
        "equal_variance",
        "alpha",
        "precision",
        "plot_dir",
        "plot_format",
        "plot_dpi",
        "output",
        "json_output",
    }
    for action in parser._actions:
        if action.dest in allowed or not hasattr(args, action.dest):
            continue
        if getattr(args, action.dest) != action.default:
            option = action.option_strings[0] if action.option_strings else action.dest
            raise DataError(
                f"{option} cannot be combined with no-file calculation commands"
            )


def _summary_sample_size(
    value: float,
    option: str,
    minimum: int,
) -> int:
    if not math.isfinite(value) or not value.is_integer() or value < minimum:
        raise DataError(f"{option} N must be an integer of at least {minimum}")
    return int(value)


def _validate_summary_values(option: str, *values: float) -> None:
    if not all(math.isfinite(value) for value in values):
        raise DataError(f"{option} values must be finite numbers")


def _validate_success_count(
    option: str,
    successes: int,
    trials: int,
) -> None:
    if trials < 1:
        raise DataError(f"{option} TRIALS must be a positive integer")
    if successes < 0 or successes > trials:
        raise DataError(
            f"{option} SUCCESSES must be from 0 through TRIALS"
        )


def _calculator_numbers(values: list[str], option: str) -> list[float]:
    try:
        numbers = [float(value) for value in values]
    except ValueError as exc:
        raise CalculatorError(
            f"{option} numerical values and parameters must be numbers"
        ) from exc
    if not all(math.isfinite(value) for value in numbers):
        raise CalculatorError(
            f"{option} numerical values and parameters must be finite"
        )
    return numbers


def _bayes_numbers(values: list[str], option: str) -> list[float]:
    try:
        numbers = [float(value) for value in values]
    except ValueError as exc:
        raise BayesError(f"{option} prior parameters must be numbers") from exc
    if not all(math.isfinite(value) for value in numbers):
        raise BayesError(f"{option} prior parameters must be finite")
    return numbers


def _run_power_analyses(args: argparse.Namespace) -> list[dict[str, Any]]:
    analyses: list[dict[str, Any]] = []
    for n, effect_size in args.power_one_mean:
        analyses.append(
            one_sample_mean_power(
                n, effect_size, args.alpha, args.alternative
            )
        )
    for effect_size, target_power in args.sample_size_one_mean:
        analyses.append(
            one_sample_mean_sample_size(
                effect_size, target_power, args.alpha, args.alternative
            )
        )
    for n, target_power in args.detectable_effect_one_mean:
        analyses.append(
            one_sample_mean_detectable_effect(
                n, target_power, args.alpha, args.alternative
            )
        )
    for pairs, effect_size in args.power_paired_mean:
        analyses.append(
            one_sample_mean_power(
                pairs, effect_size, args.alpha, args.alternative, paired=True
            )
        )
    for effect_size, target_power in args.sample_size_paired_mean:
        analyses.append(
            one_sample_mean_sample_size(
                effect_size,
                target_power,
                args.alpha,
                args.alternative,
                paired=True,
            )
        )
    for pairs, target_power in args.detectable_effect_paired_mean:
        analyses.append(
            one_sample_mean_detectable_effect(
                pairs,
                target_power,
                args.alpha,
                args.alternative,
                paired=True,
            )
        )
    for n_1, n_2, effect_size in args.power_two_means:
        analyses.append(
            two_sample_mean_power(
                n_1, n_2, effect_size, args.alpha, args.alternative
            )
        )
    for effect_size, target_power in args.sample_size_two_means:
        analyses.append(
            two_sample_mean_sample_size(
                effect_size,
                target_power,
                args.alpha,
                args.alternative,
                args.allocation_ratio,
            )
        )
    for n_1, n_2, target_power in args.detectable_effect_two_means:
        analyses.append(
            two_sample_mean_detectable_effect(
                n_1, n_2, target_power, args.alpha, args.alternative
            )
        )
    for n, actual_probability, null_probability in args.power_one_proportion:
        analyses.append(
            one_proportion_power(
                n,
                actual_probability,
                null_probability,
                args.alpha,
                args.alternative,
            )
        )
    for values in args.sample_size_one_proportion:
        analyses.append(
            one_proportion_sample_size(
                values[0], values[1], values[2], args.alpha, args.alternative
            )
        )
    for n, null_probability, target_power in args.detectable_effect_one_proportion:
        analyses.append(
            one_proportion_detectable_effect(
                n,
                null_probability,
                target_power,
                args.alpha,
                args.alternative,
            )
        )
    for n_1, n_2, probability_1, probability_2 in args.power_two_proportions:
        analyses.append(
            two_proportion_power(
                n_1,
                n_2,
                probability_1,
                probability_2,
                args.alpha,
                args.alternative,
            )
        )
    for probability_1, probability_2, target_power in args.sample_size_two_proportions:
        analyses.append(
            two_proportion_sample_size(
                probability_1,
                probability_2,
                target_power,
                args.alpha,
                args.alternative,
                args.allocation_ratio,
            )
        )
    for values in args.detectable_effect_two_proportions:
        analyses.append(
            two_proportion_detectable_effect(
                values[0],
                values[1],
                values[2],
                values[3],
                args.alpha,
                args.alternative,
            )
        )
    for groups, n_per_group, effect_size in args.power_anova:
        analyses.append(
            one_way_anova_power(groups, n_per_group, effect_size, args.alpha)
        )
    for groups, effect_size, target_power in args.sample_size_anova:
        analyses.append(
            one_way_anova_sample_size(
                groups, effect_size, target_power, args.alpha
            )
        )
    for groups, n_per_group, target_power in args.detectable_effect_anova:
        analyses.append(
            one_way_anova_detectable_effect(
                groups, n_per_group, target_power, args.alpha
            )
        )
    return analyses


def _run_summary_discrete_estimations(
    args: argparse.Namespace,
) -> list[dict[str, Any]]:
    analyses: list[dict[str, Any]] = []
    for request in args.estimate_binomial_summary:
        option = "--estimate-binomial-summary"
        _estimation_request_length(
            request, option, (2, 3), "SUCCESSES TRIALS [P0]"
        )
        successes = _estimation_integer(request[0], f"{option} SUCCESSES", 0)
        trials = _estimation_integer(request[1], f"{option} TRIALS", 1)
        _validate_success_count(option, successes, trials)
        null = _estimation_float(request[2], f"{option} P0") if len(request) == 3 else None
        result = binomial_estimation(
            [successes],
            [trials],
            "summary data",
            args.alpha,
            args.alternative,
            null,
        )
        result["source"] = "summary_data"
        analyses.append(result)

    for request in args.estimate_geometric_summary:
        option = "--estimate-geometric-summary"
        _estimation_request_length(
            request, option, (2, 3), "OBSERVATIONS TOTAL_TRIALS [P0]"
        )
        observations = _estimation_integer(
            request[0], f"{option} OBSERVATIONS", 1
        )
        total_trials = _estimation_integer(
            request[1], f"{option} TOTAL_TRIALS", 1
        )
        null = _estimation_float(request[2], f"{option} P0") if len(request) == 3 else None
        analyses.append(
            geometric_summary_estimation(
                observations,
                total_trials,
                args.alpha,
                args.alternative,
                null,
            )
        )

    for request in args.estimate_poisson_summary:
        option = "--estimate-poisson-summary"
        _estimation_request_length(
            request, option, (2, 3), "OBSERVATIONS TOTAL_EVENTS [MEAN0]"
        )
        observations = _estimation_integer(
            request[0], f"{option} OBSERVATIONS", 1
        )
        total_events = _estimation_integer(
            request[1], f"{option} TOTAL_EVENTS", 0
        )
        null = (
            _estimation_float(request[2], f"{option} MEAN0")
            if len(request) == 3
            else None
        )
        analyses.append(
            poisson_summary_estimation(
                observations,
                total_events,
                args.alpha,
                args.alternative,
                null,
            )
        )

    for request in args.estimate_negative_binomial_summary:
        option = "--estimate-negative-binomial-summary"
        _estimation_request_length(
            request,
            option,
            (3, 4),
            "OBSERVATIONS TOTAL_FAILURES R [P0]",
        )
        observations = _estimation_integer(
            request[0], f"{option} OBSERVATIONS", 1
        )
        failures = _estimation_integer(
            request[1], f"{option} TOTAL_FAILURES", 0
        )
        successes_per_observation = _estimation_integer(
            request[2], f"{option} R", 1
        )
        null = _estimation_float(request[3], f"{option} P0") if len(request) == 4 else None
        analyses.append(
            negative_binomial_known_r_summary_estimation(
                observations,
                failures,
                successes_per_observation,
                args.alpha,
                args.alternative,
                null,
            )
        )

    for request in args.estimate_discrete_uniform_summary:
        option = "--estimate-discrete-uniform-summary"
        _estimation_request_length(
            request, option, (2, 3), "OBSERVATIONS SAMPLE_MAX [N0]"
        )
        observations = _estimation_integer(
            request[0], f"{option} OBSERVATIONS", 1
        )
        sample_maximum = _estimation_integer(
            request[1], f"{option} SAMPLE_MAX", 1
        )
        null = (
            _estimation_integer(request[2], f"{option} N0", 1)
            if len(request) == 3
            else None
        )
        result = discrete_uniform_estimation(
            [sample_maximum],
            "summary data",
            args.alpha,
            null,
            observations_override=observations,
        )
        result["source"] = "summary_data"
        analyses.append(result)

    for request in args.estimate_hypergeometric_count:
        option = "--estimate-hypergeometric-count"
        _estimation_request_length(
            request,
            option,
            (3, 4),
            "OBSERVED POPULATION_SIZE DRAWS [M0]",
        )
        observed = _estimation_integer(request[0], f"{option} OBSERVED", 0)
        population_size = _estimation_integer(
            request[1], f"{option} POPULATION_SIZE", 1
        )
        draws = _estimation_integer(request[2], f"{option} DRAWS", 1)
        null = (
            _estimation_integer(request[3], f"{option} M0", 0)
            if len(request) == 4
            else None
        )
        result = hypergeometric_estimation(
            [observed],
            "summary data",
            population_size,
            draws,
            args.alpha,
            null,
        )
        result["source"] = "summary_data"
        analyses.append(result)

    for request in args.estimate_multinomial_counts:
        option = "--estimate-multinomial-counts"
        if len(request) < 2:
            raise DataError(f"{option} requires at least two LABEL=COUNT values")
        categories: list[str] = []
        counts: list[int] = []
        for token in request:
            if "=" not in token:
                raise DataError(f"{option} values must have the form LABEL=COUNT")
            category, count_text = token.rsplit("=", 1)
            if not category:
                raise DataError(f"{option} category labels cannot be empty")
            categories.append(category)
            counts.append(
                _estimation_integer(count_text, f"{option} count for {category}", 0)
            )
        result = multinomial_count_estimation(
            categories, counts, "summary data", args.alpha
        )
        result["source"] = "summary_data"
        analyses.append(result)
    return analyses


def run_aggregate_count_analysis(args: argparse.Namespace) -> dict[str, Any]:
    mean_tests_requested = bool(
        args.one_sample_summary or args.z_summary or args.two_sample_summary
        or args.paired_summary
    )
    proportion_tests_requested = bool(
        args.one_proportion_counts or args.two_proportion_counts
    )
    discrete_estimation_requested = any(
        (
            args.estimate_binomial_summary,
            args.estimate_geometric_summary,
            args.estimate_poisson_summary,
            args.estimate_negative_binomial_summary,
            args.estimate_discrete_uniform_summary,
            args.estimate_hypergeometric_count,
            args.estimate_multinomial_counts,
        )
    )
    direct_ci_requested = bool(
        args.mean_ci
        or args.mean_ci_z
        or args.proportion_ci
        or args.variance_ci
        or args.poisson_rate_ci
    )
    distribution_requested = bool(
        args.distribution_probability
        or args.distribution_interval
        or args.distribution_quantile
        or args.distribution_density
        or args.distribution_info
    )
    power_requested = any(
        (
            args.power_one_mean,
            args.sample_size_one_mean,
            args.detectable_effect_one_mean,
            args.power_paired_mean,
            args.sample_size_paired_mean,
            args.detectable_effect_paired_mean,
            args.power_two_means,
            args.sample_size_two_means,
            args.detectable_effect_two_means,
            args.power_one_proportion,
            args.sample_size_one_proportion,
            args.detectable_effect_one_proportion,
            args.power_two_proportions,
            args.sample_size_two_proportions,
            args.detectable_effect_two_proportions,
            args.power_anova,
            args.sample_size_anova,
            args.detectable_effect_anova,
        )
    )
    bayesian_requested = bool(
        args.bayes_binomial
        or args.bayes_poisson
        or args.bayes_normal_known
        or args.bayes_normal_unknown
    )
    inferential_analysis_requested = bool(
        mean_tests_requested
        or proportion_tests_requested
        or discrete_estimation_requested
        or args.poisson_count
        or direct_ci_requested
        or power_requested
        or bayesian_requested
    )
    if inferential_analysis_requested and not 0.0 < args.alpha < 1.0:
        raise DataError("--alpha must be strictly between 0 and 1")
    if not inferential_analysis_requested and args.alpha != 0.05:
        raise DataError(
            "--alpha requires an inferential aggregate-count command"
        )
    if args.p0 is not None and not args.one_proportion_counts:
        raise DataError("--p0 requires --one-proportion-counts")
    if args.one_proportion_counts and args.p0 is None:
        raise DataError("--one-proportion-counts requires --p0 PROBABILITY")
    if args.p0 is not None and (
        not math.isfinite(args.p0) or not 0.0 < args.p0 < 1.0
    ):
        raise DataError("--p0 must be strictly between 0 and 1")
    if any(
        not math.isfinite(probability) or not 0.0 <= probability <= 1.0
        for probability in args.likelihood_p
    ):
        raise DataError("--likelihood-p values must be between 0 and 1")
    if args.likelihood_p and not args.binomial_likelihood_counts:
        raise DataError("--likelihood-p requires --binomial-likelihood-counts")
    if not math.isfinite(args.mu):
        raise DataError("--mu must be finite")
    mu_tests_requested = bool(
        args.one_sample_summary or args.z_summary or args.paired_summary
    )
    if args.mu != 0.0 and not mu_tests_requested:
        raise DataError(
            "--mu requires --one-sample-summary, --z-summary, or --paired-summary"
        )
    if args.equal_variance and not args.two_sample_summary:
        raise DataError("--equal-variance requires --two-sample-summary")
    directional_power_requested = any(
        (
            args.power_one_mean,
            args.sample_size_one_mean,
            args.detectable_effect_one_mean,
            args.power_paired_mean,
            args.sample_size_paired_mean,
            args.detectable_effect_paired_mean,
            args.power_two_means,
            args.sample_size_two_means,
            args.detectable_effect_two_means,
            args.power_one_proportion,
            args.sample_size_one_proportion,
            args.detectable_effect_one_proportion,
            args.power_two_proportions,
            args.sample_size_two_proportions,
            args.detectable_effect_two_proportions,
        )
    )
    directional_tests_requested = bool(
        mean_tests_requested
        or proportion_tests_requested
        or discrete_estimation_requested
        or directional_power_requested
    )
    if args.alternative != "two-sided" and not directional_tests_requested:
        raise DataError(
            "--alternative requires a summary mean, proportion, power, or "
            "discrete-estimation command"
        )
    if args.allocation_ratio != 1.0 and not (
        args.sample_size_two_means or args.sample_size_two_proportions
    ):
        raise DataError(
            "--allocation-ratio requires --sample-size-two-means or "
            "--sample-size-two-proportions"
        )
    if args.bayes_plots and not bayesian_requested:
        raise DataError("--bayes-plots requires at least one Bayesian analysis")
    if args.bayes_future_trials != 1 and not args.bayes_binomial:
        raise DataError("--bayes-future-trials requires --bayes-binomial")
    if args.bayes_future_exposure != 1.0 and not args.bayes_poisson:
        raise DataError("--bayes-future-exposure requires --bayes-poisson")
    plot_settings_changed = (
        args.plot_dir != Path("plots")
        or args.plot_format != "png"
        or args.plot_dpi != 150
    )
    if plot_settings_changed and not args.bayes_plots:
        raise DataError(
            "--plot-dir, --plot-format, and --plot-dpi require --bayes-plots "
            "in no-file calculation mode"
        )
    if args.bayes_plots and not 50 <= args.plot_dpi <= 600:
        raise DataError("--plot-dpi must be an integer from 50 through 600")

    distribution_calculations: list[dict[str, Any]] = []
    for request in args.distribution_probability:
        if len(request) < 4:
            raise CalculatorError(
                "--distribution-probability requires DISTRIBUTION, RELATION, "
                "VALUE, and distribution parameter(s)"
            )
        numbers = _calculator_numbers(
            request[2:], "--distribution-probability"
        )
        distribution_calculations.append(
            distribution_probability(
                request[0], request[1], numbers[0], numbers[1:]
            )
        )
    for request in args.distribution_interval:
        if len(request) < 4:
            raise CalculatorError(
                "--distribution-interval requires DISTRIBUTION, LOWER, UPPER, "
                "and distribution parameter(s)"
            )
        numbers = _calculator_numbers(request[1:], "--distribution-interval")
        distribution_calculations.append(
            distribution_interval_probability(
                request[0], numbers[0], numbers[1], numbers[2:]
            )
        )
    for request in args.distribution_quantile:
        if len(request) < 3:
            raise CalculatorError(
                "--distribution-quantile requires DISTRIBUTION, "
                "CUMULATIVE_PROBABILITY, and distribution parameter(s)"
            )
        numbers = _calculator_numbers(request[1:], "--distribution-quantile")
        distribution_calculations.append(
            distribution_quantile(request[0], numbers[0], numbers[1:])
        )
    for request in args.distribution_density:
        if len(request) < 3:
            raise CalculatorError(
                "--distribution-density requires DISTRIBUTION, X, and "
                "distribution parameter(s)"
            )
        numbers = _calculator_numbers(request[1:], "--distribution-density")
        distribution_calculations.append(
            distribution_density(request[0], numbers[0], numbers[1:])
        )
    for request in args.distribution_info:
        if len(request) < 2:
            raise CalculatorError(
                "--distribution-info requires DISTRIBUTION and parameter(s)"
            )
        numbers = _calculator_numbers(request[1:], "--distribution-info")
        distribution_calculations.append(
            distribution_info(request[0], numbers)
        )

    mean_confidence_intervals: list[dict[str, Any]] = []
    for n_value, sample_mean, sample_sd in args.mean_ci:
        n = _summary_sample_size(n_value, "--mean-ci", 2)
        mean_confidence_intervals.append(
            mean_confidence_interval(
                n, sample_mean, sample_sd, args.alpha, False
            )
        )
    for n_value, sample_mean, population_sd in args.mean_ci_z:
        n = _summary_sample_size(n_value, "--mean-ci-z", 1)
        mean_confidence_intervals.append(
            mean_confidence_interval(
                n, sample_mean, population_sd, args.alpha, True
            )
        )

    proportion_confidence_intervals: list[dict[str, Any]] = []
    for successes, trials in args.proportion_ci:
        proportion_confidence_intervals.append(
            proportion_confidence_interval(successes, trials, args.alpha)
        )

    variance_confidence_intervals: list[dict[str, Any]] = []
    for n_value, sample_variance in args.variance_ci:
        n = _summary_sample_size(n_value, "--variance-ci", 2)
        variance_confidence_intervals.append(
            variance_confidence_interval(n, sample_variance, args.alpha)
        )

    poisson_rate_confidence_intervals: list[dict[str, Any]] = []
    for events_value, exposure in args.poisson_rate_ci:
        events = _summary_sample_size(events_value, "--poisson-rate-ci EVENTS", 0)
        poisson_rate_confidence_intervals.append(
            poisson_rate_confidence_interval(events, exposure, args.alpha)
        )

    power_analyses = _run_power_analyses(args)

    bayesian_analyses: list[dict[str, Any]] = []
    for successes, trials, prior_alpha, prior_beta in args.bayes_binomial:
        bayesian_analyses.append(
            beta_binomial_analysis(
                successes,
                trials,
                prior_alpha,
                prior_beta,
                args.alpha,
                args.bayes_future_trials,
            )
        )
    for events, exposure, prior_shape, prior_rate in args.bayes_poisson:
        bayesian_analyses.append(
            gamma_poisson_analysis(
                events,
                exposure,
                prior_shape,
                prior_rate,
                args.alpha,
                args.bayes_future_exposure,
            )
        )
    for n, sample_mean, sigma, prior_mean, prior_sd in args.bayes_normal_known:
        bayesian_analyses.append(
            normal_known_variance_analysis(
                n,
                sample_mean,
                sigma,
                prior_mean,
                prior_sd,
                args.alpha,
            )
        )
    for request in args.bayes_normal_unknown:
        bayesian_analyses.append(
            normal_inverse_gamma_analysis(
                request[0],
                request[1],
                request[2],
                request[3],
                request[4],
                request[5],
                request[6],
                args.alpha,
            )
        )

    discrete_estimation_analyses = _run_summary_discrete_estimations(args)

    likelihood_analyses: list[dict[str, Any]] = []
    for successes, trials in args.binomial_likelihood_counts:
        _validate_success_count(
            "--binomial-likelihood-counts", successes, trials
        )
        likelihood_analyses.append(
            binomial_likelihood_counts_analysis(
                successes,
                trials,
                args.likelihood_p,
            )
        )

    poisson_analyses: list[dict[str, Any]] = []
    for events in args.poisson_count:
        if events < 0:
            raise DataError("--poisson-count EVENTS must be a nonnegative integer")
        poisson_analyses.append(
            poisson_mean_confidence_interval(events, args.alpha)
        )

    one_proportion_analyses: list[dict[str, Any]] = []
    for successes, trials in args.one_proportion_counts:
        _validate_success_count(
            "--one-proportion-counts", successes, trials
        )
        one_proportion_analyses.append(
            one_proportion_counts_test(
                successes,
                trials,
                args.p0,
                args.alternative,
                args.alpha,
            )
        )

    two_proportion_analyses: list[dict[str, Any]] = []
    for successes_1, trials_1, successes_2, trials_2 in args.two_proportion_counts:
        _validate_success_count(
            "--two-proportion-counts sample 1", successes_1, trials_1
        )
        _validate_success_count(
            "--two-proportion-counts sample 2", successes_2, trials_2
        )
        two_proportion_analyses.append(
            two_proportion_counts_test(
                successes_1,
                trials_1,
                successes_2,
                trials_2,
                args.alternative,
                args.alpha,
            )
        )

    summary_one_sample_tests: list[dict[str, Any]] = []
    for n_value, sample_mean, sample_sd in args.one_sample_summary:
        n = _summary_sample_size(n_value, "--one-sample-summary", 2)
        _validate_summary_values("--one-sample-summary", sample_mean, sample_sd)
        if sample_sd <= 0.0:
            raise DataError("--one-sample-summary SD must be positive")
        summary_one_sample_tests.append(
            one_sample_summary_t_test(
                n,
                sample_mean,
                sample_sd,
                args.mu,
                args.alternative,
                args.alpha,
            )
        )

    summary_z_tests: list[dict[str, Any]] = []
    for n_value, sample_mean, population_sd in args.z_summary:
        n = _summary_sample_size(n_value, "--z-summary", 1)
        _validate_summary_values("--z-summary", sample_mean, population_sd)
        if population_sd <= 0.0:
            raise DataError("--z-summary SIGMA must be positive")
        summary_z_tests.append(
            one_sample_summary_z_test(
                n,
                sample_mean,
                population_sd,
                args.mu,
                args.alternative,
                args.alpha,
            )
        )

    summary_two_sample_tests: list[dict[str, Any]] = []
    for values in args.two_sample_summary:
        n_1 = _summary_sample_size(values[0], "--two-sample-summary N1", 2)
        n_2 = _summary_sample_size(values[3], "--two-sample-summary N2", 2)
        mean_1, sd_1, mean_2, sd_2 = values[1], values[2], values[4], values[5]
        _validate_summary_values(
            "--two-sample-summary", mean_1, sd_1, mean_2, sd_2
        )
        if sd_1 <= 0.0 or sd_2 <= 0.0:
            raise DataError("--two-sample-summary SD1 and SD2 must be positive")
        summary_two_sample_tests.append(
            two_sample_summary_t_test(
                n_1,
                mean_1,
                sd_1,
                n_2,
                mean_2,
                sd_2,
                args.equal_variance,
                args.alternative,
                args.alpha,
            )
        )

    summary_paired_tests: list[dict[str, Any]] = []
    for n_value, mean_difference, difference_sd in args.paired_summary:
        n_pairs = _summary_sample_size(n_value, "--paired-summary", 2)
        _validate_summary_values(
            "--paired-summary", mean_difference, difference_sd
        )
        if difference_sd <= 0.0:
            raise DataError("--paired-summary SD_DIFFERENCE must be positive")
        summary_paired_tests.append(
            paired_summary_t_test(
                n_pairs,
                mean_difference,
                difference_sd,
                args.mu,
                args.alternative,
                args.alpha,
            )
        )

    aggregate_analysis_count = sum(
        len(items)
        for items in (
            likelihood_analyses,
            poisson_analyses,
            one_proportion_analyses,
            two_proportion_analyses,
            summary_one_sample_tests,
            summary_z_tests,
            summary_two_sample_tests,
            summary_paired_tests,
            distribution_calculations,
            mean_confidence_intervals,
            proportion_confidence_intervals,
            variance_confidence_intervals,
            poisson_rate_confidence_intervals,
            power_analyses,
            bayesian_analyses,
            discrete_estimation_analyses,
        )
    )

    results = _empty_results(
        {
            "program_version": __version__,
            "analysis_source": (
                "summary_data"
                if mean_tests_requested or discrete_estimation_requested
                else "direct_calculations"
                if distribution_requested
                or direct_ci_requested
                or power_requested
                or bayesian_requested
                else "aggregate_counts"
            ),
            "input_file": None,
            "rows": 0,
            "aggregate_analysis_count": aggregate_analysis_count,
            "columns_found": 0,
            "column_names": [],
            "numeric_columns_found": 0,
            "numeric_column_names": [],
            "analyzed_columns": [],
            "header_detected": False,
            "delimiter": "not applicable",
            "alpha": args.alpha,
            "output_precision": args.precision,
            "alternative": args.alternative,
        }
    )
    results["poisson_mean_analyses"] = poisson_analyses
    results["binomial_likelihood_analyses"] = likelihood_analyses
    results["one_proportion_count_tests"] = one_proportion_analyses
    results["two_proportion_count_tests"] = two_proportion_analyses
    results["summary_one_sample_tests"] = summary_one_sample_tests
    results["summary_z_tests"] = summary_z_tests
    results["summary_two_sample_tests"] = summary_two_sample_tests
    results["summary_paired_tests"] = summary_paired_tests
    results["distribution_calculations"] = distribution_calculations
    results["mean_confidence_intervals"] = mean_confidence_intervals
    results["proportion_confidence_intervals"] = proportion_confidence_intervals
    results["variance_confidence_intervals"] = variance_confidence_intervals
    results["poisson_rate_confidence_intervals"] = poisson_rate_confidence_intervals
    results["power_analyses"] = power_analyses
    results["bayesian_analyses"] = bayesian_analyses
    results["discrete_distribution_estimates"] = discrete_estimation_analyses
    if args.bayes_plots:
        results["generated_plots"] = generate_bayesian_plots(
            bayesian_analyses,
            args.plot_dir,
            args.plot_format,
            args.plot_dpi,
        )
        results["plot_count"] = len(results["generated_plots"])
        results["plot_settings"] = {
            "directory": str(args.plot_dir.resolve()),
            "format": args.plot_format,
            "dpi": args.plot_dpi,
        }
    return results


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        set_output_precision(args.precision)
        transformed_export_frame: pd.DataFrame | None = None
        aggregate_mode = bool(
            args.binomial_likelihood_counts
            or args.poisson_count
            or args.estimate_binomial_summary
            or args.estimate_geometric_summary
            or args.estimate_poisson_summary
            or args.estimate_negative_binomial_summary
            or args.estimate_discrete_uniform_summary
            or args.estimate_hypergeometric_count
            or args.estimate_multinomial_counts
            or args.one_proportion_counts
            or args.two_proportion_counts
            or args.one_sample_summary
            or args.z_summary
            or args.two_sample_summary
            or args.paired_summary
            or args.distribution_probability
            or args.distribution_interval
            or args.distribution_quantile
            or args.distribution_density
            or args.distribution_info
            or args.mean_ci
            or args.mean_ci_z
            or args.proportion_ci
            or args.variance_ci
            or args.poisson_rate_ci
            or args.power_one_mean
            or args.sample_size_one_mean
            or args.detectable_effect_one_mean
            or args.power_paired_mean
            or args.sample_size_paired_mean
            or args.detectable_effect_paired_mean
            or args.power_two_means
            or args.sample_size_two_means
            or args.detectable_effect_two_means
            or args.power_one_proportion
            or args.sample_size_one_proportion
            or args.detectable_effect_one_proportion
            or args.power_two_proportions
            or args.sample_size_two_proportions
            or args.detectable_effect_two_proportions
            or args.power_anova
            or args.sample_size_anova
            or args.detectable_effect_anova
            or args.bayes_binomial
            or args.bayes_poisson
            or args.bayes_normal_known
            or args.bayes_normal_unknown
        )
        if aggregate_mode:
            if args.input_file is not None:
                raise DataError(
                    "no-file calculation commands do not use an input file"
                )
            _validate_aggregate_mode_options(parser, args)
            input_path = None
            results = make_json_safe(run_aggregate_count_analysis(args))
        else:
            if args.input_file is None:
                raise DataError(
                    "an input file is required unless "
                    "a no-file calculation command is used"
                )
            input_path = args.input_file.resolve()
            if (
                args.plot or args.model_plots or args.bayes_plots
            ) and args.plot_dir.resolve() == input_path:
                raise DataError("the plot directory cannot be the input data file")
            raw_results = run_analysis(args)
            transformed_export_frame = raw_results.pop(
                "_transformed_export_frame", None
            )
            results = make_json_safe(raw_results)

        output_paths = [
            path
            for path in (
                args.output,
                args.json_output,
                args.save_predictions,
                args.save_residuals,
                args.save_transformed,
                args.save_pca_scores,
                args.save_discriminant,
            )
            if path
        ]
        if input_path is not None and any(
            path.resolve() == input_path for path in output_paths
        ):
            raise DataError("an output file cannot overwrite the input data file")
        resolved_outputs = [path.resolve() for path in output_paths]
        if len(set(resolved_outputs)) != len(resolved_outputs):
            raise DataError("every output option must name a different file")

        report = build_text_report(results)
        sys.stdout.write(report)
        if args.output:
            args.output.write_text(report, encoding="utf-8")
        if args.json_output:
            args.json_output.write_text(
                json.dumps(
                    results,
                    indent=2,
                    ensure_ascii=False,
                    allow_nan=False,
                )
                + "\n",
                encoding="utf-8",
            )
        prediction_rows = results.get("casewise_predictions", [])
        if args.save_predictions:
            pd.DataFrame(prediction_rows).to_csv(
                args.save_predictions, index=False
            )
        if args.save_residuals:
            residual_columns = [
                name
                for name in (
                    "model_family",
                    "model_name",
                    "source_index",
                    "subject",
                    "group",
                    "within_level",
                    "outcome_variable",
                    "observed",
                    "observed_category",
                    "predicted",
                    "predicted_category",
                    "residual",
                    "pearson_residual",
                )
                if any(name in row for row in prediction_rows)
            ]
            pd.DataFrame(prediction_rows).reindex(
                columns=residual_columns
            ).to_csv(args.save_residuals, index=False)
        if args.save_transformed:
            if transformed_export_frame is None:
                raise DataError(
                    "--save-transformed requires completed data processing"
                )
            transformed_export_frame.to_csv(args.save_transformed, index=False)
        if args.save_pca_scores:
            pd.DataFrame(results.get("pca_score_rows", [])).to_csv(
                args.save_pca_scores, index=False
            )
        if args.save_discriminant:
            pd.DataFrame(
                results.get("discriminant_prediction_rows", [])
            ).to_csv(args.save_discriminant, index=False)
    except MemoryError:
        parser.exit(
            2,
            "error: the requested operation exhausted available memory. No "
            "automatic row truncation was applied; reduce the input or the "
            "requested method intentionally, or make more memory available.\n",
        )
    except (
        BayesError,
        AdvancedRegressionError,
        CalculatorError,
        DataError,
        DiscreteEstimationError,
        OSError,
        PowerError,
        TransformationError,
    ) as exc:
        parser.exit(2, f"error: {exc}\n")
    return 0
