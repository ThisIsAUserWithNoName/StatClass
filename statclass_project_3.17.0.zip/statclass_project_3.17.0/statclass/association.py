"""Pearson, Spearman, and Kendall association tests."""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .data import paired_samples
from .utils import decision_from_pvalue, finite_or_none


CORRELATION_METHODS = ("pearson", "spearman", "kendall")


def correlation_tests(
    first: pd.Series,
    second: pd.Series,
    first_name: str,
    second_name: str,
    methods: list[str],
    alpha: float,
) -> dict[str, Any]:
    sample_1, sample_2 = paired_samples(first, second)
    n = sample_1.size
    result: dict[str, Any] = {
        "column_1": first_name,
        "column_2": second_name,
        "n_complete_pairs": int(n),
        "tests": [],
    }
    if n < 3:
        for method in methods:
            result["tests"].append(
                {
                    "method": method.title(),
                    "status": "not_run",
                    "reason": "requires at least 3 complete pairs",
                }
            )
        return result
    if np.ptp(sample_1) == 0 or np.ptp(sample_2) == 0:
        for method in methods:
            result["tests"].append(
                {
                    "method": method.title(),
                    "status": "not_run",
                    "reason": "correlation is undefined for a constant variable",
                }
            )
        return result

    for method in methods:
        if method == "pearson":
            test = scipy_stats.pearsonr(sample_1, sample_2)
            display_name = "Pearson correlation"
            coefficient_name = "r"
        elif method == "spearman":
            test = scipy_stats.spearmanr(sample_1, sample_2)
            display_name = "Spearman rank correlation"
            coefficient_name = "rho"
        elif method == "kendall":
            test = scipy_stats.kendalltau(sample_1, sample_2)
            display_name = "Kendall rank correlation"
            coefficient_name = "tau"
        else:
            raise ValueError(f"unsupported correlation method: {method}")

        coefficient = float(test.statistic)
        p_value = float(test.pvalue)
        result["tests"].append(
            {
                "method": display_name,
                "status": "completed",
                "null_hypothesis": "population association coefficient = 0",
                "coefficient_name": coefficient_name,
                "coefficient": finite_or_none(coefficient),
                "p_value": finite_or_none(p_value),
                "decision": decision_from_pvalue(p_value, alpha),
            }
        )
    return result

