"""Conjugate Bayesian analyses for aggregate summaries and data columns."""

from __future__ import annotations

import math
from typing import Any

from scipy import stats as scipy_stats


class BayesError(ValueError):
    """Raised when a conjugate Bayesian analysis request is invalid."""


def _finite(value: float, label: str) -> float:
    numeric = float(value)
    if not math.isfinite(numeric):
        raise BayesError(f"{label} must be finite")
    return numeric


def _positive(value: float, label: str) -> float:
    numeric = _finite(value, label)
    if numeric <= 0.0:
        raise BayesError(f"{label} must be positive")
    return numeric


def _count(value: float, label: str, minimum: int = 0) -> int:
    if isinstance(value, bool):
        raise BayesError(f"{label} must be an integer of at least {minimum}")
    numeric = _finite(value, label)
    if not numeric.is_integer() or numeric < minimum:
        raise BayesError(f"{label} must be an integer of at least {minimum}")
    return int(numeric)


def _interval_alpha(alpha: float) -> float:
    alpha = _finite(alpha, "alpha")
    if not 0.0 < alpha < 1.0:
        raise BayesError("alpha must be strictly between 0 and 1")
    return alpha


def _computed_finite(
    value: float,
    label: str,
    *,
    positive: bool = False,
    nonnegative: bool = False,
) -> float:
    """Validate a floating-point result produced by posterior algebra."""
    numeric = float(value)
    if not math.isfinite(numeric):
        raise BayesError(f"{label} is nonfinite")
    if positive and numeric <= 0.0:
        raise BayesError(f"{label} must be positive")
    if nonnegative and numeric < 0.0:
        raise BayesError(f"{label} must be nonnegative")
    return numeric


def _computed_square(value: float, label: str) -> float:
    """Square a finite value and reject overflow."""
    return _computed_finite(float(value) * float(value), label, nonnegative=True)


def _validate_posterior_parameters(
    parameters: dict[str, float],
    *,
    positive: set[str],
) -> dict[str, Any]:
    """Validate computed posterior hyperparameters before distribution calls."""
    for name, value in parameters.items():
        if not math.isfinite(float(value)):
            raise BayesError(f"computed posterior parameter {name} is nonfinite")
        if name in positive and float(value) <= 0.0:
            raise BayesError(
                f"computed posterior parameter {name} must be positive"
            )
    return {
        "status": "validated",
        "finite": True,
        "within_parameter_support": True,
        "parameters_checked": list(parameters),
        "positive_parameters": sorted(positive),
    }


def _validate_interval_result(
    values: list[float | int],
    label: str,
    *,
    support_lower: float = -math.inf,
    support_upper: float = math.inf,
    integer_endpoints: bool = False,
    strictly_inside_support: bool = False,
) -> dict[str, Any]:
    """Validate finiteness, ordering, support, and endpoint type for an interval."""
    numeric = [float(value) for value in values]
    finite = all(math.isfinite(value) for value in numeric)
    ordered = finite and numeric[0] <= numeric[1]
    within_support = bool(
        finite
        and numeric[0] >= support_lower
        and numeric[1] <= support_upper
    )
    integers_valid = bool(
        not integer_endpoints
        or all(value.is_integer() for value in numeric)
    )
    if not finite:
        raise BayesError(f"{label} returned a nonfinite endpoint")
    if not ordered:
        raise BayesError(f"{label} returned endpoints in decreasing order")
    if not within_support:
        raise BayesError(f"{label} returned an endpoint outside its support")
    if not integers_valid:
        raise BayesError(f"{label} returned a noninteger discrete endpoint")
    boundary_value = bool(
        strictly_inside_support
        and (
            (math.isfinite(support_lower) and numeric[0] <= support_lower)
            or (math.isfinite(support_upper) and numeric[1] >= support_upper)
        )
    )
    warnings = (
        [
            f"{label} reached a floating-point support boundary; the exact interior quantile may be beyond numeric resolution."
        ]
        if boundary_value
        else []
    )
    return {
        "label": label,
        "status": "validated_with_warning" if warnings else "validated",
        "method": "specialized inverse CDF (PPF)",
        "finite": finite,
        "ordered": ordered,
        "support": {
            "lower": support_lower if math.isfinite(support_lower) else None,
            "upper": support_upper if math.isfinite(support_upper) else None,
        },
        "within_support": within_support,
        "integer_endpoints_required": integer_endpoints,
        "integer_endpoints_valid": integers_valid,
        "boundary_value": boundary_value,
        "warnings": warnings,
    }


def _validate_probability_result(
    value: float,
    label: str,
    method: str = "specialized probability mass function",
) -> dict[str, Any]:
    """Validate a computed Bayesian predictive probability."""
    numeric = float(value)
    tolerance = 1e-12
    if not math.isfinite(numeric):
        raise BayesError(f"{label} returned a nonfinite probability")
    if numeric < -tolerance or numeric > 1.0 + tolerance:
        raise BayesError(f"{label} returned a probability outside [0, 1]")
    return {
        "label": label,
        "status": "validated",
        "method": method,
        "finite": True,
        "within_probability_support": True,
    }


def _bayesian_numerical_status(
    posterior_parameters: dict[str, Any],
    intervals: list[dict[str, Any]],
    probabilities: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Describe the noniterative numerical work in a conjugate analysis."""
    probability_checks = probabilities or []
    warnings = [
        warning
        for validation in intervals
        for warning in validation.get("warnings", [])
    ]
    return {
        "status": "warning" if warnings else "completed",
        "posterior_update_method": "closed-form conjugate algebra",
        "interval_method": "specialized inverse CDF (PPF)",
        "derivatives_used": False,
        "optimization_used": False,
        "iterative_algorithm_used": False,
        "numerical_integration_used": False,
        "ode_solver_used": False,
        "mcmc_used": False,
        "posterior_parameter_validation": posterior_parameters,
        "interval_validations": intervals,
        "probability_validations": probability_checks,
        "warnings": warnings,
    }


def _beta_summary(alpha: float, beta: float) -> dict[str, Any]:
    total = _computed_finite(alpha + beta, "beta parameter total", positive=True)
    if alpha > 1.0 and beta > 1.0:
        mode: float | list[float] | None = (alpha - 1.0) / (total - 2.0)
        mode_status = "unique interior mode"
    elif alpha < 1.0 and beta < 1.0:
        mode = [0.0, 1.0]
        mode_status = "two boundary modes"
    elif alpha <= 1.0 and beta > 1.0:
        mode = 0.0
        mode_status = "boundary mode"
    elif alpha > 1.0 and beta <= 1.0:
        mode = 1.0
        mode_status = "boundary mode"
    else:
        mode = None
        mode_status = "no unique mode"
    mean = _computed_finite(alpha / total, "beta mean")
    variance = _computed_finite(
        mean * (1.0 - mean) / (total + 1.0),
        "beta variance",
        nonnegative=True,
    )
    return {
        "distribution": "beta",
        "alpha": alpha,
        "beta": beta,
        "mean": mean,
        "variance": variance,
        "mode": mode,
        "mode_status": mode_status,
    }


def _gamma_summary(shape: float, rate: float) -> dict[str, Any]:
    mean = _computed_finite(shape / rate, "gamma mean", positive=True)
    variance = _computed_finite(
        mean / rate, "gamma variance", positive=True
    )
    mode = _computed_finite(
        max(0.0, (shape - 1.0) / rate),
        "gamma mode",
        nonnegative=True,
    )
    return {
        "distribution": "gamma",
        "parameterization": "shape-rate",
        "shape": shape,
        "rate": rate,
        "mean": mean,
        "variance": variance,
        "mode": mode,
        "mode_status": "interior mode" if shape > 1.0 else "boundary mode",
    }


def _normal_summary(mean: float, standard_deviation: float) -> dict[str, Any]:
    return {
        "distribution": "normal",
        "mean": mean,
        "variance": _computed_square(
            standard_deviation, "normal variance"
        ),
        "standard_deviation": standard_deviation,
        "mode": mean,
    }


def beta_binomial_analysis(
    successes: int,
    trials: int,
    prior_alpha: float,
    prior_beta: float,
    interval_alpha: float = 0.05,
    future_trials: int = 1,
    *,
    source: str = "aggregate_counts",
    column: str | None = None,
    success_value: str | None = None,
    missing: int = 0,
) -> dict[str, Any]:
    """Update a beta prior with binomial observations."""
    trials = _count(trials, "trials", 1)
    successes = _count(successes, "successes")
    if successes > trials:
        raise BayesError("successes must be from 0 through trials")
    prior_alpha = _positive(prior_alpha, "prior alpha")
    prior_beta = _positive(prior_beta, "prior beta")
    interval_alpha = _interval_alpha(interval_alpha)
    future_trials = _count(future_trials, "future trials", 1)

    posterior_alpha = prior_alpha + successes
    posterior_beta = prior_beta + trials - successes
    posterior_parameter_validation = _validate_posterior_parameters(
        {"alpha": posterior_alpha, "beta": posterior_beta},
        positive={"alpha", "beta"},
    )
    prior = _beta_summary(prior_alpha, prior_beta)
    posterior = _beta_summary(posterior_alpha, posterior_beta)
    credible_interval = [
        float(scipy_stats.beta.ppf(interval_alpha / 2.0, posterior_alpha, posterior_beta)),
        float(
            scipy_stats.beta.ppf(
                1.0 - interval_alpha / 2.0,
                posterior_alpha,
                posterior_beta,
            )
        ),
    ]
    predictive_distribution = scipy_stats.betabinom(
        future_trials, posterior_alpha, posterior_beta
    )
    predictive_interval_raw = [
        float(predictive_distribution.ppf(interval_alpha / 2.0)),
        float(predictive_distribution.ppf(1.0 - interval_alpha / 2.0)),
    ]
    interval_validations = [
        _validate_interval_result(
            credible_interval,
            "beta posterior credible interval",
            support_lower=0.0,
            support_upper=1.0,
            strictly_inside_support=True,
        ),
        _validate_interval_result(
            predictive_interval_raw,
            "beta-binomial posterior-predictive interval",
            support_lower=0.0,
            support_upper=float(future_trials),
            integer_endpoints=True,
        ),
    ]
    predictive_interval = [int(value) for value in predictive_interval_raw]
    predictive_mean = _computed_finite(
        future_trials * posterior["mean"],
        "beta-binomial predictive mean",
        nonnegative=True,
    )
    posterior_total = posterior_alpha + posterior_beta
    predictive_variance = _computed_finite(
        future_trials
        * posterior["mean"]
        * (1.0 - posterior["mean"])
        * (posterior_total + future_trials)
        / (posterior_total + 1.0),
        "beta-binomial predictive variance",
        nonnegative=True,
    )
    result: dict[str, Any] = {
        "model": "beta-binomial",
        "method": "beta-binomial conjugate analysis",
        "source": source,
        "status": "completed",
        "successes": successes,
        "failures": trials - successes,
        "trials": trials,
        "missing": int(missing),
        "prior": prior,
        "posterior": posterior,
        "credible_level": 1.0 - interval_alpha,
        "credible_interval": credible_interval,
        "posterior_predictive": {
            "distribution": "beta-binomial",
            "future_trials": future_trials,
            "mean_successes": predictive_mean,
            "variance_successes": predictive_variance,
            "probability_of_success_on_next_trial": posterior["mean"],
            "predictive_interval": predictive_interval,
        },
        "numerical_status": _bayesian_numerical_status(
            posterior_parameter_validation,
            interval_validations,
            [
                _validate_probability_result(
                    posterior["mean"],
                    "posterior predictive success probability",
                    "closed-form posterior predictive probability",
                )
            ],
        ),
    }
    if column is not None:
        result["column"] = column
    if success_value is not None:
        result["success_value"] = success_value
    return result


def gamma_poisson_analysis(
    events: int,
    exposure: float,
    prior_shape: float,
    prior_rate: float,
    interval_alpha: float = 0.05,
    future_exposure: float = 1.0,
    *,
    source: str = "aggregate_counts",
    column: str | None = None,
    exposure_column: str | None = None,
    observations: int | None = None,
    missing: int = 0,
) -> dict[str, Any]:
    """Update a shape-rate gamma prior with Poisson event data."""
    events = _count(events, "events")
    exposure = _positive(exposure, "exposure")
    prior_shape = _positive(prior_shape, "prior shape")
    prior_rate = _positive(prior_rate, "prior rate")
    interval_alpha = _interval_alpha(interval_alpha)
    future_exposure = _positive(future_exposure, "future exposure")

    posterior_shape = prior_shape + events
    posterior_rate = prior_rate + exposure
    posterior_parameter_validation = _validate_posterior_parameters(
        {"shape": posterior_shape, "rate": posterior_rate},
        positive={"shape", "rate"},
    )
    prior = _gamma_summary(prior_shape, prior_rate)
    posterior = _gamma_summary(posterior_shape, posterior_rate)
    credible_interval = [
        float(
            scipy_stats.gamma.ppf(
                interval_alpha / 2.0,
                posterior_shape,
                scale=1.0 / posterior_rate,
            )
        ),
        float(
            scipy_stats.gamma.ppf(
                1.0 - interval_alpha / 2.0,
                posterior_shape,
                scale=1.0 / posterior_rate,
            )
        ),
    ]
    predictive_probability = posterior_rate / (posterior_rate + future_exposure)
    predictive_distribution = scipy_stats.nbinom(
        posterior_shape, predictive_probability
    )
    predictive_mean = _computed_finite(
        future_exposure * posterior_shape / posterior_rate,
        "gamma-Poisson predictive mean",
        nonnegative=True,
    )
    predictive_variance = _computed_finite(
        predictive_mean * (1.0 + future_exposure / posterior_rate),
        "gamma-Poisson predictive variance",
        nonnegative=True,
    )
    predictive_zero_probability = float(predictive_distribution.pmf(0))
    predictive_interval_raw = [
        float(predictive_distribution.ppf(interval_alpha / 2.0)),
        float(predictive_distribution.ppf(1.0 - interval_alpha / 2.0)),
    ]
    interval_validations = [
        _validate_interval_result(
            credible_interval,
            "gamma posterior credible interval",
            support_lower=0.0,
            strictly_inside_support=True,
        ),
        _validate_interval_result(
            predictive_interval_raw,
            "negative-binomial posterior-predictive interval",
            support_lower=0.0,
            integer_endpoints=True,
        ),
    ]
    predictive_interval = [int(value) for value in predictive_interval_raw]
    result: dict[str, Any] = {
        "model": "gamma-poisson",
        "method": "gamma-Poisson conjugate analysis",
        "source": source,
        "status": "completed",
        "events": events,
        "exposure": exposure,
        "missing": int(missing),
        "prior": prior,
        "posterior": posterior,
        "credible_level": 1.0 - interval_alpha,
        "credible_interval": credible_interval,
        "posterior_predictive": {
            "distribution": "negative-binomial",
            "future_exposure": future_exposure,
            "mean_events": predictive_mean,
            "variance_events": predictive_variance,
            "probability_of_zero_events": predictive_zero_probability,
            "predictive_interval": predictive_interval,
        },
        "numerical_status": _bayesian_numerical_status(
            posterior_parameter_validation,
            interval_validations,
            [
                _validate_probability_result(
                    predictive_zero_probability,
                    "posterior predictive probability of zero events",
                )
            ],
        ),
    }
    if column is not None:
        result["column"] = column
    if exposure_column is not None:
        result["exposure_column"] = exposure_column
    if observations is not None:
        result["observations"] = int(observations)
    return result


def normal_known_variance_analysis(
    n: int,
    sample_mean: float,
    population_standard_deviation: float,
    prior_mean: float,
    prior_standard_deviation: float,
    interval_alpha: float = 0.05,
    *,
    source: str = "summary_data",
    column: str | None = None,
    missing: int = 0,
) -> dict[str, Any]:
    """Update a normal prior for a normal mean with known variance."""
    n = _count(n, "sample size", 1)
    sample_mean = _finite(sample_mean, "sample mean")
    population_standard_deviation = _positive(
        population_standard_deviation, "known population standard deviation"
    )
    prior_mean = _finite(prior_mean, "prior mean")
    prior_standard_deviation = _positive(
        prior_standard_deviation, "prior standard deviation"
    )
    interval_alpha = _interval_alpha(interval_alpha)

    likelihood_variance = _computed_square(
        population_standard_deviation, "known likelihood variance"
    )
    prior_variance = _computed_square(
        prior_standard_deviation, "prior variance"
    )
    posterior_precision = _computed_finite(
        1.0 / prior_variance + n / likelihood_variance,
        "posterior precision",
        positive=True,
    )
    posterior_variance = _computed_finite(
        1.0 / posterior_precision, "posterior variance", positive=True
    )
    posterior_mean = _computed_finite(
        posterior_variance
        * (prior_mean / prior_variance + n * sample_mean / likelihood_variance),
        "posterior mean",
    )
    posterior_standard_deviation = math.sqrt(posterior_variance)
    predictive_variance = _computed_finite(
        likelihood_variance + posterior_variance,
        "posterior predictive variance",
        positive=True,
    )
    predictive_standard_deviation = math.sqrt(predictive_variance)
    posterior_parameter_validation = _validate_posterior_parameters(
        {
            "mean": posterior_mean,
            "variance": posterior_variance,
            "standard_deviation": posterior_standard_deviation,
        },
        positive={"variance", "standard_deviation"},
    )
    credible_interval = [
        float(
            scipy_stats.norm.ppf(
                interval_alpha / 2.0,
                loc=posterior_mean,
                scale=posterior_standard_deviation,
            )
        ),
        float(
            scipy_stats.norm.ppf(
                1.0 - interval_alpha / 2.0,
                loc=posterior_mean,
                scale=posterior_standard_deviation,
            )
        ),
    ]
    predictive_interval = [
        float(
            scipy_stats.norm.ppf(
                interval_alpha / 2.0,
                loc=posterior_mean,
                scale=predictive_standard_deviation,
            )
        ),
        float(
            scipy_stats.norm.ppf(
                1.0 - interval_alpha / 2.0,
                loc=posterior_mean,
                scale=predictive_standard_deviation,
            )
        ),
    ]
    interval_validations = [
        _validate_interval_result(
            credible_interval, "normal posterior credible interval"
        ),
        _validate_interval_result(
            predictive_interval, "normal posterior-predictive interval"
        ),
    ]
    result: dict[str, Any] = {
        "model": "normal-normal-known-variance",
        "method": "normal-normal conjugate analysis with known variance",
        "source": source,
        "status": "completed",
        "n": n,
        "sample_mean": sample_mean,
        "known_population_standard_deviation": population_standard_deviation,
        "missing": int(missing),
        "prior": _normal_summary(prior_mean, prior_standard_deviation),
        "posterior": _normal_summary(
            posterior_mean, posterior_standard_deviation
        ),
        "credible_level": 1.0 - interval_alpha,
        "credible_interval": credible_interval,
        "posterior_predictive": {
            "distribution": "normal",
            "mean": posterior_mean,
            "variance": predictive_variance,
            "standard_deviation": predictive_standard_deviation,
            "predictive_interval": predictive_interval,
        },
        "numerical_status": _bayesian_numerical_status(
            posterior_parameter_validation,
            interval_validations,
        ),
    }
    if column is not None:
        result["column"] = column
    return result


def normal_inverse_gamma_analysis(
    n: int,
    sample_mean: float,
    sample_standard_deviation: float,
    prior_mean: float,
    prior_kappa: float,
    prior_alpha: float,
    prior_beta: float,
    interval_alpha: float = 0.05,
    *,
    source: str = "summary_data",
    column: str | None = None,
    missing: int = 0,
) -> dict[str, Any]:
    """Update a normal-inverse-gamma prior for unknown mean and variance."""
    n = _count(n, "sample size", 2)
    sample_mean = _finite(sample_mean, "sample mean")
    sample_standard_deviation = _positive(
        sample_standard_deviation, "sample standard deviation"
    )
    prior_mean = _finite(prior_mean, "prior mean")
    prior_kappa = _positive(prior_kappa, "prior kappa")
    prior_alpha = _positive(prior_alpha, "prior alpha")
    prior_beta = _positive(prior_beta, "prior beta")
    interval_alpha = _interval_alpha(interval_alpha)

    posterior_kappa = prior_kappa + n
    posterior_mean = (prior_kappa * prior_mean + n * sample_mean) / posterior_kappa
    posterior_alpha = prior_alpha + n / 2.0
    centered_sum_squares = _computed_finite(
        (n - 1.0)
        * _computed_square(
            sample_standard_deviation, "sample variance contribution"
        ),
        "centered sum of squares",
        nonnegative=True,
    )
    prior_mean_difference_square = _computed_square(
        sample_mean - prior_mean, "prior-to-sample mean difference square"
    )
    posterior_beta = prior_beta + 0.5 * (
        centered_sum_squares
        + prior_kappa
        * n
        / posterior_kappa
        * prior_mean_difference_square
    )
    posterior_parameter_validation = _validate_posterior_parameters(
        {
            "mu": posterior_mean,
            "kappa": posterior_kappa,
            "alpha": posterior_alpha,
            "beta": posterior_beta,
        },
        positive={"kappa", "alpha", "beta"},
    )

    prior_mu_scale = math.sqrt(
        _computed_finite(
            prior_beta / (prior_alpha * prior_kappa),
            "prior marginal mean scale squared",
            positive=True,
        )
    )
    posterior_mu_scale = math.sqrt(
        _computed_finite(
            posterior_beta / (posterior_alpha * posterior_kappa),
            "posterior marginal mean scale squared",
            positive=True,
        )
    )
    posterior_variance_mean = (
        _computed_finite(
            posterior_beta / (posterior_alpha - 1.0),
            "posterior mean of variance",
            positive=True,
        )
        if posterior_alpha > 1.0
        else None
    )
    posterior_variance_variance = (
        _computed_finite(
            _computed_square(
                posterior_beta, "posterior variance numerator"
            )
            / (
                _computed_square(
                    posterior_alpha - 1.0,
                    "posterior variance denominator square",
                )
                * (posterior_alpha - 2.0)
            ),
            "posterior variance of variance",
            positive=True,
        )
        if posterior_alpha > 2.0
        else None
    )
    posterior_mu_variance = (
        _computed_finite(
            posterior_beta
            / (posterior_kappa * (posterior_alpha - 1.0)),
            "posterior variance of mean parameter",
            positive=True,
        )
        if posterior_alpha > 1.0
        else None
    )
    predictive_scale = math.sqrt(
        _computed_finite(
            posterior_beta
            * (posterior_kappa + 1.0)
            / (posterior_alpha * posterior_kappa),
            "posterior predictive scale squared",
            positive=True,
        )
    )
    predictive_degrees_of_freedom = 2.0 * posterior_alpha
    posterior_variance_mode = _computed_finite(
        posterior_beta / (posterior_alpha + 1.0),
        "posterior variance mode",
        positive=True,
    )
    predictive_variance = _computed_finite(
        _computed_square(
            predictive_scale, "posterior predictive scale square"
        )
        * predictive_degrees_of_freedom
        / (predictive_degrees_of_freedom - 2.0),
        "posterior predictive variance",
        positive=True,
    )
    mean_credible_interval = [
        float(
            scipy_stats.t.ppf(
                interval_alpha / 2.0,
                df=2.0 * posterior_alpha,
                loc=posterior_mean,
                scale=posterior_mu_scale,
            )
        ),
        float(
            scipy_stats.t.ppf(
                1.0 - interval_alpha / 2.0,
                df=2.0 * posterior_alpha,
                loc=posterior_mean,
                scale=posterior_mu_scale,
            )
        ),
    ]
    variance_credible_interval = [
        float(
            scipy_stats.invgamma.ppf(
                interval_alpha / 2.0,
                a=posterior_alpha,
                scale=posterior_beta,
            )
        ),
        float(
            scipy_stats.invgamma.ppf(
                1.0 - interval_alpha / 2.0,
                a=posterior_alpha,
                scale=posterior_beta,
            )
        ),
    ]
    predictive_interval = [
        float(
            scipy_stats.t.ppf(
                interval_alpha / 2.0,
                df=predictive_degrees_of_freedom,
                loc=posterior_mean,
                scale=predictive_scale,
            )
        ),
        float(
            scipy_stats.t.ppf(
                1.0 - interval_alpha / 2.0,
                df=predictive_degrees_of_freedom,
                loc=posterior_mean,
                scale=predictive_scale,
            )
        ),
    ]
    interval_validations = [
        _validate_interval_result(
            mean_credible_interval,
            "normal-inverse-gamma mean credible interval",
        ),
        _validate_interval_result(
            variance_credible_interval,
            "normal-inverse-gamma variance credible interval",
            support_lower=0.0,
            strictly_inside_support=True,
        ),
        _validate_interval_result(
            predictive_interval,
            "normal-inverse-gamma posterior-predictive interval",
        ),
    ]
    result: dict[str, Any] = {
        "model": "normal-inverse-gamma",
        "method": "normal-inverse-gamma conjugate analysis",
        "source": source,
        "status": "completed",
        "n": n,
        "sample_mean": sample_mean,
        "sample_standard_deviation": sample_standard_deviation,
        "missing": int(missing),
        "prior": {
            "distribution": "normal-inverse-gamma",
            "mu": prior_mean,
            "kappa": prior_kappa,
            "alpha": prior_alpha,
            "beta": prior_beta,
            "marginal_mu_distribution": "Student t",
            "marginal_mu_degrees_of_freedom": 2.0 * prior_alpha,
            "marginal_mu_scale": prior_mu_scale,
            "variance_distribution": "inverse-gamma",
        },
        "posterior": {
            "distribution": "normal-inverse-gamma",
            "mu": posterior_mean,
            "kappa": posterior_kappa,
            "alpha": posterior_alpha,
            "beta": posterior_beta,
            "mean_parameter_mean": posterior_mean,
            "mean_parameter_mode": posterior_mean,
            "mean_parameter_variance": posterior_mu_variance,
            "variance_mean": posterior_variance_mean,
            "variance_mean_status": (
                "finite" if posterior_variance_mean is not None else "undefined"
            ),
            "variance_mode": posterior_variance_mode,
            "variance_variance": posterior_variance_variance,
            "variance_variance_status": (
                "finite"
                if posterior_variance_variance is not None
                else "undefined"
            ),
            "marginal_mu_distribution": "Student t",
            "marginal_mu_degrees_of_freedom": 2.0 * posterior_alpha,
            "marginal_mu_scale": posterior_mu_scale,
            "variance_distribution": "inverse-gamma",
        },
        "credible_level": 1.0 - interval_alpha,
        "mean_credible_interval": mean_credible_interval,
        "variance_credible_interval": variance_credible_interval,
        "posterior_predictive": {
            "distribution": "Student t",
            "degrees_of_freedom": predictive_degrees_of_freedom,
            "location": posterior_mean,
            "scale": predictive_scale,
            "mean": posterior_mean,
            "variance": predictive_variance,
            "predictive_interval": predictive_interval,
        },
        "numerical_status": _bayesian_numerical_status(
            posterior_parameter_validation,
            interval_validations,
        ),
    }
    if column is not None:
        result["column"] = column
    return result
