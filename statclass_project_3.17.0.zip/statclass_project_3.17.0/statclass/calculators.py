"""No-file distribution and confidence-interval calculators."""

from __future__ import annotations

import math
from typing import Any

from scipy import stats as scipy_stats

from .utils import format_number


class CalculatorError(ValueError):
    """Raised when a direct calculator request is invalid."""


_DISTRIBUTION_ALIASES = {
    "bernoulli": "bernoulli",
    "bern": "bernoulli",
    "binomial": "binomial",
    "binom": "binomial",
    "discrete-uniform": "discrete-uniform",
    "discrete_uniform": "discrete-uniform",
    "discreteuniform": "discrete-uniform",
    "geometric": "geometric",
    "geom": "geometric",
    "hypergeometric": "hypergeometric",
    "hypergeom": "hypergeometric",
    "negative-binomial": "negative-binomial",
    "negative_binomial": "negative-binomial",
    "negativebinomial": "negative-binomial",
    "nbinom": "negative-binomial",
    "poisson": "poisson",
    "beta": "beta",
    "beta-binomial": "beta-binomial",
    "beta_binomial": "beta-binomial",
    "betabinomial": "beta-binomial",
    "betabinom": "beta-binomial",
    "cauchy": "cauchy",
    "chi-square": "chi-square",
    "chi_square": "chi-square",
    "chisquare": "chi-square",
    "chi2": "chi-square",
    "double-exponential": "laplace",
    "double_exponential": "laplace",
    "doubleexponential": "laplace",
    "laplace": "laplace",
    "exponential": "exponential",
    "expon": "exponential",
    "f": "f",
    "gamma": "gamma",
    "logistic": "logistic",
    "lognormal": "lognormal",
    "log-normal": "lognormal",
    "lognorm": "lognormal",
    "normal": "normal",
    "norm": "normal",
    "gaussian": "normal",
    "pareto": "pareto",
    "t": "t",
    "student-t": "t",
    "student_t": "t",
    "uniform": "uniform",
    "continuous-uniform": "uniform",
    "continuous_uniform": "uniform",
    "weibull": "weibull",
}

SUPPORTED_DISTRIBUTIONS = (
    "bernoulli",
    "binomial",
    "discrete-uniform",
    "geometric",
    "hypergeometric",
    "negative-binomial",
    "poisson",
    "beta",
    "beta-binomial",
    "cauchy",
    "chi-square",
    "laplace",
    "exponential",
    "f",
    "gamma",
    "logistic",
    "lognormal",
    "normal",
    "pareto",
    "t",
    "uniform",
    "weibull",
)

DISTRIBUTION_PARAMETER_GUIDE = {
    "bernoulli": "P",
    "binomial": "N P",
    "discrete-uniform": "N",
    "geometric": "P",
    "hypergeometric": "N M K",
    "negative-binomial": "R P",
    "poisson": "MEAN",
    "beta": "ALPHA BETA",
    "beta-binomial": "N ALPHA BETA",
    "cauchy": "THETA SIGMA",
    "chi-square": "DF",
    "laplace": "MU SIGMA",
    "exponential": "BETA",
    "f": "DF1 DF2",
    "gamma": "ALPHA BETA",
    "logistic": "MU BETA",
    "lognormal": "MU SIGMA",
    "normal": "MEAN SD",
    "pareto": "ALPHA BETA",
    "t": "DF",
    "uniform": "A B",
    "weibull": "GAMMA BETA",
}


def _normalize_distribution(name: str) -> str:
    normalized = name.strip().lower()
    resolved = _DISTRIBUTION_ALIASES.get(normalized)
    if resolved is None:
        raise CalculatorError(
            "distribution must be one of: " + ", ".join(SUPPORTED_DISTRIBUTIONS)
        )
    return resolved


def _finite_number(value: float, label: str) -> float:
    value = float(value)
    if not math.isfinite(value):
        raise CalculatorError(f"{label} must be finite")
    return value


def _positive_number(value: float, label: str) -> float:
    value = _finite_number(value, label)
    if value <= 0.0:
        raise CalculatorError(f"{label} must be positive")
    return value


def _integer(value: float, label: str, minimum: int | None = None) -> int:
    value = _finite_number(value, label)
    if not value.is_integer():
        raise CalculatorError(f"{label} must be an integer")
    integer = int(value)
    if minimum is not None and integer < minimum:
        raise CalculatorError(f"{label} must be at least {minimum}")
    return integer


def _probability(value: float, label: str, strict: bool = False) -> float:
    value = _finite_number(value, label)
    valid = 0.0 < value < 1.0 if strict else 0.0 <= value <= 1.0
    if not valid:
        qualification = "strictly " if strict else ""
        raise CalculatorError(
            f"{label} must be {qualification}between 0 and 1"
        )
    return value


def _success_probability(value: float, label: str) -> float:
    value = _probability(value, label)
    if value == 0.0:
        raise CalculatorError(f"{label} must be greater than 0 and at most 1")
    return value


def _parameter_count(
    distribution: str,
    parameters: list[float],
    expected: int,
) -> None:
    if len(parameters) != expected:
        guide = DISTRIBUTION_PARAMETER_GUIDE[distribution]
        raise CalculatorError(f"{distribution} requires parameters {guide}")


def _distribution(
    name: str,
    parameters: list[float],
) -> tuple[Any, dict[str, Any], bool]:
    distribution = _normalize_distribution(name)
    if distribution == "bernoulli":
        _parameter_count(distribution, parameters, 1)
        probability = _probability(parameters[0], "Bernoulli P")
        return (
            scipy_stats.bernoulli(p=probability),
            {"probability": probability},
            True,
        )
    if distribution == "binomial":
        _parameter_count(distribution, parameters, 2)
        trials = _integer(parameters[0], "binomial N", 1)
        probability = _probability(parameters[1], "binomial P")
        return (
            scipy_stats.binom(n=trials, p=probability),
            {"trials": trials, "probability": probability},
            True,
        )
    if distribution == "discrete-uniform":
        _parameter_count(distribution, parameters, 1)
        maximum = _integer(parameters[0], "discrete-uniform N", 1)
        return (
            scipy_stats.randint(low=1, high=maximum + 1),
            {"maximum": maximum},
            True,
        )
    if distribution == "geometric":
        _parameter_count(distribution, parameters, 1)
        probability = _success_probability(parameters[0], "geometric P")
        return (
            scipy_stats.geom(p=probability),
            {"probability": probability},
            True,
        )
    if distribution == "hypergeometric":
        _parameter_count(distribution, parameters, 3)
        population = _integer(parameters[0], "hypergeometric N", 1)
        successes = _integer(parameters[1], "hypergeometric M", 0)
        draws = _integer(parameters[2], "hypergeometric K", 0)
        if successes > population:
            raise CalculatorError("hypergeometric M must not exceed N")
        if draws > population:
            raise CalculatorError("hypergeometric K must not exceed N")
        return (
            scipy_stats.hypergeom(M=population, n=successes, N=draws),
            {
                "population_size": population,
                "population_successes": successes,
                "draws": draws,
            },
            True,
        )
    if distribution == "negative-binomial":
        _parameter_count(distribution, parameters, 2)
        required_successes = _integer(parameters[0], "negative-binomial R", 1)
        probability = _success_probability(parameters[1], "negative-binomial P")
        return (
            scipy_stats.nbinom(n=required_successes, p=probability),
            {
                "required_successes": required_successes,
                "probability": probability,
            },
            True,
        )
    if distribution == "poisson":
        _parameter_count(distribution, parameters, 1)
        mean = _finite_number(parameters[0], "Poisson mean")
        if mean < 0.0:
            raise CalculatorError("Poisson mean must be nonnegative")
        return scipy_stats.poisson(mu=mean), {"mean": mean}, True
    if distribution == "beta":
        _parameter_count(distribution, parameters, 2)
        alpha = _positive_number(parameters[0], "beta ALPHA")
        beta = _positive_number(parameters[1], "beta BETA")
        return (
            scipy_stats.beta(a=alpha, b=beta),
            {"alpha": alpha, "beta": beta},
            False,
        )
    if distribution == "beta-binomial":
        _parameter_count(distribution, parameters, 3)
        trials = _integer(parameters[0], "beta-binomial N", 1)
        alpha = _positive_number(parameters[1], "beta-binomial ALPHA")
        beta = _positive_number(parameters[2], "beta-binomial BETA")
        return (
            scipy_stats.betabinom(n=trials, a=alpha, b=beta),
            {"trials": trials, "alpha": alpha, "beta": beta},
            True,
        )
    if distribution == "cauchy":
        _parameter_count(distribution, parameters, 2)
        location = _finite_number(parameters[0], "Cauchy THETA")
        scale = _positive_number(parameters[1], "Cauchy SIGMA")
        return (
            scipy_stats.cauchy(loc=location, scale=scale),
            {"location_theta": location, "scale_sigma": scale},
            False,
        )
    if distribution == "chi-square":
        _parameter_count(distribution, parameters, 1)
        degrees_of_freedom = _positive_number(parameters[0], "chi-square DF")
        return (
            scipy_stats.chi2(df=degrees_of_freedom),
            {"degrees_of_freedom": degrees_of_freedom},
            False,
        )
    if distribution == "laplace":
        _parameter_count(distribution, parameters, 2)
        location = _finite_number(parameters[0], "Laplace MU")
        scale = _positive_number(parameters[1], "Laplace SIGMA")
        return (
            scipy_stats.laplace(loc=location, scale=scale),
            {"location_mu": location, "scale_sigma": scale},
            False,
        )
    if distribution == "exponential":
        _parameter_count(distribution, parameters, 1)
        scale = _positive_number(parameters[0], "exponential BETA")
        return (
            scipy_stats.expon(scale=scale),
            {"scale_beta": scale},
            False,
        )
    if distribution == "f":
        _parameter_count(distribution, parameters, 2)
        numerator_df = _positive_number(parameters[0], "F DF1")
        denominator_df = _positive_number(parameters[1], "F DF2")
        return (
            scipy_stats.f(dfn=numerator_df, dfd=denominator_df),
            {
                "numerator_degrees_of_freedom": numerator_df,
                "denominator_degrees_of_freedom": denominator_df,
            },
            False,
        )
    if distribution == "gamma":
        _parameter_count(distribution, parameters, 2)
        alpha = _positive_number(parameters[0], "gamma ALPHA")
        beta = _positive_number(parameters[1], "gamma BETA")
        return (
            scipy_stats.gamma(a=alpha, scale=beta),
            {"shape_alpha": alpha, "scale_beta": beta},
            False,
        )
    if distribution == "logistic":
        _parameter_count(distribution, parameters, 2)
        location = _finite_number(parameters[0], "logistic MU")
        scale = _positive_number(parameters[1], "logistic BETA")
        return (
            scipy_stats.logistic(loc=location, scale=scale),
            {"location_mu": location, "scale_beta": scale},
            False,
        )
    if distribution == "lognormal":
        _parameter_count(distribution, parameters, 2)
        log_mean = _finite_number(parameters[0], "lognormal MU")
        log_sd = _positive_number(parameters[1], "lognormal SIGMA")
        try:
            scale = math.exp(log_mean)
        except OverflowError as exc:
            raise CalculatorError("lognormal MU is too large") from exc
        if scale == 0.0 or not math.isfinite(scale):
            raise CalculatorError("lognormal MU magnitude is too large")
        return (
            scipy_stats.lognorm(s=log_sd, scale=scale),
            {"log_mean_mu": log_mean, "log_sd_sigma": log_sd},
            False,
        )
    if distribution == "normal":
        _parameter_count(distribution, parameters, 2)
        mean = _finite_number(parameters[0], "normal mean")
        standard_deviation = _positive_number(parameters[1], "normal SD")
        return (
            scipy_stats.norm(loc=mean, scale=standard_deviation),
            {"mean": mean, "standard_deviation": standard_deviation},
            False,
        )
    if distribution == "pareto":
        _parameter_count(distribution, parameters, 2)
        minimum = _positive_number(parameters[0], "Pareto ALPHA")
        shape = _positive_number(parameters[1], "Pareto BETA")
        return (
            scipy_stats.pareto(b=shape, scale=minimum),
            {"minimum_alpha": minimum, "shape_beta": shape},
            False,
        )
    if distribution == "t":
        _parameter_count(distribution, parameters, 1)
        degrees_of_freedom = _positive_number(parameters[0], "t DF")
        return (
            scipy_stats.t(df=degrees_of_freedom),
            {"degrees_of_freedom": degrees_of_freedom},
            False,
        )
    if distribution == "uniform":
        _parameter_count(distribution, parameters, 2)
        lower = _finite_number(parameters[0], "uniform A")
        upper = _finite_number(parameters[1], "uniform B")
        if lower >= upper:
            raise CalculatorError("uniform A must be less than B")
        return (
            scipy_stats.uniform(loc=lower, scale=upper - lower),
            {"lower_a": lower, "upper_b": upper},
            False,
        )
    _parameter_count(distribution, parameters, 2)
    shape = _positive_number(parameters[0], "Weibull GAMMA")
    beta_parameter = _positive_number(parameters[1], "Weibull BETA")
    try:
        scale = beta_parameter ** (1.0 / shape)
    except OverflowError as exc:
        raise CalculatorError("Weibull parameters produce an invalid scale") from exc
    if scale == 0.0 or not math.isfinite(scale):
        raise CalculatorError("Weibull parameters produce an invalid scale")
    return (
        scipy_stats.weibull_min(c=shape, scale=scale),
        {"shape_gamma": shape, "beta_parameter": beta_parameter},
        False,
    )


_PARAMETERIZATION_DESCRIPTIONS = {
    "bernoulli": "P is the probability of X = 1; support is 0 and 1.",
    "binomial": "N is the number of trials and P is the success probability.",
    "discrete-uniform": "All integers from 1 through N are equally likely.",
    "geometric": "X counts trials through the first success, so X starts at 1.",
    "hypergeometric": "N is population size, M population successes, and K draws without replacement.",
    "negative-binomial": "X counts failures before the Rth success; P is success probability.",
    "poisson": "MEAN is the Poisson rate or expected count.",
    "beta": "ALPHA and BETA are positive shape parameters on [0, 1].",
    "beta-binomial": "N is trials; ALPHA and BETA define beta mixing of the binomial probability.",
    "cauchy": "THETA is location and SIGMA is positive scale.",
    "chi-square": "DF is the positive degrees-of-freedom parameter.",
    "laplace": "MU is location and SIGMA is scale in exp(-abs(x-MU)/SIGMA)/(2 SIGMA).",
    "exponential": "BETA is the positive scale, equal to the mean.",
    "f": "DF1 and DF2 are numerator and denominator degrees of freedom.",
    "gamma": "ALPHA is shape and BETA is scale, giving mean ALPHA*BETA.",
    "logistic": "MU is location and BETA is positive scale.",
    "lognormal": "log(X) is normal with mean MU and standard deviation SIGMA.",
    "normal": "MEAN is location and SD is the positive standard deviation.",
    "pareto": "ALPHA is the positive minimum and BETA is the positive shape.",
    "t": "DF is the positive degrees-of-freedom parameter.",
    "uniform": "A and B are the lower and upper endpoints, with A < B.",
    "weibull": "GAMMA is shape and BETA appears in exp(-x^GAMMA/BETA).",
}

_MGF_DESCRIPTIONS = {
    "bernoulli": "M(t) = (1-P) + P*exp(t); all real t.",
    "binomial": "M(t) = [(1-P) + P*exp(t)]^N; all real t.",
    "discrete-uniform": "M(t) = (1/N)*sum(exp(i*t), i=1,...,N); all real t.",
    "geometric": "M(t) = P*exp(t)/[1-(1-P)*exp(t)]; t < -log(1-P).",
    "hypergeometric": "M(t) is the finite sum of PMF(x)*exp(t*x); all real t.",
    "negative-binomial": "M(t) = [P/(1-(1-P)*exp(t))]^R; t < -log(1-P).",
    "poisson": "M(t) = exp(MEAN*(exp(t)-1)); all real t.",
    "beta": "M(t) = 1F1(ALPHA; ALPHA+BETA; t); all real t.",
    "beta-binomial": "M(t) is the finite sum of PMF(x)*exp(t*x); all real t.",
    "cauchy": "The MGF does not exist.",
    "chi-square": "M(t) = (1-2*t)^(-DF/2); t < 1/2.",
    "laplace": "M(t) = exp(MU*t)/(1-SIGMA^2*t^2); abs(t) < 1/SIGMA.",
    "exponential": "M(t) = 1/(1-BETA*t); t < 1/BETA.",
    "f": "The MGF does not exist.",
    "gamma": "M(t) = (1-BETA*t)^(-ALPHA); t < 1/BETA.",
    "logistic": "M(t) = exp(MU*t)*Gamma(1-BETA*t)*Gamma(1+BETA*t); abs(t) < 1/BETA.",
    "lognormal": "The MGF is infinite for t > 0 and does not exist around 0.",
    "normal": "M(t) = exp(MEAN*t + SD^2*t^2/2); all real t.",
    "pareto": "The MGF is infinite for t > 0 and does not exist around 0.",
    "t": "The MGF does not exist.",
    "uniform": "M(t) = [exp(B*t)-exp(A*t)]/[(B-A)*t], with M(0)=1.",
}


def _support_description(
    distribution: str,
    parameters: dict[str, Any],
) -> str:
    if distribution == "bernoulli":
        return "{0, 1}"
    if distribution == "binomial":
        return f"integers 0 through {parameters['trials']}"
    if distribution == "discrete-uniform":
        return f"integers 1 through {parameters['maximum']}"
    if distribution == "geometric":
        return "integers 1, 2, 3, ..."
    if distribution == "hypergeometric":
        lower = max(
            0,
            parameters["draws"]
            - (parameters["population_size"] - parameters["population_successes"]),
        )
        upper = min(parameters["draws"], parameters["population_successes"])
        return f"integers {lower} through {upper}"
    if distribution in {"negative-binomial", "poisson"}:
        return "integers 0, 1, 2, ..."
    if distribution == "beta":
        return "0 <= x <= 1"
    if distribution == "beta-binomial":
        return f"integers 0 through {parameters['trials']}"
    if distribution in {"cauchy", "laplace", "logistic", "normal", "t"}:
        return "all real x"
    if distribution in {"chi-square", "exponential", "f", "gamma", "weibull"}:
        return "x >= 0"
    if distribution == "lognormal":
        return "x > 0"
    if distribution == "pareto":
        return f"x >= {format_number(parameters['minimum_alpha'])}"
    return (
        f"{format_number(parameters['lower_a'])} <= x <= "
        f"{format_number(parameters['upper_b'])}"
    )


def _mgf_description(
    distribution: str,
    parameters: dict[str, Any],
) -> str:
    if distribution == "geometric" and parameters["probability"] == 1.0:
        return "M(t) = exp(t); all real t."
    if distribution == "negative-binomial" and parameters["probability"] == 1.0:
        return "M(t) = 1; all real t."
    if distribution != "weibull":
        return _MGF_DESCRIPTIONS[distribution]
    shape = parameters["shape_gamma"]
    beta = parameters["beta_parameter"]
    if shape > 1.0:
        return "The MGF exists for all real t but has no simple elementary form."
    if shape == 1.0:
        return f"M(t) = 1/(1-BETA*t); t < {format_number(1.0 / beta)}."
    return "The MGF is infinite for t > 0 and does not exist around 0."


def _finite_statistic(value: Any) -> tuple[float | None, str]:
    numeric = float(value)
    if math.isnan(numeric):
        return None, "undefined"
    if math.isinf(numeric):
        return None, "infinite"
    return numeric, "finite"


def _validated_probability_result(
    value: Any, label: str
) -> tuple[float, dict[str, Any]]:
    """Validate a probability returned by a distribution algorithm."""
    numeric = float(value)
    tolerance = 1e-12
    if not math.isfinite(numeric):
        raise CalculatorError(f"{label} returned a nonfinite probability")
    if numeric < -tolerance or numeric > 1.0 + tolerance:
        raise CalculatorError(
            f"{label} returned a value outside the probability range [0, 1]"
        )
    adjusted = max(0.0, min(1.0, numeric))
    return adjusted, {
        "status": "validated",
        "finite": True,
        "valid_probability_range": True,
        "roundoff_clipped": adjusted != numeric,
    }


def _validated_quantile_result(
    value: Any, label: str
) -> tuple[float, dict[str, Any]]:
    numeric = float(value)
    if not math.isfinite(numeric):
        raise CalculatorError(f"{label} returned a nonfinite quantile")
    return numeric, {"status": "validated", "finite": True}


def _support_boundary(
    distribution: Any, value: float
) -> tuple[str | None, str | None]:
    """Identify a finite support endpoint and its interior derivative side."""
    lower, upper = map(float, distribution.support())
    scale = max(1.0, abs(value), abs(lower) if math.isfinite(lower) else 0.0,
                abs(upper) if math.isfinite(upper) else 0.0)
    tolerance = 8.0 * math.ulp(scale)
    if math.isfinite(lower) and math.isclose(
        value, lower, rel_tol=0.0, abs_tol=tolerance
    ):
        return "lower", "right"
    if math.isfinite(upper) and math.isclose(
        value, upper, rel_tol=0.0, abs_tol=tolerance
    ):
        return "upper", "left"
    return None, None


def _log_difference(log_larger: float, log_smaller: float) -> float:
    """Return log(exp(log_larger) - exp(log_smaller)) stably."""
    if math.isnan(log_larger) or math.isnan(log_smaller):
        return math.nan
    if log_smaller > log_larger:
        return math.nan
    if log_larger == -math.inf or log_smaller == log_larger:
        return -math.inf
    if log_smaller == -math.inf:
        return log_larger
    return log_larger + math.log(-math.expm1(log_smaller - log_larger))


def _continuous_interval_probability(
    distribution: Any,
    lower: float,
    upper: float,
    label: str,
) -> tuple[float, dict[str, Any]]:
    """Evaluate a continuous interval with tail-aware subtraction."""
    support_lower, support_upper = map(float, distribution.support())
    endpoint_semantics = (
        "continuous CDF; open and closed interval endpoints have the same probability"
    )
    if lower == upper:
        return 0.0, {
            "status": "validated",
            "finite": True,
            "valid_probability_range": True,
            "roundoff_clipped": False,
            "evaluation_method": "zero-width continuous interval",
            "endpoint_semantics": endpoint_semantics,
            "underflow_to_zero": False,
            "warnings": [],
        }
    if (
        (math.isfinite(support_lower) and upper <= support_lower)
        or (math.isfinite(support_upper) and lower >= support_upper)
    ):
        return 0.0, {
            "status": "validated",
            "finite": True,
            "valid_probability_range": True,
            "roundoff_clipped": False,
            "evaluation_method": "support exclusion check",
            "endpoint_semantics": endpoint_semantics,
            "underflow_to_zero": False,
            "warnings": [],
        }
    if (
        math.isfinite(support_lower)
        and lower <= support_lower
        and math.isfinite(support_upper)
        and upper >= support_upper
    ):
        return 1.0, {
            "status": "validated",
            "finite": True,
            "valid_probability_range": True,
            "roundoff_clipped": False,
            "evaluation_method": "complete-support check",
            "endpoint_semantics": endpoint_semantics,
            "underflow_to_zero": False,
            "warnings": [],
        }

    cdf_upper = float(distribution.cdf(upper))
    cdf_lower = float(distribution.cdf(lower))
    sf_lower = float(distribution.sf(lower))
    sf_upper = float(distribution.sf(upper))
    for value, component in (
        (cdf_upper, "upper-bound CDF"),
        (cdf_lower, "lower-bound CDF"),
        (sf_lower, "lower-bound survival function"),
        (sf_upper, "upper-bound survival function"),
    ):
        if not math.isfinite(value):
            raise CalculatorError(f"{label} returned a nonfinite {component}")

    if cdf_upper <= 0.5:
        raw_result = cdf_upper - cdf_lower
        method = "CDF difference"
        log_result = _log_difference(
            float(distribution.logcdf(upper)),
            float(distribution.logcdf(lower)),
        )
        log_method = "log-CDF difference"
    elif sf_lower <= 0.5:
        raw_result = sf_lower - sf_upper
        method = "survival-function difference"
        log_result = _log_difference(
            float(distribution.logsf(lower)),
            float(distribution.logsf(upper)),
        )
        log_method = "log-survival-function difference"
    else:
        raw_result = cdf_upper - cdf_lower
        method = "central CDF difference"
        log_result = _log_difference(
            float(distribution.logcdf(upper)),
            float(distribution.logcdf(lower)),
        )
        log_method = "central log-CDF difference"

    if raw_result <= 0.0 and math.isfinite(log_result):
        raw_result = math.exp(log_result)
        method = log_method
    underflow = bool(raw_result == 0.0 and lower < upper)
    warnings: list[str] = []
    if underflow:
        warnings.append(
            "The positive interval probability is smaller than floating-point output can resolve; zero is an underflow result, not an exact probability."
        )
    result, validation = _validated_probability_result(raw_result, label)
    validation.update(
        {
            "status": "underflow_to_zero" if underflow else "validated",
            "evaluation_method": method,
            "endpoint_semantics": endpoint_semantics,
            "underflow_to_zero": underflow,
            "log_probability": log_result if math.isfinite(log_result) else None,
            "warnings": warnings,
        }
    )
    return result, validation


def _discrete_moment_information(
    distribution: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Return closed-form first, second raw, and second central moments."""
    if distribution == "bernoulli":
        probability = parameters["probability"]
        mean = probability
        variance = probability * (1.0 - probability)
        second_raw = probability
        formulas = {
            "first_raw": "E[X] = P",
            "second_raw": "E[X^2] = P",
            "second_central": "Var(X) = P*(1-P)",
        }
    elif distribution == "binomial":
        trials = parameters["trials"]
        probability = parameters["probability"]
        mean = trials * probability
        variance = trials * probability * (1.0 - probability)
        second_raw = variance + mean**2
        formulas = {
            "first_raw": "E[X] = N*P",
            "second_raw": "E[X^2] = N*P*(1-P) + (N*P)^2",
            "second_central": "Var(X) = N*P*(1-P)",
        }
    elif distribution == "discrete-uniform":
        maximum = parameters["maximum"]
        mean = (maximum + 1.0) / 2.0
        second_raw = (maximum + 1.0) * (2.0 * maximum + 1.0) / 6.0
        variance = (maximum**2 - 1.0) / 12.0
        formulas = {
            "first_raw": "E[X] = (N+1)/2",
            "second_raw": "E[X^2] = (N+1)*(2*N+1)/6",
            "second_central": "Var(X) = (N^2-1)/12",
        }
    elif distribution == "geometric":
        probability = parameters["probability"]
        mean = 1.0 / probability
        variance = (1.0 - probability) / probability**2
        second_raw = (2.0 - probability) / probability**2
        formulas = {
            "first_raw": "E[X] = 1/P",
            "second_raw": "E[X^2] = (2-P)/P^2",
            "second_central": "Var(X) = (1-P)/P^2",
        }
    elif distribution == "hypergeometric":
        population = parameters["population_size"]
        population_successes = parameters["population_successes"]
        draws = parameters["draws"]
        population_probability = population_successes / population
        mean = draws * population_probability
        if population == 1:
            variance = 0.0
            variance_formula = "Var(X) = 0 when N = 1"
        else:
            variance = (
                draws
                * population_probability
                * (1.0 - population_probability)
                * (population - draws)
                / (population - 1.0)
            )
            variance_formula = (
                "Var(X) = K*(M/N)*(1-M/N)*(N-K)/(N-1)"
            )
        second_raw = variance + mean**2
        formulas = {
            "first_raw": "E[X] = K*M/N",
            "second_raw": "E[X^2] = Var(X) + (K*M/N)^2",
            "second_central": variance_formula,
        }
    elif distribution == "negative-binomial":
        required_successes = parameters["required_successes"]
        probability = parameters["probability"]
        failure_probability = 1.0 - probability
        mean = required_successes * failure_probability / probability
        variance = required_successes * failure_probability / probability**2
        second_raw = (
            required_successes
            * failure_probability
            * (1.0 + required_successes * failure_probability)
            / probability**2
        )
        formulas = {
            "first_raw": "E[X] = R*(1-P)/P",
            "second_raw": "E[X^2] = R*(1-P)*(1+R*(1-P))/P^2",
            "second_central": "Var(X) = R*(1-P)/P^2",
        }
    elif distribution == "poisson":
        poisson_mean = parameters["mean"]
        mean = poisson_mean
        variance = poisson_mean
        second_raw = poisson_mean + poisson_mean**2
        formulas = {
            "first_raw": "E[X] = MEAN",
            "second_raw": "E[X^2] = MEAN + MEAN^2",
            "second_central": "Var(X) = MEAN",
        }
    else:
        trials = parameters["trials"]
        alpha = parameters["alpha"]
        beta = parameters["beta"]
        concentration = alpha + beta
        mean_probability = alpha / concentration
        mean = trials * mean_probability
        variance = (
            trials
            * mean_probability
            * (1.0 - mean_probability)
            * (concentration + trials)
            / (concentration + 1.0)
        )
        second_factorial = (
            trials
            * (trials - 1.0)
            * mean_probability
            * (alpha + 1.0)
            / (concentration + 1.0)
        )
        second_raw = second_factorial + mean
        formulas = {
            "first_raw": "E[X] = N*ALPHA/(ALPHA+BETA)",
            "second_raw": (
                "E[X^2] = N*(N-1)*ALPHA*(ALPHA+1)/"
                "[(ALPHA+BETA)*(ALPHA+BETA+1)] + E[X]"
            ),
            "second_central": (
                "Var(X) = N*ALPHA*BETA*(ALPHA+BETA+N)/"
                "[(ALPHA+BETA)^2*(ALPHA+BETA+1)]"
            ),
        }
    return {
        "moment_source": "closed-form distribution formula",
        "first_raw_moment": float(mean),
        "second_raw_moment": float(second_raw),
        "second_central_moment": float(variance),
        "moment_formulas": formulas,
        "second_raw_moment_identity": "E[X^2] = Var(X) + E[X]^2",
    }


def distribution_density(
    distribution_name: str,
    value: float,
    parameters: list[float],
) -> dict[str, Any]:
    """Evaluate a probability mass function or probability density function."""
    distribution_name = _normalize_distribution(distribution_name)
    distribution, parameter_values, discrete = _distribution(
        distribution_name, parameters
    )
    value = _finite_number(value, "distribution value")
    if discrete:
        evaluated_value: int | float = _integer(value, "distribution value")
        raw_result = float(distribution.pmf(evaluated_value))
        function = "pmf"
    else:
        evaluated_value = value
        raw_result = float(distribution.pdf(evaluated_value))
        function = "pdf"
    if math.isnan(raw_result) or raw_result < 0.0:
        raise CalculatorError(
            f"{distribution_name} {function.upper()} returned an invalid numerical result"
        )
    if discrete:
        raw_result, numerical_validation = _validated_probability_result(
            raw_result, f"{distribution_name} PMF"
        )
        support_boundary = None
        derivative_side = None
        endpoint_semantics = (
            "discrete probability mass; no CDF derivative is used"
        )
    else:
        support_boundary, derivative_side = _support_boundary(
            distribution, evaluated_value
        )
        numerical_validation = {
            "status": "validated",
            "nonnegative": True,
            "finite": math.isfinite(raw_result),
            "infinite_density_allowed": math.isinf(raw_result),
        }
        endpoint_semantics = (
            f"{derivative_side}-hand density convention at the "
            f"{support_boundary} support endpoint"
            if support_boundary is not None
            else "PDF evaluated directly; the CDF is not numerically differentiated"
        )
    result, result_status = _finite_statistic(raw_result)
    return {
        "calculation_type": "density",
        "distribution": distribution_name,
        "distribution_type": "discrete" if discrete else "continuous",
        "parameters": parameter_values,
        "function": function,
        "value": evaluated_value,
        "result": result,
        "result_status": result_status,
        "support_boundary": support_boundary,
        "density_derivative_side": derivative_side,
        "endpoint_semantics": endpoint_semantics,
        "numerical_validation": numerical_validation,
        "status": "completed",
    }


def distribution_info(
    distribution_name: str,
    parameters: list[float],
) -> dict[str, Any]:
    """Return parameterization, support, moments, and MGF information."""
    distribution_name = _normalize_distribution(distribution_name)
    distribution, parameter_values, discrete = _distribution(
        distribution_name, parameters
    )
    moment_information: dict[str, Any] = {}
    if discrete:
        moment_information = _discrete_moment_information(
            distribution_name, parameter_values
        )
        mean, mean_status = _finite_statistic(
            moment_information["first_raw_moment"]
        )
        variance, variance_status = _finite_statistic(
            moment_information["second_central_moment"]
        )
    else:
        mean, mean_status = _finite_statistic(distribution.mean())
        variance, variance_status = _finite_statistic(distribution.var())
    standard_deviation = (
        math.sqrt(variance) if variance is not None and variance >= 0.0 else None
    )
    return {
        "calculation_type": "information",
        "distribution": distribution_name,
        "distribution_type": "discrete" if discrete else "continuous",
        "parameters": parameter_values,
        "parameter_order": DISTRIBUTION_PARAMETER_GUIDE[distribution_name],
        "parameterization": _PARAMETERIZATION_DESCRIPTIONS[distribution_name],
        "support": _support_description(distribution_name, parameter_values),
        "mean": mean,
        "mean_status": mean_status,
        "variance": variance,
        "variance_status": variance_status,
        "standard_deviation": standard_deviation,
        "mgf": _mgf_description(distribution_name, parameter_values),
        "status": "completed",
        **moment_information,
    }


def distribution_probability(
    distribution_name: str,
    relation: str,
    value: float,
    parameters: list[float],
) -> dict[str, Any]:
    """Calculate a point or tail probability for a supported distribution."""
    distribution_name = _normalize_distribution(distribution_name)
    distribution, parameter_values, discrete = _distribution(
        distribution_name,
        parameters,
    )
    aliases = {"pmf": "eq", "cdf": "le", "sf": "gt"}
    relation = aliases.get(relation.strip().lower(), relation.strip().lower())
    allowed = {"eq", "le", "lt", "ge", "gt"} if discrete else {"le", "lt", "ge", "gt"}
    if relation not in allowed:
        choices = "eq, le, lt, ge, gt" if discrete else "le, lt, ge, gt"
        raise CalculatorError(f"relation for {distribution_name} must be {choices}")

    _finite_number(value, "distribution value")
    if discrete:
        integer_value = _integer(value, "distribution value")
        if relation == "eq":
            result = float(distribution.pmf(integer_value))
            evaluation_method = "PMF"
        elif relation == "le":
            result = float(distribution.cdf(integer_value))
            evaluation_method = "right-continuous discrete CDF"
        elif relation == "lt":
            result = float(distribution.cdf(integer_value - 1))
            evaluation_method = "right-continuous discrete CDF with strict-bound shift"
        elif relation == "ge":
            result = float(distribution.sf(integer_value - 1))
            evaluation_method = "discrete survival function with inclusive-bound shift"
        else:
            result = float(distribution.sf(integer_value))
            evaluation_method = "discrete survival function"
        value = float(integer_value)
        endpoint_semantics = (
            "right-continuous step CDF; strict and non-strict inequalities are separated on integer support"
        )
    elif relation in {"le", "lt"}:
        result = float(distribution.cdf(value))
        evaluation_method = "continuous CDF"
        endpoint_semantics = (
            "continuous CDF; strict and non-strict inequalities have the same probability"
        )
    else:
        result = float(distribution.sf(value))
        evaluation_method = "continuous survival function"
        endpoint_semantics = (
            "continuous CDF; strict and non-strict inequalities have the same probability"
        )
    result, numerical_validation = _validated_probability_result(
        result, f"{distribution_name} probability calculation"
    )
    numerical_validation.update(
        {
            "evaluation_method": evaluation_method,
            "endpoint_semantics": endpoint_semantics,
            "warnings": [],
        }
    )

    symbols = {"eq": "=", "le": "<=", "lt": "<", "ge": ">=", "gt": ">"}
    return {
        "calculation_type": "probability",
        "distribution": distribution_name,
        "parameters": parameter_values,
        "relation": relation,
        "value": int(value) if discrete else value,
        "expression": (
            f"P(X {symbols[relation]} "
            f"{int(value) if discrete else format_number(value)})"
        ),
        "result": result,
        "evaluation_method": evaluation_method,
        "endpoint_semantics": endpoint_semantics,
        "numerical_validation": numerical_validation,
        "status": "completed",
    }


def distribution_interval_probability(
    distribution_name: str,
    lower: float,
    upper: float,
    parameters: list[float],
) -> dict[str, Any]:
    """Calculate the probability of a closed interval."""
    distribution_name = _normalize_distribution(distribution_name)
    distribution, parameter_values, discrete = _distribution(
        distribution_name,
        parameters,
    )
    _finite_number(lower, "interval lower bound")
    _finite_number(upper, "interval upper bound")
    if lower > upper:
        raise CalculatorError("interval lower bound must not exceed upper bound")
    if discrete:
        lower_integer = _integer(lower, "interval lower bound")
        upper_integer = _integer(upper, "interval upper bound")
        result = float(
            distribution.cdf(upper_integer)
            - distribution.cdf(lower_integer - 1)
        )
        evaluation_method = "right-continuous discrete CDF difference"
        endpoint_semantics = (
            "closed integer interval; both endpoint masses are included"
        )
        lower_value: int | float = lower_integer
        upper_value: int | float = upper_integer
        result, numerical_validation = _validated_probability_result(
            result, f"{distribution_name} interval-probability calculation"
        )
        numerical_validation.update(
            {
                "evaluation_method": evaluation_method,
                "endpoint_semantics": endpoint_semantics,
                "warnings": [],
            }
        )
    else:
        lower_value = lower
        upper_value = upper
        result, numerical_validation = _continuous_interval_probability(
            distribution,
            lower,
            upper,
            f"{distribution_name} interval-probability calculation",
        )
        evaluation_method = numerical_validation["evaluation_method"]
        endpoint_semantics = numerical_validation["endpoint_semantics"]
    return {
        "calculation_type": "interval_probability",
        "distribution": distribution_name,
        "parameters": parameter_values,
        "lower": lower_value,
        "upper": upper_value,
        "expression": (
            f"P({format_number(lower_value)} <= X <= "
            f"{format_number(upper_value)})"
        ),
        "result": result,
        "evaluation_method": evaluation_method,
        "endpoint_semantics": endpoint_semantics,
        "numerical_validation": numerical_validation,
        "status": "completed",
    }


def distribution_quantile(
    distribution_name: str,
    cumulative_probability: float,
    parameters: list[float],
) -> dict[str, Any]:
    """Calculate a lower-tail quantile for a supported distribution."""
    distribution_name = _normalize_distribution(distribution_name)
    distribution, parameter_values, discrete = _distribution(
        distribution_name,
        parameters,
    )
    probability = _probability(
        cumulative_probability,
        "cumulative probability",
        strict=True,
    )
    quantile, numerical_validation = _validated_quantile_result(
        distribution.ppf(probability), f"{distribution_name} quantile calculation"
    )
    quantile_definition = (
        "generalized inverse inf{x: F(x) >= p} of the right-continuous CDF"
    )
    numerical_validation["quantile_definition"] = quantile_definition
    result: int | float = int(quantile) if discrete else quantile
    return {
        "calculation_type": "quantile",
        "distribution": distribution_name,
        "parameters": parameter_values,
        "cumulative_probability": probability,
        "expression": (
            f"smallest x with P(X <= x) >= {format_number(probability)}"
        ),
        "result": result,
        "quantile_definition": quantile_definition,
        "numerical_validation": numerical_validation,
        "status": "completed",
    }


def mean_confidence_interval(
    n: int,
    sample_mean: float,
    standard_deviation: float,
    alpha: float,
    known_population_standard_deviation: bool,
) -> dict[str, Any]:
    """Calculate a t or z confidence interval for a population mean."""
    alpha = _probability(alpha, "alpha", strict=True)
    minimum = 1 if known_population_standard_deviation else 2
    if n < minimum:
        raise CalculatorError(f"mean confidence interval requires N >= {minimum}")
    _finite_number(sample_mean, "sample mean")
    _positive_number(standard_deviation, "standard deviation")
    standard_error = standard_deviation / math.sqrt(n)
    if known_population_standard_deviation:
        critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
        method = "z confidence interval for a mean with known population SD"
        degrees_of_freedom = None
    else:
        degrees_of_freedom = n - 1
        critical = float(
            scipy_stats.t.ppf(1.0 - alpha / 2.0, degrees_of_freedom)
        )
        method = "t confidence interval for a mean"
    margin = critical * standard_error
    return {
        "method": method,
        "n": n,
        "sample_mean": sample_mean,
        "standard_deviation": standard_deviation,
        "known_population_standard_deviation": known_population_standard_deviation,
        "degrees_of_freedom": degrees_of_freedom,
        "standard_error": standard_error,
        "critical_value": critical,
        "confidence_level": 1.0 - alpha,
        "confidence_interval": [sample_mean - margin, sample_mean + margin],
        "status": "completed",
    }


def proportion_confidence_interval(
    successes: int,
    trials: int,
    alpha: float,
) -> dict[str, Any]:
    """Calculate Wilson and exact intervals for a binomial proportion."""
    alpha = _probability(alpha, "alpha", strict=True)
    if trials < 1 or successes < 0 or successes > trials:
        raise CalculatorError("proportion counts require 0 <= SUCCESSES <= TRIALS")
    proportion = successes / trials
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    denominator = 1.0 + critical**2 / trials
    center = (proportion + critical**2 / (2.0 * trials)) / denominator
    half_width = (
        critical
        * math.sqrt(
            proportion * (1.0 - proportion) / trials
            + critical**2 / (4.0 * trials**2)
        )
        / denominator
    )
    wilson = [max(0.0, center - half_width), min(1.0, center + half_width)]
    exact_result = scipy_stats.binomtest(successes, trials).proportion_ci(
        confidence_level=1.0 - alpha,
        method="exact",
    )
    return {
        "method": "binomial proportion confidence intervals",
        "successes": successes,
        "trials": trials,
        "sample_proportion": proportion,
        "confidence_level": 1.0 - alpha,
        "wilson_confidence_interval": wilson,
        "exact_clopper_pearson_interval": [
            float(exact_result.low),
            float(exact_result.high),
        ],
        "status": "completed",
    }


def variance_confidence_interval(
    n: int,
    sample_variance: float,
    alpha: float,
) -> dict[str, Any]:
    """Calculate the normal-theory confidence interval for a variance."""
    alpha = _probability(alpha, "alpha", strict=True)
    if n < 2:
        raise CalculatorError("variance confidence interval requires N >= 2")
    _finite_number(sample_variance, "sample variance")
    if sample_variance < 0.0:
        raise CalculatorError("sample variance must be nonnegative")
    degrees_of_freedom = n - 1
    lower = (
        degrees_of_freedom
        * sample_variance
        / float(scipy_stats.chi2.ppf(1.0 - alpha / 2.0, degrees_of_freedom))
    )
    upper = (
        degrees_of_freedom
        * sample_variance
        / float(scipy_stats.chi2.ppf(alpha / 2.0, degrees_of_freedom))
    )
    return {
        "method": "chi-square confidence interval for a population variance",
        "n": n,
        "sample_variance": sample_variance,
        "sample_standard_deviation": math.sqrt(sample_variance),
        "degrees_of_freedom": degrees_of_freedom,
        "confidence_level": 1.0 - alpha,
        "variance_confidence_interval": [lower, upper],
        "standard_deviation_confidence_interval": [
            math.sqrt(lower),
            math.sqrt(upper),
        ],
        "status": "completed",
    }


def poisson_rate_confidence_interval(
    events: int,
    exposure: float,
    alpha: float,
) -> dict[str, Any]:
    """Calculate an exact Poisson confidence interval for an event rate."""
    alpha = _probability(alpha, "alpha", strict=True)
    if events < 0:
        raise CalculatorError("events must be nonnegative")
    _positive_number(exposure, "exposure")
    lower_mean = (
        0.0
        if events == 0
        else 0.5 * float(scipy_stats.chi2.ppf(alpha / 2.0, 2 * events))
    )
    upper_mean = 0.5 * float(
        scipy_stats.chi2.ppf(1.0 - alpha / 2.0, 2 * (events + 1))
    )
    return {
        "method": "exact Poisson event-rate confidence interval",
        "events": events,
        "exposure": exposure,
        "estimated_rate": events / exposure,
        "confidence_level": 1.0 - alpha,
        "confidence_interval": [lower_mean / exposure, upper_mean / exposure],
        "count_mean_confidence_interval": [lower_mean, upper_mean],
        "status": "completed",
    }
