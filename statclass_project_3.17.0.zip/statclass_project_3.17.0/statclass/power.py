"""No-file statistical power and sample-size calculations."""

from __future__ import annotations

import math
from collections.abc import Callable
from typing import Any

from scipy import optimize as scipy_optimize
from scipy import stats as scipy_stats


class PowerError(ValueError):
    """Raised when a power-analysis request is invalid."""


def _finite(value: float, label: str) -> float:
    value = float(value)
    if not math.isfinite(value):
        raise PowerError(f"{label} must be finite")
    return value


def _positive(value: float, label: str) -> float:
    value = _finite(value, label)
    if value <= 0.0:
        raise PowerError(f"{label} must be positive")
    return value


def _probability(value: float, label: str, strict: bool = False) -> float:
    value = _finite(value, label)
    valid = 0.0 < value < 1.0 if strict else 0.0 <= value <= 1.0
    if not valid:
        qualification = "strictly " if strict else ""
        raise PowerError(f"{label} must be {qualification}between 0 and 1")
    return value


def _sample_size(value: int, label: str, minimum: int = 2) -> int:
    if isinstance(value, bool):
        raise PowerError(f"{label} must be an integer of at least {minimum}")
    numeric = _finite(value, label)
    if not numeric.is_integer() or numeric < minimum:
        raise PowerError(f"{label} must be an integer of at least {minimum}")
    return int(numeric)


def _alternative(value: str) -> str:
    if value not in {"two-sided", "less", "greater"}:
        raise PowerError("alternative must be two-sided, less, or greater")
    return value


def _clamp_power(value: float) -> float:
    numeric = float(value)
    tolerance = 1e-12
    if not math.isfinite(numeric):
        raise PowerError("the power calculation returned a nonfinite value")
    if numeric < -tolerance or numeric > 1.0 + tolerance:
        raise PowerError("the power calculation returned a value outside [0, 1]")
    return max(0.0, min(1.0, numeric))


def _noncentral_t_power(
    degrees_of_freedom: int,
    noncentrality: float,
    alpha: float,
    alternative: str,
) -> float:
    if alternative == "two-sided":
        critical = float(scipy_stats.t.ppf(1.0 - alpha / 2.0, degrees_of_freedom))
        lower_tail = float(
            scipy_stats.nct.cdf(-critical, degrees_of_freedom, noncentrality)
        )
        upper_tail = float(
            scipy_stats.nct.sf(critical, degrees_of_freedom, noncentrality)
        )
        if not math.isfinite(lower_tail) or not math.isfinite(upper_tail):
            # SciPy can return NaN for the vanishing tail at very large
            # noncentrality.  The opposite tail reaching one identifies the
            # limiting probability without concealing an ambiguous failure.
            finite_tail = upper_tail if math.isfinite(upper_tail) else lower_tail
            if finite_tail >= 1.0 - 1e-12:
                return 1.0
            raise PowerError(
                "the noncentral-t calculation returned an indeterminate tail"
            )
        power = lower_tail + upper_tail
    elif alternative == "greater":
        critical = float(scipy_stats.t.ppf(1.0 - alpha, degrees_of_freedom))
        power = scipy_stats.nct.sf(critical, degrees_of_freedom, noncentrality)
    else:
        critical = float(scipy_stats.t.ppf(alpha, degrees_of_freedom))
        power = scipy_stats.nct.cdf(critical, degrees_of_freedom, noncentrality)
    return _clamp_power(power)


def _minimum_integer(
    power_function: Callable[[int], float],
    target_power: float,
    minimum: int,
    maximum: int = 10_000_000,
) -> tuple[int, dict[str, Any]]:
    evaluations = 1
    if power_function(minimum) >= target_power:
        return minimum, {
            "status": "converged",
            "method": "doubling bracket followed by integer bisection",
            "function_evaluations": evaluations,
            "bracketing_iterations": 0,
            "bisection_iterations": 0,
            "search_limit": maximum,
        }
    lower = minimum
    upper = minimum
    bracketing_iterations = 0
    while upper < maximum:
        lower = upper
        upper = min(maximum, upper * 2)
        bracketing_iterations += 1
        evaluations += 1
        if power_function(upper) >= target_power:
            break
    else:
        raise PowerError("target power is not attainable within the sample-size limit")
    evaluations += 1
    if power_function(upper) < target_power:
        raise PowerError("target power is not attainable within the sample-size limit")
    bisection_iterations = 0
    while lower + 1 < upper:
        midpoint = (lower + upper) // 2
        bisection_iterations += 1
        evaluations += 1
        if power_function(midpoint) >= target_power:
            upper = midpoint
        else:
            lower = midpoint
    return upper, {
        "status": "converged",
        "method": "doubling bracket followed by integer bisection",
        "function_evaluations": evaluations,
        "bracketing_iterations": bracketing_iterations,
        "bisection_iterations": bisection_iterations,
        "search_limit": maximum,
    }


def _minimum_effect(
    power_function: Callable[[float], float],
    target_power: float,
    maximum_effect: float,
) -> tuple[float, dict[str, Any]]:
    zero_power = power_function(0.0)
    if zero_power >= target_power:
        return 0.0, {
            "status": "converged",
            "method": "Brent root finding",
            "iterations": 0,
            "function_evaluations": 1,
            "residual": zero_power - target_power,
        }
    if power_function(maximum_effect) < target_power:
        raise PowerError("target power is not attainable within the effect-size range")
    try:
        root, root_result = scipy_optimize.brentq(
            lambda effect: power_function(effect) - target_power,
            0.0,
            maximum_effect,
            xtol=1e-12,
            rtol=1e-12,
            full_output=True,
            disp=False,
        )
    except (RuntimeError, ValueError) as exc:
        raise PowerError(f"detectable-effect root finding failed: {exc}") from exc
    if not root_result.converged:
        raise PowerError(
            f"detectable-effect root finding failed: {root_result.flag}"
        )
    residual = float(power_function(float(root)) - target_power)
    if not math.isfinite(residual) or abs(residual) > 1e-8:
        raise PowerError(
            "detectable-effect root finding returned an unacceptable residual"
        )
    return float(root), {
        "status": "converged",
        "method": "Brent root finding",
        "iterations": int(root_result.iterations),
        "function_evaluations": int(root_result.function_calls),
        "residual": residual,
        "flag": str(root_result.flag),
    }


def one_sample_mean_power(
    n: int,
    effect_size: float,
    alpha: float,
    alternative: str,
    paired: bool = False,
) -> dict[str, Any]:
    """Power for a one-sample or paired-sample t-test."""
    n = _sample_size(n, "N")
    effect_size = _finite(effect_size, "Cohen's d")
    alpha = _probability(alpha, "alpha", strict=True)
    alternative = _alternative(alternative)
    degrees_of_freedom = n - 1
    noncentrality = effect_size * math.sqrt(n)
    power = _noncentral_t_power(
        degrees_of_freedom, noncentrality, alpha, alternative
    )
    return {
        "calculation_type": "power",
        "design": "paired mean" if paired else "one-sample mean",
        "method": "noncentral t approximation",
        "sample_size": n,
        "effect_size_name": "Cohen's dz" if paired else "Cohen's d",
        "effect_size": effect_size,
        "degrees_of_freedom": degrees_of_freedom,
        "noncentrality_parameter": noncentrality,
        "alpha": alpha,
        "alternative": alternative,
        "power": power,
        "status": "completed",
    }


def one_sample_mean_sample_size(
    effect_size: float,
    target_power: float,
    alpha: float,
    alternative: str,
    paired: bool = False,
) -> dict[str, Any]:
    """Minimum N for a one-sample or paired-sample t-test."""
    effect_size = _finite(effect_size, "Cohen's d")
    if effect_size == 0.0:
        raise PowerError("Cohen's d must be nonzero for sample-size calculation")
    target_power = _probability(target_power, "target power", strict=True)
    alpha = _probability(alpha, "alpha", strict=True)
    alternative = _alternative(alternative)
    n, convergence = _minimum_integer(
        lambda candidate: one_sample_mean_power(
            candidate, effect_size, alpha, alternative, paired
        )["power"],
        target_power,
        2,
    )
    result = one_sample_mean_power(n, effect_size, alpha, alternative, paired)
    result.update(
        {
            "calculation_type": "required_sample_size",
            "target_power": target_power,
            "achieved_power": result.pop("power"),
            "numerical_status": convergence,
        }
    )
    return result


def one_sample_mean_detectable_effect(
    n: int,
    target_power: float,
    alpha: float,
    alternative: str,
    paired: bool = False,
) -> dict[str, Any]:
    """Minimum detectable standardized mean effect for a fixed N."""
    n = _sample_size(n, "N")
    target_power = _probability(target_power, "target power", strict=True)
    alpha = _probability(alpha, "alpha", strict=True)
    alternative = _alternative(alternative)
    sign = -1.0 if alternative == "less" else 1.0
    magnitude, convergence = _minimum_effect(
        lambda effect: one_sample_mean_power(
            n, sign * effect, alpha, alternative, paired
        )["power"],
        target_power,
        20.0,
    )
    result = one_sample_mean_power(
        n, sign * magnitude, alpha, alternative, paired
    )
    result.update(
        {
            "calculation_type": "detectable_effect",
            "target_power": target_power,
            "achieved_power": result.pop("power"),
            "detectable_effect_magnitude": magnitude,
            "numerical_status": convergence,
        }
    )
    return result


def two_sample_mean_power(
    n_1: int,
    n_2: int,
    effect_size: float,
    alpha: float,
    alternative: str,
) -> dict[str, Any]:
    """Power for an equal-variance independent two-sample t-test."""
    n_1 = _sample_size(n_1, "N1")
    n_2 = _sample_size(n_2, "N2")
    effect_size = _finite(effect_size, "Cohen's d")
    alpha = _probability(alpha, "alpha", strict=True)
    alternative = _alternative(alternative)
    degrees_of_freedom = n_1 + n_2 - 2
    noncentrality = effect_size / math.sqrt(1.0 / n_1 + 1.0 / n_2)
    power = _noncentral_t_power(
        degrees_of_freedom, noncentrality, alpha, alternative
    )
    return {
        "calculation_type": "power",
        "design": "two independent means",
        "method": "equal-variance noncentral t approximation",
        "sample_size_1": n_1,
        "sample_size_2": n_2,
        "total_sample_size": n_1 + n_2,
        "effect_size_name": "Cohen's d",
        "effect_size": effect_size,
        "degrees_of_freedom": degrees_of_freedom,
        "noncentrality_parameter": noncentrality,
        "alpha": alpha,
        "alternative": alternative,
        "power": power,
        "status": "completed",
    }


def two_sample_mean_sample_size(
    effect_size: float,
    target_power: float,
    alpha: float,
    alternative: str,
    allocation_ratio: float = 1.0,
) -> dict[str, Any]:
    """Minimum N1 and N2 for an independent two-sample t-test."""
    effect_size = _finite(effect_size, "Cohen's d")
    if effect_size == 0.0:
        raise PowerError("Cohen's d must be nonzero for sample-size calculation")
    target_power = _probability(target_power, "target power", strict=True)
    alpha = _probability(alpha, "alpha", strict=True)
    alternative = _alternative(alternative)
    allocation_ratio = _positive(allocation_ratio, "allocation ratio")

    def candidate_power(n_1: int) -> float:
        n_2 = max(2, math.ceil(allocation_ratio * n_1))
        return two_sample_mean_power(
            n_1, n_2, effect_size, alpha, alternative
        )["power"]

    n_1, convergence = _minimum_integer(candidate_power, target_power, 2)
    n_2 = max(2, math.ceil(allocation_ratio * n_1))
    result = two_sample_mean_power(n_1, n_2, effect_size, alpha, alternative)
    result.update(
        {
            "calculation_type": "required_sample_size",
            "target_power": target_power,
            "achieved_power": result.pop("power"),
            "allocation_ratio_n2_to_n1": allocation_ratio,
            "numerical_status": convergence,
        }
    )
    return result


def two_sample_mean_detectable_effect(
    n_1: int,
    n_2: int,
    target_power: float,
    alpha: float,
    alternative: str,
) -> dict[str, Any]:
    """Minimum detectable standardized difference for fixed group sizes."""
    n_1 = _sample_size(n_1, "N1")
    n_2 = _sample_size(n_2, "N2")
    target_power = _probability(target_power, "target power", strict=True)
    alpha = _probability(alpha, "alpha", strict=True)
    alternative = _alternative(alternative)
    sign = -1.0 if alternative == "less" else 1.0
    magnitude, convergence = _minimum_effect(
        lambda effect: two_sample_mean_power(
            n_1, n_2, sign * effect, alpha, alternative
        )["power"],
        target_power,
        20.0,
    )
    result = two_sample_mean_power(
        n_1, n_2, sign * magnitude, alpha, alternative
    )
    result.update(
        {
            "calculation_type": "detectable_effect",
            "target_power": target_power,
            "achieved_power": result.pop("power"),
            "detectable_effect_magnitude": magnitude,
            "numerical_status": convergence,
        }
    )
    return result


def _normal_rejection_power(
    mean: float,
    standard_deviation: float,
    lower: float | None,
    upper: float | None,
) -> float:
    if standard_deviation == 0.0:
        rejected = ((lower is not None and mean <= lower) or
                    (upper is not None and mean >= upper))
        return float(rejected)
    power = 0.0
    if lower is not None:
        power += float(scipy_stats.norm.cdf((lower - mean) / standard_deviation))
    if upper is not None:
        power += float(scipy_stats.norm.sf((upper - mean) / standard_deviation))
    return _clamp_power(power)


def one_proportion_power(
    n: int,
    actual_probability: float,
    null_probability: float,
    alpha: float,
    alternative: str,
) -> dict[str, Any]:
    """Approximate power for a one-proportion z-test."""
    n = _sample_size(n, "N", 1)
    actual_probability = _probability(actual_probability, "actual probability")
    null_probability = _probability(
        null_probability, "null probability", strict=True
    )
    alpha = _probability(alpha, "alpha", strict=True)
    alternative = _alternative(alternative)
    null_se = math.sqrt(null_probability * (1.0 - null_probability) / n)
    actual_se = math.sqrt(
        actual_probability * (1.0 - actual_probability) / n
    )
    if alternative == "two-sided":
        critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
        lower = null_probability - critical * null_se
        upper = null_probability + critical * null_se
    elif alternative == "greater":
        critical = float(scipy_stats.norm.ppf(1.0 - alpha))
        lower = None
        upper = null_probability + critical * null_se
    else:
        critical = float(scipy_stats.norm.ppf(alpha))
        lower = null_probability + critical * null_se
        upper = None
    power = _normal_rejection_power(
        actual_probability, actual_se, lower, upper
    )
    return {
        "calculation_type": "power",
        "design": "one proportion",
        "method": "normal approximation to the one-proportion z-test",
        "sample_size": n,
        "actual_probability": actual_probability,
        "null_probability": null_probability,
        "probability_difference": actual_probability - null_probability,
        "alpha": alpha,
        "alternative": alternative,
        "power": power,
        "status": "completed",
    }


def one_proportion_sample_size(
    actual_probability: float,
    null_probability: float,
    target_power: float,
    alpha: float,
    alternative: str,
) -> dict[str, Any]:
    """Minimum N for a one-proportion z-test."""
    actual_probability = _probability(actual_probability, "actual probability")
    null_probability = _probability(
        null_probability, "null probability", strict=True
    )
    if actual_probability == null_probability:
        raise PowerError("actual and null probabilities must differ")
    target_power = _probability(target_power, "target power", strict=True)
    alpha = _probability(alpha, "alpha", strict=True)
    alternative = _alternative(alternative)
    n, convergence = _minimum_integer(
        lambda candidate: one_proportion_power(
            candidate,
            actual_probability,
            null_probability,
            alpha,
            alternative,
        )["power"],
        target_power,
        1,
    )
    result = one_proportion_power(
        n, actual_probability, null_probability, alpha, alternative
    )
    result.update(
        {
            "calculation_type": "required_sample_size",
            "target_power": target_power,
            "achieved_power": result.pop("power"),
            "numerical_status": convergence,
        }
    )
    return result


def one_proportion_detectable_effect(
    n: int,
    null_probability: float,
    target_power: float,
    alpha: float,
    alternative: str,
) -> dict[str, Any]:
    """Minimum detectable raw probability difference for a fixed N."""
    n = _sample_size(n, "N", 1)
    null_probability = _probability(
        null_probability, "null probability", strict=True
    )
    target_power = _probability(target_power, "target power", strict=True)
    alpha = _probability(alpha, "alpha", strict=True)
    alternative = _alternative(alternative)
    sign = -1.0 if alternative == "less" else 1.0
    maximum = null_probability if sign < 0 else 1.0 - null_probability
    difference, convergence = _minimum_effect(
        lambda magnitude: one_proportion_power(
            n,
            null_probability + sign * magnitude,
            null_probability,
            alpha,
            alternative,
        )["power"],
        target_power,
        maximum,
    )
    result = one_proportion_power(
        n,
        null_probability + sign * difference,
        null_probability,
        alpha,
        alternative,
    )
    result.update(
        {
            "calculation_type": "detectable_effect",
            "target_power": target_power,
            "achieved_power": result.pop("power"),
            "detectable_effect_magnitude": difference,
            "numerical_status": convergence,
        }
    )
    return result


def two_proportion_power(
    n_1: int,
    n_2: int,
    probability_1: float,
    probability_2: float,
    alpha: float,
    alternative: str,
) -> dict[str, Any]:
    """Approximate power for an independent two-proportion z-test."""
    n_1 = _sample_size(n_1, "N1", 1)
    n_2 = _sample_size(n_2, "N2", 1)
    probability_1 = _probability(probability_1, "probability 1")
    probability_2 = _probability(probability_2, "probability 2")
    alpha = _probability(alpha, "alpha", strict=True)
    alternative = _alternative(alternative)
    pooled = (n_1 * probability_1 + n_2 * probability_2) / (n_1 + n_2)
    if pooled in {0.0, 1.0}:
        raise PowerError("the pooled expected probability must be between 0 and 1")
    null_se = math.sqrt(pooled * (1.0 - pooled) * (1.0 / n_1 + 1.0 / n_2))
    actual_se = math.sqrt(
        probability_1 * (1.0 - probability_1) / n_1
        + probability_2 * (1.0 - probability_2) / n_2
    )
    difference = probability_1 - probability_2
    if alternative == "two-sided":
        critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
        lower = -critical * null_se
        upper = critical * null_se
    elif alternative == "greater":
        critical = float(scipy_stats.norm.ppf(1.0 - alpha))
        lower = None
        upper = critical * null_se
    else:
        critical = float(scipy_stats.norm.ppf(alpha))
        lower = critical * null_se
        upper = None
    power = _normal_rejection_power(difference, actual_se, lower, upper)
    return {
        "calculation_type": "power",
        "design": "two independent proportions",
        "method": "normal approximation to the pooled two-proportion z-test",
        "sample_size_1": n_1,
        "sample_size_2": n_2,
        "total_sample_size": n_1 + n_2,
        "probability_1": probability_1,
        "probability_2": probability_2,
        "probability_difference": difference,
        "alpha": alpha,
        "alternative": alternative,
        "power": power,
        "status": "completed",
    }


def two_proportion_sample_size(
    probability_1: float,
    probability_2: float,
    target_power: float,
    alpha: float,
    alternative: str,
    allocation_ratio: float = 1.0,
) -> dict[str, Any]:
    """Minimum N1 and N2 for an independent two-proportion z-test."""
    probability_1 = _probability(probability_1, "probability 1")
    probability_2 = _probability(probability_2, "probability 2")
    if probability_1 == probability_2:
        raise PowerError("probability 1 and probability 2 must differ")
    target_power = _probability(target_power, "target power", strict=True)
    alpha = _probability(alpha, "alpha", strict=True)
    alternative = _alternative(alternative)
    allocation_ratio = _positive(allocation_ratio, "allocation ratio")

    def candidate_power(n_1: int) -> float:
        n_2 = max(1, math.ceil(allocation_ratio * n_1))
        return two_proportion_power(
            n_1,
            n_2,
            probability_1,
            probability_2,
            alpha,
            alternative,
        )["power"]

    n_1, convergence = _minimum_integer(candidate_power, target_power, 1)
    n_2 = max(1, math.ceil(allocation_ratio * n_1))
    result = two_proportion_power(
        n_1, n_2, probability_1, probability_2, alpha, alternative
    )
    result.update(
        {
            "calculation_type": "required_sample_size",
            "target_power": target_power,
            "achieved_power": result.pop("power"),
            "allocation_ratio_n2_to_n1": allocation_ratio,
            "numerical_status": convergence,
        }
    )
    return result


def two_proportion_detectable_effect(
    n_1: int,
    n_2: int,
    baseline_probability: float,
    target_power: float,
    alpha: float,
    alternative: str,
) -> dict[str, Any]:
    """Minimum detectable difference from a fixed second-group probability."""
    n_1 = _sample_size(n_1, "N1", 1)
    n_2 = _sample_size(n_2, "N2", 1)
    baseline_probability = _probability(
        baseline_probability, "baseline probability", strict=True
    )
    target_power = _probability(target_power, "target power", strict=True)
    alpha = _probability(alpha, "alpha", strict=True)
    alternative = _alternative(alternative)
    sign = -1.0 if alternative == "less" else 1.0
    maximum = (
        baseline_probability if sign < 0 else 1.0 - baseline_probability
    )
    difference, convergence = _minimum_effect(
        lambda magnitude: two_proportion_power(
            n_1,
            n_2,
            baseline_probability + sign * magnitude,
            baseline_probability,
            alpha,
            alternative,
        )["power"],
        target_power,
        maximum,
    )
    result = two_proportion_power(
        n_1,
        n_2,
        baseline_probability + sign * difference,
        baseline_probability,
        alpha,
        alternative,
    )
    result.update(
        {
            "calculation_type": "detectable_effect",
            "target_power": target_power,
            "achieved_power": result.pop("power"),
            "baseline_probability": baseline_probability,
            "detectable_effect_magnitude": difference,
            "numerical_status": convergence,
        }
    )
    return result


def one_way_anova_power(
    groups: int,
    sample_size_per_group: int,
    effect_size: float,
    alpha: float,
) -> dict[str, Any]:
    """Power for balanced one-way ANOVA using Cohen's f."""
    groups = _sample_size(groups, "number of groups", 2)
    sample_size_per_group = _sample_size(sample_size_per_group, "N per group", 2)
    effect_size = _finite(effect_size, "Cohen's f")
    if effect_size < 0.0:
        raise PowerError("Cohen's f must be nonnegative")
    alpha = _probability(alpha, "alpha", strict=True)
    total_sample_size = groups * sample_size_per_group
    numerator_df = groups - 1
    denominator_df = total_sample_size - groups
    noncentrality = total_sample_size * effect_size**2
    critical = float(
        scipy_stats.f.ppf(1.0 - alpha, numerator_df, denominator_df)
    )
    # scipy.stats.ncf.sf is incorrect at exactly zero noncentrality in some
    # SciPy releases; at that point the central F survival function is exact.
    if noncentrality == 0.0:
        raw_power = scipy_stats.f.sf(critical, numerator_df, denominator_df)
    else:
        raw_power = scipy_stats.ncf.sf(
            critical, numerator_df, denominator_df, noncentrality
        )
    power = _clamp_power(raw_power)
    return {
        "calculation_type": "power",
        "design": "balanced one-way ANOVA",
        "method": "noncentral F approximation",
        "groups": groups,
        "sample_size_per_group": sample_size_per_group,
        "total_sample_size": total_sample_size,
        "effect_size_name": "Cohen's f",
        "effect_size": effect_size,
        "degrees_of_freedom_numerator": numerator_df,
        "degrees_of_freedom_denominator": denominator_df,
        "noncentrality_parameter": noncentrality,
        "alpha": alpha,
        "alternative": "upper-tail F test",
        "power": power,
        "status": "completed",
    }


def one_way_anova_sample_size(
    groups: int,
    effect_size: float,
    target_power: float,
    alpha: float,
) -> dict[str, Any]:
    """Minimum equal group size for balanced one-way ANOVA."""
    groups = _sample_size(groups, "number of groups", 2)
    effect_size = _positive(effect_size, "Cohen's f")
    target_power = _probability(target_power, "target power", strict=True)
    alpha = _probability(alpha, "alpha", strict=True)
    per_group, convergence = _minimum_integer(
        lambda candidate: one_way_anova_power(
            groups, candidate, effect_size, alpha
        )["power"],
        target_power,
        2,
    )
    result = one_way_anova_power(groups, per_group, effect_size, alpha)
    result.update(
        {
            "calculation_type": "required_sample_size",
            "target_power": target_power,
            "achieved_power": result.pop("power"),
            "numerical_status": convergence,
        }
    )
    return result


def one_way_anova_detectable_effect(
    groups: int,
    sample_size_per_group: int,
    target_power: float,
    alpha: float,
) -> dict[str, Any]:
    """Minimum detectable Cohen's f for balanced one-way ANOVA."""
    groups = _sample_size(groups, "number of groups", 2)
    sample_size_per_group = _sample_size(sample_size_per_group, "N per group", 2)
    target_power = _probability(target_power, "target power", strict=True)
    alpha = _probability(alpha, "alpha", strict=True)
    effect_size, convergence = _minimum_effect(
        lambda effect: one_way_anova_power(
            groups, sample_size_per_group, effect, alpha
        )["power"],
        target_power,
        10.0,
    )
    result = one_way_anova_power(
        groups, sample_size_per_group, effect_size, alpha
    )
    result.update(
        {
            "calculation_type": "detectable_effect",
            "target_power": target_power,
            "achieved_power": result.pop("power"),
            "detectable_effect_magnitude": effect_size,
            "numerical_status": convergence,
        }
    )
    return result
