"""Dependency-version reporting without importing scientific packages."""

from __future__ import annotations

import platform
from importlib import metadata

from . import __version__


DEPENDENCIES = ("numpy", "pandas", "scipy", "matplotlib")


def dependency_report() -> str:
    """Return versions from the active Python environment."""
    versions = [
        "StatClass dependency versions",
        f"statclass={__version__}",
        f"python={platform.python_version()}",
    ]
    for package in DEPENDENCIES:
        try:
            installed_version = metadata.version(package)
        except metadata.PackageNotFoundError:
            installed_version = "not installed"
        versions.append(f"{package}={installed_version}")
    return "\n".join(versions) + "\n"
