"""One- and two-proportion inference."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .utils import decision_from_pvalue, finite_or_none, format_number


def category_matches(value: Any, target: str) -> bool:
    value_text = str(value).strip()
    target_text = str(target).strip()
    if value_text == target_text:
        return True
    try:
        return float(value_text) == float(target_text)
    except ValueError:
        return False


def _normal_p_value(statistic: float, alternative: str) -> float:
    if alternative == "two-sided":
        return float(2.0 * scipy_stats.norm.sf(abs(statistic)))
    if alternative == "less":
        return float(scipy_stats.norm.cdf(statistic))
    return float(scipy_stats.norm.sf(statistic))


def _clopper_pearson_interval(
    successes: int,
    trials: int,
    alpha: float,
) -> list[float]:
    lower = (
        0.0
        if successes == 0
        else float(
            scipy_stats.beta.ppf(alpha / 2.0, successes, trials - successes + 1)
        )
    )
    upper = (
        1.0
        if successes == trials
        else float(
            scipy_stats.beta.ppf(
                1.0 - alpha / 2.0,
                successes + 1,
                trials - successes,
            )
        )
    )
    return [lower, upper]


def _wilson_interval(
    successes: int,
    trials: int,
    alpha: float,
) -> list[float]:
    proportion = successes / trials
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    denominator = 1.0 + critical**2 / trials
    center = (proportion + critical**2 / (2.0 * trials)) / denominator
    half_width = (
        critical
        * math.sqrt(
            proportion * (1.0 - proportion) / trials
            + critical**2 / (4.0 * trials**2)
        )
        / denominator
    )
    return [max(0.0, center - half_width), min(1.0, center + half_width)]


def _binomial_log_likelihood(
    successes: int,
    trials: int,
    probability: float,
) -> float:
    """Return log P(X=successes) for X ~ Binomial(trials, probability)."""
    failures = trials - successes
    log_coefficient = (
        math.lgamma(trials + 1.0)
        - math.lgamma(successes + 1.0)
        - math.lgamma(failures + 1.0)
    )
    if probability == 0.0:
        return log_coefficient if successes == 0 else -math.inf
    if probability == 1.0:
        return log_coefficient if failures == 0 else -math.inf
    return (
        log_coefficient
        + successes * math.log(probability)
        + failures * math.log1p(-probability)
    )


def _likelihood_evaluation(
    successes: int,
    trials: int,
    probability: float,
    maximized_log_likelihood: float,
) -> dict[str, Any]:
    log_likelihood = _binomial_log_likelihood(successes, trials, probability)
    likelihood = 0.0 if log_likelihood == -math.inf else math.exp(log_likelihood)
    relative_likelihood = (
        0.0
        if log_likelihood == -math.inf
        else min(1.0, math.exp(log_likelihood - maximized_log_likelihood))
    )
    return {
        "probability": probability,
        "likelihood": likelihood,
        "log_likelihood": finite_or_none(log_likelihood),
        "relative_likelihood": relative_likelihood,
    }


def _binomial_likelihood_from_counts(
    successes: int,
    trials: int,
    probabilities: list[float],
) -> dict[str, Any]:
    failures = trials - successes
    mle_probability = successes / trials
    maximized_log_likelihood = _binomial_log_likelihood(
        successes,
        trials,
        mle_probability,
    )
    return {
        "binomial_coefficient": math.comb(trials, successes),
        "likelihood_formula": (
            f"L(p) = C({trials}, {successes}) * p^{successes} * "
            f"(1 - p)^{failures}"
        ),
        "likelihood_kernel": (
            f"L(p) proportional to p^{successes} * (1 - p)^{failures}"
        ),
        "mle_probability": mle_probability,
        "maximized_likelihood": math.exp(maximized_log_likelihood),
        "maximized_log_likelihood": maximized_log_likelihood,
        "evaluations": [
            _likelihood_evaluation(
                successes,
                trials,
                probability,
                maximized_log_likelihood,
            )
            for probability in probabilities
        ],
    }


def binomial_likelihood_analysis(
    series: pd.Series,
    column_name: str,
    success_value: str,
    probabilities: list[float] | None = None,
) -> dict[str, Any]:
    """Describe and evaluate the binomial likelihood for a binary outcome."""
    valid = series.dropna()
    n = int(valid.size)
    successes = int(
        sum(category_matches(value, success_value) for value in valid)
    )
    result: dict[str, Any] = {
        "method": "binomial likelihood analysis",
        "source": "data_column",
        "column": column_name,
        "success_value": success_value,
        "n": n,
        "successes": successes,
        "failures": n - successes,
        "missing": int(series.isna().sum()),
    }
    if n == 0:
        result.update(
            status="not_run",
            reason="requires at least 1 nonmissing observation",
        )
        return result

    requested_probabilities = list(probabilities or [])
    result.update(
        status="completed",
        **_binomial_likelihood_from_counts(
            successes,
            n,
            requested_probabilities,
        ),
    )
    return result


def binomial_likelihood_counts_analysis(
    successes: int,
    trials: int,
    probabilities: list[float] | None = None,
) -> dict[str, Any]:
    """Describe and evaluate a binomial likelihood from aggregate counts."""
    result: dict[str, Any] = {
        "method": "binomial likelihood analysis",
        "source": "aggregate_counts",
        "n": trials,
        "successes": successes,
        "failures": trials - successes,
        "missing": 0,
        "status": "completed",
    }
    result.update(
        _binomial_likelihood_from_counts(
            successes,
            trials,
            list(probabilities or []),
        )
    )
    return result


def one_proportion_counts_test(
    successes: int,
    trials: int,
    null_proportion: float,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    """One-proportion inference from an aggregate success count."""
    sample_proportion = successes / trials
    null_standard_error = math.sqrt(
        null_proportion * (1.0 - null_proportion) / trials
    )
    z_score = (sample_proportion - null_proportion) / null_standard_error
    z_p_value = _normal_p_value(z_score, alternative)
    exact_p_value = float(
        scipy_stats.binomtest(
            successes,
            trials,
            null_proportion,
            alternative=alternative,
        ).pvalue
    )
    return {
        "method": "one-proportion z-test with exact binomial comparison",
        "source": "aggregate_counts",
        "status": "completed",
        "n": trials,
        "successes": successes,
        "failures": trials - successes,
        "null_proportion": null_proportion,
        "alternative": alternative,
        "null_hypothesis": (
            f"population proportion = {format_number(null_proportion)}"
        ),
        "sample_proportion": sample_proportion,
        "null_standard_error": null_standard_error,
        "z_score": finite_or_none(z_score),
        "z_p_value": finite_or_none(z_p_value),
        "exact_binomial_p_value": finite_or_none(exact_p_value),
        "confidence_level": 1.0 - alpha,
        "wilson_confidence_interval": _wilson_interval(successes, trials, alpha),
        "exact_clopper_pearson_interval": _clopper_pearson_interval(
            successes,
            trials,
            alpha,
        ),
        "z_test_decision": decision_from_pvalue(z_p_value, alpha),
        "exact_test_decision": decision_from_pvalue(exact_p_value, alpha),
        "likelihood_analysis": _binomial_likelihood_from_counts(
            successes,
            trials,
            [null_proportion],
        ),
    }


def two_proportion_counts_test(
    successes_1: int,
    trials_1: int,
    successes_2: int,
    trials_2: int,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    """Two-proportion z inference from two aggregate success counts."""
    successes = [successes_1, successes_2]
    totals = [trials_1, trials_2]
    proportions = [successes_1 / trials_1, successes_2 / trials_2]
    group_statistics = [
        {
            "group": f"sample {index + 1}",
            "n": totals[index],
            "successes": successes[index],
            "failures": totals[index] - successes[index],
            "proportion": proportions[index],
            "wilson_confidence_interval": _wilson_interval(
                successes[index],
                totals[index],
                alpha,
            ),
        }
        for index in range(2)
    ]
    pooled_proportion = sum(successes) / sum(totals)
    pooled_standard_error = math.sqrt(
        pooled_proportion
        * (1.0 - pooled_proportion)
        * (1.0 / trials_1 + 1.0 / trials_2)
    )
    result: dict[str, Any] = {
        "method": "two-proportion z-test",
        "source": "aggregate_counts",
        "alternative": alternative,
        "group_statistics": group_statistics,
    }
    if pooled_standard_error == 0.0:
        result.update(
            status="not_run",
            reason="the pooled standard error is zero because all outcomes are identical",
        )
        return result

    difference = proportions[0] - proportions[1]
    z_score = difference / pooled_standard_error
    p_value = _normal_p_value(z_score, alternative)
    unpooled_standard_error = math.sqrt(
        proportions[0] * (1.0 - proportions[0]) / trials_1
        + proportions[1] * (1.0 - proportions[1]) / trials_2
    )
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    confidence_interval = [
        difference - critical * unpooled_standard_error,
        difference + critical * unpooled_standard_error,
    ]
    risk_ratio = (
        proportions[0] / proportions[1] if proportions[1] > 0.0 else None
    )
    odds_ratio = None
    if 0.0 < proportions[0] < 1.0 and 0.0 < proportions[1] < 1.0:
        odds_ratio = (
            proportions[0] / (1.0 - proportions[0])
        ) / (proportions[1] / (1.0 - proportions[1]))
    result.update(
        {
            "status": "completed",
            "null_hypothesis": "the two population proportions are equal",
            "risk_difference": difference,
            "pooled_proportion": pooled_proportion,
            "pooled_standard_error": pooled_standard_error,
            "unpooled_standard_error": unpooled_standard_error,
            "z_score": finite_or_none(z_score),
            "p_value": finite_or_none(p_value),
            "confidence_level": 1.0 - alpha,
            "confidence_interval_for_risk_difference": confidence_interval,
            "relative_risk": finite_or_none(risk_ratio),
            "odds_ratio": finite_or_none(odds_ratio),
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result


def one_proportion_test(
    series: pd.Series,
    column_name: str,
    success_value: str,
    null_proportion: float,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    valid = series.dropna()
    n = int(valid.size)
    successes = int(
        sum(category_matches(value, success_value) for value in valid)
    )
    result: dict[str, Any] = {
        "method": "one-proportion z-test with exact binomial comparison",
        "column": column_name,
        "success_value": success_value,
        "n": n,
        "successes": successes,
        "failures": n - successes,
        "missing": int(series.isna().sum()),
        "null_proportion": null_proportion,
        "alternative": alternative,
    }
    if n == 0:
        result.update(status="not_run", reason="requires at least 1 nonmissing observation")
        return result

    sample_proportion = successes / n
    null_standard_error = math.sqrt(
        null_proportion * (1.0 - null_proportion) / n
    )
    z_score = (sample_proportion - null_proportion) / null_standard_error
    z_p_value = _normal_p_value(z_score, alternative)
    exact = scipy_stats.binomtest(
        successes,
        n,
        null_proportion,
        alternative=alternative,
    )
    exact_p_value = float(exact.pvalue)
    result.update(
        {
            "status": "completed",
            "null_hypothesis": (
                f"population proportion = {format_number(null_proportion)}"
            ),
            "sample_proportion": sample_proportion,
            "null_standard_error": null_standard_error,
            "z_score": finite_or_none(z_score),
            "z_p_value": finite_or_none(z_p_value),
            "exact_binomial_p_value": finite_or_none(exact_p_value),
            "confidence_level": 1.0 - alpha,
            "wilson_confidence_interval": _wilson_interval(successes, n, alpha),
            "exact_clopper_pearson_interval": _clopper_pearson_interval(
                successes, n, alpha
            ),
            "z_test_decision": decision_from_pvalue(z_p_value, alpha),
            "exact_test_decision": decision_from_pvalue(exact_p_value, alpha),
            "likelihood_analysis": _binomial_likelihood_from_counts(
                successes,
                n,
                [null_proportion],
            ),
        }
    )
    return result


def two_proportion_test(
    group_series: pd.Series,
    outcome_series: pd.Series,
    group_name: str,
    outcome_name: str,
    success_value: str,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    mask = group_series.notna() & outcome_series.notna()
    groups = group_series[mask]
    outcomes = outcome_series[mask]
    group_values = list(pd.unique(groups))
    result: dict[str, Any] = {
        "method": "two-proportion z-test",
        "group_variable": group_name,
        "outcome_variable": outcome_name,
        "success_value": success_value,
        "alternative": alternative,
        "complete_cases": int(mask.sum()),
        "excluded_missing_cases": int((~mask).sum()),
    }
    if len(group_values) != 2:
        result.update(
            status="not_run",
            reason=(
                "the group variable must have exactly 2 observed nonmissing categories"
            ),
        )
        return result

    group_statistics: list[dict[str, Any]] = []
    successes: list[int] = []
    totals: list[int] = []
    proportions: list[float] = []
    for group_value in group_values:
        group_mask = groups == group_value
        group_outcomes = outcomes[group_mask]
        n = int(group_outcomes.size)
        count = int(
            sum(category_matches(value, success_value) for value in group_outcomes)
        )
        proportion = count / n
        successes.append(count)
        totals.append(n)
        proportions.append(proportion)
        group_statistics.append(
            {
                "group": str(group_value),
                "n": n,
                "successes": count,
                "failures": n - count,
                "proportion": proportion,
                "wilson_confidence_interval": _wilson_interval(count, n, alpha),
            }
        )

    pooled_proportion = sum(successes) / sum(totals)
    pooled_standard_error = math.sqrt(
        pooled_proportion
        * (1.0 - pooled_proportion)
        * (1.0 / totals[0] + 1.0 / totals[1])
    )
    if pooled_standard_error == 0:
        result.update(
            status="not_run",
            reason="the pooled standard error is zero because all outcomes are identical",
            group_statistics=group_statistics,
        )
        return result

    difference = proportions[0] - proportions[1]
    z_score = difference / pooled_standard_error
    p_value = _normal_p_value(z_score, alternative)
    unpooled_standard_error = math.sqrt(
        proportions[0] * (1.0 - proportions[0]) / totals[0]
        + proportions[1] * (1.0 - proportions[1]) / totals[1]
    )
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    confidence_interval = [
        difference - critical * unpooled_standard_error,
        difference + critical * unpooled_standard_error,
    ]
    risk_ratio = (
        proportions[0] / proportions[1]
        if proportions[1] > 0
        else None
    )
    odds_ratio = None
    if 0 < proportions[0] < 1 and 0 < proportions[1] < 1:
        odds_ratio = (
            proportions[0] / (1.0 - proportions[0])
        ) / (proportions[1] / (1.0 - proportions[1]))

    result.update(
        {
            "status": "completed",
            "null_hypothesis": "the two population proportions are equal",
            "group_statistics": group_statistics,
            "risk_difference": difference,
            "pooled_proportion": pooled_proportion,
            "pooled_standard_error": pooled_standard_error,
            "unpooled_standard_error": unpooled_standard_error,
            "z_score": finite_or_none(z_score),
            "p_value": finite_or_none(p_value),
            "confidence_level": 1.0 - alpha,
            "confidence_interval_for_risk_difference": confidence_interval,
            "relative_risk": finite_or_none(risk_ratio),
            "odds_ratio": finite_or_none(odds_ratio),
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result
