"""Headless, file-based statistical plots for StatClass."""

from __future__ import annotations

import math
import os
import re
import tempfile
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .data import DataError


PLOT_TYPES = (
    "histogram",
    "qq",
    "boxplot",
    "grouped-boxplot",
    "scatter",
    "correlation",
)

_COLOR_BLUE = "#0072B2"
_COLOR_ORANGE = "#D55E00"
_COLOR_GREEN = "#009E73"
_COLOR_PURPLE = "#CC79A7"
_COLOR_GRAY = "#666666"
_PALETTE = (
    _COLOR_BLUE,
    _COLOR_ORANGE,
    _COLOR_GREEN,
    _COLOR_PURPLE,
    "#E69F00",
    "#56B4E9",
    "#F0E442",
    "#000000",
)


def _load_pyplot() -> Any:
    if "MPLCONFIGDIR" not in os.environ:
        configuration_directory = Path(tempfile.gettempdir()) / "statclass-matplotlib"
        configuration_directory.mkdir(parents=True, exist_ok=True)
        os.environ["MPLCONFIGDIR"] = str(configuration_directory)
    try:
        import matplotlib

        matplotlib.use("Agg", force=True)
        from matplotlib import pyplot as plt
    except ImportError as exc:
        raise DataError(
            "plotting requires Matplotlib; install it with "
            "'conda install matplotlib'"
        ) from exc
    plt.rcParams.update(
        {
            "font.size": 11,
            "axes.titlesize": 13,
            "axes.labelsize": 11,
            "legend.fontsize": 9,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "axes.edgecolor": "#333333",
            "axes.grid": True,
            "grid.alpha": 0.22,
            "grid.color": "#777777",
        }
    )
    return plt


def _slug(value: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_").lower()
    return slug[:80] or "plot"


def _unique_path(directory: Path, stem: str, file_format: str) -> Path:
    candidate = directory / f"{stem}.{file_format}"
    suffix = 2
    while candidate.exists():
        candidate = directory / f"{stem}_{suffix}.{file_format}"
        suffix += 1
    return candidate


def _save_figure(
    plt: Any,
    figure: Any,
    directory: Path,
    stem: str,
    file_format: str,
    dpi: int,
    plot_type: str,
    title: str,
    source: str,
    model_name: str | None = None,
) -> dict[str, Any]:
    path = _unique_path(directory, _slug(stem), file_format)
    figure.savefig(path, format=file_format, dpi=dpi, bbox_inches="tight")
    plt.close(figure)
    return {
        "plot_type": plot_type,
        "title": title,
        "source": source,
        "model_name": model_name,
        "file": str(path),
        "format": file_format,
        "dpi": dpi,
    }


def _numeric_values(frame: pd.DataFrame, column: str) -> np.ndarray:
    values = pd.to_numeric(frame[column], errors="coerce").to_numpy(dtype=float)
    values = values[np.isfinite(values)]
    if values.size < 2:
        raise DataError(f"plotting {column!r} requires at least 2 finite values")
    return values


def _paired_numeric_values(
    frame: pd.DataFrame, first: str, second: str
) -> tuple[np.ndarray, np.ndarray]:
    first_values = pd.to_numeric(frame[first], errors="coerce").to_numpy(
        dtype=float
    )
    second_values = pd.to_numeric(frame[second], errors="coerce").to_numpy(
        dtype=float
    )
    mask = np.isfinite(first_values) & np.isfinite(second_values)
    if int(np.sum(mask)) < 2:
        raise DataError(
            f"plotting {first!r} with {second!r} requires at least 2 complete pairs"
        )
    return first_values[mask], second_values[mask]


def _histogram(
    plt: Any,
    frame: pd.DataFrame,
    column: str,
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any]:
    values = _numeric_values(frame, column)
    figure, axis = plt.subplots(figsize=(8.5, 5.5))
    axis.hist(
        values,
        bins="auto",
        density=True,
        color=_COLOR_BLUE,
        edgecolor="white",
        alpha=0.82,
        label="Histogram",
    )
    if values.size >= 3 and float(np.std(values, ddof=1)) > 0.0:
        try:
            density = scipy_stats.gaussian_kde(values)
            grid = np.linspace(float(np.min(values)), float(np.max(values)), 300)
            axis.plot(grid, density(grid), color=_COLOR_ORANGE, linewidth=2.2, label="KDE")
            axis.legend(frameon=False)
        except np.linalg.LinAlgError:
            pass
    title = f"Distribution of {column}"
    axis.set_title(title)
    axis.set_xlabel(column)
    axis.set_ylabel("Density")
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        f"histogram_{column}",
        file_format,
        dpi,
        "histogram",
        title,
        "requested",
    )


def _qq_plot(
    plt: Any,
    frame: pd.DataFrame,
    column: str,
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any]:
    values = _numeric_values(frame, column)
    theoretical, ordered = scipy_stats.probplot(values, dist="norm", fit=False)
    slope, intercept, correlation = scipy_stats.probplot(
        values, dist="norm", fit=True
    )[1]
    figure, axis = plt.subplots(figsize=(7, 6))
    axis.scatter(theoretical, ordered, color=_COLOR_BLUE, alpha=0.82, s=34)
    theoretical_array = np.asarray(theoretical, dtype=float)
    axis.plot(
        theoretical_array,
        intercept + slope * theoretical_array,
        color=_COLOR_ORANGE,
        linewidth=2,
        label=f"Normal reference (r={correlation:.3f})",
    )
    title = f"Normal Q–Q plot: {column}"
    axis.set_title(title)
    axis.set_xlabel("Theoretical normal quantiles")
    axis.set_ylabel("Ordered sample values")
    axis.legend(frameon=False)
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        f"qq_{column}",
        file_format,
        dpi,
        "qq",
        title,
        "requested",
    )


def _boxplot(
    plt: Any,
    frame: pd.DataFrame,
    column: str,
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any]:
    values = _numeric_values(frame, column)
    figure, axis = plt.subplots(figsize=(6.5, 6))
    box = axis.boxplot([values], patch_artist=True, widths=0.5)
    box["boxes"][0].set(facecolor=_COLOR_BLUE, alpha=0.72)
    box["medians"][0].set(color=_COLOR_ORANGE, linewidth=2.2)
    axis.set_xticks([1], [column])
    axis.set_ylabel(column)
    title = f"Boxplot of {column}"
    axis.set_title(title)
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        f"boxplot_{column}",
        file_format,
        dpi,
        "boxplot",
        title,
        "requested",
    )


def _grouped_boxplot(
    plt: Any,
    frame: pd.DataFrame,
    outcome: str,
    group: str,
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any]:
    numeric = pd.to_numeric(frame[outcome], errors="coerce")
    mask = np.isfinite(numeric.to_numpy(dtype=float)) & frame[group].notna().to_numpy()
    working = pd.DataFrame({outcome: numeric.loc[mask], group: frame.loc[mask, group]})
    categories = list(pd.unique(working[group]))
    if len(categories) < 2:
        raise DataError("grouped-boxplot requires at least 2 observed groups")
    if len(categories) > 30:
        raise DataError("grouped-boxplot supports at most 30 observed groups")
    samples = [
        working.loc[working[group] == category, outcome].to_numpy(dtype=float)
        for category in categories
    ]
    figure_width = max(8.0, min(18.0, 1.05 * len(categories) + 4.0))
    figure, axis = plt.subplots(figsize=(figure_width, 6))
    box = axis.boxplot(samples, patch_artist=True, widths=0.6)
    for index, patch in enumerate(box["boxes"]):
        patch.set(facecolor=_PALETTE[index % len(_PALETTE)], alpha=0.7)
    for median in box["medians"]:
        median.set(color="#222222", linewidth=2)
    axis.set_xticks(range(1, len(categories) + 1), [str(value) for value in categories])
    axis.tick_params(axis="x", rotation=30)
    axis.set_xlabel(group)
    axis.set_ylabel(outcome)
    title = f"{outcome} by {group}"
    axis.set_title(title)
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        f"grouped_boxplot_{outcome}_by_{group}",
        file_format,
        dpi,
        "grouped-boxplot",
        title,
        "requested",
    )


def _scatter_plot(
    plt: Any,
    frame: pd.DataFrame,
    x_name: str,
    y_name: str,
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any]:
    x_values, y_values = _paired_numeric_values(frame, x_name, y_name)
    figure, axis = plt.subplots(figsize=(8, 6))
    axis.scatter(x_values, y_values, color=_COLOR_BLUE, alpha=0.76, s=42)
    if float(np.ptp(x_values)) > 0.0:
        slope, intercept = np.polyfit(x_values, y_values, 1)
        grid = np.linspace(float(np.min(x_values)), float(np.max(x_values)), 200)
        axis.plot(
            grid,
            intercept + slope * grid,
            color=_COLOR_ORANGE,
            linewidth=2.2,
            label="OLS fitted line",
        )
        axis.legend(frameon=False)
    axis.set_xlabel(x_name)
    axis.set_ylabel(y_name)
    title = f"{y_name} versus {x_name}"
    axis.set_title(title)
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        f"scatter_{y_name}_versus_{x_name}",
        file_format,
        dpi,
        "scatter",
        title,
        "requested",
    )


def _correlation_plot(
    plt: Any,
    frame: pd.DataFrame,
    columns: list[str],
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any]:
    numeric = frame[columns].apply(pd.to_numeric, errors="coerce")
    correlation = numeric.corr(min_periods=2).to_numpy(dtype=float)
    if not np.any(np.isfinite(correlation)):
        raise DataError("correlation plot has no estimable correlations")
    size = max(7.0, min(15.0, 0.75 * len(columns) + 4.0))
    figure, axis = plt.subplots(figsize=(size, size))
    image = axis.imshow(correlation, vmin=-1.0, vmax=1.0, cmap="coolwarm")
    axis.set_xticks(range(len(columns)), columns, rotation=45, ha="right")
    axis.set_yticks(range(len(columns)), columns)
    if len(columns) <= 12:
        for row in range(len(columns)):
            for column in range(len(columns)):
                value = correlation[row, column]
                if np.isfinite(value):
                    axis.text(
                        column,
                        row,
                        f"{value:.2f}",
                        ha="center",
                        va="center",
                        color="white" if abs(value) > 0.55 else "black",
                        fontsize=9,
                    )
    figure.colorbar(image, ax=axis, label="Pearson correlation")
    title = "Correlation heatmap"
    axis.set_title(title)
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        "correlation_heatmap_" + "_".join(columns),
        file_format,
        dpi,
        "correlation",
        title,
        "requested",
    )


def _finite_prediction_rows(
    rows: list[dict[str, Any]], residual_name: str = "residual"
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    values = []
    for row in rows:
        observed = row.get("observed")
        predicted = row.get("predicted")
        residual = row.get(residual_name)
        if residual is None and residual_name != "residual":
            residual = row.get("residual")
        try:
            triplet = (float(observed), float(predicted), float(residual))
        except (TypeError, ValueError):
            continue
        if all(math.isfinite(value) for value in triplet):
            values.append(triplet)
    if len(values) < 3:
        return np.asarray([]), np.asarray([]), np.asarray([])
    array = np.asarray(values, dtype=float)
    return array[:, 0], array[:, 1], array[:, 2]


def _diagnostic_plot(
    plt: Any,
    model: dict[str, Any],
    directory: Path,
    file_format: str,
    dpi: int,
    residual_name: str = "residual",
) -> dict[str, Any] | None:
    observed, predicted, residuals = _finite_prediction_rows(
        model.get("prediction_rows", []), residual_name
    )
    if observed.size < 3:
        return None
    model_name = model.get("model_name") or model.get("method", "Model")
    figure, axes = plt.subplots(1, 3, figsize=(15, 4.8))
    axes[0].scatter(predicted, observed, color=_COLOR_BLUE, alpha=0.72, s=32)
    lower = float(min(np.min(predicted), np.min(observed)))
    upper = float(max(np.max(predicted), np.max(observed)))
    axes[0].plot([lower, upper], [lower, upper], color=_COLOR_ORANGE, linewidth=1.8)
    axes[0].set_xlabel("Predicted")
    axes[0].set_ylabel("Observed")
    axes[0].set_title("Observed versus predicted")

    axes[1].scatter(predicted, residuals, color=_COLOR_GREEN, alpha=0.72, s=32)
    axes[1].axhline(0.0, color=_COLOR_ORANGE, linewidth=1.8)
    axes[1].set_xlabel("Predicted")
    axes[1].set_ylabel("Pearson residual" if residual_name == "pearson_residual" else "Residual")
    axes[1].set_title("Residuals versus fitted")

    theoretical, ordered = scipy_stats.probplot(residuals, dist="norm", fit=False)
    slope, intercept, _ = scipy_stats.probplot(residuals, dist="norm", fit=True)[1]
    theoretical_array = np.asarray(theoretical, dtype=float)
    axes[2].scatter(theoretical_array, ordered, color=_COLOR_PURPLE, alpha=0.75, s=30)
    axes[2].plot(
        theoretical_array,
        intercept + slope * theoretical_array,
        color=_COLOR_ORANGE,
        linewidth=1.8,
    )
    axes[2].set_xlabel("Theoretical normal quantiles")
    axes[2].set_ylabel("Ordered residuals")
    axes[2].set_title("Residual Q–Q plot")

    title = f"Model diagnostics: {model_name}"
    figure.suptitle(title, fontsize=15)
    figure.tight_layout(rect=(0, 0, 1, 0.94))
    return _save_figure(
        plt,
        figure,
        directory,
        f"model_diagnostics_{model_name}",
        file_format,
        dpi,
        "model-diagnostics",
        title,
        "model",
        str(model_name),
    )


def _binary_logistic_plot(
    plt: Any,
    model: dict[str, Any],
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any] | None:
    pairs = []
    for row in model.get("prediction_rows", []):
        try:
            observed = int(row["observed"])
            probability = float(row["predicted"])
        except (KeyError, TypeError, ValueError):
            continue
        if observed in (0, 1) and math.isfinite(probability):
            pairs.append((observed, probability))
    if len(pairs) < 4:
        return None
    array = np.asarray(pairs, dtype=float)
    observed = array[:, 0].astype(int)
    probability = array[:, 1]
    positives = int(np.sum(observed == 1))
    negatives = int(np.sum(observed == 0))
    if not positives or not negatives:
        return None

    order = np.argsort(-probability, kind="mergesort")
    sorted_probability = probability[order]
    sorted_observed = observed[order]
    distinct = np.where(np.diff(sorted_probability))[0]
    threshold_indices = np.r_[distinct, observed.size - 1]
    true_positive = np.cumsum(sorted_observed)[threshold_indices]
    false_positive = 1 + threshold_indices - true_positive
    true_positive_rate = np.r_[0.0, true_positive / positives]
    false_positive_rate = np.r_[0.0, false_positive / negatives]

    bin_count = min(10, len(pairs))
    calibration_groups = np.array_split(np.argsort(probability), bin_count)
    mean_predicted = np.asarray(
        [np.mean(probability[group]) for group in calibration_groups]
    )
    observed_rate = np.asarray(
        [np.mean(observed[group]) for group in calibration_groups]
    )

    model_name = model.get("model_name") or "Binary logistic model"
    figure, axes = plt.subplots(1, 2, figsize=(12, 5.2))
    axes[0].plot(false_positive_rate, true_positive_rate, color=_COLOR_BLUE, linewidth=2.3)
    axes[0].plot([0, 1], [0, 1], color=_COLOR_GRAY, linestyle="--")
    auc = model.get("classification", {}).get("roc_auc")
    axes[0].set_title(
        "ROC curve" + (f" (AUC={auc:.3f})" if isinstance(auc, (int, float)) else "")
    )
    axes[0].set_xlabel("False-positive rate")
    axes[0].set_ylabel("True-positive rate")
    axes[0].set_xlim(0, 1)
    axes[0].set_ylim(0, 1)

    axes[1].plot([0, 1], [0, 1], color=_COLOR_GRAY, linestyle="--", label="Perfect calibration")
    axes[1].plot(mean_predicted, observed_rate, "o-", color=_COLOR_ORANGE, linewidth=2, label="Observed")
    axes[1].set_title("Calibration plot")
    axes[1].set_xlabel("Mean predicted probability")
    axes[1].set_ylabel("Observed event rate")
    axes[1].set_xlim(0, 1)
    axes[1].set_ylim(0, 1)
    axes[1].legend(frameon=False)

    title = f"Binary logistic diagnostics: {model_name}"
    figure.suptitle(title, fontsize=15)
    figure.tight_layout(rect=(0, 0, 1, 0.94))
    return _save_figure(
        plt,
        figure,
        directory,
        f"logistic_roc_calibration_{model_name}",
        file_format,
        dpi,
        "logistic-roc-calibration",
        title,
        "model",
        str(model_name),
    )


def _confusion_matrix_plot(
    plt: Any,
    model: dict[str, Any],
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any] | None:
    classification = model.get("classification", {})
    matrix = np.asarray(classification.get("confusion_matrix", []))
    row_labels = classification.get("row_categories_actual", [])
    column_labels = classification.get("column_categories_predicted", [])
    if matrix.ndim != 2 or matrix.size == 0 or not row_labels or not column_labels:
        return None
    is_discriminant = model.get("analysis_type") == "linear_discriminant_analysis"
    model_name = model.get("model_name") or (
        "Linear discriminant analysis"
        if is_discriminant
        else "Multinomial logistic model"
    )
    size = max(6.0, min(12.0, 0.8 * len(row_labels) + 4.0))
    figure, axis = plt.subplots(figsize=(size, size))
    image = axis.imshow(matrix, cmap="Blues")
    axis.set_xticks(range(len(column_labels)), column_labels, rotation=35, ha="right")
    axis.set_yticks(range(len(row_labels)), row_labels)
    axis.set_xlabel("Predicted category")
    axis.set_ylabel("Actual category")
    maximum = float(np.max(matrix)) if matrix.size else 0.0
    for row in range(matrix.shape[0]):
        for column in range(matrix.shape[1]):
            axis.text(
                column,
                row,
                str(int(matrix[row, column])),
                ha="center",
                va="center",
                color="white" if maximum and matrix[row, column] > maximum / 2 else "black",
            )
    figure.colorbar(image, ax=axis, label="Observations")
    title = (
        f"Discriminant confusion matrix: {model_name}"
        if is_discriminant
        else f"Multinomial confusion matrix: {model_name}"
    )
    axis.set_title(title)
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        (
            f"discriminant_confusion_matrix_{model_name}"
            if is_discriminant
            else f"multinomial_confusion_matrix_{model_name}"
        ),
        file_format,
        dpi,
        (
            "discriminant-confusion-matrix"
            if is_discriminant
            else "multinomial-confusion-matrix"
        ),
        title,
        "model",
        str(model_name),
    )


def _pca_scree_plot(
    plt: Any,
    analysis: dict[str, Any],
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any] | None:
    components = analysis.get("components", [])
    if not components:
        return None
    labels = [component["component"] for component in components]
    explained = np.asarray(
        [component["explained_variance_ratio"] for component in components]
    )
    cumulative = np.cumsum(explained)
    positions = np.arange(len(labels))
    figure, axis = plt.subplots(figsize=(9, 5.6))
    axis.bar(positions, explained * 100.0, color=_COLOR_BLUE, alpha=0.78)
    axis.plot(
        positions,
        cumulative * 100.0,
        color=_COLOR_ORANGE,
        marker="o",
        linewidth=2.0,
        label="Cumulative",
    )
    axis.set_xticks(positions, labels, rotation=30, ha="right")
    axis.set_ylabel("Explained variance (%)")
    axis.set_ylim(0.0, 105.0)
    axis.legend(frameon=False)
    name = analysis.get("analysis_name", "PCA")
    title = f"PCA scree plot: {name}"
    axis.set_title(title)
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        f"pca_scree_{name}",
        file_format,
        dpi,
        "pca-scree",
        title,
        "model",
        str(name),
    )


def _pca_score_plot(
    plt: Any,
    analysis: dict[str, Any],
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any] | None:
    rows = analysis.get("score_rows", [])
    components = analysis.get("components", [])
    if not rows or analysis.get("retained_component_count", 0) < 2:
        return None
    x = np.asarray([row["PC1"] for row in rows], dtype=float)
    y = np.asarray([row["PC2"] for row in rows], dtype=float)
    x_percent = 100.0 * components[0]["explained_variance_ratio"]
    y_percent = 100.0 * components[1]["explained_variance_ratio"]
    figure, axis = plt.subplots(figsize=(8, 6.2))
    axis.scatter(x, y, color=_COLOR_BLUE, alpha=0.72, edgecolor="white", linewidth=0.4)
    axis.axhline(0.0, color=_COLOR_GRAY, linewidth=0.8)
    axis.axvline(0.0, color=_COLOR_GRAY, linewidth=0.8)
    axis.set_xlabel(f"PC1 ({x_percent:.1f}%)")
    axis.set_ylabel(f"PC2 ({y_percent:.1f}%)")
    name = analysis.get("analysis_name", "PCA")
    title = f"PCA score plot: {name}"
    axis.set_title(title)
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        f"pca_scores_{name}",
        file_format,
        dpi,
        "pca-scores",
        title,
        "model",
        str(name),
    )


def _manova_profile_plot(
    plt: Any,
    analysis: dict[str, Any],
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any] | None:
    responses = analysis.get("response_variables", [])
    summaries = analysis.get("group_summaries", [])
    error = np.asarray(analysis.get("error_sscp", []), dtype=float)
    error_df = analysis.get("error_degrees_of_freedom", 0)
    if not responses or not summaries or error.shape != (len(responses), len(responses)):
        return None
    pooled_sds = np.sqrt(np.maximum(np.diag(error) / error_df, np.finfo(float).eps))
    grand = np.asarray([analysis["grand_means"][name] for name in responses])
    positions = np.arange(len(responses))
    figure, axis = plt.subplots(figsize=(max(8.5, 1.1 * len(responses)), 5.8))
    for index, summary in enumerate(summaries):
        means = np.asarray([summary["means"][name] for name in responses])
        standardized = (means - grand) / pooled_sds
        axis.plot(
            positions,
            standardized,
            marker="o",
            linewidth=2.0,
            color=_PALETTE[index % len(_PALETTE)],
            label=str(summary["group"]),
        )
    axis.axhline(0.0, color=_COLOR_GRAY, linewidth=0.9)
    axis.set_xticks(positions, responses, rotation=30, ha="right")
    axis.set_ylabel("Group mean deviation (pooled SD units)")
    axis.legend(title=analysis.get("group_variable"), frameon=False)
    name = analysis.get("analysis_name", "MANOVA")
    title = f"MANOVA group mean profiles: {name}"
    axis.set_title(title)
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        f"manova_profiles_{name}",
        file_format,
        dpi,
        "manova-group-profiles",
        title,
        "model",
        str(name),
    )


def _discriminant_score_plot(
    plt: Any,
    analysis: dict[str, Any],
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any] | None:
    rows = analysis.get("score_rows", [])
    dimensions = analysis.get("canonical_dimensions", [])
    if not rows or not dimensions:
        return None
    classes = analysis.get("class_labels", [])
    figure, axis = plt.subplots(figsize=(8.5, 6.2))
    for index, label in enumerate(classes):
        class_rows = [row for row in rows if row["observed_class"] == label]
        x = np.asarray([row["LD1"] for row in class_rows], dtype=float)
        if len(dimensions) >= 2:
            y = np.asarray([row["LD2"] for row in class_rows], dtype=float)
        else:
            y = np.full(x.shape, index, dtype=float)
        axis.scatter(
            x,
            y,
            alpha=0.76,
            edgecolor="white",
            linewidth=0.4,
            color=_PALETTE[index % len(_PALETTE)],
            label=str(label),
        )
    axis.set_xlabel("LD1")
    if len(dimensions) >= 2:
        axis.set_ylabel("LD2")
    else:
        axis.set_yticks(range(len(classes)), classes)
        axis.set_ylabel("Observed class")
    axis.legend(title=analysis.get("class_variable"), frameon=False)
    name = analysis.get("analysis_name", "LDA")
    title = f"Canonical discriminant scores: {name}"
    axis.set_title(title)
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        f"discriminant_scores_{name}",
        file_format,
        dpi,
        "discriminant-scores",
        title,
        "model",
        str(name),
    )


def _factorial_interaction_plot(
    plt: Any,
    model: dict[str, Any],
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any] | None:
    marginal = model.get("estimated_marginal_means", {})
    cells = marginal.get("cell_marginal_means", [])
    if not cells:
        return None
    first = model["factor_1"]
    second = model["factor_2"]
    first_levels = model["factor_levels"][first]
    second_levels = model["factor_levels"][second]
    lookup = {(cell[first], cell[second]): cell for cell in cells}
    model_name = model.get("model_name") or "Factorial model"
    figure, axis = plt.subplots(figsize=(9, 6))
    positions = np.arange(len(second_levels))
    for index, first_level in enumerate(first_levels):
        estimates = []
        errors = []
        for second_level in second_levels:
            cell = lookup.get((first_level, second_level))
            if not cell or cell.get("estimate") is None:
                estimates.append(np.nan)
                errors.append(np.nan)
                continue
            estimate = float(cell["estimate"])
            interval = cell.get("confidence_interval", [estimate, estimate])
            estimates.append(estimate)
            errors.append(max(0.0, float(interval[1]) - estimate))
        axis.errorbar(
            positions,
            estimates,
            yerr=errors,
            marker="o",
            markersize=6,
            linewidth=2,
            capsize=4,
            color=_PALETTE[index % len(_PALETTE)],
            label=f"{first}={first_level}",
        )
    axis.set_xticks(positions, second_levels)
    axis.set_xlabel(second)
    axis.set_ylabel(f"Estimated marginal mean of {model['outcome_variable']}")
    axis.legend(frameon=False, title=first)
    title = f"Interaction plot: {first} × {second}"
    axis.set_title(title)
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        f"factorial_interaction_{model_name}",
        file_format,
        dpi,
        "factorial-interaction",
        title,
        "model",
        str(model_name),
    )


def _repeated_measures_plot(
    plt: Any,
    model: dict[str, Any],
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any] | None:
    rows = model.get("prediction_rows", [])
    levels = model.get("factor_levels", [])
    if not rows or len(levels) < 2:
        return None
    position = {str(level): index for index, level in enumerate(levels)}
    subjects: dict[str, dict[str, float]] = {}
    for row in rows:
        subject = str(row.get("subject"))
        level = str(row.get("within_level"))
        observed = row.get("observed")
        if level in position and observed is not None:
            subjects.setdefault(subject, {})[level] = float(observed)
    model_name = model.get("model_name") or "Repeated-measures model"
    figure, axis = plt.subplots(figsize=(9.5, 6))
    x_values = np.arange(len(levels))
    for subject_values in list(subjects.values())[:60]:
        y_values = [subject_values.get(str(level), np.nan) for level in levels]
        axis.plot(x_values, y_values, color="#A6A6A6", alpha=0.35, linewidth=1)
    means = model.get("estimated_marginal_means", [])
    mean_lookup = {str(item["level"]): item for item in means}
    estimates = [float(mean_lookup[str(level)]["estimate"]) for level in levels]
    lower = [float(mean_lookup[str(level)]["confidence_interval"][0]) for level in levels]
    upper = [float(mean_lookup[str(level)]["confidence_interval"][1]) for level in levels]
    errors = np.asarray([np.asarray(estimates) - lower, np.asarray(upper) - estimates])
    axis.errorbar(
        x_values,
        estimates,
        yerr=errors,
        color=_COLOR_BLUE,
        marker="o",
        markersize=7,
        linewidth=2.6,
        capsize=4,
        label="Estimated marginal mean",
    )
    axis.set_xticks(x_values, levels)
    axis.set_xlabel(model["within_subject_factor"])
    axis.set_ylabel(model["outcome_variable"])
    axis.legend(frameon=False)
    title = f"Repeated-measures profiles: {model_name}"
    axis.set_title(title)
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        f"repeated_measures_profiles_{model_name}",
        file_format,
        dpi,
        "repeated-measures-profiles",
        title,
        "model",
        str(model_name),
    )


def _mixed_trajectory_plot(
    plt: Any,
    frame: pd.DataFrame,
    model: dict[str, Any],
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any] | None:
    group_name = model.get("group_variable")
    outcome_name = model.get("outcome_variable")
    if group_name not in frame or outcome_name not in frame:
        return None
    x_name = None
    x_numeric = None
    for predictor in model.get("predictors", []):
        candidate = pd.to_numeric(frame[predictor], errors="coerce")
        finite = candidate[np.isfinite(candidate.to_numpy(dtype=float))]
        if finite.nunique() >= 2:
            x_name = predictor
            x_numeric = candidate
            break
    if x_name is None or x_numeric is None:
        return None
    outcome = pd.to_numeric(frame[outcome_name], errors="coerce")
    mask = (
        np.isfinite(x_numeric.to_numpy(dtype=float))
        & np.isfinite(outcome.to_numpy(dtype=float))
        & frame[group_name].notna().to_numpy()
    )
    working = pd.DataFrame(
        {
            "x": x_numeric.loc[mask],
            "y": outcome.loc[mask],
            "group": frame.loc[mask, group_name],
        }
    )
    if working.empty:
        return None
    model_name = model.get("model_name") or "Mixed-effects model"
    figure, axis = plt.subplots(figsize=(9.5, 6))
    group_values = list(pd.unique(working["group"]))
    for index, group in enumerate(group_values[:60]):
        group_frame = working.loc[working["group"] == group].sort_values("x")
        axis.plot(
            group_frame["x"],
            group_frame["y"],
            marker="o",
            markersize=3.5,
            linewidth=1,
            alpha=0.42,
            color=_PALETTE[index % len(_PALETTE)],
        )
    axis.set_xlabel(x_name)
    axis.set_ylabel(outcome_name)
    title = f"Group trajectories: {outcome_name} over {x_name}"
    axis.set_title(title)
    if len(group_values) > 60:
        axis.text(
            0.01,
            0.01,
            "First 60 groups shown",
            transform=axis.transAxes,
            fontsize=9,
            color=_COLOR_GRAY,
        )
    figure.tight_layout()
    return _save_figure(
        plt,
        figure,
        directory,
        f"mixed_group_trajectories_{model_name}",
        file_format,
        dpi,
        "mixed-group-trajectories",
        title,
        "model",
        str(model_name),
    )


def _requested_plot(
    plt: Any,
    frame: pd.DataFrame,
    request: dict[str, Any],
    directory: Path,
    file_format: str,
    dpi: int,
) -> dict[str, Any]:
    plot_type = request["plot_type"]
    columns = request["columns"]
    if plot_type == "histogram":
        return _histogram(plt, frame, columns[0], directory, file_format, dpi)
    if plot_type == "qq":
        return _qq_plot(plt, frame, columns[0], directory, file_format, dpi)
    if plot_type == "boxplot":
        return _boxplot(plt, frame, columns[0], directory, file_format, dpi)
    if plot_type == "grouped-boxplot":
        return _grouped_boxplot(
            plt, frame, columns[0], columns[1], directory, file_format, dpi
        )
    if plot_type == "scatter":
        return _scatter_plot(
            plt, frame, columns[0], columns[1], directory, file_format, dpi
        )
    return _correlation_plot(
        plt, frame, columns, directory, file_format, dpi
    )


def _model_plots(
    plt: Any,
    frame: pd.DataFrame,
    results: dict[str, Any],
    directory: Path,
    file_format: str,
    dpi: int,
) -> list[dict[str, Any]]:
    generated: list[dict[str, Any]] = []

    def add(plot: dict[str, Any] | None) -> None:
        if plot is not None:
            generated.append(plot)

    for key in (
        "regression_analyses",
        "multiple_regression_analyses",
        "robust_regression_analyses",
        "regularized_regression_analyses",
        "regression_spline_analyses",
        "smoothing_spline_analyses",
        "loess_analyses",
        "kernel_regression_analyses",
        "isotonic_regression_analyses",
    ):
        for model in results.get(key, []):
            if model.get("status") in {"completed", "completed_with_warnings"}:
                add(_diagnostic_plot(plt, model, directory, file_format, dpi))
    for model in results.get("binary_logistic_regression_analyses", []):
        if model.get("status") == "completed":
            add(_binary_logistic_plot(plt, model, directory, file_format, dpi))
    for model in results.get("multinomial_logistic_regression_analyses", []):
        if model.get("status") == "completed":
            add(_confusion_matrix_plot(plt, model, directory, file_format, dpi))
    for key in (
        "poisson_regression_analyses",
        "negative_binomial_regression_analyses",
    ):
        for model in results.get(key, []):
            if model.get("status") == "completed":
                add(
                    _diagnostic_plot(
                        plt,
                        model,
                        directory,
                        file_format,
                        dpi,
                        "pearson_residual",
                    )
                )
    for model in results.get("factorial_analyses", []):
        if model.get("status") == "completed":
            add(_factorial_interaction_plot(plt, model, directory, file_format, dpi))
            add(_diagnostic_plot(plt, model, directory, file_format, dpi))
    for model in results.get("repeated_measures_analyses", []):
        if model.get("status") == "completed":
            add(_repeated_measures_plot(plt, model, directory, file_format, dpi))
    for model in results.get("mixed_effects_analyses", []):
        if model.get("status") == "completed":
            add(_diagnostic_plot(plt, model, directory, file_format, dpi))
            add(_mixed_trajectory_plot(plt, frame, model, directory, file_format, dpi))
    for analysis in results.get("principal_component_analyses", []):
        if analysis.get("status") == "completed":
            add(_pca_scree_plot(plt, analysis, directory, file_format, dpi))
            add(_pca_score_plot(plt, analysis, directory, file_format, dpi))
    for analysis in results.get("manova_analyses", []):
        if analysis.get("status") == "completed":
            add(_manova_profile_plot(plt, analysis, directory, file_format, dpi))
    for analysis in results.get("discriminant_analyses", []):
        if analysis.get("status") == "completed":
            add(_confusion_matrix_plot(plt, analysis, directory, file_format, dpi))
            add(
                _discriminant_score_plot(
                    plt, analysis, directory, file_format, dpi
                )
            )
    return generated


def generate_plots(
    frame: pd.DataFrame,
    results: dict[str, Any],
    requests: list[dict[str, Any]],
    model_plots: bool,
    output_directory: Path,
    file_format: str,
    dpi: int,
) -> list[dict[str, Any]]:
    """Generate requested and model-aware plots and return their metadata."""
    if not requests and not model_plots:
        return []
    if output_directory.exists() and not output_directory.is_dir():
        raise DataError(f"plot output path is not a directory: {output_directory}")
    output_directory.mkdir(parents=True, exist_ok=True)
    output_directory = output_directory.resolve()
    plt = _load_pyplot()
    generated = [
        _requested_plot(
            plt, frame, request, output_directory, file_format, dpi
        )
        for request in requests
    ]
    if model_plots:
        model_generated = _model_plots(
            plt, frame, results, output_directory, file_format, dpi
        )
        if not model_generated:
            raise DataError(
                "--model-plots requires at least one successfully fitted supported model"
            )
        generated.extend(model_generated)
    return generated


def _bayesian_density_plot(
    plt: Any,
    x_values: np.ndarray,
    prior_density: np.ndarray,
    posterior_density: np.ndarray,
    title: str,
    x_label: str,
    directory: Path,
    stem: str,
    file_format: str,
    dpi: int,
    model_name: str,
) -> dict[str, Any]:
    """Create one prior-versus-posterior density comparison."""
    prior_density = np.asarray(prior_density, dtype=float)
    posterior_density = np.asarray(posterior_density, dtype=float)
    finite = np.concatenate(
        [prior_density[np.isfinite(prior_density)], posterior_density[np.isfinite(posterior_density)]]
    )
    ceiling = float(np.quantile(finite, 0.995)) if finite.size else 1.0
    ceiling = max(ceiling, np.finfo(float).eps)
    prior_density = np.nan_to_num(
        prior_density, nan=0.0, posinf=ceiling, neginf=0.0
    )
    posterior_density = np.nan_to_num(
        posterior_density, nan=0.0, posinf=ceiling, neginf=0.0
    )

    figure, axis = plt.subplots(figsize=(8.4, 5.2))
    axis.plot(
        x_values,
        prior_density,
        color=_COLOR_GRAY,
        linewidth=2.0,
        linestyle="--",
        label="Prior",
    )
    axis.plot(
        x_values,
        posterior_density,
        color=_COLOR_BLUE,
        linewidth=2.4,
        label="Posterior",
    )
    axis.fill_between(
        x_values,
        0.0,
        posterior_density,
        color=_COLOR_BLUE,
        alpha=0.14,
    )
    axis.set_title(title)
    axis.set_xlabel(x_label)
    axis.set_ylabel("Density")
    axis.set_ylim(bottom=0.0)
    axis.legend()
    return _save_figure(
        plt,
        figure,
        directory,
        stem,
        file_format,
        dpi,
        "bayesian-prior-posterior",
        title,
        "Bayesian conjugate analysis",
        model_name,
    )


def generate_bayesian_plots(
    analyses: list[dict[str, Any]],
    output_directory: Path,
    file_format: str,
    dpi: int,
) -> list[dict[str, Any]]:
    """Save prior-versus-posterior density plots for conjugate models."""
    completed = [
        analysis for analysis in analyses if analysis.get("status") == "completed"
    ]
    if not completed:
        raise DataError("--bayes-plots requires a completed Bayesian analysis")
    if output_directory.exists() and not output_directory.is_dir():
        raise DataError(f"plot output path is not a directory: {output_directory}")
    output_directory.mkdir(parents=True, exist_ok=True)
    directory = output_directory.resolve()
    plt = _load_pyplot()
    generated: list[dict[str, Any]] = []

    for index, analysis in enumerate(completed, start=1):
        model = analysis["model"]
        prior = analysis["prior"]
        posterior = analysis["posterior"]
        prefix = f"bayesian_{index}_{model}"
        if model == "beta-binomial":
            x_values = np.linspace(0.001, 0.999, 700)
            generated.append(
                _bayesian_density_plot(
                    plt,
                    x_values,
                    scipy_stats.beta.pdf(
                        x_values, prior["alpha"], prior["beta"]
                    ),
                    scipy_stats.beta.pdf(
                        x_values, posterior["alpha"], posterior["beta"]
                    ),
                    "Beta-binomial prior and posterior for p",
                    "Probability p",
                    directory,
                    prefix,
                    file_format,
                    dpi,
                    model,
                )
            )
        elif model == "gamma-poisson":
            prior_distribution = scipy_stats.gamma(
                a=prior["shape"], scale=1.0 / prior["rate"]
            )
            posterior_distribution = scipy_stats.gamma(
                a=posterior["shape"], scale=1.0 / posterior["rate"]
            )
            upper = max(
                float(prior_distribution.ppf(0.997)),
                float(posterior_distribution.ppf(0.997)),
            )
            x_values = np.linspace(max(upper / 10000.0, 1e-10), upper, 700)
            generated.append(
                _bayesian_density_plot(
                    plt,
                    x_values,
                    prior_distribution.pdf(x_values),
                    posterior_distribution.pdf(x_values),
                    "Gamma-Poisson prior and posterior for event rate",
                    "Event rate",
                    directory,
                    prefix,
                    file_format,
                    dpi,
                    model,
                )
            )
        elif model == "normal-normal-known-variance":
            prior_distribution = scipy_stats.norm(
                loc=prior["mean"], scale=prior["standard_deviation"]
            )
            posterior_distribution = scipy_stats.norm(
                loc=posterior["mean"], scale=posterior["standard_deviation"]
            )
            lower = min(
                float(prior_distribution.ppf(0.001)),
                float(posterior_distribution.ppf(0.001)),
            )
            upper = max(
                float(prior_distribution.ppf(0.999)),
                float(posterior_distribution.ppf(0.999)),
            )
            x_values = np.linspace(lower, upper, 700)
            generated.append(
                _bayesian_density_plot(
                    plt,
                    x_values,
                    prior_distribution.pdf(x_values),
                    posterior_distribution.pdf(x_values),
                    "Normal prior and posterior for population mean",
                    "Population mean",
                    directory,
                    prefix,
                    file_format,
                    dpi,
                    model,
                )
            )
        else:
            prior_mu = scipy_stats.t(
                df=prior["marginal_mu_degrees_of_freedom"],
                loc=prior["mu"],
                scale=prior["marginal_mu_scale"],
            )
            posterior_mu = scipy_stats.t(
                df=posterior["marginal_mu_degrees_of_freedom"],
                loc=posterior["mu"],
                scale=posterior["marginal_mu_scale"],
            )
            lower = min(float(prior_mu.ppf(0.001)), float(posterior_mu.ppf(0.001)))
            upper = max(float(prior_mu.ppf(0.999)), float(posterior_mu.ppf(0.999)))
            x_values = np.linspace(lower, upper, 700)
            generated.append(
                _bayesian_density_plot(
                    plt,
                    x_values,
                    prior_mu.pdf(x_values),
                    posterior_mu.pdf(x_values),
                    "Normal-inverse-gamma marginal prior and posterior for mean",
                    "Population mean",
                    directory,
                    f"{prefix}_mean",
                    file_format,
                    dpi,
                    model,
                )
            )

            prior_variance = scipy_stats.invgamma(
                a=prior["alpha"], scale=prior["beta"]
            )
            posterior_variance = scipy_stats.invgamma(
                a=posterior["alpha"], scale=posterior["beta"]
            )
            lower = max(
                min(
                    float(prior_variance.ppf(0.001)),
                    float(posterior_variance.ppf(0.001)),
                ),
                1e-12,
            )
            upper = max(
                float(prior_variance.ppf(0.997)),
                float(posterior_variance.ppf(0.997)),
            )
            variance_values = np.linspace(lower, upper, 700)
            generated.append(
                _bayesian_density_plot(
                    plt,
                    variance_values,
                    prior_variance.pdf(variance_values),
                    posterior_variance.pdf(variance_values),
                    "Normal-inverse-gamma prior and posterior for variance",
                    "Population variance",
                    directory,
                    f"{prefix}_variance",
                    file_format,
                    dpi,
                    model,
                )
            )
    return generated
