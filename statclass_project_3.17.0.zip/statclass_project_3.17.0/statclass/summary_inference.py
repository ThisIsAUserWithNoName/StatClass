"""Parametric inference from sufficient summary statistics."""

from __future__ import annotations

import math
from typing import Any

from scipy import stats as scipy_stats

from .utils import decision_from_pvalue, finite_or_none, format_number


def _p_value(statistic: float, distribution: Any, alternative: str) -> float:
    if alternative == "two-sided":
        return float(2.0 * distribution.sf(abs(statistic)))
    if alternative == "less":
        return float(distribution.cdf(statistic))
    return float(distribution.sf(statistic))


def one_sample_summary_t_test(
    n: int,
    sample_mean: float,
    sample_standard_deviation: float,
    hypothesized_mean: float,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    """One-sample t inference from n, sample mean, and sample SD."""
    result: dict[str, Any] = {
        "method": "one-sample t-test from summary statistics",
        "source": "summary_statistics",
        "n": n,
        "sample_mean": sample_mean,
        "sample_standard_deviation": sample_standard_deviation,
        "hypothesized_mean": hypothesized_mean,
        "alternative": alternative,
    }
    if n < 2:
        result.update(status="not_run", reason="requires n of at least 2")
        return result
    if sample_standard_deviation <= 0.0:
        result.update(status="not_run", reason="sample standard deviation must be positive")
        return result

    degrees_of_freedom = n - 1
    standard_error = sample_standard_deviation / math.sqrt(n)
    mean_difference = sample_mean - hypothesized_mean
    statistic = mean_difference / standard_error
    distribution = scipy_stats.t(df=degrees_of_freedom)
    p_value = _p_value(statistic, distribution, alternative)
    critical = float(distribution.ppf(1.0 - alpha / 2.0))
    margin = critical * standard_error
    result.update(
        {
            "status": "completed",
            "null_hypothesis": f"mean = {format_number(hypothesized_mean)}",
            "mean_difference": mean_difference,
            "standard_error": standard_error,
            "statistic": finite_or_none(statistic),
            "degrees_of_freedom": degrees_of_freedom,
            "p_value": finite_or_none(p_value),
            "confidence_level": 1.0 - alpha,
            "two_sided_confidence_interval_for_mean": [
                sample_mean - margin,
                sample_mean + margin,
            ],
            "cohens_d": mean_difference / sample_standard_deviation,
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result


def one_sample_summary_z_test(
    n: int,
    sample_mean: float,
    population_standard_deviation: float,
    hypothesized_mean: float,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    """Population-mean z inference from n, mean, and known population SD."""
    result: dict[str, Any] = {
        "method": "population-mean z-test from summary statistics",
        "source": "summary_statistics",
        "n": n,
        "sample_mean": sample_mean,
        "population_standard_deviation": population_standard_deviation,
        "hypothesized_mean": hypothesized_mean,
        "alternative": alternative,
    }
    if n < 1:
        result.update(status="not_run", reason="requires n of at least 1")
        return result
    if population_standard_deviation <= 0.0:
        result.update(
            status="not_run",
            reason="population standard deviation must be positive",
        )
        return result

    standard_error = population_standard_deviation / math.sqrt(n)
    mean_difference = sample_mean - hypothesized_mean
    statistic = mean_difference / standard_error
    p_value = _p_value(statistic, scipy_stats.norm, alternative)
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    margin = critical * standard_error
    result.update(
        {
            "status": "completed",
            "null_hypothesis": f"mean = {format_number(hypothesized_mean)}",
            "mean_difference": mean_difference,
            "standard_error": standard_error,
            "z_score": finite_or_none(statistic),
            "p_value": finite_or_none(p_value),
            "confidence_level": 1.0 - alpha,
            "two_sided_confidence_interval_for_mean": [
                sample_mean - margin,
                sample_mean + margin,
            ],
            "standardized_difference": (
                mean_difference / population_standard_deviation
            ),
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result


def two_sample_summary_t_test(
    n_1: int,
    mean_1: float,
    standard_deviation_1: float,
    n_2: int,
    mean_2: float,
    standard_deviation_2: float,
    equal_variance: bool,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    """Independent two-sample t inference from group summaries."""
    method = (
        "Student independent t-test from summary statistics"
        if equal_variance
        else "Welch independent t-test from summary statistics"
    )
    result: dict[str, Any] = {
        "method": method,
        "source": "summary_statistics",
        "n_1": n_1,
        "mean_1": mean_1,
        "standard_deviation_1": standard_deviation_1,
        "n_2": n_2,
        "mean_2": mean_2,
        "standard_deviation_2": standard_deviation_2,
        "equal_variance": equal_variance,
        "alternative": alternative,
    }
    if n_1 < 2 or n_2 < 2:
        result.update(status="not_run", reason="each sample requires n of at least 2")
        return result
    if standard_deviation_1 <= 0.0 or standard_deviation_2 <= 0.0:
        result.update(
            status="not_run",
            reason="both sample standard deviations must be positive",
        )
        return result

    variance_1 = standard_deviation_1**2
    variance_2 = standard_deviation_2**2
    mean_difference = mean_1 - mean_2
    pooled_df = n_1 + n_2 - 2
    pooled_variance = (
        (n_1 - 1) * variance_1 + (n_2 - 1) * variance_2
    ) / pooled_df
    if equal_variance:
        degrees_of_freedom: float = float(pooled_df)
        standard_error = math.sqrt(
            pooled_variance * (1.0 / n_1 + 1.0 / n_2)
        )
    else:
        term_1 = variance_1 / n_1
        term_2 = variance_2 / n_2
        standard_error = math.sqrt(term_1 + term_2)
        degrees_of_freedom = (term_1 + term_2) ** 2 / (
            term_1**2 / (n_1 - 1) + term_2**2 / (n_2 - 1)
        )

    statistic = mean_difference / standard_error
    distribution = scipy_stats.t(df=degrees_of_freedom)
    p_value = _p_value(statistic, distribution, alternative)
    critical = float(distribution.ppf(1.0 - alpha / 2.0))
    margin = critical * standard_error
    pooled_standard_deviation = math.sqrt(pooled_variance)
    cohens_d = mean_difference / pooled_standard_deviation
    correction = 1.0 - 3.0 / (4.0 * pooled_df - 1.0)
    result.update(
        {
            "status": "completed",
            "null_hypothesis": "mean_1 = mean_2",
            "mean_difference": mean_difference,
            "standard_error": standard_error,
            "statistic": finite_or_none(statistic),
            "degrees_of_freedom": finite_or_none(degrees_of_freedom),
            "p_value": finite_or_none(p_value),
            "confidence_level": 1.0 - alpha,
            "two_sided_confidence_interval_for_mean_difference": [
                mean_difference - margin,
                mean_difference + margin,
            ],
            "cohens_d": finite_or_none(cohens_d),
            "hedges_g": finite_or_none(cohens_d * correction),
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result


def paired_summary_t_test(
    n_pairs: int,
    mean_difference: float,
    standard_deviation_of_differences: float,
    hypothesized_difference: float,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    """Paired t inference from a summary of the pairwise differences."""
    result: dict[str, Any] = {
        "method": "paired-sample t-test from difference summaries",
        "source": "summary_statistics",
        "n_pairs": n_pairs,
        "mean_difference": mean_difference,
        "standard_deviation_of_differences": standard_deviation_of_differences,
        "hypothesized_difference": hypothesized_difference,
        "alternative": alternative,
    }
    if n_pairs < 2:
        result.update(status="not_run", reason="requires at least 2 pairs")
        return result
    if standard_deviation_of_differences <= 0.0:
        result.update(
            status="not_run",
            reason="standard deviation of differences must be positive",
        )
        return result

    degrees_of_freedom = n_pairs - 1
    standard_error = standard_deviation_of_differences / math.sqrt(n_pairs)
    difference_from_null = mean_difference - hypothesized_difference
    statistic = difference_from_null / standard_error
    distribution = scipy_stats.t(df=degrees_of_freedom)
    p_value = _p_value(statistic, distribution, alternative)
    critical = float(distribution.ppf(1.0 - alpha / 2.0))
    margin = critical * standard_error
    result.update(
        {
            "status": "completed",
            "null_hypothesis": (
                f"mean paired difference = {format_number(hypothesized_difference)}"
            ),
            "mean_difference_from_null": difference_from_null,
            "standard_error": standard_error,
            "statistic": finite_or_none(statistic),
            "degrees_of_freedom": degrees_of_freedom,
            "p_value": finite_or_none(p_value),
            "confidence_level": 1.0 - alpha,
            "two_sided_confidence_interval_for_mean_difference": [
                mean_difference - margin,
                mean_difference + margin,
            ],
            "cohens_dz": (
                difference_from_null / standard_deviation_of_differences
            ),
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result
