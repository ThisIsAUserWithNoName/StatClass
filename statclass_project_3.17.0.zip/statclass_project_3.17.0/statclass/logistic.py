"""Binary and multinomial logistic regression."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd
from scipy import optimize as scipy_optimize
from scipy import special as scipy_special
from scipy import stats as scipy_stats

from .design_terms import add_engineered_terms
from .multiple_regression import _variance_inflation_factors
from .numerical import (
    NumericalComputationError,
    covariance_from_information,
    optimizer_convergence_diagnostics,
    statistical_numerical_status,
)
from .proportions import category_matches
from .utils import decision_from_pvalue, finite_or_none


def _prepare_design(
    frame: pd.DataFrame,
    outcome_name: str,
    predictor_names: list[str],
    categorical_predictors: set[str],
    polynomial_terms: dict[str, int] | None = None,
    interactions: list[tuple[str, str]] | None = None,
) -> dict[str, Any]:
    mask = frame[outcome_name].notna().to_numpy()
    numeric_values: dict[str, np.ndarray] = {}
    for name in predictor_names:
        if name in categorical_predictors:
            mask &= frame[name].notna().to_numpy()
        else:
            values = pd.to_numeric(frame[name], errors="coerce").to_numpy(
                dtype=float
            )
            numeric_values[name] = values
            mask &= np.isfinite(values)

    complete = frame.loc[mask]
    outcome = complete[outcome_name].to_numpy()
    columns = [np.ones(len(complete), dtype=float)]
    terms = ["Intercept"]
    term_predictors: list[str | None] = [None]
    term_types = ["intercept"]
    categorical_codings: list[dict[str, Any]] = []
    predictor_components: dict[str, list[int]] = {}
    invalid_reason = None
    for name in predictor_names:
        if name not in categorical_predictors:
            component_index = len(columns)
            columns.append(numeric_values[name][mask])
            terms.append(name)
            term_predictors.append(name)
            term_types.append("numeric")
            predictor_components[name] = [component_index]
            continue

        values = complete[name]
        categories = list(pd.unique(values))
        if len(categories) < 2:
            invalid_reason = (
                f"categorical predictor {name!r} has fewer than 2 observed "
                "categories among complete cases"
            )
            break
        reference = categories[0]
        dummy_terms = []
        component_indices = []
        for category in categories[1:]:
            term = f"{name}[T.{category}]"
            component_indices.append(len(columns))
            columns.append((values == category).to_numpy(dtype=float))
            terms.append(term)
            term_predictors.append(name)
            term_types.append("categorical_dummy")
            dummy_terms.append(term)
        predictor_components[name] = component_indices
        categorical_codings.append(
            {
                "predictor": name,
                "reference_category": str(reference),
                "categories": [str(category) for category in categories],
                "dummy_terms": dummy_terms,
            }
        )
    engineered = add_engineered_terms(
        columns,
        terms,
        term_predictors,
        term_types,
        predictor_components,
        categorical_predictors,
        polynomial_terms,
        interactions,
    )
    design = (
        np.column_stack(columns)
        if len(complete)
        else np.empty((0, len(columns)), dtype=float)
    )
    return {
        "mask": mask,
        "complete_frame": complete,
        "outcome": outcome,
        "design": design,
        "terms": terms,
        "term_predictors": term_predictors,
        "term_types": term_types,
        "categorical_codings": categorical_codings,
        "polynomial_terms": engineered["polynomial_terms"],
        "interactions": engineered["interactions"],
        "invalid_reason": invalid_reason,
    }


def _match_requested_category(
    categories: list[Any], requested: str | None
) -> Any | None:
    if requested is None:
        return None
    for category in categories:
        if category_matches(category, requested):
            return category
    return None


def _condition_number(design: np.ndarray) -> float:
    standardized = design[:, 1:].copy()
    standardized -= np.mean(standardized, axis=0)
    standardized /= np.std(standardized, axis=0, ddof=1)
    return float(np.linalg.cond(standardized))


def _safe_exp(value: float) -> float | None:
    if value > 709:
        return None
    if value < -745:
        return 0.0
    return finite_or_none(math.exp(value))


def _binary_classification(
    response: np.ndarray,
    probabilities: np.ndarray,
    threshold: float,
) -> dict[str, Any]:
    predicted = (probabilities >= threshold).astype(int)
    true_positive = int(np.sum((response == 1) & (predicted == 1)))
    true_negative = int(np.sum((response == 0) & (predicted == 0)))
    false_positive = int(np.sum((response == 0) & (predicted == 1)))
    false_negative = int(np.sum((response == 1) & (predicted == 0)))
    sensitivity = (
        true_positive / (true_positive + false_negative)
        if true_positive + false_negative
        else None
    )
    specificity = (
        true_negative / (true_negative + false_positive)
        if true_negative + false_positive
        else None
    )
    precision = (
        true_positive / (true_positive + false_positive)
        if true_positive + false_positive
        else None
    )
    negative_predictive_value = (
        true_negative / (true_negative + false_negative)
        if true_negative + false_negative
        else None
    )
    f1_score = (
        2.0 * precision * sensitivity / (precision + sensitivity)
        if precision is not None
        and sensitivity is not None
        and precision + sensitivity > 0
        else None
    )
    positive_count = int(np.sum(response == 1))
    negative_count = int(np.sum(response == 0))
    ranks = scipy_stats.rankdata(probabilities, method="average")
    roc_auc = (
        (
            float(np.sum(ranks[response == 1]))
            - positive_count * (positive_count + 1.0) / 2.0
        )
        / (positive_count * negative_count)
        if positive_count and negative_count
        else None
    )
    clipped_probabilities = np.clip(
        probabilities, np.finfo(float).eps, 1.0 - np.finfo(float).eps
    )
    log_loss = -float(
        np.mean(
            response * np.log(clipped_probabilities)
            + (1.0 - response) * np.log(1.0 - clipped_probabilities)
        )
    )
    return {
        "threshold": threshold,
        "confusion_matrix": {
            "true_negative": true_negative,
            "false_positive": false_positive,
            "false_negative": false_negative,
            "true_positive": true_positive,
        },
        "accuracy": (true_positive + true_negative) / response.size,
        "sensitivity": finite_or_none(sensitivity),
        "specificity": finite_or_none(specificity),
        "precision": finite_or_none(precision),
        "negative_predictive_value": finite_or_none(
            negative_predictive_value
        ),
        "f1_score": finite_or_none(f1_score),
        "roc_auc": finite_or_none(roc_auc),
        "log_loss": finite_or_none(log_loss),
        "brier_score": finite_or_none(np.mean((response - probabilities) ** 2)),
    }


def _hosmer_lemeshow_test(
    response: np.ndarray,
    probabilities: np.ndarray,
    alpha: float,
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "method": "Hosmer-Lemeshow goodness-of-fit test",
        "null_hypothesis": "observed and expected event rates agree by risk group",
    }
    requested_groups = min(10, max(2, response.size // 5))
    order = np.argsort(probabilities, kind="stable")
    codes = np.empty(response.size, dtype=int)
    codes[order] = (
        np.arange(response.size, dtype=int) * requested_groups // response.size
    )
    unique_groups = np.unique(codes)
    if unique_groups.size < 3:
        result.update(
            status="not_run", reason="fewer than 3 distinct risk groups"
        )
        return result
    statistic = 0.0
    details = []
    for group in unique_groups:
        group_mask = codes == group
        count = int(np.sum(group_mask))
        observed_events = int(np.sum(response[group_mask]))
        expected_events = float(np.sum(probabilities[group_mask]))
        expected_nonevents = count - expected_events
        observed_nonevents = count - observed_events
        contribution = 0.0
        if expected_events > 0:
            contribution += (observed_events - expected_events) ** 2 / expected_events
        if expected_nonevents > 0:
            contribution += (
                (observed_nonevents - expected_nonevents) ** 2
                / expected_nonevents
            )
        statistic += contribution
        details.append(
            {
                "risk_group": int(group) + 1,
                "n": count,
                "observed_events": observed_events,
                "expected_events": expected_events,
                "mean_predicted_probability": expected_events / count,
            }
        )
    degrees_of_freedom = int(unique_groups.size - 2)
    p_value = float(scipy_stats.chi2.sf(statistic, degrees_of_freedom))
    result.update(
        {
            "status": "completed",
            "groups": int(unique_groups.size),
            "group_details": details,
            "statistic": finite_or_none(statistic),
            "degrees_of_freedom": degrees_of_freedom,
            "p_value": finite_or_none(p_value),
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result


def _binary_influence(
    complete_frame: pd.DataFrame,
    response: np.ndarray,
    probabilities: np.ndarray,
    design: np.ndarray,
    hessian_inverse: np.ndarray,
) -> dict[str, Any]:
    observation_count, parameter_count = design.shape
    weights = np.maximum(
        probabilities * (1.0 - probabilities), np.finfo(float).eps
    )
    leverage = weights * np.sum((design @ hessian_inverse) * design, axis=1)
    pearson_residuals = (response - probabilities) / np.sqrt(weights)
    one_minus_leverage = np.maximum(1.0 - leverage, np.finfo(float).eps)
    standardized_pearson = pearson_residuals / np.sqrt(one_minus_leverage)
    cooks_distance = (
        standardized_pearson**2
        * leverage
        / (parameter_count * one_minus_leverage)
    )
    leverage_threshold = 2.0 * parameter_count / observation_count
    cooks_threshold = 4.0 / observation_count
    unusual = (
        (leverage > leverage_threshold)
        | (cooks_distance > cooks_threshold)
        | (np.abs(standardized_pearson) > 2.0)
    )
    unusual_indices = np.flatnonzero(unusual)
    cases = []
    for position in unusual_indices[:100]:
        cases.append(
            {
                "source_index": finite_or_none(complete_frame.index[position]),
                "observed_event": int(response[position]),
                "predicted_probability": finite_or_none(probabilities[position]),
                "standardized_pearson_residual": finite_or_none(
                    standardized_pearson[position]
                ),
                "leverage": finite_or_none(leverage[position]),
                "cooks_distance": finite_or_none(cooks_distance[position]),
            }
        )
    return {
        "leverage_threshold": leverage_threshold,
        "cooks_distance_threshold": cooks_threshold,
        "maximum_leverage": finite_or_none(np.max(leverage)),
        "maximum_absolute_standardized_pearson_residual": finite_or_none(
            np.max(np.abs(standardized_pearson))
        ),
        "maximum_cooks_distance": finite_or_none(np.max(cooks_distance)),
        "flagged_case_count": int(unusual_indices.size),
        "flagged_cases_returned": len(cases),
        "flagged_cases_truncated": unusual_indices.size > len(cases),
        "flagged_cases": cases,
    }


def binary_logistic_regression(
    frame: pd.DataFrame,
    outcome_name: str,
    predictor_names: list[str],
    categorical_predictors: set[str],
    event_value: str,
    alpha: float,
    classification_threshold: float = 0.5,
    model_name: str | None = None,
    polynomial_terms: dict[str, int] | None = None,
    interactions: list[tuple[str, str]] | None = None,
) -> dict[str, Any]:
    """Fit an unpenalized binary logistic regression by maximum likelihood."""
    prepared = _prepare_design(
        frame,
        outcome_name,
        predictor_names,
        categorical_predictors,
        polynomial_terms,
        interactions,
    )
    outcome = prepared["outcome"]
    design = prepared["design"]
    categories = list(pd.unique(outcome))
    observation_count, parameter_count = design.shape
    result: dict[str, Any] = {
        "method": "binary logistic regression",
        "model_name": model_name,
        "outcome_variable": outcome_name,
        "predictors": predictor_names,
        "categorical_predictors": [
            name for name in predictor_names if name in categorical_predictors
        ],
        "categorical_codings": prepared["categorical_codings"],
        "polynomial_terms": prepared["polynomial_terms"],
        "interactions": prepared["interactions"],
        "total_rows": int(len(frame)),
        "n_complete_cases": int(observation_count),
        "excluded_rows": int(len(frame) - observation_count),
        "parameter_count": int(parameter_count),
        "terms": prepared["terms"],
    }
    if prepared["invalid_reason"]:
        result.update(status="not_run", reason=prepared["invalid_reason"])
        return result
    if len(categories) != 2:
        result.update(
            status="not_run",
            reason="binary logistic regression requires exactly 2 outcome categories",
            observed_outcome_categories=[str(value) for value in categories],
        )
        return result
    event_category = _match_requested_category(categories, event_value)
    if event_category is None:
        result.update(
            status="not_run",
            reason=(
                f"event value {event_value!r} does not match an observed outcome "
                f"category: {', '.join(str(value) for value in categories)}"
            ),
        )
        return result
    nonevent_category = next(
        category for category in categories if category != event_category
    )
    response = np.asarray(outcome == event_category, dtype=float)
    result.update(
        {
            "event_category": str(event_category),
            "nonevent_category": str(nonevent_category),
            "events": int(np.sum(response)),
            "nonevents": int(np.sum(1.0 - response)),
        }
    )
    if observation_count <= parameter_count:
        result.update(
            status="not_run",
            reason="requires more observations than estimated parameters",
        )
        return result
    design_rank = int(np.linalg.matrix_rank(design))
    if design_rank < parameter_count:
        result.update(
            status="not_run",
            reason="the design matrix is rank deficient",
            design_matrix_rank=design_rank,
        )
        return result

    event_rate = float(np.mean(response))
    initial = np.zeros(parameter_count, dtype=float)
    initial[0] = math.log(event_rate / (1.0 - event_rate))

    def objective(estimates: np.ndarray) -> tuple[float, np.ndarray]:
        linear_predictor = design @ estimates
        value = float(
            np.sum(np.logaddexp(0.0, linear_predictor) - response * linear_predictor)
        )
        probabilities = scipy_special.expit(linear_predictor)
        gradient = design.T @ (probabilities - response)
        return value, gradient

    optimization = scipy_optimize.minimize(
        lambda estimates: objective(estimates)[0],
        initial,
        jac=lambda estimates: objective(estimates)[1],
        method="L-BFGS-B",
        options={
            "maxiter": 2000,
            "ftol": 1e-15,
            "gtol": 1e-10,
            "maxcor": 30,
            "maxls": 50,
        },
    )
    estimates = np.asarray(optimization.x, dtype=float)
    objective_value, final_gradient = objective(estimates)
    optimization_diagnostics = optimizer_convergence_diagnostics(
        optimization,
        parameters=estimates,
        objective_value=objective_value,
        gradient=final_gradient,
        method="L-BFGS-B",
    )
    gradient_norm = optimization_diagnostics["gradient_infinity_norm"]
    if not optimization_diagnostics["converged"]:
        failure_reason = f"maximum-likelihood optimization failed: {optimization.message}"
        result.update(
            status="not_run",
            reason=failure_reason,
            convergence=optimization_diagnostics,
            numerical_status=statistical_numerical_status(
                optimization=optimization_diagnostics,
                covariance_available=False,
                inference_available=False,
                failure_reason=failure_reason,
            ),
        )
        return result

    linear_predictor = design @ estimates
    probabilities = scipy_special.expit(linear_predictor)
    weights = probabilities * (1.0 - probabilities)
    hessian = design.T @ (weights[:, None] * design)
    try:
        covariance, information_diagnostics = covariance_from_information(hessian)
    except NumericalComputationError as exc:
        failure_reason = (
            "the information matrix cannot support covariance inference; "
            "complete or quasi-complete separation may be present"
        )
        result.update(
            status="not_run",
            reason=failure_reason,
            convergence=optimization_diagnostics,
            information_matrix_diagnostics=exc.diagnostics,
            numerical_status=statistical_numerical_status(
                optimization=optimization_diagnostics,
                information=exc.diagnostics,
                covariance_available=False,
                inference_available=False,
                failure_reason=failure_reason,
            ),
        )
        return result
    hessian_rank = int(information_diagnostics["rank"])
    standard_errors = np.sqrt(np.maximum(0.0, np.diag(covariance)))
    z_statistics = estimates / standard_errors
    p_values = 2.0 * scipy_stats.norm.sf(np.abs(z_statistics))
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    coefficients = []
    for index, term in enumerate(prepared["terms"]):
        lower = estimates[index] - critical * standard_errors[index]
        upper = estimates[index] + critical * standard_errors[index]
        coefficients.append(
            {
                "term": term,
                "predictor": prepared["term_predictors"][index],
                "term_type": prepared["term_types"][index],
                "estimate": finite_or_none(estimates[index]),
                "standard_error": finite_or_none(standard_errors[index]),
                "z_statistic": finite_or_none(z_statistics[index]),
                "p_value": finite_or_none(p_values[index]),
                "confidence_interval": [
                    finite_or_none(lower),
                    finite_or_none(upper),
                ],
                "odds_ratio": _safe_exp(estimates[index]),
                "odds_ratio_confidence_interval": [
                    _safe_exp(lower),
                    _safe_exp(upper),
                ],
            }
        )

    log_likelihood = -float(objective(estimates)[0])
    null_log_likelihood = float(
        np.sum(
            response * math.log(event_rate)
            + (1.0 - response) * math.log(1.0 - event_rate)
        )
    )
    likelihood_ratio = 2.0 * (log_likelihood - null_log_likelihood)
    model_degrees_of_freedom = parameter_count - 1
    likelihood_ratio_p = float(
        scipy_stats.chi2.sf(likelihood_ratio, model_degrees_of_freedom)
    )
    cox_snell = 1.0 - math.exp(
        2.0 * (null_log_likelihood - log_likelihood) / observation_count
    )
    nagelkerke_denominator = 1.0 - math.exp(
        2.0 * null_log_likelihood / observation_count
    )
    linear_standard_errors = np.sqrt(
        np.maximum(0.0, np.sum((design @ covariance) * design, axis=1))
    )
    prediction_rows = []
    for index, source_index in enumerate(prepared["complete_frame"].index):
        lower_probability = scipy_special.expit(
            linear_predictor[index] - critical * linear_standard_errors[index]
        )
        upper_probability = scipy_special.expit(
            linear_predictor[index] + critical * linear_standard_errors[index]
        )
        prediction_rows.append(
            {
                "model_family": "binary_logistic_regression",
                "model_name": model_name or "Binary logistic model",
                "source_index": str(source_index),
                "outcome_variable": outcome_name,
                "observed": int(response[index]),
                "observed_category": str(outcome[index]),
                "predicted": finite_or_none(probabilities[index]),
                "predicted_category": (
                    str(event_category)
                    if probabilities[index] >= classification_threshold
                    else str(nonevent_category)
                ),
                "residual": finite_or_none(response[index] - probabilities[index]),
                "mean_ci_lower": finite_or_none(lower_probability),
                "mean_ci_upper": finite_or_none(upper_probability),
            }
        )
    result.update(
        {
            "status": "completed",
            "design_matrix_rank": design_rank,
            "information_matrix_rank": hessian_rank,
            "observed_information_type": "analytic expected/observed binomial-logit information",
            "observed_information_matrix": hessian.tolist(),
            "parameter_covariance_matrix": covariance.tolist(),
            "covariance_type": "model-based inverse analytic information; not sandwich",
            "information_matrix_diagnostics": information_diagnostics,
            "convergence": optimization_diagnostics,
            "numerical_status": statistical_numerical_status(
                optimization=optimization_diagnostics,
                information=information_diagnostics,
                covariance_available=True,
                inference_available=True,
            ),
            "coefficients": coefficients,
            "assumption_warnings": [
                warning
                for warning, condition in (
                    (
                        "Some fitted probabilities are extremely close to 0 or "
                        "1; separation may be present.",
                        bool(np.min(weights) < 1e-8),
                    ),
                    (
                        "At least one coefficient has absolute value above 20; "
                        "estimates may be unstable.",
                        bool(np.max(np.abs(estimates)) > 20),
                    ),
                    (
                        "There are fewer than 10 events or nonevents per estimated parameter.",
                        bool(
                            min(np.sum(response), np.sum(1.0 - response))
                            < 10 * parameter_count
                        ),
                    ),
                )
                if condition
            ],
            "log_likelihood": log_likelihood,
            "null_log_likelihood": null_log_likelihood,
            "deviance": -2.0 * log_likelihood,
            "null_deviance": -2.0 * null_log_likelihood,
            "likelihood_ratio_statistic": likelihood_ratio,
            "likelihood_ratio_degrees_of_freedom": model_degrees_of_freedom,
            "likelihood_ratio_p_value": likelihood_ratio_p,
            "decision": decision_from_pvalue(likelihood_ratio_p, alpha),
            "aic": 2.0 * parameter_count - 2.0 * log_likelihood,
            "bic": parameter_count * math.log(observation_count)
            - 2.0 * log_likelihood,
            "mcfadden_r_squared": 1.0 - log_likelihood / null_log_likelihood,
            "cox_snell_r_squared": cox_snell,
            "nagelkerke_r_squared": (
                cox_snell / nagelkerke_denominator
                if nagelkerke_denominator > 0
                else None
            ),
            "classification": _binary_classification(
                response, probabilities, classification_threshold
            ),
            "hosmer_lemeshow_test": _hosmer_lemeshow_test(
                response, probabilities, alpha
            ),
            "condition_number_standardized_design": _condition_number(design),
            "variance_inflation_factors": _variance_inflation_factors(
                design, prepared["terms"]
            ),
            "influence_diagnostics": _binary_influence(
                prepared["complete_frame"],
                response,
                probabilities,
                design,
                covariance,
            ),
            "prediction_rows": prediction_rows,
        }
    )
    return result


def _multinomial_classification(
    actual_indices: np.ndarray,
    predicted_indices: np.ndarray,
    probabilities: np.ndarray,
    category_names: list[str],
) -> dict[str, Any]:
    category_count = len(category_names)
    matrix = np.zeros((category_count, category_count), dtype=int)
    for actual, predicted in zip(actual_indices, predicted_indices):
        matrix[actual, predicted] += 1
    per_category = []
    f1_values = []
    precision_values = []
    recall_values = []
    for index, category in enumerate(category_names):
        true_positive = int(matrix[index, index])
        false_positive = int(np.sum(matrix[:, index]) - true_positive)
        false_negative = int(np.sum(matrix[index, :]) - true_positive)
        precision = (
            true_positive / (true_positive + false_positive)
            if true_positive + false_positive
            else 0.0
        )
        recall = (
            true_positive / (true_positive + false_negative)
            if true_positive + false_negative
            else 0.0
        )
        f1_score = (
            2.0 * precision * recall / (precision + recall)
            if precision + recall
            else 0.0
        )
        precision_values.append(precision)
        recall_values.append(recall)
        f1_values.append(f1_score)
        per_category.append(
            {
                "category": category,
                "support": int(np.sum(matrix[index, :])),
                "precision": precision,
                "recall": recall,
                "f1_score": f1_score,
            }
        )
    one_hot = np.eye(category_count)[actual_indices]
    log_loss = -float(
        np.mean(
            np.log(
                np.clip(
                    probabilities[np.arange(actual_indices.size), actual_indices],
                    np.finfo(float).eps,
                    1.0,
                )
            )
        )
    )
    return {
        "confusion_matrix": matrix.tolist(),
        "row_categories_actual": category_names,
        "column_categories_predicted": category_names,
        "accuracy": float(np.mean(actual_indices == predicted_indices)),
        "macro_precision": float(np.mean(precision_values)),
        "macro_recall": float(np.mean(recall_values)),
        "macro_f1_score": float(np.mean(f1_values)),
        "log_loss": log_loss,
        "per_category": per_category,
        "multiclass_brier_score": float(np.mean(np.sum((one_hot - probabilities) ** 2, axis=1))),
    }


def multinomial_logistic_regression(
    frame: pd.DataFrame,
    outcome_name: str,
    predictor_names: list[str],
    categorical_predictors: set[str],
    reference_category_value: str | None,
    alpha: float,
    model_name: str | None = None,
    polynomial_terms: dict[str, int] | None = None,
    interactions: list[tuple[str, str]] | None = None,
) -> dict[str, Any]:
    """Fit baseline-category multinomial logistic regression."""
    prepared = _prepare_design(
        frame,
        outcome_name,
        predictor_names,
        categorical_predictors,
        polynomial_terms,
        interactions,
    )
    outcome = prepared["outcome"]
    design = prepared["design"]
    observed_categories = list(pd.unique(outcome))
    observation_count, design_parameter_count = design.shape
    result: dict[str, Any] = {
        "method": "baseline-category multinomial logistic regression",
        "model_name": model_name,
        "outcome_variable": outcome_name,
        "predictors": predictor_names,
        "categorical_predictors": [
            name for name in predictor_names if name in categorical_predictors
        ],
        "categorical_codings": prepared["categorical_codings"],
        "polynomial_terms": prepared["polynomial_terms"],
        "interactions": prepared["interactions"],
        "total_rows": int(len(frame)),
        "n_complete_cases": int(observation_count),
        "excluded_rows": int(len(frame) - observation_count),
        "terms": prepared["terms"],
    }
    if prepared["invalid_reason"]:
        result.update(status="not_run", reason=prepared["invalid_reason"])
        return result
    if len(observed_categories) < 3:
        result.update(
            status="not_run",
            reason="multinomial logistic regression requires at least 3 outcome categories",
            observed_outcome_categories=[
                str(value) for value in observed_categories
            ],
        )
        return result
    requested_reference = _match_requested_category(
        observed_categories, reference_category_value
    )
    if reference_category_value is not None and requested_reference is None:
        result.update(
            status="not_run",
            reason=(
                f"reference category {reference_category_value!r} does not match "
                "an observed outcome category"
            ),
        )
        return result
    reference = (
        requested_reference
        if requested_reference is not None
        else observed_categories[0]
    )
    categories = [reference] + [
        category for category in observed_categories if category != reference
    ]
    category_names = [str(category) for category in categories]
    category_count = len(categories)
    nonreference_count = category_count - 1
    parameter_count = nonreference_count * design_parameter_count
    result.update(
        {
            "reference_category": str(reference),
            "outcome_categories": category_names,
            "category_counts": {
                str(category): int(np.sum(outcome == category))
                for category in categories
            },
            "design_parameter_count_per_logit": int(design_parameter_count),
            "parameter_count": int(parameter_count),
        }
    )
    if observation_count <= design_parameter_count:
        result.update(
            status="not_run",
            reason="requires more observations than design parameters",
        )
        return result
    design_rank = int(np.linalg.matrix_rank(design))
    if design_rank < design_parameter_count:
        result.update(status="not_run", reason="the design matrix is rank deficient")
        return result

    actual_indices = np.asarray(
        [
            next(index for index, category in enumerate(categories) if value == category)
            for value in outcome
        ],
        dtype=int,
    )
    response_nonreference = np.eye(category_count)[actual_indices, 1:]
    proportions = np.bincount(actual_indices, minlength=category_count) / observation_count
    initial_matrix = np.zeros(
        (nonreference_count, design_parameter_count), dtype=float
    )
    initial_matrix[:, 0] = np.log(proportions[1:] / proportions[0])

    def objective(parameters: np.ndarray) -> tuple[float, np.ndarray]:
        coefficient_matrix = parameters.reshape(
            nonreference_count, design_parameter_count
        )
        nonreference_logits = design @ coefficient_matrix.T
        full_logits = np.column_stack(
            [np.zeros(observation_count), nonreference_logits]
        )
        log_denominator = scipy_special.logsumexp(full_logits, axis=1)
        log_probabilities = full_logits - log_denominator[:, None]
        value = -float(np.sum(log_probabilities[np.arange(observation_count), actual_indices]))
        nonreference_probabilities = np.exp(log_probabilities[:, 1:])
        gradient = (
            (nonreference_probabilities - response_nonreference).T @ design
        )
        return value, gradient.ravel()

    optimization = scipy_optimize.minimize(
        lambda parameters: objective(parameters)[0],
        initial_matrix.ravel(),
        jac=lambda parameters: objective(parameters)[1],
        method="L-BFGS-B",
        options={
            "maxiter": 3000,
            "ftol": 1e-15,
            "gtol": 1e-10,
            "maxcor": 30,
            "maxls": 50,
        },
    )
    parameters = np.asarray(optimization.x, dtype=float)
    objective_value, final_gradient = objective(parameters)
    optimization_diagnostics = optimizer_convergence_diagnostics(
        optimization,
        parameters=parameters,
        objective_value=objective_value,
        gradient=final_gradient,
        method="L-BFGS-B",
    )
    gradient_norm = optimization_diagnostics["gradient_infinity_norm"]
    if not optimization_diagnostics["converged"]:
        failure_reason = f"maximum-likelihood optimization failed: {optimization.message}"
        result.update(
            status="not_run",
            reason=failure_reason,
            convergence=optimization_diagnostics,
            numerical_status=statistical_numerical_status(
                optimization=optimization_diagnostics,
                covariance_available=False,
                inference_available=False,
                failure_reason=failure_reason,
            ),
        )
        return result
    coefficient_matrix = parameters.reshape(
        nonreference_count, design_parameter_count
    )
    nonreference_logits = design @ coefficient_matrix.T
    full_logits = np.column_stack(
        [np.zeros(observation_count), nonreference_logits]
    )
    log_denominator = scipy_special.logsumexp(full_logits, axis=1)
    log_probabilities = full_logits - log_denominator[:, None]
    probabilities = np.exp(log_probabilities)
    log_likelihood = float(
        np.sum(log_probabilities[np.arange(observation_count), actual_indices])
    )

    hessian = np.zeros((parameter_count, parameter_count), dtype=float)
    for row_index in range(observation_count):
        probability_vector = probabilities[row_index, 1:]
        category_covariance = np.diag(probability_vector) - np.outer(
            probability_vector, probability_vector
        )
        predictor_cross_product = np.outer(design[row_index], design[row_index])
        hessian += np.kron(category_covariance, predictor_cross_product)
    try:
        covariance, information_diagnostics = covariance_from_information(hessian)
    except NumericalComputationError as exc:
        failure_reason = (
            "the information matrix cannot support covariance inference; "
            "sparse categories or separation may be present"
        )
        result.update(
            status="not_run",
            reason=failure_reason,
            convergence=optimization_diagnostics,
            information_matrix_diagnostics=exc.diagnostics,
            numerical_status=statistical_numerical_status(
                optimization=optimization_diagnostics,
                information=exc.diagnostics,
                covariance_available=False,
                inference_available=False,
                failure_reason=failure_reason,
            ),
        )
        return result
    hessian_rank = int(information_diagnostics["rank"])
    standard_errors = np.sqrt(np.maximum(0.0, np.diag(covariance))).reshape(
        nonreference_count, design_parameter_count
    )
    z_statistics = coefficient_matrix / standard_errors
    p_values = 2.0 * scipy_stats.norm.sf(np.abs(z_statistics))
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    coefficients = []
    for category_index, category in enumerate(categories[1:]):
        for term_index, term in enumerate(prepared["terms"]):
            estimate = coefficient_matrix[category_index, term_index]
            standard_error = standard_errors[category_index, term_index]
            lower = estimate - critical * standard_error
            upper = estimate + critical * standard_error
            coefficients.append(
                {
                    "outcome_category": str(category),
                    "reference_category": str(reference),
                    "term": term,
                    "predictor": prepared["term_predictors"][term_index],
                    "term_type": prepared["term_types"][term_index],
                    "estimate": finite_or_none(estimate),
                    "standard_error": finite_or_none(standard_error),
                    "z_statistic": finite_or_none(
                        z_statistics[category_index, term_index]
                    ),
                    "p_value": finite_or_none(
                        p_values[category_index, term_index]
                    ),
                    "confidence_interval": [
                        finite_or_none(lower),
                        finite_or_none(upper),
                    ],
                    "relative_risk_ratio": _safe_exp(estimate),
                    "relative_risk_ratio_confidence_interval": [
                        _safe_exp(lower),
                        _safe_exp(upper),
                    ],
                }
            )

    null_log_likelihood = float(
        np.sum(np.log(proportions[actual_indices]))
    )
    likelihood_ratio = 2.0 * (log_likelihood - null_log_likelihood)
    likelihood_ratio_df = nonreference_count * (design_parameter_count - 1)
    likelihood_ratio_p = float(
        scipy_stats.chi2.sf(likelihood_ratio, likelihood_ratio_df)
    )
    predicted_indices = np.argmax(probabilities, axis=1)
    prediction_rows = []
    for index, source_index in enumerate(prepared["complete_frame"].index):
        row: dict[str, Any] = {
            "model_family": "multinomial_logistic_regression",
            "model_name": model_name or "Multinomial logistic model",
            "source_index": str(source_index),
            "outcome_variable": outcome_name,
            "observed_category": str(outcome[index]),
            "predicted_category": category_names[predicted_indices[index]],
            "predicted": finite_or_none(np.max(probabilities[index])),
            "residual": None,
        }
        for category_index, category in enumerate(category_names):
            row[f"probability_{category}"] = finite_or_none(
                probabilities[index, category_index]
            )
        prediction_rows.append(row)
    result.update(
        {
            "status": "completed",
            "design_matrix_rank": design_rank,
            "information_matrix_rank": hessian_rank,
            "observed_information_type": "analytic expected/observed multinomial-logit information",
            "observed_information_matrix": hessian.tolist(),
            "parameter_covariance_matrix": covariance.tolist(),
            "covariance_type": "model-based inverse analytic information; not sandwich",
            "information_matrix_diagnostics": information_diagnostics,
            "convergence": optimization_diagnostics,
            "numerical_status": statistical_numerical_status(
                optimization=optimization_diagnostics,
                information=information_diagnostics,
                covariance_available=True,
                inference_available=True,
            ),
            "coefficients": coefficients,
            "assumption_warnings": [
                warning
                for warning, condition in (
                    (
                        "At least one outcome category has fewer than 10 "
                        "observations per design parameter; estimates may be "
                        "unstable.",
                        bool(
                            np.min(
                                np.bincount(
                                    actual_indices, minlength=category_count
                                )
                            )
                            < 10 * design_parameter_count
                        ),
                    ),
                    (
                        "At least one coefficient has absolute value above 20; "
                        "sparse-category separation may be present.",
                        bool(np.max(np.abs(coefficient_matrix)) > 20),
                    ),
                )
                if condition
            ],
            "log_likelihood": log_likelihood,
            "null_log_likelihood": null_log_likelihood,
            "deviance": -2.0 * log_likelihood,
            "null_deviance": -2.0 * null_log_likelihood,
            "likelihood_ratio_statistic": likelihood_ratio,
            "likelihood_ratio_degrees_of_freedom": likelihood_ratio_df,
            "likelihood_ratio_p_value": likelihood_ratio_p,
            "decision": decision_from_pvalue(likelihood_ratio_p, alpha),
            "aic": 2.0 * parameter_count - 2.0 * log_likelihood,
            "bic": parameter_count * math.log(observation_count)
            - 2.0 * log_likelihood,
            "mcfadden_r_squared": 1.0 - log_likelihood / null_log_likelihood,
            "classification": _multinomial_classification(
                actual_indices,
                predicted_indices,
                probabilities,
                category_names,
            ),
            "condition_number_standardized_design": _condition_number(design),
            "variance_inflation_factors": _variance_inflation_factors(
                design, prepared["terms"]
            ),
            "prediction_rows": prediction_rows,
        }
    )
    return result
