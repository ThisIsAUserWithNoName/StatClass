"""Standalone estimation for supported discrete probability models."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd
from scipy import optimize as scipy_optimize
from scipy import special as scipy_special
from scipy import stats as scipy_stats

from .numerical import (
    NumericalComputationError,
    covariance_from_information,
    delta_method_covariance,
    numerical_hessian,
    optimizer_convergence_diagnostics,
    statistical_numerical_status,
)
from .utils import finite_or_none


class DiscreteEstimationError(ValueError):
    """Raised when a discrete-distribution model cannot be estimated safely."""


def _normal_p_value(statistic: float, alternative: str) -> float:
    if alternative == "two-sided":
        return float(2.0 * scipy_stats.norm.sf(abs(statistic)))
    if alternative == "less":
        return float(scipy_stats.norm.cdf(statistic))
    return float(scipy_stats.norm.sf(statistic))


def _integer_values(values: Any, name: str, minimum: int) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    array = array[np.isfinite(array)]
    if array.size == 0:
        raise DiscreteEstimationError(f"{name} requires at least one observation")
    if np.any(array < minimum) or np.any(array != np.floor(array)):
        raise DiscreteEstimationError(
            f"{name} observations must be integers of at least {minimum}"
        )
    return array.astype(np.int64)


def _wald_test(
    estimate: float,
    null_value: float,
    standard_error: float,
    alternative: str,
) -> dict[str, Any]:
    if not math.isfinite(standard_error) or standard_error <= 0.0:
        return {
            "method": "Wald z-test",
            "status": "not_run",
            "reason": "the estimated standard error is zero or undefined",
        }
    statistic = (estimate - null_value) / standard_error
    return {
        "method": "Wald z-test",
        "status": "completed",
        "statistic": statistic,
        "p_value": _normal_p_value(statistic, alternative),
    }


def _wald_interval(
    estimate: float,
    standard_error: float,
    alpha: float,
) -> list[float] | None:
    if not math.isfinite(standard_error) or standard_error <= 0.0:
        return None
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    return [estimate - critical * standard_error, estimate + critical * standard_error]


def _likelihood_ratio_test(
    maximized_log_likelihood: float,
    null_log_likelihood: float,
    boundary_null: bool = False,
) -> dict[str, Any]:
    statistic = max(0.0, 2.0 * (maximized_log_likelihood - null_log_likelihood))
    if boundary_null:
        return {
            "method": "likelihood-ratio test",
            "status": "completed",
            "statistic": finite_or_none(statistic),
            "statistic_status": (
                "finite" if math.isfinite(statistic) else "infinite"
            ),
            "p_value": None,
            "degrees_of_freedom": 1,
            "reference_distribution": (
                "ordinary chi-square calibration is invalid at this boundary null; "
                "use the exact test"
            ),
        }
    return {
        "method": "likelihood-ratio test",
        "status": "completed",
        "statistic": statistic,
        "p_value": float(scipy_stats.chi2.sf(statistic, 1)),
        "degrees_of_freedom": 1,
        "reference_distribution": "asymptotic chi-square",
    }


def _wilson_interval(successes: int, trials: int, alpha: float) -> list[float]:
    estimate = successes / trials
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    denominator = 1.0 + critical**2 / trials
    center = (estimate + critical**2 / (2.0 * trials)) / denominator
    half_width = (
        critical
        * math.sqrt(
            estimate * (1.0 - estimate) / trials
            + critical**2 / (4.0 * trials**2)
        )
        / denominator
    )
    return [max(0.0, center - half_width), min(1.0, center + half_width)]


def _clopper_pearson_interval(
    successes: int,
    trials: int,
    alpha: float,
) -> list[float]:
    result = scipy_stats.binomtest(successes, trials).proportion_ci(
        confidence_level=1.0 - alpha,
        method="exact",
    )
    return [float(result.low), float(result.high)]


def binomial_estimation(
    successes: Any,
    trials: Any,
    column: str,
    alpha: float,
    alternative: str,
    null_probability: float | None = None,
    distribution: str = "binomial",
    success_value: str | None = None,
) -> dict[str, Any]:
    """Estimate a common success probability from Bernoulli/binomial data."""
    success_array = np.asarray(successes, dtype=float)
    trial_array = np.asarray(trials, dtype=float)
    complete = np.isfinite(success_array) & np.isfinite(trial_array)
    success_array = success_array[complete]
    trial_array = trial_array[complete]
    if success_array.size == 0:
        raise DiscreteEstimationError(
            f"{distribution} estimation requires at least one complete observation"
        )
    if (
        np.any(success_array < 0)
        or np.any(trial_array < 1)
        or np.any(success_array != np.floor(success_array))
        or np.any(trial_array != np.floor(trial_array))
        or np.any(success_array > trial_array)
    ):
        raise DiscreteEstimationError(
            f"{distribution} successes and trials must be integers satisfying "
            "0 <= successes <= trials"
        )
    total_successes = int(np.sum(success_array))
    total_trials = int(np.sum(trial_array))
    estimate = total_successes / total_trials
    standard_error = math.sqrt(estimate * (1.0 - estimate) / total_trials)
    fisher_information = (
        total_trials / (estimate * (1.0 - estimate))
        if 0.0 < estimate < 1.0
        else None
    )
    wald_interval = _wald_interval(estimate, standard_error, alpha)
    log_coefficient = float(
        np.sum(
            scipy_special.gammaln(trial_array + 1.0)
            - scipy_special.gammaln(success_array + 1.0)
            - scipy_special.gammaln(trial_array - success_array + 1.0)
        )
    )

    def grouped_log_likelihood(probability: float) -> float:
        return float(
            log_coefficient
            + scipy_special.xlogy(total_successes, probability)
            + scipy_special.xlog1py(
                total_trials - total_successes, -probability
            )
        )

    maximized_log_likelihood = grouped_log_likelihood(estimate)
    warnings: list[str] = []
    if wald_interval is None:
        warnings.append(
            "The Wald standard error degenerates when the estimated probability is 0 or 1."
        )
    elif wald_interval[0] < 0.0 or wald_interval[1] > 1.0:
        warnings.append(
            "The unbounded Wald interval extends outside the probability parameter space."
        )
    tests: list[dict[str, Any]] = []
    if null_probability is not None:
        if not math.isfinite(null_probability) or not 0.0 <= null_probability <= 1.0:
            raise DiscreteEstimationError("the null probability must be from 0 through 1")
        boundary_null = null_probability in {0.0, 1.0}
        if boundary_null:
            tests.append(
                {
                    "method": "Wald z-test",
                    "status": "not_run",
                    "reason": "the null probability lies on the boundary",
                }
            )
        else:
            tests.append(
                _wald_test(estimate, null_probability, standard_error, alternative)
            )
        null_variance = null_probability * (1.0 - null_probability)
        if null_variance == 0.0:
            tests.append(
                {
                    "method": "score z-test",
                    "status": "not_run",
                    "reason": "the null model is on a boundary with zero variance",
                }
            )
        else:
            null_standard_error = math.sqrt(null_variance / total_trials)
            score_statistic = (estimate - null_probability) / null_standard_error
            tests.append(
                {
                    "method": "score z-test",
                    "status": "completed",
                    "statistic": score_statistic,
                    "p_value": _normal_p_value(score_statistic, alternative),
                }
            )
        exact = scipy_stats.binomtest(
            total_successes,
            total_trials,
            null_probability,
            alternative=alternative,
        )
        tests.append(
            {
                "method": "exact binomial test",
                "status": "completed",
                "statistic": total_successes,
                "p_value": float(exact.pvalue),
            }
        )
        if alternative == "two-sided":
            tests.append(
                _likelihood_ratio_test(
                    maximized_log_likelihood,
                    grouped_log_likelihood(null_probability),
                    boundary_null,
                )
            )
    return {
        "method": f"{distribution} probability estimation",
        "distribution": distribution,
        "column": column,
        "parameterization": (
            "binary outcomes with success probability p"
            if distribution == "bernoulli"
            else "independent binomial counts with a common success probability p"
        ),
        "success_value": success_value,
        "status": "completed",
        "observations": int(success_array.size),
        "total_successes": total_successes,
        "total_failures": total_trials - total_successes,
        "total_trials": total_trials,
        "mle_probability": estimate,
        "estimated_standard_error": standard_error,
        "estimated_fisher_information": fisher_information,
        "fisher_information_type": (
            "expected Fisher information evaluated at the MLE; it equals the "
            "observed information at an interior MLE"
        ),
        "confidence_level": 1.0 - alpha,
        "wald_confidence_interval": wald_interval,
        "wilson_confidence_interval": _wilson_interval(
            total_successes, total_trials, alpha
        ),
        "exact_clopper_pearson_interval": _clopper_pearson_interval(
            total_successes, total_trials, alpha
        ),
        "maximized_log_likelihood": maximized_log_likelihood,
        "null_value": null_probability,
        "alternative": alternative,
        "tests": tests,
        "warnings": warnings,
        "estimator_note": "The MLE is total successes divided by total trials.",
    }


def _stopped_trial_exact_interval(
    successes: int,
    failures: int,
    alpha: float,
) -> list[float]:
    lower = float(scipy_stats.beta.ppf(alpha / 2.0, successes, failures + 1))
    upper = (
        1.0
        if failures == 0
        else float(scipy_stats.beta.ppf(1.0 - alpha / 2.0, successes, failures))
    )
    return [lower, upper]


def _negative_binomial_exact_p_value(
    failures: int,
    successes: int,
    probability: float,
    alternative: str,
) -> float:
    lower_parameter_tail = float(
        scipy_stats.nbinom.sf(failures - 1, successes, probability)
    )
    upper_parameter_tail = float(
        scipy_stats.nbinom.cdf(failures, successes, probability)
    )
    if alternative == "less":
        return lower_parameter_tail
    if alternative == "greater":
        return upper_parameter_tail
    return min(1.0, 2.0 * min(lower_parameter_tail, upper_parameter_tail))


def stopped_trial_probability_estimation(
    failures: int,
    successes: int,
    observations: int,
    column: str,
    distribution: str,
    alpha: float,
    alternative: str,
    null_probability: float | None,
    known_successes_per_observation: int | None = None,
) -> dict[str, Any]:
    total_trials = successes + failures
    estimate = successes / total_trials
    standard_error = estimate * math.sqrt((1.0 - estimate) / successes)
    fisher_information = (
        successes / (estimate**2 * (1.0 - estimate))
        if 0.0 < estimate < 1.0
        else None
    )
    wald_interval = _wald_interval(estimate, standard_error, alpha)
    maximized_log_likelihood = (
        successes * math.log(estimate)
        + failures * math.log1p(-estimate)
        if failures
        else 0.0
    )
    warnings: list[str] = []
    if wald_interval is None:
        warnings.append(
            "The Wald standard error degenerates at the boundary estimate p = 1."
        )
    elif wald_interval[0] < 0.0 or wald_interval[1] > 1.0:
        warnings.append(
            "The unbounded Wald interval extends outside the probability parameter space."
        )
    tests: list[dict[str, Any]] = []
    if null_probability is not None:
        if not math.isfinite(null_probability) or not 0.0 < null_probability <= 1.0:
            raise DiscreteEstimationError(
                "the null stopped-trial probability must be greater than 0 and at most 1"
            )
        boundary_null = null_probability == 1.0
        if boundary_null:
            tests.append(
                {
                    "method": "Wald z-test",
                    "status": "not_run",
                    "reason": "the null probability lies on the boundary p = 1",
                }
            )
        else:
            tests.append(
                _wald_test(estimate, null_probability, standard_error, alternative)
            )
        if null_probability == 1.0:
            tests.append(
                {
                    "method": "score test",
                    "status": "not_run",
                    "reason": "the null model is on the boundary p = 1",
                }
            )
        else:
            score = (
                successes / null_probability
                - failures / (1.0 - null_probability)
            ) / math.sqrt(
                successes / (null_probability**2 * (1.0 - null_probability))
            )
            tests.append(
                {
                    "method": "score test",
                    "status": "completed",
                    "statistic": score,
                    "p_value": _normal_p_value(score, alternative),
                }
            )
        tests.append(
            {
                "method": "exact negative-binomial tail test",
                "status": "completed",
                "statistic": failures,
                "p_value": _negative_binomial_exact_p_value(
                    failures, successes, null_probability, alternative
                ),
                "two_sided_definition": "twice the smaller exact tail",
            }
        )
        if alternative == "two-sided":
            null_log_likelihood = float(
                scipy_special.xlogy(successes, null_probability)
                + scipy_special.xlog1py(failures, -null_probability)
            )
            tests.append(
                _likelihood_ratio_test(
                    maximized_log_likelihood,
                    null_log_likelihood,
                    boundary_null,
                )
            )
    return {
        "method": f"{distribution} probability estimation",
        "distribution": distribution,
        "column": column,
        "status": "completed",
        "observations": observations,
        "known_successes_per_observation": known_successes_per_observation,
        "total_successes": successes,
        "total_failures": failures,
        "mle_probability": estimate,
        "estimated_standard_error": standard_error,
        "estimated_fisher_information": fisher_information,
        "fisher_information_type": (
            "expected Fisher information evaluated at the MLE; it equals the "
            "observed information at an interior MLE"
        ),
        "confidence_level": 1.0 - alpha,
        "wald_confidence_interval": wald_interval,
        "exact_stopped_trial_interval": _stopped_trial_exact_interval(
            successes, failures, alpha
        ),
        "maximized_log_likelihood_without_constant": maximized_log_likelihood,
        "null_value": null_probability,
        "alternative": alternative,
        "tests": tests,
        "warnings": warnings,
    }


def geometric_estimation(
    values: Any,
    column: str,
    alpha: float,
    alternative: str,
    null_probability: float | None = None,
) -> dict[str, Any]:
    sample = _integer_values(values, "geometric estimation", 1)
    successes = int(sample.size)
    failures = int(np.sum(sample - 1))
    result = stopped_trial_probability_estimation(
        failures,
        successes,
        int(sample.size),
        column,
        "geometric",
        alpha,
        alternative,
        null_probability,
        1,
    )
    result["sample_mean"] = float(np.mean(sample))
    result["parameterization"] = "trials through the first success; support 1, 2, ..."
    result["estimator_note"] = "The MLE is 1 divided by the sample mean."
    return result


def geometric_summary_estimation(
    observations: int,
    total_trials: int,
    alpha: float,
    alternative: str,
    null_probability: float | None = None,
) -> dict[str, Any]:
    if observations < 1 or total_trials < observations:
        raise DiscreteEstimationError(
            "geometric summary estimation requires TOTAL_TRIALS >= OBSERVATIONS >= 1"
        )
    result = stopped_trial_probability_estimation(
        total_trials - observations,
        observations,
        observations,
        "summary data",
        "geometric",
        alpha,
        alternative,
        null_probability,
        1,
    )
    result["sample_mean"] = total_trials / observations
    result["source"] = "summary_data"
    result["parameterization"] = "trials through the first success; support 1, 2, ..."
    result["estimator_note"] = "The MLE is observations divided by total trials."
    return result


def negative_binomial_known_r_estimation(
    values: Any,
    column: str,
    successes_per_observation: int,
    alpha: float,
    alternative: str,
    null_probability: float | None = None,
) -> dict[str, Any]:
    if successes_per_observation < 1:
        raise DiscreteEstimationError("known negative-binomial R must be positive")
    sample = _integer_values(values, "negative-binomial estimation", 0)
    successes = int(sample.size) * successes_per_observation
    failures = int(np.sum(sample))
    result = stopped_trial_probability_estimation(
        failures,
        successes,
        int(sample.size),
        column,
        "negative-binomial-known-r",
        alpha,
        alternative,
        null_probability,
        successes_per_observation,
    )
    result["sample_mean_failures"] = float(np.mean(sample))
    result["parameterization"] = "failures before the Rth success"
    result["estimator_note"] = "With R known, p-hat = nR/(nR + total failures)."
    return result


def negative_binomial_known_r_summary_estimation(
    observations: int,
    total_failures: int,
    successes_per_observation: int,
    alpha: float,
    alternative: str,
    null_probability: float | None = None,
) -> dict[str, Any]:
    if observations < 1 or total_failures < 0 or successes_per_observation < 1:
        raise DiscreteEstimationError(
            "negative-binomial summary estimation requires positive OBSERVATIONS and R and nonnegative TOTAL_FAILURES"
        )
    successes = observations * successes_per_observation
    result = stopped_trial_probability_estimation(
        total_failures,
        successes,
        observations,
        "summary data",
        "negative-binomial-known-r",
        alpha,
        alternative,
        null_probability,
        successes_per_observation,
    )
    result["sample_mean_failures"] = total_failures / observations
    result["source"] = "summary_data"
    result["parameterization"] = "failures before the Rth success"
    result["estimator_note"] = "With R known, p-hat = nR/(nR + total failures)."
    return result


def _negative_binomial_profile_log_likelihood(
    sample: np.ndarray,
    mean: float,
    log_size: float,
) -> float:
    size = math.exp(log_size)
    probability = size / (size + mean)
    return float(
        np.sum(
            scipy_special.gammaln(sample + size)
            - scipy_special.gammaln(size)
            - scipy_special.gammaln(sample + 1.0)
            + size * math.log(probability)
            + sample * math.log1p(-probability)
        )
    )


def negative_binomial_joint_estimation(
    values: Any,
    column: str,
    alpha: float,
) -> dict[str, Any]:
    """Numerically estimate NB size and probability from failure counts."""
    sample = _integer_values(values, "negative-binomial estimation", 0)
    if sample.size < 2:
        raise DiscreteEstimationError(
            "joint negative-binomial estimation requires at least 2 observations"
        )
    mean = float(np.mean(sample))
    variance = float(np.var(sample, ddof=1))
    base = {
        "method": "negative-binomial joint maximum-likelihood estimation",
        "distribution": "negative-binomial",
        "column": column,
        "observations": int(sample.size),
        "sample_mean": mean,
        "sample_variance": variance,
        "confidence_level": 1.0 - alpha,
        "parameterization": "failures before R successes; R and p estimated",
        "tests": [],
        "warnings": [],
    }
    if mean == 0.0:
        base.update(
            status="boundary",
            mle_mean=0.0,
            mle_size=None,
            mle_probability=1.0,
            mle_dispersion=0.0,
            size_profile_likelihood_interval=None,
            numerical_status=statistical_numerical_status(
                covariance_available=False,
                inference_available=False,
                boundary="All observations are zero; the size parameter is not identifiable.",
            ),
        )
        base["warnings"].append(
            "All observations are zero; the size parameter is not identifiable."
        )
        return base
    if variance <= mean:
        standard_error = math.sqrt(mean / sample.size)
        base.update(
            status="poisson_boundary",
            mle_mean=mean,
            mle_size=None,
            mle_probability=1.0,
            mle_dispersion=0.0,
            estimated_standard_error_for_mean=standard_error,
            wald_confidence_interval_for_mean=_wald_interval(
                mean, standard_error, alpha
            ),
            size_profile_likelihood_interval=[None, None],
            numerical_status=statistical_numerical_status(
                covariance_available=False,
                inference_available=False,
                boundary=(
                    "The negative-binomial size is infinite on the Poisson boundary."
                ),
            ),
        )
        base["warnings"].append(
            "The sample variance does not exceed the mean; the NB MLE is on the Poisson boundary R = infinity."
        )
        return base

    moment_size = mean**2 / (variance - mean)
    objective = lambda log_size: -_negative_binomial_profile_log_likelihood(
        sample, mean, float(log_size)
    )
    fit = scipy_optimize.minimize_scalar(
        objective,
        bounds=(-16.0, 30.0),
        method="bounded",
        options={"xatol": 1e-10},
    )
    optimization_diagnostics = optimizer_convergence_diagnostics(
        fit,
        parameters=np.asarray([fit.x], dtype=float),
        objective_value=float(fit.fun),
        method="bounded scalar minimization",
    )
    if not optimization_diagnostics["converged"]:
        failure_reason = "negative-binomial numerical MLE failed"
        base.update(
            status="not_run",
            reason=failure_reason,
            convergence=optimization_diagnostics,
            numerical_status=statistical_numerical_status(
                optimization=optimization_diagnostics,
                covariance_available=False,
                inference_available=False,
                failure_reason=failure_reason,
            ),
        )
        return base
    log_size = float(fit.x)
    size = math.exp(log_size)
    probability = size / (size + mean)
    dispersion = 1.0 / size
    maximized_log_likelihood = -float(fit.fun)
    cutoff = float(scipy_stats.chi2.ppf(1.0 - alpha, 1))

    def profile_target(candidate: float) -> float:
        return 2.0 * (
            maximized_log_likelihood
            - _negative_binomial_profile_log_likelihood(sample, mean, candidate)
        ) - cutoff

    lower_log = -16.0
    upper_log = 30.0
    lower = None
    upper = None
    profile_warnings: list[str] = []
    profile_convergence: dict[str, dict[str, Any]] = {}

    def profile_limit(
        label: str, bracket_lower: float, bracket_upper: float
    ) -> float | None:
        try:
            root, root_result = scipy_optimize.brentq(
                profile_target,
                bracket_lower,
                bracket_upper,
                xtol=1e-12,
                rtol=1e-12,
                full_output=True,
                disp=False,
            )
        except (RuntimeError, ValueError) as exc:
            reason = f"{label} profile-likelihood root finding failed: {exc}"
            profile_convergence[label] = {
                "status": "failed",
                "method": "Brent root finding",
                "reason": reason,
            }
            profile_warnings.append(reason)
            return None
        residual = float(profile_target(float(root)))
        converged = bool(
            root_result.converged
            and math.isfinite(residual)
            and abs(residual) <= 1e-8
        )
        profile_convergence[label] = {
            "status": "converged" if converged else "failed",
            "method": "Brent root finding",
            "iterations": int(root_result.iterations),
            "function_evaluations": int(root_result.function_calls),
            "residual": residual if math.isfinite(residual) else None,
            "flag": str(root_result.flag),
        }
        if not converged:
            reason = (
                f"{label} profile-likelihood root finding did not meet its "
                "convergence and residual checks"
            )
            profile_convergence[label]["reason"] = reason
            profile_warnings.append(reason)
            return None
        return math.exp(float(root))

    if profile_target(lower_log) > 0.0:
        lower = profile_limit("lower", lower_log, log_size)
    else:
        profile_convergence["lower"] = {
            "status": "outside_search_range",
            "method": "profile-likelihood bracket check",
            "search_boundary": math.exp(lower_log),
        }
    if profile_target(upper_log) > 0.0:
        upper = profile_limit("upper", log_size, upper_log)
    else:
        profile_convergence["upper"] = {
            "status": "unbounded_at_requested_level",
            "method": "profile-likelihood bracket check",
            "search_boundary": math.exp(upper_log),
        }
    if profile_convergence["lower"]["status"] == "outside_search_range":
        profile_warnings.append(
            "The lower profile-likelihood limit for R lies below the numerical search range."
        )
    if profile_convergence["upper"]["status"] == "unbounded_at_requested_level":
        profile_warnings.append(
            "The upper profile-likelihood limit for R is unbounded at the requested level."
        )
    base["warnings"].extend(profile_warnings)
    standard_error = math.sqrt((mean + mean**2 / size) / sample.size)
    mean_wald_interval = _wald_interval(mean, standard_error, alpha)
    information = None
    optimizer_covariance = None
    information_diagnostics = None
    hessian_diagnostics = None
    transformed_covariance = None
    transformed_standard_errors = None
    transformed_mean_interval = None
    transformed_size_interval = None
    transformed_probability_interval = None
    transformed_dispersion_interval = None
    try:
        log_mean = math.log(mean)

        def joint_objective(log_parameters: np.ndarray) -> float:
            candidate_mean = math.exp(float(log_parameters[0]))
            candidate_size = math.exp(float(log_parameters[1]))
            log_total = math.log(candidate_size + candidate_mean)
            return -float(
                np.sum(
                    scipy_special.gammaln(sample + candidate_size)
                    - scipy_special.gammaln(candidate_size)
                    - scipy_special.gammaln(sample + 1.0)
                    + candidate_size * (math.log(candidate_size) - log_total)
                    + sample * (math.log(candidate_mean) - log_total)
                )
            )

        information, hessian_diagnostics = numerical_hessian(
            joint_objective, np.asarray([log_mean, log_size])
        )
        optimizer_covariance, information_diagnostics = (
            covariance_from_information(information)
        )
        probability_derivative = probability * (1.0 - probability)
        jacobian = np.asarray(
            [
                [mean, 0.0],
                [0.0, size],
                [-probability_derivative, probability_derivative],
                [0.0, -dispersion],
            ]
        )
        transformed_covariance = delta_method_covariance(
            optimizer_covariance, jacobian
        )
        transformed_standard_errors = {
            name: math.sqrt(
                max(0.0, float(transformed_covariance[index, index]))
            )
            for index, name in enumerate(
                ["mean", "size", "probability", "dispersion"]
            )
        }
        critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
        log_standard_errors = np.sqrt(
            np.maximum(0.0, np.diag(optimizer_covariance))
        )
        log_odds_variance = float(
            np.asarray([-1.0, 1.0])
            @ optimizer_covariance
            @ np.asarray([-1.0, 1.0])
        )
        log_odds_standard_error = math.sqrt(max(0.0, log_odds_variance))
        log_odds = log_size - log_mean
        transformed_mean_interval = [
            math.exp(log_mean - critical * log_standard_errors[0]),
            math.exp(log_mean + critical * log_standard_errors[0]),
        ]
        transformed_size_interval = [
            math.exp(log_size - critical * log_standard_errors[1]),
            math.exp(log_size + critical * log_standard_errors[1]),
        ]
        transformed_probability_interval = [
            float(scipy_special.expit(log_odds - critical * log_odds_standard_error)),
            float(scipy_special.expit(log_odds + critical * log_odds_standard_error)),
        ]
        transformed_dispersion_interval = [
            math.exp(-log_size - critical * log_standard_errors[1]),
            math.exp(-log_size + critical * log_standard_errors[1]),
        ]
        if not hessian_diagnostics["step_stable"]:
            base["warnings"].append(
                "The joint negative-binomial Hessian changed materially when its finite-difference step was halved."
            )
    except NumericalComputationError as exc:
        information_diagnostics = exc.diagnostics or None
        base["warnings"].append(
            f"Joint Wald covariance inference is unavailable: {exc}."
        )
    base.update(
        status="completed",
        method_of_moments_size=moment_size,
        mle_mean=mean,
        mle_size=size,
        mle_probability=probability,
        mle_dispersion=dispersion,
        maximized_log_likelihood=maximized_log_likelihood,
        estimated_standard_error_for_mean=standard_error,
        wald_confidence_interval_for_mean=mean_wald_interval,
        size_profile_likelihood_interval=[lower, upper],
        size_profile_likelihood_convergence=profile_convergence,
        observed_information_type=(
            "numerical Hessian of the joint negative log-likelihood on log-mean and log-size scales"
        ),
        optimizer_parameter_names=["log_mean", "log_size"],
        observed_information_matrix=(
            information.tolist() if information is not None else None
        ),
        optimizer_scale_covariance_matrix=(
            optimizer_covariance.tolist()
            if optimizer_covariance is not None
            else None
        ),
        information_matrix_diagnostics=information_diagnostics,
        numerical_hessian_diagnostics=hessian_diagnostics,
        transformed_parameter_names=["mean", "size", "probability", "dispersion"],
        transformed_parameter_covariance_matrix=(
            transformed_covariance.tolist()
            if transformed_covariance is not None
            else None
        ),
        transformed_parameter_standard_errors=transformed_standard_errors,
        transformed_wald_interval_for_mean=transformed_mean_interval,
        transformed_wald_interval_for_size=transformed_size_interval,
        transformed_wald_interval_for_probability=transformed_probability_interval,
        transformed_wald_interval_for_dispersion=transformed_dispersion_interval,
        convergence=optimization_diagnostics,
        covariance_type="model-based inverse observed information; not sandwich",
        numerical_status=statistical_numerical_status(
            optimization=optimization_diagnostics,
            information=information_diagnostics,
            differentiation=hessian_diagnostics,
            covariance_available=optimizer_covariance is not None,
            inference_available=optimizer_covariance is not None,
            additional_warnings=profile_warnings,
        ),
    )
    if mean_wald_interval is not None and mean_wald_interval[0] < 0.0:
        base["warnings"].append(
            "The Wald interval for the mean has a negative lower endpoint; profile or transformed inference is preferable near zero."
        )
    return base


def poisson_estimation(
    values: Any,
    column: str,
    alpha: float,
    alternative: str,
    null_mean: float | None = None,
) -> dict[str, Any]:
    sample = _integer_values(values, "Poisson estimation", 0)
    observations = int(sample.size)
    total = int(np.sum(sample))
    estimate = total / observations
    standard_error = math.sqrt(estimate / observations)
    fisher_information = observations / estimate if estimate > 0.0 else None
    wald_interval = _wald_interval(estimate, standard_error, alpha)
    lower_total = (
        0.0
        if total == 0
        else 0.5 * float(scipy_stats.chi2.ppf(alpha / 2.0, 2 * total))
    )
    upper_total = 0.5 * float(
        scipy_stats.chi2.ppf(1.0 - alpha / 2.0, 2 * (total + 1))
    )
    exact_interval = [lower_total / observations, upper_total / observations]
    maximized_log_likelihood = float(
        np.sum(scipy_stats.poisson.logpmf(sample, estimate))
    )
    variance = float(np.var(sample, ddof=1)) if observations > 1 else None
    dispersion = variance / estimate if variance is not None and estimate > 0 else None
    tests: list[dict[str, Any]] = []
    if variance is not None and estimate > 0.0:
        dispersion_statistic = (observations - 1) * variance / estimate
        dispersion_p_value = min(
            1.0,
            2.0
            * min(
                float(scipy_stats.chi2.cdf(dispersion_statistic, observations - 1)),
                float(scipy_stats.chi2.sf(dispersion_statistic, observations - 1)),
            ),
        )
        tests.append(
            {
                "method": "index-of-dispersion test",
                "status": "completed",
                "statistic": dispersion_statistic,
                "degrees_of_freedom": observations - 1,
                "p_value": dispersion_p_value,
                "reference_distribution": "chi-square approximation under Poisson equidispersion",
            }
        )
    if null_mean is not None:
        if not math.isfinite(null_mean) or null_mean < 0.0:
            raise DiscreteEstimationError("the null Poisson mean must be nonnegative")
        boundary_null = null_mean == 0.0
        if boundary_null:
            tests.append(
                {
                    "method": "Wald z-test",
                    "status": "not_run",
                    "reason": "the null mean lies on the boundary lambda = 0",
                }
            )
            tests.append(
                {
                    "method": "score z-test",
                    "status": "not_run",
                    "reason": "the null model is on the boundary with zero variance",
                }
            )
        else:
            tests.append(
                _wald_test(estimate, null_mean, standard_error, alternative)
            )
            null_standard_error = math.sqrt(null_mean / observations)
            score = (estimate - null_mean) / null_standard_error
            tests.append(
                {
                    "method": "score z-test",
                    "status": "completed",
                    "statistic": score,
                    "p_value": _normal_p_value(score, alternative),
                }
            )
        null_total_mean = observations * null_mean
        lower_tail = float(scipy_stats.poisson.cdf(total, null_total_mean))
        upper_tail = float(scipy_stats.poisson.sf(total - 1, null_total_mean))
        exact_p = (
            lower_tail
            if alternative == "less"
            else upper_tail
            if alternative == "greater"
            else min(1.0, 2.0 * min(lower_tail, upper_tail))
        )
        tests.append(
            {
                "method": "exact Poisson tail test",
                "status": "completed",
                "statistic": total,
                "p_value": exact_p,
                "two_sided_definition": "twice the smaller exact tail",
            }
        )
        if alternative == "two-sided":
            null_log_likelihood = float(
                np.sum(scipy_stats.poisson.logpmf(sample, null_mean))
            )
            tests.append(
                _likelihood_ratio_test(
                    maximized_log_likelihood,
                    null_log_likelihood,
                    boundary_null,
                )
            )
    warnings: list[str] = []
    if wald_interval is None:
        warnings.append(
            "The Wald standard error degenerates when the estimated Poisson mean is zero."
        )
    elif wald_interval[0] < 0.0:
        warnings.append(
            "The unbounded Wald interval has a negative lower endpoint; the exact Garwood interval remains nonnegative."
        )
    return {
        "method": "Poisson mean estimation",
        "distribution": "poisson",
        "column": column,
        "parameterization": "count per observation with mean lambda; support 0, 1, ...",
        "status": "completed",
        "observations": observations,
        "total_events": total,
        "mle_mean": estimate,
        "estimated_standard_error": standard_error,
        "estimated_fisher_information": fisher_information,
        "fisher_information_type": (
            "expected Fisher information evaluated at the MLE; it equals the "
            "observed information at an interior MLE"
        ),
        "sample_variance": variance,
        "variance_to_mean_ratio": dispersion,
        "confidence_level": 1.0 - alpha,
        "wald_confidence_interval": wald_interval,
        "exact_garwood_confidence_interval": exact_interval,
        "maximized_log_likelihood": maximized_log_likelihood,
        "null_value": null_mean,
        "alternative": alternative,
        "tests": tests,
        "warnings": warnings,
    }


def poisson_summary_estimation(
    observations: int,
    total_events: int,
    alpha: float,
    alternative: str,
    null_mean: float | None = None,
) -> dict[str, Any]:
    if observations < 1 or total_events < 0:
        raise DiscreteEstimationError(
            "Poisson summary estimation requires positive OBSERVATIONS and nonnegative TOTAL_EVENTS"
        )
    estimate = total_events / observations
    standard_error = math.sqrt(estimate / observations)
    fisher_information = observations / estimate if estimate > 0.0 else None
    wald_interval = _wald_interval(estimate, standard_error, alpha)
    lower_total = (
        0.0
        if total_events == 0
        else 0.5
        * float(scipy_stats.chi2.ppf(alpha / 2.0, 2 * total_events))
    )
    upper_total = 0.5 * float(
        scipy_stats.chi2.ppf(1.0 - alpha / 2.0, 2 * (total_events + 1))
    )
    maximized_log_likelihood = (
        total_events * math.log(estimate) - observations * estimate
        if total_events
        else 0.0
    )
    tests: list[dict[str, Any]] = []
    if null_mean is not None:
        if not math.isfinite(null_mean) or null_mean < 0.0:
            raise DiscreteEstimationError("the null Poisson mean must be nonnegative")
        boundary_null = null_mean == 0.0
        if boundary_null:
            tests.append(
                {
                    "method": "Wald z-test",
                    "status": "not_run",
                    "reason": "the null mean lies on the boundary lambda = 0",
                }
            )
            tests.append(
                {
                    "method": "score z-test",
                    "status": "not_run",
                    "reason": "the null model is on the boundary with zero variance",
                }
            )
        else:
            tests.append(
                _wald_test(estimate, null_mean, standard_error, alternative)
            )
            score = (estimate - null_mean) / math.sqrt(
                null_mean / observations
            )
            tests.append(
                {
                    "method": "score z-test",
                    "status": "completed",
                    "statistic": score,
                    "p_value": _normal_p_value(score, alternative),
                }
            )
        null_total_mean = observations * null_mean
        lower_tail = float(scipy_stats.poisson.cdf(total_events, null_total_mean))
        upper_tail = float(scipy_stats.poisson.sf(total_events - 1, null_total_mean))
        exact_p = (
            lower_tail
            if alternative == "less"
            else upper_tail
            if alternative == "greater"
            else min(1.0, 2.0 * min(lower_tail, upper_tail))
        )
        tests.append(
            {
                "method": "exact Poisson tail test",
                "status": "completed",
                "statistic": total_events,
                "p_value": exact_p,
                "two_sided_definition": "twice the smaller exact tail",
            }
        )
        if alternative == "two-sided":
            null_log_likelihood = float(
                scipy_special.xlogy(total_events, null_mean)
                - observations * null_mean
            )
            tests.append(
                _likelihood_ratio_test(
                    maximized_log_likelihood,
                    null_log_likelihood,
                    boundary_null,
                )
            )
    warnings: list[str] = []
    if wald_interval is None:
        warnings.append(
            "The Wald standard error degenerates when the estimated Poisson mean is zero."
        )
    elif wald_interval[0] < 0.0:
        warnings.append(
            "The unbounded Wald interval has a negative lower endpoint; the exact Garwood interval remains nonnegative."
        )
    return {
        "method": "Poisson mean estimation from summary data",
        "distribution": "poisson",
        "column": "summary data",
        "parameterization": "count per observation with mean lambda; support 0, 1, ...",
        "source": "summary_data",
        "status": "completed",
        "observations": observations,
        "total_events": total_events,
        "mle_mean": estimate,
        "estimated_standard_error": standard_error,
        "estimated_fisher_information": fisher_information,
        "fisher_information_type": (
            "expected Fisher information evaluated at the MLE; it equals the "
            "observed information at an interior MLE"
        ),
        "sample_variance": None,
        "variance_to_mean_ratio": None,
        "confidence_level": 1.0 - alpha,
        "wald_confidence_interval": wald_interval,
        "exact_garwood_confidence_interval": [
            lower_total / observations,
            upper_total / observations,
        ],
        "maximized_log_likelihood_without_constant": maximized_log_likelihood,
        "null_value": null_mean,
        "alternative": alternative,
        "tests": tests,
        "warnings": warnings,
    }


def discrete_uniform_estimation(
    values: Any,
    column: str,
    alpha: float,
    null_maximum: int | None = None,
    observations_override: int | None = None,
) -> dict[str, Any]:
    sample = _integer_values(values, "discrete-uniform estimation", 1)
    observations = (
        int(sample.size) if observations_override is None else observations_override
    )
    if observations < 1:
        raise DiscreteEstimationError(
            "discrete-uniform estimation requires positive OBSERVATIONS"
        )
    maximum = int(np.max(sample))
    upper = int(math.floor(maximum / alpha ** (1.0 / observations)))
    tests: list[dict[str, Any]] = []
    if null_maximum is not None:
        if null_maximum < 1:
            raise DiscreteEstimationError(
                "the null discrete-uniform maximum must be positive"
            )
        if maximum > null_maximum:
            p_value = 0.0
            statistic = math.inf
        else:
            p_value = (maximum / null_maximum) ** observations
            statistic = 2.0 * observations * math.log(null_maximum / maximum)
        tests.append(
            {
                "method": "exact likelihood-ratio test for the endpoint",
                "status": "completed",
                "statistic": finite_or_none(statistic),
                "p_value": p_value,
                "null_value": null_maximum,
            }
        )
    return {
        "method": "discrete-uniform endpoint estimation",
        "distribution": "discrete-uniform",
        "column": column,
        "parameterization": "equal probabilities on the integers 1 through N",
        "status": "completed",
        "observations": observations,
        "sample_maximum": maximum,
        "mle_maximum": maximum,
        "confidence_level": 1.0 - alpha,
        "exact_one_sided_confidence_set": [maximum, upper],
        "maximized_log_likelihood": -observations * math.log(maximum),
        "null_value": null_maximum,
        "tests": tests,
        "warnings": [
            "N is an integer and determines the support, so ordinary Wald inference is not valid.",
            "The MLE sample maximum is downward biased for finite samples.",
        ],
    }


def _hypergeometric_log_likelihoods(
    sample: np.ndarray,
    population_size: int,
    draws: int,
) -> tuple[np.ndarray, np.ndarray]:
    lower = int(np.max(sample))
    upper = int(population_size - draws + np.min(sample))
    candidates = np.arange(lower, upper + 1, dtype=int)
    log_likelihoods = np.asarray(
        [
            float(
                np.sum(
                    scipy_stats.hypergeom.logpmf(
                        sample, population_size, candidate, draws
                    )
                )
            )
            for candidate in candidates
        ]
    )
    return candidates, log_likelihoods


def _single_hypergeometric_exact_lr_p_value(
    observed: int,
    population_size: int,
    draws: int,
    null_successes: int,
) -> float:
    lower = max(0, draws - (population_size - null_successes))
    upper = min(draws, null_successes)

    def lr_statistic(value: int) -> float:
        sample = np.asarray([value], dtype=int)
        candidates, likelihoods = _hypergeometric_log_likelihoods(
            sample, population_size, draws
        )
        null_ll = float(
            scipy_stats.hypergeom.logpmf(
                value, population_size, null_successes, draws
            )
        )
        return max(0.0, 2.0 * (float(np.max(likelihoods)) - null_ll))

    observed_statistic = lr_statistic(observed)
    p_value = 0.0
    for value in range(lower, upper + 1):
        if lr_statistic(value) >= observed_statistic - 1e-12:
            p_value += float(
                scipy_stats.hypergeom.pmf(
                    value, population_size, null_successes, draws
                )
            )
    return min(1.0, p_value)


def hypergeometric_estimation(
    values: Any,
    column: str,
    population_size: int,
    draws: int,
    alpha: float,
    null_population_successes: int | None = None,
) -> dict[str, Any]:
    if population_size < 1 or not 1 <= draws <= population_size:
        raise DiscreteEstimationError(
            "hypergeometric estimation requires 1 <= DRAWS <= POPULATION_SIZE"
        )
    sample = _integer_values(values, "hypergeometric estimation", 0)
    if np.any(sample > draws):
        raise DiscreteEstimationError(
            "hypergeometric observations cannot exceed the number of draws"
        )
    candidates, log_likelihoods = _hypergeometric_log_likelihoods(
        sample, population_size, draws
    )
    maximum = float(np.max(log_likelihoods))
    mle_values = candidates[np.isclose(log_likelihoods, maximum, atol=1e-10)]
    cutoff = float(scipy_stats.chi2.ppf(1.0 - alpha, 1))
    lr_statistics = 2.0 * (maximum - log_likelihoods)
    confidence_candidates = candidates[lr_statistics <= cutoff + 1e-12]
    interval_method = "asymptotic likelihood-ratio"
    exact_inversion_feasible = (
        sample.size == 1 and candidates.size <= 500 and draws <= 200
    )
    warnings = [
        "The unknown population-success count is an integer; ordinary Wald inference is not used."
    ]
    if exact_inversion_feasible:
        exact_candidates = []
        observed = int(sample[0])
        for candidate in candidates:
            p_value = _single_hypergeometric_exact_lr_p_value(
                observed, population_size, draws, int(candidate)
            )
            if p_value >= alpha - 1e-12:
                exact_candidates.append(int(candidate))
        if exact_candidates:
            confidence_candidates = np.asarray(exact_candidates, dtype=int)
            interval_method = "exact likelihood-ratio inversion"
    elif sample.size == 1:
        warnings.append(
            "Exact confidence-set inversion was replaced by the asymptotic likelihood-ratio set because the candidate space is large."
        )
    tests: list[dict[str, Any]] = []
    if null_population_successes is not None:
        if not 0 <= null_population_successes <= population_size:
            raise DiscreteEstimationError(
                "the null number of population successes must be from 0 through N"
            )
        null_likelihood = float(
            np.sum(
                scipy_stats.hypergeom.logpmf(
                    sample,
                    population_size,
                    null_population_successes,
                    draws,
                )
            )
        )
        if not math.isfinite(null_likelihood):
            statistic = math.inf
            p_value = 0.0
            reference = "null model assigns zero probability to the observations"
        else:
            statistic = max(0.0, 2.0 * (maximum - null_likelihood))
            if exact_inversion_feasible:
                p_value = _single_hypergeometric_exact_lr_p_value(
                    int(sample[0]),
                    population_size,
                    draws,
                    null_population_successes,
                )
                reference = "exact likelihood-ratio ordering"
            else:
                p_value = float(scipy_stats.chi2.sf(statistic, 1))
                reference = "asymptotic chi-square"
        tests.append(
            {
                "method": "hypergeometric likelihood-ratio test",
                "status": "completed",
                "statistic": finite_or_none(statistic),
                "p_value": p_value,
                "reference_distribution": reference,
                "null_value": null_population_successes,
            }
        )
    return {
        "method": "hypergeometric population-success estimation",
        "distribution": "hypergeometric",
        "column": column,
        "parameterization": (
            "success count in draws without replacement from a finite population"
        ),
        "status": "completed",
        "observations": int(sample.size),
        "population_size": population_size,
        "draws_per_observation": draws,
        "mle_population_successes": [int(value) for value in mle_values],
        "mle_population_proportions": [
            float(value / population_size) for value in mle_values
        ],
        "maximized_log_likelihood": maximum,
        "confidence_level": 1.0 - alpha,
        "confidence_set_method": interval_method,
        "confidence_set_for_population_successes": [
            int(confidence_candidates[0]),
            int(confidence_candidates[-1]),
        ],
        "null_value": null_population_successes,
        "tests": tests,
        "warnings": warnings,
    }


def _beta_binomial_log_likelihood(
    successes: np.ndarray,
    trials: np.ndarray,
    logit_mean: float,
    log_concentration: float,
) -> float:
    mean = float(scipy_special.expit(logit_mean))
    concentration = math.exp(log_concentration)
    alpha_parameter = mean * concentration
    beta_parameter = (1.0 - mean) * concentration
    return float(
        np.sum(
            scipy_special.gammaln(trials + 1.0)
            - scipy_special.gammaln(successes + 1.0)
            - scipy_special.gammaln(trials - successes + 1.0)
            + scipy_special.betaln(
                successes + alpha_parameter,
                trials - successes + beta_parameter,
            )
            - scipy_special.betaln(alpha_parameter, beta_parameter)
        )
    )


def beta_binomial_estimation(
    successes: Any,
    trials: Any,
    column: str,
    alpha: float,
    trials_source: str,
) -> dict[str, Any]:
    success_array = np.asarray(successes, dtype=float)
    trial_array = np.asarray(trials, dtype=float)
    complete = np.isfinite(success_array) & np.isfinite(trial_array)
    success_array = success_array[complete]
    trial_array = trial_array[complete]
    if success_array.size < 3:
        raise DiscreteEstimationError(
            "beta-binomial estimation requires at least 3 complete groups"
        )
    if (
        np.any(success_array < 0)
        or np.any(trial_array < 1)
        or np.any(success_array != np.floor(success_array))
        or np.any(trial_array != np.floor(trial_array))
        or np.any(success_array > trial_array)
    ):
        raise DiscreteEstimationError(
            "beta-binomial successes and trials must be integers satisfying "
            "0 <= successes <= trials"
        )
    if float(np.max(trial_array)) <= 1.0:
        raise DiscreteEstimationError(
            "beta-binomial overdispersion is not identifiable when every group has only one trial"
        )
    pooled_mean = float(np.sum(success_array) / np.sum(trial_array))
    if not 0.0 < pooled_mean < 1.0:
        raise DiscreteEstimationError(
            "beta-binomial alpha and beta are not jointly identifiable when every group is at the same boundary"
        )
    expected_variance = trial_array * pooled_mean * (1.0 - pooled_mean)
    pearson = float(
        np.sum((success_array - trial_array * pooled_mean) ** 2 / expected_variance)
        / max(1, success_array.size - 1)
    )
    mean_trials = float(np.mean(trial_array))
    rho_start = (
        max(1e-4, min(0.9, (pearson - 1.0) / max(1.0, mean_trials - 1.0)))
        if pearson > 1.0
        else 1e-4
    )
    concentration_start = 1.0 / rho_start - 1.0
    start = np.asarray(
        [scipy_special.logit(pooled_mean), math.log(concentration_start)]
    )

    def objective(parameters: np.ndarray) -> float:
        return -_beta_binomial_log_likelihood(
            success_array, trial_array, float(parameters[0]), float(parameters[1])
        )

    fit = scipy_optimize.minimize(
        objective,
        start,
        method="L-BFGS-B",
        bounds=[(-15.0, 15.0), (-12.0, 20.0)],
    )
    optimization_diagnostics = optimizer_convergence_diagnostics(
        fit,
        parameters=np.asarray(fit.x, dtype=float),
        objective_value=float(fit.fun),
        method="L-BFGS-B",
    )
    if not optimization_diagnostics["converged"]:
        failure_reason = "beta-binomial numerical MLE failed"
        return {
            "method": "beta-binomial maximum-likelihood estimation",
            "distribution": "beta-binomial",
            "column": column,
            "parameterization": (
                "group success probability is beta(alpha, beta), followed by a binomial count"
            ),
            "trials_source": trials_source,
            "status": "not_run",
            "reason": failure_reason,
            "groups": int(success_array.size),
            "total_successes": int(np.sum(success_array)),
            "total_trials": int(np.sum(trial_array)),
            "confidence_level": 1.0 - alpha,
            "convergence": optimization_diagnostics,
            "numerical_status": statistical_numerical_status(
                optimization=optimization_diagnostics,
                covariance_available=False,
                inference_available=False,
                failure_reason=failure_reason,
            ),
            "tests": [],
            "warnings": [],
        }
    logit_mean, log_concentration = map(float, fit.x)
    mean = float(scipy_special.expit(logit_mean))
    concentration = math.exp(log_concentration)
    rho = 1.0 / (concentration + 1.0)
    alpha_parameter = mean * concentration
    beta_parameter = (1.0 - mean) * concentration
    warnings: list[str] = []
    mean_interval = None
    rho_interval = None
    hessian = None
    optimizer_covariance = None
    transformed_covariance = None
    information_diagnostics = None
    hessian_diagnostics = None
    transformed_standard_errors = None
    try:
        hessian, hessian_diagnostics = numerical_hessian(
            objective, np.asarray(fit.x, dtype=float)
        )
        optimizer_covariance, information_diagnostics = (
            covariance_from_information(hessian)
        )
        derivative_mean = mean * (1.0 - mean)
        jacobian = np.asarray(
            [
                [concentration * derivative_mean, alpha_parameter],
                [-concentration * derivative_mean, beta_parameter],
                [derivative_mean, 0.0],
                [0.0, concentration],
                [0.0, -concentration / (concentration + 1.0) ** 2],
            ]
        )
        transformed_covariance = delta_method_covariance(
            optimizer_covariance, jacobian
        )
        transformed_standard_errors = {
            name: math.sqrt(max(0.0, float(transformed_covariance[index, index])))
            for index, name in enumerate(
                ("alpha", "beta", "mean_probability", "concentration", "intraclass_correlation")
            )
        }
        critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
        se_logit_mean = math.sqrt(float(optimizer_covariance[0, 0]))
        se_log_concentration = math.sqrt(float(optimizer_covariance[1, 1]))
        mean_interval = [
            float(scipy_special.expit(logit_mean - critical * se_logit_mean)),
            float(scipy_special.expit(logit_mean + critical * se_logit_mean)),
        ]
        rho_interval = [
            float(
                scipy_special.expit(
                    -(log_concentration + critical * se_log_concentration)
                )
            ),
            float(
                scipy_special.expit(
                    -(log_concentration - critical * se_log_concentration)
                )
            ),
        ]
        if not hessian_diagnostics["step_stable"]:
            warnings.append(
                "The numerical Hessian changed materially when the finite-difference step was halved."
            )
    except NumericalComputationError as exc:
        if exc.diagnostics:
            information_diagnostics = exc.diagnostics
        warnings.append(
            f"Wald intervals could not be obtained from the observed-information matrix: {exc}."
        )
    binomial_log_likelihood = float(
        np.sum(
            scipy_special.gammaln(trial_array + 1.0)
            - scipy_special.gammaln(success_array + 1.0)
            - scipy_special.gammaln(trial_array - success_array + 1.0)
            + scipy_special.xlogy(success_array, pooled_mean)
            + scipy_special.xlog1py(trial_array - success_array, -pooled_mean)
        )
    )
    likelihood_ratio = max(0.0, 2.0 * (-float(fit.fun) - binomial_log_likelihood))
    concentration_boundary = concentration > 1.0e7
    boundary_message = None
    if concentration_boundary:
        rho_interval = None
        boundary_message = (
            "The beta-binomial concentration is effectively nonidentified on the binomial boundary."
        )
        warnings.append(
            "The concentration estimate is extremely large, indicating the binomial boundary with negligible extra-binomial variation."
        )
    return {
        "method": "beta-binomial maximum-likelihood estimation",
        "distribution": "beta-binomial",
        "column": column,
        "parameterization": (
            "group success probability is beta(alpha, beta), followed by a binomial count"
        ),
        "trials_source": trials_source,
        "status": "completed",
        "groups": int(success_array.size),
        "total_successes": int(np.sum(success_array)),
        "total_trials": int(np.sum(trial_array)),
        "mle_alpha": alpha_parameter,
        "mle_beta": beta_parameter,
        "mle_mean_probability": mean,
        "mle_concentration": concentration,
        "mle_intraclass_correlation": rho,
        "confidence_level": 1.0 - alpha,
        "transformed_wald_interval_for_mean_probability": mean_interval,
        "transformed_wald_interval_for_intraclass_correlation": rho_interval,
        "observed_information_type": (
            "numerical Hessian of the negative log-likelihood on logit-mean and log-concentration scales"
        ),
        "optimizer_parameter_names": ["logit_mean", "log_concentration"],
        "observed_information_matrix": (
            hessian.tolist() if hessian is not None else None
        ),
        "optimizer_scale_covariance_matrix": (
            optimizer_covariance.tolist()
            if optimizer_covariance is not None
            else None
        ),
        "covariance_type": "model-based inverse observed information; not sandwich",
        "information_matrix_diagnostics": information_diagnostics,
        "numerical_hessian_diagnostics": hessian_diagnostics,
        "transformed_parameter_names": [
            "alpha",
            "beta",
            "mean_probability",
            "concentration",
            "intraclass_correlation",
        ],
        "transformed_parameter_covariance_matrix": (
            transformed_covariance.tolist()
            if transformed_covariance is not None
            else None
        ),
        "transformed_parameter_standard_errors": transformed_standard_errors,
        "convergence": optimization_diagnostics,
        "numerical_status": statistical_numerical_status(
            optimization=optimization_diagnostics,
            information=information_diagnostics,
            differentiation=hessian_diagnostics,
            covariance_available=optimizer_covariance is not None,
            inference_available=(
                optimizer_covariance is not None and not concentration_boundary
            ),
            boundary=boundary_message,
        ),
        "maximized_log_likelihood": -float(fit.fun),
        "binomial_boundary_log_likelihood": binomial_log_likelihood,
        "likelihood_ratio_statistic_against_binomial_boundary": likelihood_ratio,
        "likelihood_ratio_note": (
            "The binomial null is a boundary model, so an ordinary chi-square p-value is not reported."
        ),
        "method_of_moments_start": {
            "pooled_mean_probability": pooled_mean,
            "pearson_dispersion": pearson,
            "intraclass_correlation": rho_start,
        },
        "tests": [],
        "warnings": warnings,
    }


def _wilson_from_count(count: int, total: int, alpha: float) -> list[float]:
    return _wilson_interval(count, total, alpha)


def multinomial_count_estimation(
    categories: list[str],
    counts: Any,
    column: str,
    alpha: float,
) -> dict[str, Any]:
    counts = _integer_values(counts, "multinomial estimation", 0)
    if len(categories) != counts.size or len(set(categories)) != len(categories):
        raise DiscreteEstimationError(
            "multinomial category labels must be different and match the counts"
        )
    if int(np.sum(counts)) < 1:
        raise DiscreteEstimationError(
            "multinomial estimation requires at least one observation"
        )
    total = int(np.sum(counts))
    probabilities = counts / total
    category_count = len(categories)
    simultaneous_alpha = alpha / category_count
    estimates = []
    for category, count, probability in zip(categories, counts, probabilities):
        standard_error = math.sqrt(probability * (1.0 - probability) / total)
        estimates.append(
            {
                "category": category,
                "count": int(count),
                "mle_probability": float(probability),
                "estimated_standard_error": standard_error,
                "wald_confidence_interval": _wald_interval(
                    float(probability), standard_error, alpha
                ),
                "wilson_confidence_interval": _wilson_from_count(
                    int(count), total, alpha
                ),
                "bonferroni_simultaneous_wilson_interval": _wilson_from_count(
                    int(count), total, simultaneous_alpha
                ),
            }
        )
    covariance = (
        np.diag(probabilities) - np.outer(probabilities, probabilities)
    ) / total
    count_covariance = total * (
        np.diag(probabilities) - np.outer(probabilities, probabilities)
    )
    count_moments = []
    for category, probability in zip(categories, probabilities):
        count_mean = total * probability
        count_variance = total * probability * (1.0 - probability)
        count_moments.append(
            {
                "category": category,
                "first_raw_moment": float(count_mean),
                "second_raw_moment": float(count_variance + count_mean**2),
                "second_central_moment": float(count_variance),
            }
        )
    log_likelihood = float(
        scipy_special.gammaln(total + 1.0)
        - np.sum(scipy_special.gammaln(counts + 1.0))
        + np.sum(scipy_special.xlogy(counts, probabilities))
    )
    entropy = float(-np.sum(scipy_special.xlogy(probabilities, probabilities)))
    warnings = []
    if any(
        estimate["wald_confidence_interval"] is None for estimate in estimates
    ):
        warnings.append(
            "At least one marginal Wald standard error degenerates at a boundary probability."
        )
    if any(
        estimate["wald_confidence_interval"] is not None
        and (
            estimate["wald_confidence_interval"][0] < 0.0
            or estimate["wald_confidence_interval"][1] > 1.0
        )
        for estimate in estimates
    ):
        warnings.append(
            "At least one marginal Wald interval extends outside the probability parameter space."
        )
    return {
        "method": "multinomial probability estimation",
        "distribution": "multinomial",
        "column": column,
        "parameterization": "one categorical outcome with probabilities summing to 1",
        "status": "completed",
        "observations": total,
        "categories": category_count,
        "confidence_level": 1.0 - alpha,
        "simultaneous_family_confidence_level": 1.0 - alpha,
        "category_estimates": estimates,
        "covariance_matrix": covariance.tolist(),
        "probability_estimator_covariance_matrix": covariance.tolist(),
        "multinomial_count_mean_vector": counts.astype(float).tolist(),
        "multinomial_count_covariance_matrix": count_covariance.tolist(),
        "multinomial_count_moments_at_mle": count_moments,
        "multinomial_moment_formulas": {
            "first_raw": "E[X_i] = n*p_i",
            "second_raw": "E[X_i^2] = n*p_i*(1-p_i) + (n*p_i)^2",
            "second_central": "Var(X_i) = n*p_i*(1-p_i)",
            "cross_covariance": "Cov(X_i,X_j) = -n*p_i*p_j for i != j",
        },
        "maximized_log_likelihood": log_likelihood,
        "entropy_nats": entropy,
        "tests": [],
        "warnings": warnings,
        "interval_note": (
            "Bonferroni Wilson intervals use alpha divided by the number of categories."
        ),
    }


def multinomial_estimation(
    values: pd.Series,
    column: str,
    alpha: float,
) -> dict[str, Any]:
    sample = values.dropna().astype(str)
    if sample.empty:
        raise DiscreteEstimationError(
            "multinomial estimation requires at least one nonmissing observation"
        )
    counts_series = sample.value_counts(sort=False)
    categories = sorted(str(value) for value in counts_series.index)
    counts = [int(counts_series[category]) for category in categories]
    return multinomial_count_estimation(categories, counts, column, alpha)
