"""Parametric tests for means."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .data import clean_sample, paired_samples
from .utils import decision_from_pvalue, finite_or_none, format_number


def one_sample_t_test(
    series: pd.Series,
    column_name: str,
    hypothesized_mean: float,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    sample = clean_sample(series)
    n = sample.size
    result: dict[str, Any] = {
        "method": "one-sample t-test",
        "column": column_name,
        "hypothesized_mean": hypothesized_mean,
        "alternative": alternative,
        "n": int(n),
    }
    if n < 2:
        result.update(status="not_run", reason="requires at least 2 observations")
        return result

    sample_mean = float(np.mean(sample))
    sample_std = float(np.std(sample, ddof=1))
    if sample_std == 0:
        result.update(status="not_run", reason="sample variance is zero")
        return result

    test = scipy_stats.ttest_1samp(
        sample,
        popmean=hypothesized_mean,
        alternative=alternative,
    )
    p_value = float(test.pvalue)
    standard_error = sample_std / math.sqrt(n)
    critical = float(scipy_stats.t.ppf(1.0 - alpha / 2.0, n - 1))
    margin = critical * standard_error
    result.update(
        {
            "status": "completed",
            "null_hypothesis": f"mean = {format_number(hypothesized_mean)}",
            "sample_mean": sample_mean,
            "mean_difference": sample_mean - hypothesized_mean,
            "statistic": finite_or_none(test.statistic),
            "degrees_of_freedom": int(n - 1),
            "p_value": finite_or_none(p_value),
            "confidence_level": 1.0 - alpha,
            "two_sided_confidence_interval_for_mean": [
                sample_mean - margin,
                sample_mean + margin,
            ],
            "cohens_d": (sample_mean - hypothesized_mean) / sample_std,
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result


def one_sample_z_test(
    series: pd.Series,
    column_name: str,
    hypothesized_mean: float,
    population_standard_deviation: float,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    sample = clean_sample(series)
    n = sample.size
    result: dict[str, Any] = {
        "method": "one-sample population-mean z-test",
        "column": column_name,
        "hypothesized_mean": hypothesized_mean,
        "population_standard_deviation": population_standard_deviation,
        "alternative": alternative,
        "n": int(n),
    }
    if n < 1:
        result.update(status="not_run", reason="requires at least 1 observation")
        return result

    sample_mean = float(np.mean(sample))
    standard_error = population_standard_deviation / math.sqrt(n)
    z_score = (sample_mean - hypothesized_mean) / standard_error
    if alternative == "two-sided":
        p_value = float(2.0 * scipy_stats.norm.sf(abs(z_score)))
    elif alternative == "less":
        p_value = float(scipy_stats.norm.cdf(z_score))
    else:
        p_value = float(scipy_stats.norm.sf(z_score))

    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    margin = critical * standard_error
    result.update(
        {
            "status": "completed",
            "null_hypothesis": f"mean = {format_number(hypothesized_mean)}",
            "sample_mean": sample_mean,
            "mean_difference": sample_mean - hypothesized_mean,
            "standard_error": standard_error,
            "z_score": finite_or_none(z_score),
            "p_value": finite_or_none(p_value),
            "confidence_level": 1.0 - alpha,
            "two_sided_confidence_interval_for_mean": [
                sample_mean - margin,
                sample_mean + margin,
            ],
            "standardized_difference": (
                sample_mean - hypothesized_mean
            ) / population_standard_deviation,
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result


def two_sample_t_test(
    first: pd.Series,
    second: pd.Series,
    first_name: str,
    second_name: str,
    equal_variance: bool,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    sample_1 = clean_sample(first)
    sample_2 = clean_sample(second)
    n_1, n_2 = sample_1.size, sample_2.size
    method = (
        "Student independent t-test"
        if equal_variance
        else "Welch independent t-test"
    )
    result: dict[str, Any] = {
        "method": method,
        "column_1": first_name,
        "column_2": second_name,
        "alternative": alternative,
        "n_1": int(n_1),
        "n_2": int(n_2),
    }
    if n_1 < 2 or n_2 < 2:
        result.update(
            status="not_run",
            reason="each independent sample requires at least 2 observations",
        )
        return result

    mean_1, mean_2 = float(np.mean(sample_1)), float(np.mean(sample_2))
    variance_1 = float(np.var(sample_1, ddof=1))
    variance_2 = float(np.var(sample_2, ddof=1))
    mean_difference = mean_1 - mean_2

    if equal_variance:
        degrees_of_freedom = n_1 + n_2 - 2
        pooled_variance = (
            (n_1 - 1) * variance_1 + (n_2 - 1) * variance_2
        ) / degrees_of_freedom
        standard_error = math.sqrt(
            pooled_variance * (1.0 / n_1 + 1.0 / n_2)
        )
    else:
        variance_term_1 = variance_1 / n_1
        variance_term_2 = variance_2 / n_2
        standard_error = math.sqrt(variance_term_1 + variance_term_2)
        denominator = (
            variance_term_1**2 / (n_1 - 1)
            + variance_term_2**2 / (n_2 - 1)
        )
        degrees_of_freedom = (
            (variance_term_1 + variance_term_2) ** 2 / denominator
            if denominator > 0
            else math.nan
        )

    if standard_error == 0 or not math.isfinite(standard_error):
        result.update(status="not_run", reason="the estimated standard error is zero")
        return result

    test = scipy_stats.ttest_ind(
        sample_1,
        sample_2,
        equal_var=equal_variance,
        alternative=alternative,
    )
    p_value = float(test.pvalue)
    critical = float(
        scipy_stats.t.ppf(1.0 - alpha / 2.0, degrees_of_freedom)
    )
    margin = critical * standard_error

    pooled_df = n_1 + n_2 - 2
    pooled_variance_effect = (
        (n_1 - 1) * variance_1 + (n_2 - 1) * variance_2
    ) / pooled_df
    pooled_std = math.sqrt(pooled_variance_effect)
    cohens_d = mean_difference / pooled_std if pooled_std > 0 else None
    correction = 1.0 - 3.0 / (4.0 * pooled_df - 1.0)
    hedges_g = cohens_d * correction if cohens_d is not None else None
    result.update(
        {
            "status": "completed",
            "null_hypothesis": "mean_1 = mean_2",
            "mean_1": mean_1,
            "mean_2": mean_2,
            "mean_difference": mean_difference,
            "statistic": finite_or_none(test.statistic),
            "degrees_of_freedom": finite_or_none(degrees_of_freedom),
            "p_value": finite_or_none(p_value),
            "confidence_level": 1.0 - alpha,
            "two_sided_confidence_interval_for_mean_difference": [
                mean_difference - margin,
                mean_difference + margin,
            ],
            "cohens_d": finite_or_none(cohens_d),
            "hedges_g": finite_or_none(hedges_g),
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result


def paired_t_test(
    first: pd.Series,
    second: pd.Series,
    first_name: str,
    second_name: str,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    sample_1, sample_2 = paired_samples(first, second)
    differences = sample_1 - sample_2
    n = differences.size
    result: dict[str, Any] = {
        "method": "paired-sample t-test",
        "column_1": first_name,
        "column_2": second_name,
        "difference_definition": f"{first_name} - {second_name}",
        "alternative": alternative,
        "n_pairs": int(n),
    }
    if n < 2:
        result.update(status="not_run", reason="requires at least 2 complete pairs")
        return result

    mean_1 = float(np.mean(sample_1))
    mean_2 = float(np.mean(sample_2))
    mean_difference = float(np.mean(differences))
    difference_std = float(np.std(differences, ddof=1))
    if difference_std == 0:
        result.update(status="not_run", reason="paired differences have zero variance")
        return result

    test = scipy_stats.ttest_rel(
        sample_1,
        sample_2,
        alternative=alternative,
    )
    p_value = float(test.pvalue)
    degrees_of_freedom = n - 1
    standard_error = difference_std / math.sqrt(n)
    critical = float(
        scipy_stats.t.ppf(1.0 - alpha / 2.0, degrees_of_freedom)
    )
    margin = critical * standard_error
    result.update(
        {
            "status": "completed",
            "null_hypothesis": "mean paired difference = 0",
            "mean_1": mean_1,
            "mean_2": mean_2,
            "mean_difference": mean_difference,
            "standard_deviation_of_differences": difference_std,
            "standard_error": standard_error,
            "statistic": finite_or_none(test.statistic),
            "degrees_of_freedom": int(degrees_of_freedom),
            "p_value": finite_or_none(p_value),
            "confidence_level": 1.0 - alpha,
            "two_sided_confidence_interval_for_mean_difference": [
                mean_difference - margin,
                mean_difference + margin,
            ],
            "cohens_dz": mean_difference / difference_std,
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result
