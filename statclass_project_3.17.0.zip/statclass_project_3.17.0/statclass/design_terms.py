"""Shared construction of polynomial and interaction design terms."""

from __future__ import annotations

from typing import Any

import numpy as np


def add_engineered_terms(
    columns: list[np.ndarray],
    terms: list[str],
    term_predictors: list[str | None],
    term_types: list[str],
    predictor_components: dict[str, list[int]],
    categorical_predictors: set[str],
    polynomial_terms: dict[str, int] | None,
    interactions: list[tuple[str, str]] | None,
) -> dict[str, Any]:
    """Append raw powers and hierarchical cross-products to design columns."""
    polynomial_terms = polynomial_terms or {}
    interactions = interactions or []
    polynomial_metadata = []
    interaction_metadata = []
    existing_terms = set(terms)

    for predictor, degree in polynomial_terms.items():
        if predictor not in predictor_components:
            continue
        if predictor in categorical_predictors:
            continue
        base_index = predictor_components[predictor][0]
        added_terms = []
        for power in range(2, degree + 1):
            term = f"{predictor}^{power}"
            if term in existing_terms:
                continue
            columns.append(np.asarray(columns[base_index], dtype=float) ** power)
            terms.append(term)
            term_predictors.append(predictor)
            term_types.append("polynomial")
            existing_terms.add(term)
            added_terms.append(term)
        polynomial_metadata.append(
            {
                "predictor": predictor,
                "degree": degree,
                "terms": added_terms,
                "basis": "raw powers",
            }
        )

    seen_interactions: set[tuple[str, str]] = set()
    for first, second in interactions:
        if first not in predictor_components or second not in predictor_components:
            continue
        key = tuple(sorted((first, second)))
        if key in seen_interactions:
            continue
        seen_interactions.add(key)
        added_terms = []
        for first_index in predictor_components[first]:
            for second_index in predictor_components[second]:
                term = f"{terms[first_index]}:{terms[second_index]}"
                if term in existing_terms:
                    continue
                columns.append(
                    np.asarray(columns[first_index], dtype=float)
                    * np.asarray(columns[second_index], dtype=float)
                )
                terms.append(term)
                term_predictors.append(f"{first}:{second}")
                term_types.append("interaction")
                existing_terms.add(term)
                added_terms.append(term)
        interaction_metadata.append(
            {
                "predictor_1": first,
                "predictor_2": second,
                "terms": added_terms,
            }
        )

    return {
        "polynomial_terms": polynomial_metadata,
        "interactions": interaction_metadata,
    }
