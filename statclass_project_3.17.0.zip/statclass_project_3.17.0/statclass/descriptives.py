"""Summary statistics and normality tests."""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .data import clean_sample
from .utils import decision_from_pvalue, finite_or_none


def summary_statistics(series: pd.Series) -> dict[str, Any]:
    sample = clean_sample(series)
    n = sample.size
    total_rows = len(series)
    result: dict[str, Any] = {
        "n": int(n),
        "missing_or_nonfinite": int(total_rows - n),
        "mean": None,
        "variance": None,
        "standard_deviation": None,
        "minimum": None,
        "first_quartile": None,
        "median": None,
        "third_quartile": None,
        "maximum": None,
        "skewness": None,
        "excess_kurtosis": None,
    }
    if n == 0:
        return result

    quartiles = np.quantile(sample, [0.25, 0.50, 0.75])
    result.update(
        {
            "mean": finite_or_none(np.mean(sample)),
            "minimum": finite_or_none(np.min(sample)),
            "first_quartile": finite_or_none(quartiles[0]),
            "median": finite_or_none(quartiles[1]),
            "third_quartile": finite_or_none(quartiles[2]),
            "maximum": finite_or_none(np.max(sample)),
        }
    )
    if n >= 2:
        result["variance"] = finite_or_none(np.var(sample, ddof=1))
        result["standard_deviation"] = finite_or_none(np.std(sample, ddof=1))
    if n >= 3 and np.ptp(sample) > 0:
        result["skewness"] = finite_or_none(
            scipy_stats.skew(sample, bias=False)
        )
    if n >= 4 and np.ptp(sample) > 0:
        result["excess_kurtosis"] = finite_or_none(
            scipy_stats.kurtosis(sample, fisher=True, bias=False)
        )
    return result


def skipped_test(method: str, reason: str) -> dict[str, Any]:
    return {"method": method, "status": "not_run", "reason": reason}


def normality_tests(series: pd.Series, alpha: float) -> list[dict[str, Any]]:
    sample = clean_sample(series)
    n = sample.size
    constant = n > 0 and np.ptp(sample) == 0
    results: list[dict[str, Any]] = []

    if n < 3:
        results.append(
            skipped_test("Shapiro-Wilk", "requires at least 3 observations")
        )
    elif n > 5000:
        results.append(
            skipped_test(
                "Shapiro-Wilk",
                "not run for n > 5000 because its p-value may be inaccurate",
            )
        )
    elif constant:
        results.append(
            skipped_test("Shapiro-Wilk", "all observations are identical")
        )
    else:
        test = scipy_stats.shapiro(sample)
        p_value = float(test.pvalue)
        results.append(
            {
                "method": "Shapiro-Wilk",
                "status": "completed",
                "null_hypothesis": "the sample comes from a normal distribution",
                "statistic": finite_or_none(test.statistic),
                "p_value": finite_or_none(p_value),
                "decision": decision_from_pvalue(p_value, alpha),
            }
        )

    method = "D'Agostino-Pearson K-squared"
    if n < 8:
        results.append(
            skipped_test(method, "requires at least 8 observations")
        )
    elif constant:
        results.append(skipped_test(method, "all observations are identical"))
    else:
        test = scipy_stats.normaltest(sample)
        p_value = float(test.pvalue)
        results.append(
            {
                "method": method,
                "status": "completed",
                "null_hypothesis": "the sample comes from a normal distribution",
                "statistic": finite_or_none(test.statistic),
                "p_value": finite_or_none(p_value),
                "decision": decision_from_pvalue(p_value, alpha),
            }
        )
    return results

