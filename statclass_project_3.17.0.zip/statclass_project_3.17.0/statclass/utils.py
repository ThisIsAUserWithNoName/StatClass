"""Shared result, formatting, and hypothesis-decision utilities."""

from __future__ import annotations

import math
from typing import Any

import numpy as np


DEFAULT_OUTPUT_PRECISION = 6
MIN_OUTPUT_PRECISION = 1
MAX_OUTPUT_PRECISION = 15
_output_precision = DEFAULT_OUTPUT_PRECISION


def set_output_precision(precision: int) -> None:
    """Set the maximum decimal places used in human-readable output."""
    if not MIN_OUTPUT_PRECISION <= precision <= MAX_OUTPUT_PRECISION:
        raise ValueError(
            f"output precision must be from {MIN_OUTPUT_PRECISION} through "
            f"{MAX_OUTPUT_PRECISION}"
        )
    global _output_precision
    _output_precision = precision


def _trim_scientific_notation(value: str) -> str:
    mantissa, exponent = value.split("e")
    mantissa = mantissa.rstrip("0").rstrip(".")
    sign = ""
    if exponent.startswith(("+", "-")):
        sign, exponent = exponent[0], exponent[1:]
    exponent = exponent.lstrip("0") or "0"
    return f"{mantissa}e{sign}{exponent}"


def finite_or_none(value: Any) -> bool | float | int | str | None:
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    if isinstance(value, (np.integer, int)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        converted = float(value)
        return converted if math.isfinite(converted) else None
    return value


def decision_from_pvalue(p_value: float, alpha: float) -> str:
    if not math.isfinite(p_value):
        return "No decision"
    if p_value < alpha:
        return f"Reject H0 at alpha = {format_number(alpha)}"
    return f"Fail to reject H0 at alpha = {format_number(alpha)}"


def make_json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): make_json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [make_json_safe(item) for item in value]
    return finite_or_none(value)


def format_number(value: Any) -> str:
    if value is None:
        return "not available"
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if not math.isfinite(value):
            return str(value)
        if value == 0.0:
            return "0"
        magnitude = abs(value)
        if magnitude < 10.0 ** (-_output_precision) or magnitude >= 1.0e12:
            return _trim_scientific_notation(
                f"{value:.{_output_precision}e}"
            )
        fixed = f"{value:.{_output_precision}f}"
        return fixed.rstrip("0").rstrip(".")
    return str(value)
