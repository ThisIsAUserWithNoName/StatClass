"""Human-readable report generation."""

from __future__ import annotations

from typing import Any

from .utils import format_number


def _format_bytes(value: Any) -> str:
    if value is None:
        return "unknown"
    amount = float(value)
    units = ("bytes", "KiB", "MiB", "GiB", "TiB")
    for unit in units:
        if amount < 1024.0 or unit == units[-1]:
            if unit == "bytes":
                return f"{int(amount)} {unit}"
            return f"{amount:.1f} {unit}"
        amount /= 1024.0
    return f"{amount:.1f} TiB"


def _format_estimation_interval(values: Any) -> str:
    if values is None:
        return "not available"
    if len(values) != 2:
        return ", ".join(format_number(value) for value in values)
    return f"({format_number(values[0])}, {format_number(values[1])})"


def _append_information_diagnostics(
    lines: list[str],
    analysis: dict[str, Any],
    *,
    diagnostics_key: str = "information_matrix_diagnostics",
    type_key: str = "observed_information_type",
    covariance_type_key: str | None = "covariance_type",
    hessian_key: str | None = "numerical_hessian_diagnostics",
    label: str = "Information matrix",
    indent: str = "  ",
) -> None:
    """Append compact curvature diagnostics suitable for a text terminal."""
    diagnostics = analysis.get(diagnostics_key)
    information_type = analysis.get(type_key)
    if information_type:
        lines.append(f"{indent}{label} source = {information_type}")
    if covariance_type_key is not None and analysis.get(covariance_type_key):
        lines.append(
            f"{indent}Covariance type = {analysis[covariance_type_key]}"
        )
    if diagnostics:
        dimension = diagnostics.get("dimension")
        rank = diagnostics.get("rank")
        rank_text = (
            f"{format_number(rank)}/{format_number(dimension)}"
            if dimension is not None
            else "not available"
        )
        lines.append(
            f"{indent}{label} diagnostics: rank = {rank_text}; "
            f"positive definite = {format_number(diagnostics.get('positive_definite'))}; "
            f"condition number = {format_number(diagnostics.get('condition_number'))}; "
            f"near singular = {format_number(diagnostics.get('near_singular'))}"
        )
        if diagnostics.get("covariance_method"):
            lines.append(
                f"{indent}Covariance calculation = "
                f"{diagnostics['covariance_method']}"
            )
        for warning in diagnostics.get("warnings", []):
            lines.append(f"{indent}Curvature warning: {warning}")
    if hessian_key is not None:
        hessian = analysis.get(hessian_key)
        if hessian:
            lines.append(
                f"{indent}Numerical Hessian: {hessian['method']}; "
                f"step stable = {format_number(hessian.get('step_stable'))}; "
                f"relative step sensitivity = "
                f"{format_number(hessian.get('step_sensitivity_relative_frobenius_norm'))}"
            )


def _append_numerical_status(
    lines: list[str], analysis: dict[str, Any], indent: str = "  "
) -> None:
    """Append uniform optimizer and numerical-inference status."""
    status = analysis.get("numerical_status")
    if not status:
        return
    lines.append(f"{indent}Numerical status = {status['status']}")
    optimization = status.get("optimization")
    if optimization:
        lines.append(
            f"{indent}Optimizer = {optimization['status']}; "
            f"method = {optimization.get('method') or 'not supplied'}; "
            f"iterations = {format_number(optimization.get('iterations'))}; "
            f"gradient infinity norm = "
            f"{format_number(optimization.get('gradient_infinity_norm'))}"
        )
        if optimization.get("message"):
            lines.append(f"{indent}Optimizer message = {optimization['message']}")
    elif status.get("method"):
        detail = (
            f"{indent}Iterative calculation = {status['method']}; "
            f"iterations = {format_number(status.get('iterations'))}; "
            f"function evaluations = "
            f"{format_number(status.get('function_evaluations'))}; "
            f"residual = {format_number(status.get('residual'))}"
        )
        lines.append(detail)
        if status.get("bracketing_iterations") is not None:
            lines.append(
                f"{indent}Search iterations: bracketing = "
                f"{status['bracketing_iterations']}; bisection = "
                f"{status.get('bisection_iterations', 0)}"
            )
    if status.get("failure_reason"):
        lines.append(f"{indent}Numerical failure = {status['failure_reason']}")
    if status.get("boundary"):
        lines.append(f"{indent}Boundary status = {status['boundary']}")
    if status.get("covariance_available") is False:
        lines.append(f"{indent}Covariance matrix = unavailable")
    if status.get("inference_available") is False:
        lines.append(f"{indent}Hessian-based Wald inference = unavailable")
    if status.get("status") != "completed":
        for warning in status.get("warnings", []):
            lines.append(f"{indent}Numerical warning: {warning}")


def _append_estimation_tests(
    lines: list[str],
    analysis: dict[str, Any],
    alpha: float,
) -> None:
    for test in analysis.get("tests", []):
        lines.append(f"  {test['method']}:")
        if test.get("status") != "completed":
            lines.append(
                f"    Not run ({test.get('reason', 'unspecified reason')})"
            )
            continue
        if test.get("statistic") is not None:
            lines.append(f"    Statistic = {format_number(test['statistic'])}")
        elif test.get("statistic_status") == "infinite":
            lines.append("    Statistic = infinity")
        if test.get("degrees_of_freedom") is not None:
            lines.append(
                f"    Degrees of freedom = {format_number(test['degrees_of_freedom'])}"
            )
        p_value = test.get("p_value")
        if p_value is not None:
            lines.append(f"    p-value = {format_number(p_value)}")
            decision = "Reject H0" if p_value < alpha else "Fail to reject H0"
            lines.append(
                f"    Decision = {decision} at alpha = {format_number(alpha)}"
            )
        if test.get("reference_distribution"):
            lines.append(
                f"    Reference = {test['reference_distribution']}"
            )


def _append_discrete_estimations(
    lines: list[str], results: dict[str, Any]
) -> None:
    analyses = results.get("discrete_distribution_estimates", [])
    if not analyses:
        return
    alpha = float(results["metadata"]["alpha"])
    lines.extend(["DISCRETE DISTRIBUTION ESTIMATION", "-" * 32])
    for analysis in analyses:
        distribution = analysis["distribution"]
        lines.append(analysis["method"])
        lines.append(f"  Column = {analysis['column']}")
        if analysis.get("parameterization"):
            lines.append(f"  Parameterization = {analysis['parameterization']}")
        if analysis.get("confidence_level") is not None:
            lines.append(
                f"  Confidence level = "
                f"{format_number(analysis['confidence_level'])}"
            )
        if analysis.get("status") not in {"completed", None}:
            lines.append(f"  Status = {analysis['status']}")
            if analysis.get("reason"):
                lines.append(f"  Reason = {analysis['reason']}")
            if analysis.get("status") == "not_run":
                _append_numerical_status(lines, analysis)
                for warning in analysis.get("warnings", []):
                    lines.append(f"  Warning: {warning}")
                lines.append("")
                continue

        if distribution in {"bernoulli", "binomial"}:
            if analysis.get("success_value") is not None:
                lines.append(f"  Success category = {analysis['success_value']}")
            if analysis.get("trials_source"):
                lines.append(f"  Trials source = {analysis['trials_source']}")
            lines.extend(
                [
                    f"  Observations = {analysis['observations']}",
                    f"  Total successes/trials = {analysis['total_successes']}/"
                    f"{analysis['total_trials']}",
                    f"  MLE of p = {format_number(analysis['mle_probability'])}",
                    f"  Estimated SE = "
                    f"{format_number(analysis['estimated_standard_error'])}",
                    f"  Expected Fisher information at MLE = "
                    f"{format_number(analysis['estimated_fisher_information'])}",
                    f"  Wald CI = {_format_estimation_interval(analysis['wald_confidence_interval'])}",
                    f"  Wilson CI = "
                    f"{_format_estimation_interval(analysis['wilson_confidence_interval'])}",
                    f"  Exact Clopper-Pearson CI = "
                    f"{_format_estimation_interval(analysis['exact_clopper_pearson_interval'])}",
                ]
            )
        elif distribution in {"geometric", "negative-binomial-known-r"}:
            lines.extend(
                [
                    f"  Observations = {analysis['observations']}",
                    f"  Total successes = {analysis['total_successes']}; "
                    f"total failures = {analysis['total_failures']}",
                    f"  MLE of p = {format_number(analysis['mle_probability'])}",
                    f"  Estimated SE = "
                    f"{format_number(analysis['estimated_standard_error'])}",
                    f"  Expected Fisher information at MLE = "
                    f"{format_number(analysis['estimated_fisher_information'])}",
                    f"  Wald CI = {_format_estimation_interval(analysis['wald_confidence_interval'])}",
                    f"  Exact stopped-trial CI = "
                    f"{_format_estimation_interval(analysis['exact_stopped_trial_interval'])}",
                ]
            )
        elif distribution == "negative-binomial":
            lines.extend(
                [
                    f"  Observations = {analysis['observations']}",
                    f"  Sample mean = {format_number(analysis['sample_mean'])}",
                    f"  Sample variance = {format_number(analysis['sample_variance'])}",
                    f"  MLE mean = {format_number(analysis.get('mle_mean'))}",
                    f"  MLE R = {format_number(analysis.get('mle_size'))}",
                    f"  MLE p = {format_number(analysis.get('mle_probability'))}",
                    f"  MLE dispersion 1/R = "
                    f"{format_number(analysis.get('mle_dispersion'))}",
                ]
            )
            if analysis.get("wald_confidence_interval_for_mean") is not None:
                lines.append(
                    f"  Wald CI for mean = "
                    f"{_format_estimation_interval(analysis['wald_confidence_interval_for_mean'])}"
                )
            if analysis.get("size_profile_likelihood_interval") is not None:
                lines.append(
                    f"  Profile-likelihood CI for R = "
                    f"{_format_estimation_interval(analysis['size_profile_likelihood_interval'])}"
                )
            if analysis.get("transformed_wald_interval_for_probability") is not None:
                lines.extend(
                    [
                        f"  Transformed Wald CI for p = "
                        f"{_format_estimation_interval(analysis['transformed_wald_interval_for_probability'])}",
                        f"  Transformed Wald CI for dispersion 1/R = "
                        f"{_format_estimation_interval(analysis['transformed_wald_interval_for_dispersion'])}",
                    ]
                )
            _append_information_diagnostics(lines, analysis)
        elif distribution == "poisson":
            lines.extend(
                [
                    f"  Observations = {analysis['observations']}; "
                    f"total events = {analysis['total_events']}",
                    f"  MLE of lambda = {format_number(analysis['mle_mean'])}",
                    f"  Estimated SE = "
                    f"{format_number(analysis['estimated_standard_error'])}",
                    f"  Expected Fisher information at MLE = "
                    f"{format_number(analysis['estimated_fisher_information'])}",
                    f"  Sample variance = {format_number(analysis['sample_variance'])}",
                    f"  Variance/mean = "
                    f"{format_number(analysis['variance_to_mean_ratio'])}",
                    f"  Wald CI = {_format_estimation_interval(analysis['wald_confidence_interval'])}",
                    f"  Exact Garwood CI = "
                    f"{_format_estimation_interval(analysis['exact_garwood_confidence_interval'])}",
                ]
            )
        elif distribution == "discrete-uniform":
            lines.extend(
                [
                    f"  Observations = {analysis['observations']}",
                    f"  Sample maximum and MLE of N = {analysis['mle_maximum']}",
                    f"  Exact one-sided confidence set for N = "
                    f"{_format_estimation_interval(analysis['exact_one_sided_confidence_set'])}",
                ]
            )
        elif distribution == "hypergeometric":
            lines.extend(
                [
                    f"  Observations = {analysis['observations']}",
                    f"  Population size = {analysis['population_size']}; "
                    f"draws per observation = {analysis['draws_per_observation']}",
                    f"  MLE value(s) of population successes = "
                    f"{', '.join(format_number(value) for value in analysis['mle_population_successes'])}",
                    f"  Confidence set = "
                    f"{_format_estimation_interval(analysis['confidence_set_for_population_successes'])}",
                    f"  Confidence-set method = {analysis['confidence_set_method']}",
                ]
            )
        elif distribution == "beta-binomial":
            lines.extend(
                [
                    f"  Complete groups = {analysis['groups']}",
                    f"  Total successes/trials = {analysis['total_successes']}/"
                    f"{analysis['total_trials']}",
                    f"  MLE alpha = {format_number(analysis['mle_alpha'])}",
                    f"  MLE beta = {format_number(analysis['mle_beta'])}",
                    f"  MLE mean probability = "
                    f"{format_number(analysis['mle_mean_probability'])}",
                    f"  MLE concentration = "
                    f"{format_number(analysis['mle_concentration'])}",
                    f"  MLE intraclass correlation = "
                    f"{format_number(analysis['mle_intraclass_correlation'])}",
                    f"  Transformed Wald CI for mean probability = "
                    f"{_format_estimation_interval(analysis['transformed_wald_interval_for_mean_probability'])}",
                    f"  Transformed Wald CI for intraclass correlation = "
                    f"{_format_estimation_interval(analysis['transformed_wald_interval_for_intraclass_correlation'])}",
                    f"  LR statistic against binomial boundary = "
                    f"{format_number(analysis['likelihood_ratio_statistic_against_binomial_boundary'])}",
                    f"  Note: {analysis['likelihood_ratio_note']}",
                ]
            )
            _append_information_diagnostics(lines, analysis)
        else:
            lines.extend(
                [
                    f"  Observations = {analysis['observations']}; "
                    f"categories = {analysis['categories']}",
                    "  Category estimates:",
                ]
            )
            for estimate in analysis["category_estimates"]:
                lines.append(
                    f"    {estimate['category']}: count = {estimate['count']}; "
                    f"p-hat = {format_number(estimate['mle_probability'])}; "
                    f"SE = {format_number(estimate['estimated_standard_error'])}; "
                    f"Wald CI = {_format_estimation_interval(estimate['wald_confidence_interval'])}; "
                    f"Wilson CI = {_format_estimation_interval(estimate['wilson_confidence_interval'])}; "
                    f"simultaneous Wilson CI = "
                    f"{_format_estimation_interval(estimate['bonferroni_simultaneous_wilson_interval'])}"
                )

        _append_numerical_status(lines, analysis)

        log_likelihood_key = next(
            (
                key
                for key in (
                    "maximized_log_likelihood",
                    "maximized_log_likelihood_without_constant",
                )
                if analysis.get(key) is not None
            ),
            None,
        )
        if log_likelihood_key is not None:
            label = (
                "Maximized log-likelihood without constant"
                if log_likelihood_key.endswith("without_constant")
                else "Maximized log-likelihood"
            )
            lines.append(
                f"  {label} = {format_number(analysis[log_likelihood_key])}"
            )
        _append_estimation_tests(lines, analysis, alpha)
        for warning in analysis.get("warnings", []):
            lines.append(f"  Warning: {warning}")
        lines.append("")


def format_test(test: dict[str, Any], indent: str = "  ") -> list[str]:
    method = test["method"]
    if test.get("status") != "completed":
        return [
            f"{indent}{method}: not run "
            f"({test.get('reason', 'unspecified reason')})"
        ]
    lines = [f"{indent}{method}:"]
    labels = (
        ("z_score", "z-score"),
        ("statistic", "Statistic"),
        ("degrees_of_freedom", "Degrees of freedom"),
        ("degrees_of_freedom_numerator", "Numerator degrees of freedom"),
        ("degrees_of_freedom_denominator", "Denominator degrees of freedom"),
        ("p_value", "p-value"),
        ("decision", "Decision"),
    )
    for key, label in labels:
        if key in test:
            lines.append(f"{indent}  {label} = {format_number(test[key])}")
    return lines


def _append_summary(lines: list[str], results: dict[str, Any]) -> None:
    if not results["summary_statistics"]:
        return
    labels = (
        ("n", "Observations"),
        ("missing_or_nonfinite", "Missing or nonfinite"),
        ("mean", "Mean"),
        ("variance", "Sample variance"),
        ("standard_deviation", "Sample standard deviation"),
        ("minimum", "Minimum"),
        ("first_quartile", "First quartile"),
        ("median", "Median"),
        ("third_quartile", "Third quartile"),
        ("maximum", "Maximum"),
        ("skewness", "Adjusted sample skewness"),
        ("excess_kurtosis", "Unbiased excess kurtosis"),
    )
    lines.extend(["SUMMARY STATISTICS", "-" * 18])
    for column, summary in results["summary_statistics"].items():
        lines.append(f"Column: {column}")
        for key, label in labels:
            lines.append(f"  {label} = {format_number(summary[key])}")
        lines.append("")


def _append_normality(lines: list[str], results: dict[str, Any]) -> None:
    if not results["normality_tests"]:
        return
    lines.extend(["NORMALITY TESTS", "-" * 15])
    lines.append("H0: the sample comes from a normal distribution.")
    for column, tests in results["normality_tests"].items():
        lines.append(f"Column: {column}")
        for test in tests:
            lines.extend(format_test(test))
        lines.append("")


def _append_resampling(lines: list[str], results: dict[str, Any]) -> None:
    bootstrap_analyses = results.get("bootstrap_analyses", [])
    if not bootstrap_analyses:
        return
    lines.extend(["BOOTSTRAP CONFIDENCE INTERVALS", "-" * 30])
    for analysis in bootstrap_analyses:
        if "difference_definition" in analysis:
            lines.append(f"Statistic: {analysis['difference_definition']}")
            lines.append(f"  Sample sizes = {analysis['n_1']} and {analysis['n_2']}")
        else:
            lines.append(
                f"Column: {analysis['column']}; statistic = {analysis['statistic']}"
            )
            lines.append(f"  Observations = {analysis['n']}")
        if analysis.get("status") != "completed":
            lines.append(f"  Analysis not run ({analysis['reason']})")
            lines.append("")
            continue
        observed_key = (
            "observed_difference"
            if "observed_difference" in analysis
            else "observed_statistic"
        )
        interval = analysis["confidence_interval"]
        lines.extend(
            [
                f"  Observed estimate = {format_number(analysis[observed_key])}",
                f"  Resamples = {analysis['bootstrap_resamples']}; "
                f"random seed = {analysis['random_seed']}",
                f"  Bootstrap mean = {format_number(analysis['bootstrap_mean'])}",
                f"  Bootstrap standard error = "
                f"{format_number(analysis['bootstrap_standard_error'])}",
                f"  Estimated bias = {format_number(analysis['bootstrap_bias'])}",
                f"  Interval method = {analysis['interval_method_used']} "
                f"(requested {analysis['interval_method_requested']})",
                f"  {format_number(100 * analysis['confidence_level'])}% "
                f"confidence interval = "
                f"({format_number(interval[0])}, {format_number(interval[1])})",
            ]
        )
        if analysis["interval_method_used"] == "bca":
            lines.append(
                f"  BCa bias correction = "
                f"{format_number(analysis['bca_bias_correction'])}; acceleration = "
                f"{format_number(analysis['bca_acceleration'])}"
            )
        lines.append("")


def _append_permutation_tests(
    lines: list[str], results: dict[str, Any]
) -> None:
    permutation_tests = results.get("permutation_tests", [])
    if not permutation_tests:
        return
    lines.extend(["PERMUTATION TESTS", "-" * 17])
    for test in permutation_tests:
        lines.append(test["method"])
        if "difference_definition" in test:
            lines.append(f"  Statistic: {test['difference_definition']}")
        else:
            lines.append(f"  Columns: {test['column_1']} and {test['column_2']}")
        if test.get("status") != "completed":
            lines.append(f"  Test not run ({test['reason']})")
            lines.append("")
            continue
        possible = test.get("possible_permutations")
        possible_text = (
            str(possible)
            if possible is not None
            else "more than the requested permutation count"
        )
        lines.extend(
            [
                f"  Observed statistic = {format_number(test['observed_statistic'])}",
                f"  Alternative = {test['alternative']}",
                f"  Enumeration = {test['enumeration']}; "
                f"permutations performed = {test['permutations_performed']}",
                f"  Possible permutations = {possible_text}",
                f"  Extreme permutations = {test['extreme_permutations']}",
                f"  p-value = {format_number(test['p_value'])}",
            ]
        )
        if test["enumeration"] == "monte_carlo":
            lines.extend(
                [
                    f"  Monte Carlo standard error = "
                    f"{format_number(test['monte_carlo_standard_error'])}",
                    f"  Random seed = {test['random_seed']}",
                ]
            )
        lines.append(f"  Decision = {test['decision']}")
        lines.append("")


def _append_transformations(
    lines: list[str], results: dict[str, Any]
) -> None:
    transformations = results.get("transformations", [])
    standardizations = results.get("standardizations", [])
    if not transformations and not standardizations:
        return
    lines.extend(["TRANSFORMATIONS AND STANDARDIZATION", "-" * 35])
    for analysis in transformations + standardizations:
        kind = (
            "Transformation"
            if analysis["analysis_type"] == "transformation"
            else "Standardization"
        )
        lines.extend(
            [
                f"{kind}: {analysis['column']} -> {analysis['output_column']}",
                f"  Method = {analysis['method']}",
                f"  Formula = {analysis['formula']}",
            ]
        )
        if analysis.get("parameter") is not None:
            lines.append(
                f"  Parameter = {format_number(analysis['parameter'])} "
                f"({analysis['parameter_source']})"
            )
        if analysis["analysis_type"] == "standardization":
            lines.append(
                f"  Center = {format_number(analysis['center'])}; "
                f"scale = {format_number(analysis['scale'])}"
            )
        original = analysis["original_summary"]
        transformed = analysis["transformed_summary"]
        lines.extend(
            [
                f"  Usable n = {analysis['n']}; missing/nonfinite = "
                f"{analysis['missing_or_nonfinite']}",
                f"  Original: mean = {format_number(original['mean'])}; SD = "
                f"{format_number(original['standard_deviation'])}; range = "
                f"({format_number(original['minimum'])}, "
                f"{format_number(original['maximum'])})",
                f"  Result: mean = {format_number(transformed['mean'])}; SD = "
                f"{format_number(transformed['standard_deviation'])}; range = "
                f"({format_number(transformed['minimum'])}, "
                f"{format_number(transformed['maximum'])})",
                "",
            ]
        )


def _append_outlier_diagnostics(
    lines: list[str], results: dict[str, Any]
) -> None:
    diagnostics = results.get("outlier_diagnostics", [])
    if not diagnostics:
        return
    lines.extend(["OUTLIER DIAGNOSTICS", "-" * 19])
    for diagnostic in diagnostics:
        lines.extend(
            [
                f"Column: {diagnostic['column']}; method = {diagnostic['method']}",
                f"  Flag column = {diagnostic['flag_column']}",
                f"  Threshold/multiplier = {format_number(diagnostic['threshold'])}",
                f"  Center = {format_number(diagnostic['center'])}; "
                f"{diagnostic['scale_label']} = {format_number(diagnostic['scale'])}",
                f"  Fences = ({format_number(diagnostic['lower_fence'])}, "
                f"{format_number(diagnostic['upper_fence'])})",
            ]
        )
        if diagnostic["status"] != "completed":
            lines.append(f"  Diagnostic not run: {diagnostic['reason']}")
            lines.append("")
            continue
        lines.append(
            f"  Outliers = {diagnostic['outlier_count']} of {diagnostic['n']} "
            f"({format_number(diagnostic['outlier_proportion'])})"
        )
        displayed = diagnostic["outliers"][:20]
        for outlier in displayed:
            lines.append(
                f"    Row {outlier['row_number']}: value = "
                f"{format_number(outlier['value'])}; score = "
                f"{format_number(outlier['score'])}"
            )
        remaining = diagnostic["outlier_count"] - len(displayed)
        if remaining > 0:
            lines.append(f"    ... {remaining} additional outliers")
        lines.append("")


def _append_transformed_export(
    lines: list[str], results: dict[str, Any]
) -> None:
    export = results.get("transformed_data_export")
    if not export:
        return
    lines.extend(
        [
            "TRANSFORMED DATA EXPORT",
            "-" * 23,
            f"File: {export['file']}",
            f"Rows: {export['rows']}; appended columns: "
            f"{export['derived_column_count']}",
            f"Derived columns: {', '.join(export['derived_columns'])}",
            "",
        ]
    )

def _append_one_sample_tests(lines: list[str], results: dict[str, Any]) -> None:
    if results["one_sample_tests"]:
        lines.extend(["ONE-SAMPLE MEAN TESTS", "-" * 21])
        for test in results["one_sample_tests"]:
            lines.append(
                f"Column: {test['column']}  "
                f"(H0: mean = {format_number(test['hypothesized_mean'])})"
            )
            lines.append(f"  Observations = {test['n']}")
            lines.extend(format_test(test))
            if test.get("status") == "completed":
                interval = test["two_sided_confidence_interval_for_mean"]
                lines.extend(
                    [
                        f"  Sample mean = {format_number(test['sample_mean'])}",
                        f"  Mean difference = {format_number(test['mean_difference'])}",
                        f"  {format_number(100 * test['confidence_level'])}% "
                        f"two-sided CI for mean = "
                        f"({format_number(interval[0])}, {format_number(interval[1])})",
                        f"  Cohen's d = {format_number(test['cohens_d'])}",
                    ]
                )
            lines.append("")

    if results["one_sample_z_tests"]:
        lines.extend(["ONE-SAMPLE POPULATION-MEAN Z-TESTS", "-" * 34])
        for test in results["one_sample_z_tests"]:
            lines.append(
                f"Column: {test['column']}  "
                f"(H0: mean = {format_number(test['hypothesized_mean'])})"
            )
            lines.append(f"  Observations = {test['n']}")
            lines.append(
                "  Known population standard deviation = "
                f"{format_number(test['population_standard_deviation'])}"
            )
            lines.extend(format_test(test))
            if test.get("status") == "completed":
                interval = test["two_sided_confidence_interval_for_mean"]
                lines.extend(
                    [
                        f"  Sample mean = {format_number(test['sample_mean'])}",
                        f"  Standard error = {format_number(test['standard_error'])}",
                        f"  {format_number(100 * test['confidence_level'])}% "
                        f"two-sided CI for mean = "
                        f"({format_number(interval[0])}, {format_number(interval[1])})",
                    ]
                )
            lines.append("")


def _append_two_sample_tests(lines: list[str], results: dict[str, Any]) -> None:
    if results["two_sample_tests"]:
        lines.extend(["INDEPENDENT TWO-SAMPLE TESTS", "-" * 28])
        for test in results["two_sample_tests"]:
            lines.append(f"Columns: {test['column_1']} minus {test['column_2']}")
            lines.append(f"  Observations in sample 1 = {test['n_1']}")
            lines.append(f"  Observations in sample 2 = {test['n_2']}")
            lines.extend(format_test(test))
            if test.get("status") == "completed":
                interval = test["two_sided_confidence_interval_for_mean_difference"]
                lines.extend(
                    [
                        f"  Mean 1 = {format_number(test['mean_1'])}",
                        f"  Mean 2 = {format_number(test['mean_2'])}",
                        f"  Mean difference = {format_number(test['mean_difference'])}",
                        f"  {format_number(100 * test['confidence_level'])}% "
                        f"CI for difference = "
                        f"({format_number(interval[0])}, {format_number(interval[1])})",
                        f"  Cohen's d = {format_number(test['cohens_d'])}",
                        f"  Hedges' g = {format_number(test['hedges_g'])}",
                    ]
                )
            lines.append("")

    if results["paired_tests"]:
        lines.extend(["PAIRED-SAMPLE TESTS", "-" * 19])
        for test in results["paired_tests"]:
            lines.append(f"Paired columns: {test['difference_definition']}")
            lines.append(f"  Complete pairs = {test['n_pairs']}")
            lines.extend(format_test(test))
            if test.get("status") == "completed":
                interval = test["two_sided_confidence_interval_for_mean_difference"]
                lines.extend(
                    [
                        f"  Mean 1 = {format_number(test['mean_1'])}",
                        f"  Mean 2 = {format_number(test['mean_2'])}",
                        f"  Mean paired difference = {format_number(test['mean_difference'])}",
                        f"  Standard deviation of differences = "
                        f"{format_number(test['standard_deviation_of_differences'])}",
                        f"  {format_number(100 * test['confidence_level'])}% "
                        f"CI for mean difference = "
                        f"({format_number(interval[0])}, {format_number(interval[1])})",
                        f"  Cohen's dz = {format_number(test['cohens_dz'])}",
                    ]
                )
            lines.append("")


def _append_summary_data_tests(
    lines: list[str], results: dict[str, Any]
) -> None:
    if results["summary_one_sample_tests"]:
        lines.extend(["SUMMARY-DATA ONE-SAMPLE T-TESTS", "-" * 31])
        for test in results["summary_one_sample_tests"]:
            lines.append(
                f"Summary: n = {test['n']}; mean = "
                f"{format_number(test['sample_mean'])}; sample SD = "
                f"{format_number(test['sample_standard_deviation'])}"
            )
            lines.append(
                f"  H0: mean = {format_number(test['hypothesized_mean'])}"
            )
            lines.extend(format_test(test))
            if test.get("status") == "completed":
                interval = test["two_sided_confidence_interval_for_mean"]
                lines.extend(
                    [
                        f"  Standard error = "
                        f"{format_number(test['standard_error'])}",
                        f"  Mean difference = "
                        f"{format_number(test['mean_difference'])}",
                        f"  {format_number(100 * test['confidence_level'])}% "
                        f"CI for mean = "
                        f"({format_number(interval[0])}, "
                        f"{format_number(interval[1])})",
                        f"  Cohen's d = {format_number(test['cohens_d'])}",
                    ]
                )
            lines.append("")

    if results["summary_z_tests"]:
        lines.extend(["SUMMARY-DATA POPULATION-MEAN Z-TESTS", "-" * 36])
        for test in results["summary_z_tests"]:
            lines.append(
                f"Summary: n = {test['n']}; mean = "
                f"{format_number(test['sample_mean'])}; known sigma = "
                f"{format_number(test['population_standard_deviation'])}"
            )
            lines.append(
                f"  H0: mean = {format_number(test['hypothesized_mean'])}"
            )
            lines.extend(format_test(test))
            if test.get("status") == "completed":
                interval = test["two_sided_confidence_interval_for_mean"]
                lines.extend(
                    [
                        f"  Standard error = "
                        f"{format_number(test['standard_error'])}",
                        f"  Mean difference = "
                        f"{format_number(test['mean_difference'])}",
                        f"  {format_number(100 * test['confidence_level'])}% "
                        f"CI for mean = "
                        f"({format_number(interval[0])}, "
                        f"{format_number(interval[1])})",
                        f"  Standardized difference = "
                        f"{format_number(test['standardized_difference'])}",
                    ]
                )
            lines.append("")

    if results["summary_two_sample_tests"]:
        lines.extend(["SUMMARY-DATA INDEPENDENT TWO-SAMPLE TESTS", "-" * 41])
        for test in results["summary_two_sample_tests"]:
            lines.extend(
                [
                    f"Sample 1: n = {test['n_1']}; mean = "
                    f"{format_number(test['mean_1'])}; sample SD = "
                    f"{format_number(test['standard_deviation_1'])}",
                    f"Sample 2: n = {test['n_2']}; mean = "
                    f"{format_number(test['mean_2'])}; sample SD = "
                    f"{format_number(test['standard_deviation_2'])}",
                ]
            )
            lines.extend(format_test(test))
            if test.get("status") == "completed":
                interval = test[
                    "two_sided_confidence_interval_for_mean_difference"
                ]
                lines.extend(
                    [
                        f"  Mean difference (sample 1 minus sample 2) = "
                        f"{format_number(test['mean_difference'])}",
                        f"  Standard error = "
                        f"{format_number(test['standard_error'])}",
                        f"  {format_number(100 * test['confidence_level'])}% "
                        f"CI for difference = "
                        f"({format_number(interval[0])}, "
                        f"{format_number(interval[1])})",
                        f"  Cohen's d = {format_number(test['cohens_d'])}",
                        f"  Hedges' g = {format_number(test['hedges_g'])}",
                    ]
                )
            lines.append("")

    if results["summary_paired_tests"]:
        lines.extend(["SUMMARY-DATA PAIRED-DIFFERENCE TESTS", "-" * 36])
        for test in results["summary_paired_tests"]:
            lines.append(
                f"Difference summary: n = {test['n_pairs']}; mean = "
                f"{format_number(test['mean_difference'])}; sample SD = "
                f"{format_number(test['standard_deviation_of_differences'])}"
            )
            lines.append(
                f"  H0: mean difference = "
                f"{format_number(test['hypothesized_difference'])}"
            )
            lines.extend(format_test(test))
            if test.get("status") == "completed":
                interval = test[
                    "two_sided_confidence_interval_for_mean_difference"
                ]
                lines.extend(
                    [
                        f"  Difference from null = "
                        f"{format_number(test['mean_difference_from_null'])}",
                        f"  Standard error = "
                        f"{format_number(test['standard_error'])}",
                        f"  {format_number(100 * test['confidence_level'])}% "
                        f"CI for mean "
                        f"difference = ({format_number(interval[0])}, "
                        f"{format_number(interval[1])})",
                        f"  Cohen's dz = {format_number(test['cohens_dz'])}",
                    ]
                )
            lines.append("")


def _append_distribution_calculations(
    lines: list[str], results: dict[str, Any]
) -> None:
    calculations = results.get("distribution_calculations", [])
    if not calculations:
        return
    lines.extend(["DISTRIBUTION CALCULATOR", "-" * 23])
    for calculation in calculations:
        parameters = ", ".join(
            f"{name} = {format_number(value)}"
            for name, value in calculation["parameters"].items()
        )
        lines.append(f"{calculation['distribution']}; {parameters}")
        calculation_type = calculation["calculation_type"]
        if calculation_type == "information":
            lines.extend(
                [
                    f"  Type = {calculation['distribution_type']}",
                    f"  Parameter order = {calculation['parameter_order']}",
                    f"  Parameterization = {calculation['parameterization']}",
                    f"  Support = {calculation['support']}",
                    f"  Mean = {format_number(calculation['mean'])} "
                    f"({calculation['mean_status']})",
                    f"  Variance = {format_number(calculation['variance'])} "
                    f"({calculation['variance_status']})",
                    f"  Standard deviation = "
                    f"{format_number(calculation['standard_deviation'])}",
                    f"  MGF: {calculation['mgf']}",
                ]
            )
            if calculation["distribution_type"] == "discrete":
                formulas = calculation["moment_formulas"]
                lines.extend(
                    [
                        f"  First raw moment = "
                        f"{format_number(calculation['first_raw_moment'])}",
                        f"    Formula: {formulas['first_raw']}",
                        f"  Second raw moment = "
                        f"{format_number(calculation['second_raw_moment'])}",
                        f"    Formula: {formulas['second_raw']}",
                        f"  Second central moment = "
                        f"{format_number(calculation['second_central_moment'])}",
                        f"    Formula: {formulas['second_central']}",
                    ]
                )
        elif calculation_type == "density":
            result = (
                format_number(calculation["result"])
                if calculation["result_status"] == "finite"
                else calculation["result_status"]
            )
            lines.append(
                f"  {calculation['function'].upper()} at x = "
                f"{format_number(calculation['value'])} is {result}"
            )
            if calculation.get("support_boundary"):
                lines.append(
                    f"  Endpoint convention = {calculation['endpoint_semantics']}"
                )
        elif calculation_type == "quantile":
            lines.append(
                f"  Lower-tail cumulative probability = "
                f"{format_number(calculation['cumulative_probability'])}"
            )
            lines.append(
                f"  Quantile = {format_number(calculation['result'])}"
            )
            lines.append(
                f"  Quantile definition = {calculation['quantile_definition']}"
            )
        else:
            lines.append(f"  {calculation['expression']}")
            lines.append(
                f"  Probability = {format_number(calculation['result'])}"
            )
            lines.append(
                f"  Evaluation method = {calculation['evaluation_method']}"
            )
            lines.append(
                f"  Endpoint convention = {calculation['endpoint_semantics']}"
            )
        numerical_validation = calculation.get("numerical_validation")
        if numerical_validation:
            lines.append(
                f"  Numerical validation = {numerical_validation['status']}"
            )
            if numerical_validation.get("log_probability") is not None:
                lines.append(
                    f"  Log probability = "
                    f"{format_number(numerical_validation['log_probability'])}"
                )
            for warning in numerical_validation.get("warnings", []):
                lines.append(f"  Numerical warning: {warning}")
        lines.append("")


def _append_bayesian_analyses(
    lines: list[str], results: dict[str, Any]
) -> None:
    analyses = results.get("bayesian_analyses", [])
    if not analyses:
        return
    lines.extend(["BAYESIAN CONJUGATE ANALYSES", "-" * 29])
    for analysis in analyses:
        model = analysis["model"]
        lines.append(analysis["method"])
        if analysis.get("column"):
            source = f"column = {analysis['column']}"
            if analysis.get("success_value") is not None:
                source += f"; success = {analysis['success_value']}"
            if analysis.get("exposure_column"):
                source += f"; exposure column = {analysis['exposure_column']}"
            lines.append(f"  Data source: {source}")

        prior = analysis["prior"]
        posterior = analysis["posterior"]
        level = 100.0 * analysis["credible_level"]
        predictive = analysis["posterior_predictive"]
        if model == "beta-binomial":
            interval = analysis["credible_interval"]
            predictive_interval = predictive["predictive_interval"]
            lines.extend(
                [
                    f"  Data: {analysis['successes']} successes and "
                    f"{analysis['failures']} failures in {analysis['trials']} trials",
                    f"  Prior: Beta(alpha = {format_number(prior['alpha'])}, "
                    f"beta = {format_number(prior['beta'])})",
                    f"  Posterior: Beta(alpha = "
                    f"{format_number(posterior['alpha'])}, beta = "
                    f"{format_number(posterior['beta'])})",
                    f"  Posterior mean = {format_number(posterior['mean'])}",
                    f"  Posterior variance = "
                    f"{format_number(posterior['variance'])}",
                    f"  Posterior mode = {format_number(posterior['mode'])} "
                    f"({posterior['mode_status']})",
                    f"  {format_number(level)}% credible interval for p = "
                    f"({format_number(interval[0])}, {format_number(interval[1])})",
                    f"  Predictive distribution: beta-binomial for "
                    f"{predictive['future_trials']} future trials",
                    f"  Predictive mean successes = "
                    f"{format_number(predictive['mean_successes'])}",
                    f"  Probability of success on the next trial = "
                    f"{format_number(predictive['probability_of_success_on_next_trial'])}",
                    f"  {format_number(level)}% predictive interval for future successes = "
                    f"({predictive_interval[0]}, {predictive_interval[1]})",
                ]
            )
        elif model == "gamma-poisson":
            interval = analysis["credible_interval"]
            predictive_interval = predictive["predictive_interval"]
            lines.extend(
                [
                    f"  Data: {analysis['events']} events over exposure "
                    f"{format_number(analysis['exposure'])}",
                    f"  Prior: Gamma(shape = {format_number(prior['shape'])}, "
                    f"rate = {format_number(prior['rate'])})",
                    f"  Posterior: Gamma(shape = "
                    f"{format_number(posterior['shape'])}, rate = "
                    f"{format_number(posterior['rate'])})",
                    f"  Posterior mean rate = {format_number(posterior['mean'])}",
                    f"  Posterior variance = "
                    f"{format_number(posterior['variance'])}",
                    f"  Posterior mode = {format_number(posterior['mode'])} "
                    f"({posterior['mode_status']})",
                    f"  {format_number(level)}% credible interval for rate = "
                    f"({format_number(interval[0])}, {format_number(interval[1])})",
                    f"  Predictive distribution: negative-binomial for future "
                    f"exposure {format_number(predictive['future_exposure'])}",
                    f"  Predictive mean events = "
                    f"{format_number(predictive['mean_events'])}",
                    f"  Probability of zero future events = "
                    f"{format_number(predictive['probability_of_zero_events'])}",
                    f"  {format_number(level)}% predictive interval for future events = "
                    f"({predictive_interval[0]}, {predictive_interval[1]})",
                ]
            )
        elif model == "normal-normal-known-variance":
            interval = analysis["credible_interval"]
            predictive_interval = predictive["predictive_interval"]
            lines.extend(
                [
                    f"  Data: n = {analysis['n']}; sample mean = "
                    f"{format_number(analysis['sample_mean'])}; known SD = "
                    f"{format_number(analysis['known_population_standard_deviation'])}",
                    f"  Prior mean = {format_number(prior['mean'])}; prior SD = "
                    f"{format_number(prior['standard_deviation'])}",
                    f"  Posterior mean = {format_number(posterior['mean'])}",
                    f"  Posterior variance = "
                    f"{format_number(posterior['variance'])}",
                    f"  Posterior SD = "
                    f"{format_number(posterior['standard_deviation'])}",
                    f"  {format_number(level)}% credible interval for mean = "
                    f"({format_number(interval[0])}, {format_number(interval[1])})",
                    f"  Posterior predictive: Normal(mean = "
                    f"{format_number(predictive['mean'])}, SD = "
                    f"{format_number(predictive['standard_deviation'])})",
                    f"  {format_number(level)}% predictive interval for a future observation = "
                    f"({format_number(predictive_interval[0])}, "
                    f"{format_number(predictive_interval[1])})",
                ]
            )
        else:
            mean_interval = analysis["mean_credible_interval"]
            variance_interval = analysis["variance_credible_interval"]
            predictive_interval = predictive["predictive_interval"]
            lines.extend(
                [
                    f"  Data: n = {analysis['n']}; sample mean = "
                    f"{format_number(analysis['sample_mean'])}; sample SD = "
                    f"{format_number(analysis['sample_standard_deviation'])}",
                    f"  Prior NIG: mu = {format_number(prior['mu'])}; kappa = "
                    f"{format_number(prior['kappa'])}; alpha = "
                    f"{format_number(prior['alpha'])}; beta = "
                    f"{format_number(prior['beta'])}",
                    f"  Posterior NIG: mu = {format_number(posterior['mu'])}; "
                    f"kappa = {format_number(posterior['kappa'])}; alpha = "
                    f"{format_number(posterior['alpha'])}; beta = "
                    f"{format_number(posterior['beta'])}",
                    f"  Posterior mean of mean parameter = "
                    f"{format_number(posterior['mean_parameter_mean'])}",
                    f"  Posterior mean of variance = "
                    f"{format_number(posterior['variance_mean'])} "
                    f"({posterior['variance_mean_status']})",
                    f"  Posterior mode of variance = "
                    f"{format_number(posterior['variance_mode'])}",
                    f"  {format_number(level)}% credible interval for mean = "
                    f"({format_number(mean_interval[0])}, "
                    f"{format_number(mean_interval[1])})",
                    f"  {format_number(level)}% credible interval for variance = "
                    f"({format_number(variance_interval[0])}, "
                    f"{format_number(variance_interval[1])})",
                    f"  Posterior predictive: Student t(df = "
                    f"{format_number(predictive['degrees_of_freedom'])}, "
                    f"location = {format_number(predictive['location'])}, "
                    f"scale = {format_number(predictive['scale'])})",
                    f"  {format_number(level)}% predictive interval for a future observation = "
                    f"({format_number(predictive_interval[0])}, "
                    f"{format_number(predictive_interval[1])})",
                ]
            )
        numerical = analysis.get("numerical_status")
        if numerical:
            lines.extend(
                [
                    f"  Bayesian numerical status = {numerical['status']}",
                    f"  Posterior update = "
                    f"{numerical['posterior_update_method']}",
                    f"  Interval calculation = {numerical['interval_method']}",
                    "  Derivatives, optimization, iteration, quadrature, ODE solving, and MCMC = not used",
                    f"  Posterior parameters: finite = "
                    f"{format_number(numerical['posterior_parameter_validation']['finite'])}; "
                    f"within support = "
                    f"{format_number(numerical['posterior_parameter_validation']['within_parameter_support'])}",
                ]
            )
            for validation in numerical["interval_validations"]:
                support = validation["support"]
                lower_support = (
                    format_number(support["lower"])
                    if support["lower"] is not None
                    else "-infinity"
                )
                upper_support = (
                    format_number(support["upper"])
                    if support["upper"] is not None
                    else "infinity"
                )
                lines.append(
                    f"  {validation['label']}: {validation['status']}; "
                    f"finite = {format_number(validation['finite'])}; "
                    f"ordered = {format_number(validation['ordered'])}; "
                    f"support = [{lower_support}, {upper_support}]; "
                    f"within support = "
                    f"{format_number(validation['within_support'])}"
                )
            for validation in numerical["probability_validations"]:
                lines.append(
                    f"  {validation['label']}: {validation['status']}; "
                    f"finite = {format_number(validation['finite'])}; "
                    f"within [0, 1] = "
                    f"{format_number(validation['within_probability_support'])}"
                )
            for warning in numerical["warnings"]:
                lines.append(f"  Bayesian numerical warning: {warning}")
        lines.append("")


def _append_direct_confidence_intervals(
    lines: list[str], results: dict[str, Any]
) -> None:
    mean_intervals = results.get("mean_confidence_intervals", [])
    proportion_intervals = results.get("proportion_confidence_intervals", [])
    variance_intervals = results.get("variance_confidence_intervals", [])
    rate_intervals = results.get("poisson_rate_confidence_intervals", [])
    if not any(
        (mean_intervals, proportion_intervals, variance_intervals, rate_intervals)
    ):
        return
    lines.extend(["DIRECT CONFIDENCE INTERVALS", "-" * 27])
    for interval in mean_intervals:
        limits = interval["confidence_interval"]
        scale_label = (
            "Known population SD"
            if interval["known_population_standard_deviation"]
            else "Sample SD"
        )
        lines.extend(
            [
                interval["method"],
                f"  n = {interval['n']}; mean = "
                f"{format_number(interval['sample_mean'])}; {scale_label} = "
                f"{format_number(interval['standard_deviation'])}",
                f"  Standard error = {format_number(interval['standard_error'])}",
                f"  Critical value = {format_number(interval['critical_value'])}",
                f"  {format_number(100 * interval['confidence_level'])}% "
                f"CI for mean = "
                f"({format_number(limits[0])}, {format_number(limits[1])})",
                "",
            ]
        )
    for interval in proportion_intervals:
        wilson = interval["wilson_confidence_interval"]
        exact = interval["exact_clopper_pearson_interval"]
        lines.extend(
            [
                interval["method"],
                f"  Successes/trials = {interval['successes']}/{interval['trials']}",
                f"  Sample proportion = "
                f"{format_number(interval['sample_proportion'])}",
                f"  {format_number(100 * interval['confidence_level'])}% Wilson CI = "
                f"({format_number(wilson[0])}, {format_number(wilson[1])})",
                f"  {format_number(100 * interval['confidence_level'])}% exact "
                f"Clopper-Pearson CI = ({format_number(exact[0])}, "
                f"{format_number(exact[1])})",
                "",
            ]
        )
    for interval in variance_intervals:
        variance_limits = interval["variance_confidence_interval"]
        sd_limits = interval["standard_deviation_confidence_interval"]
        lines.extend(
            [
                interval["method"],
                f"  n = {interval['n']}; degrees of freedom = "
                f"{format_number(interval['degrees_of_freedom'])}",
                f"  Sample variance = {format_number(interval['sample_variance'])}",
                f"  {format_number(100 * interval['confidence_level'])}% "
                f"CI for variance = "
                f"({format_number(variance_limits[0])}, "
                f"{format_number(variance_limits[1])})",
                f"  {format_number(100 * interval['confidence_level'])}% "
                f"CI for SD = "
                f"({format_number(sd_limits[0])}, {format_number(sd_limits[1])})",
                "",
            ]
        )
    for interval in rate_intervals:
        limits = interval["confidence_interval"]
        lines.extend(
            [
                interval["method"],
                f"  Events = {interval['events']}; exposure = "
                f"{format_number(interval['exposure'])}",
                f"  Estimated rate = {format_number(interval['estimated_rate'])}",
                f"  Exact {format_number(100 * interval['confidence_level'])}% "
                f"CI for rate = "
                f"({format_number(limits[0])}, {format_number(limits[1])})",
                "",
            ]
        )


def _append_power_analyses(lines: list[str], results: dict[str, Any]) -> None:
    analyses = results.get("power_analyses", [])
    if not analyses:
        return
    lines.extend(["POWER AND SAMPLE-SIZE ANALYSES", "-" * 31])
    for analysis in analyses:
        lines.append(f"Design: {analysis['design']}")
        lines.append(f"  Method: {analysis['method']}")
        if "sample_size" in analysis:
            label = "Pairs" if analysis["design"] == "paired mean" else "N"
            lines.append(f"  {label} = {analysis['sample_size']}")
        if "sample_size_1" in analysis:
            lines.append(
                f"  N1 = {analysis['sample_size_1']}; "
                f"N2 = {analysis['sample_size_2']}; "
                f"total N = {analysis['total_sample_size']}"
            )
        if "groups" in analysis:
            lines.append(
                f"  Groups = {analysis['groups']}; N per group = "
                f"{analysis['sample_size_per_group']}; total N = "
                f"{analysis['total_sample_size']}"
            )
        if "effect_size" in analysis:
            lines.append(
                f"  {analysis['effect_size_name']} = "
                f"{format_number(analysis['effect_size'])}"
            )
        if analysis["design"] == "one proportion":
            lines.append(
                f"  Actual p = {format_number(analysis['actual_probability'])}; "
                f"null p = {format_number(analysis['null_probability'])}; "
                f"difference = {format_number(analysis['probability_difference'])}"
            )
        if analysis["design"] == "two independent proportions":
            lines.append(
                f"  p1 = {format_number(analysis['probability_1'])}; "
                f"p2 = {format_number(analysis['probability_2'])}; "
                f"difference = {format_number(analysis['probability_difference'])}"
            )
        if "allocation_ratio_n2_to_n1" in analysis:
            lines.append(
                f"  Allocation ratio N2/N1 = "
                f"{format_number(analysis['allocation_ratio_n2_to_n1'])}"
            )
        lines.append(
            f"  Alpha = {format_number(analysis['alpha'])}; "
            f"alternative = {analysis['alternative']}"
        )
        if analysis["calculation_type"] == "power":
            lines.append(f"  Power = {format_number(analysis['power'])}")
        else:
            lines.append(
                f"  Target power = {format_number(analysis['target_power'])}; "
                f"achieved power = {format_number(analysis['achieved_power'])}"
            )
            if analysis["calculation_type"] == "required_sample_size":
                lines.append("  Result: minimum integer sample size shown above")
            else:
                lines.append(
                    f"  Detectable effect magnitude = "
                    f"{format_number(analysis['detectable_effect_magnitude'])}"
                )
        _append_numerical_status(lines, analysis)
        lines.append("")


def _append_anova(lines: list[str], results: dict[str, Any]) -> None:
    if not results["anova_tests"]:
        return
    lines.extend(["INDEPENDENT MULTI-SAMPLE TESTS", "-" * 30])
    for test in results["anova_tests"]:
        lines.append(f"Columns: {', '.join(test['columns'])}")
        for group in test["group_statistics"]:
            lines.append(
                f"  {group['column']}: n = {group['n']}, "
                f"mean = {format_number(group['mean'])}, "
                f"variance = {format_number(group['variance'])}"
            )
        lines.extend(format_test(test))
        if test.get("status") == "completed" and "eta_squared" in test:
            lines.append(f"  Eta-squared = {format_number(test['eta_squared'])}")
            lines.append(f"  Omega-squared = {format_number(test['omega_squared'])}")
        lines.append("")


def _append_nonparametric_tests(
    lines: list[str], results: dict[str, Any]
) -> None:
    if results["mann_whitney_tests"]:
        lines.extend(["MANN-WHITNEY U TESTS", "-" * 20])
        for test in results["mann_whitney_tests"]:
            lines.append(f"Columns: {test['column_1']} and {test['column_2']}")
            lines.append(
                f"  {test['column_1']}: n = {test['n_1']}, "
                f"median = {format_number(test['sample_1']['median'])}, "
                f"IQR = ({format_number(test['sample_1']['first_quartile'])}, "
                f"{format_number(test['sample_1']['third_quartile'])})"
            )
            lines.append(
                f"  {test['column_2']}: n = {test['n_2']}, "
                f"median = {format_number(test['sample_2']['median'])}, "
                f"IQR = ({format_number(test['sample_2']['first_quartile'])}, "
                f"{format_number(test['sample_2']['third_quartile'])})"
            )
            if test.get("status") != "completed":
                lines.append(f"  Test not run ({test['reason']})")
                lines.append("")
                continue
            lines.extend(format_test(test))
            lines.extend(
                [
                    f"  Median difference = "
                    f"{format_number(test['median_difference'])}",
                    f"  Common-language effect = "
                    f"{format_number(test['common_language_effect'])}",
                    f"  Rank-biserial correlation = "
                    f"{format_number(test['rank_biserial_correlation'])}",
                ]
            )
            lines.append("")

    if results["wilcoxon_tests"]:
        lines.extend(["WILCOXON SIGNED-RANK TESTS", "-" * 27])
        for test in results["wilcoxon_tests"]:
            lines.append(f"Paired columns: {test['difference_definition']}")
            lines.append(
                f"  Complete pairs = {test['n_pairs']}; "
                f"nonzero differences = {test['nonzero_differences']}; "
                f"zero differences = {test['zero_differences']}"
            )
            if test.get("status") != "completed":
                lines.append(f"  Test not run ({test['reason']})")
                lines.append("")
                continue
            lines.extend(format_test(test))
            lines.extend(
                [
                    f"  Median paired difference = "
                    f"{format_number(test['median_difference'])}",
                    f"  Positive rank sum = "
                    f"{format_number(test['positive_rank_sum'])}",
                    f"  Negative rank sum = "
                    f"{format_number(test['negative_rank_sum'])}",
                    f"  Rank-biserial correlation = "
                    f"{format_number(test['rank_biserial_correlation'])}",
                ]
            )
            lines.append("")

    if results["kruskal_wallis_tests"]:
        lines.extend(["KRUSKAL-WALLIS TESTS", "-" * 21])
        for test in results["kruskal_wallis_tests"]:
            lines.append(f"Columns: {', '.join(test['columns'])}")
            for group in test["group_statistics"]:
                lines.append(
                    f"  {group['column']}: n = {group['n']}, "
                    f"median = {format_number(group['median'])}, "
                    f"IQR = ({format_number(group['first_quartile'])}, "
                    f"{format_number(group['third_quartile'])})"
                )
            if test.get("status") != "completed":
                lines.append(f"  Test not run ({test['reason']})")
                lines.append("")
                continue
            lines.extend(format_test(test))
            lines.append(
                f"  Epsilon-squared = {format_number(test['epsilon_squared'])}"
            )
            if test["posthoc_comparisons"]:
                adjustment = test["posthoc_adjustment"]
                lines.append(
                    f"  Dunn post-hoc comparisons ({adjustment} adjustment):"
                )
                lines.append(
                    "    Columns | Mean-rank difference | z | Raw p | Adjusted p | Decision"
                )
                for comparison in test["posthoc_comparisons"]:
                    lines.append(
                        f"    {comparison['column_1']} vs "
                        f"{comparison['column_2']} | "
                        f"{format_number(comparison['mean_rank_difference'])} | "
                        f"{format_number(comparison['z_score'])} | "
                        f"{format_number(comparison['raw_p_value'])} | "
                        f"{format_number(comparison['adjusted_p_value'])} | "
                        f"{comparison['decision']}"
                    )
            lines.append("")


def _append_correlations(lines: list[str], results: dict[str, Any]) -> None:
    if not results["correlation_analyses"]:
        return
    lines.extend(["CORRELATION ANALYSES", "-" * 20])
    lines.append("All correlation p-values are two-sided.")
    for analysis in results["correlation_analyses"]:
        lines.append(
            f"Columns: {analysis['column_1']} and {analysis['column_2']}"
        )
        lines.append(f"  Complete pairs = {analysis['n_complete_pairs']}")
        for test in analysis["tests"]:
            if test.get("status") != "completed":
                lines.append(
                    f"  {test['method']}: not run ({test['reason']})"
                )
                continue
            lines.extend(
                [
                    f"  {test['method']}:",
                    f"    {test['coefficient_name']} = "
                    f"{format_number(test['coefficient'])}",
                    f"    p-value = {format_number(test['p_value'])}",
                    f"    Decision = {test['decision']}",
                ]
            )
        lines.append("")


def _append_regressions(lines: list[str], results: dict[str, Any]) -> None:
    if not results["regression_analyses"]:
        return
    lines.extend(["SIMPLE LINEAR REGRESSION", "-" * 24])
    for model in results["regression_analyses"]:
        lines.append(
            f"Dependent variable: {model['dependent_variable']}"
        )
        lines.append(
            f"Independent variable: {model['independent_variable']}"
        )
        lines.append(f"Complete cases: {model['n_complete_cases']}")
        if model.get("status") != "completed":
            lines.append(f"  Model not run ({model['reason']})")
            lines.append("")
            continue
        lines.extend(
            [
                f"R-squared = {format_number(model['r_squared'])}",
                f"Adjusted R-squared = {format_number(model['adjusted_r_squared'])}",
                f"Residual standard error = "
                f"{format_number(model['residual_standard_error'])}",
                f"F-statistic = {format_number(model['f_statistic'])}",
                f"F-test p-value = {format_number(model['f_p_value'])}",
                f"Decision for H0: slope = 0: {model['decision']}",
                "",
                "Coefficients:",
                "  Term | Estimate | Std. Error | t | p-value | Confidence interval",
            ]
        )
        for coefficient in model["coefficients"]:
            interval = coefficient["confidence_interval"]
            lines.append(
                f"  {coefficient['term']} | "
                f"{format_number(coefficient['estimate'])} | "
                f"{format_number(coefficient['standard_error'])} | "
                f"{format_number(coefficient['t_statistic'])} | "
                f"{format_number(coefficient['p_value'])} | "
                f"({format_number(interval[0])}, {format_number(interval[1])})"
            )
        lines.extend(["", "ANOVA table:"])
        for row in model["anova_table"]:
            row_text = (
                f"  {row['source']}: SS = {format_number(row['sum_of_squares'])}, "
                f"df = {row['degrees_of_freedom']}"
            )
            if "mean_square" in row:
                row_text += f", MS = {format_number(row['mean_square'])}"
            if "f_statistic" in row:
                row_text += f", F = {format_number(row['f_statistic'])}"
            if "p_value" in row:
                row_text += f", p = {format_number(row['p_value'])}"
            lines.append(row_text)
        lines.append("")


def _append_engineered_terms(lines: list[str], model: dict[str, Any]) -> None:
    for polynomial in model.get("polynomial_terms", []):
        lines.append(
            f"  Polynomial predictor {polynomial['predictor']}: degree "
            f"{polynomial['degree']} ({polynomial['basis']}); terms = "
            f"{', '.join(polynomial['terms'])}"
        )
    for interaction in model.get("interactions", []):
        lines.append(
            f"  Interaction {interaction['predictor_1']} x "
            f"{interaction['predictor_2']}: terms = "
            f"{', '.join(interaction['terms'])}"
        )


def _append_multiple_regressions(
    lines: list[str], results: dict[str, Any]
) -> None:
    if results["multiple_regression_analyses"]:
        lines.extend(["MULTIPLE LINEAR REGRESSION", "-" * 26])
        for model in results["multiple_regression_analyses"]:
            model_name = model.get("model_name") or "Model"
            lines.append(
                f"{model_name}: {model['dependent_variable']} = "
                f"f({', '.join(model['predictors'])})"
            )
            lines.append(
                f"  Complete cases = {model['n_complete_cases']}; "
                f"excluded rows = {model['excluded_rows']}"
            )
            for coding in model["categorical_codings"]:
                lines.append(
                    f"  Categorical predictor {coding['predictor']}: "
                    f"reference = {coding['reference_category']}; categories = "
                    f"{', '.join(coding['categories'])}"
                )
            _append_engineered_terms(lines, model)
            if model.get("status") != "completed":
                lines.append(f"  Model not run ({model['reason']})")
                _append_numerical_status(lines, model, indent="    ")
                _append_information_diagnostics(lines, model, indent="    ")
                lines.append("")
                continue
            lines.extend(
                [
                    f"  R-squared = {format_number(model['r_squared'])}",
                    f"  Adjusted R-squared = "
                    f"{format_number(model['adjusted_r_squared'])}",
                    f"  Residual standard error = "
                    f"{format_number(model['residual_standard_error'])}",
                    f"  F({model['f_degrees_of_freedom_numerator']}, "
                    f"{model['f_degrees_of_freedom_denominator']}) = "
                    f"{format_number(model['f_statistic'])}",
                    f"  Model p-value = {format_number(model['f_p_value'])}",
                    f"  AIC = {format_number(model['aic'])}",
                    f"  BIC = {format_number(model['bic'])}",
                    f"  Decision = {model['decision']}",
                    "",
                    "  Coefficients:",
                    "    Term | Estimate | Std. Error | t | p-value | CI | Standardized",
                ]
            )
            for coefficient in model["coefficients"]:
                interval = coefficient["confidence_interval"]
                lines.append(
                    f"    {coefficient['term']} | "
                    f"{format_number(coefficient['estimate'])} | "
                    f"{format_number(coefficient['standard_error'])} | "
                    f"{format_number(coefficient['t_statistic'])} | "
                    f"{format_number(coefficient['p_value'])} | "
                    f"({format_number(interval[0])}, "
                    f"{format_number(interval[1])}) | "
                    f"{format_number(coefficient['standardized_coefficient'])}"
                )

            lines.extend(["", "  ANOVA table:"])
            for row in model["anova_table"]:
                row_text = (
                    f"    {row['source']}: SS = "
                    f"{format_number(row['sum_of_squares'])}, "
                    f"df = {row['degrees_of_freedom']}"
                )
                if "mean_square" in row:
                    row_text += f", MS = {format_number(row['mean_square'])}"
                if "f_statistic" in row:
                    row_text += f", F = {format_number(row['f_statistic'])}"
                if "p_value" in row:
                    row_text += f", p = {format_number(row['p_value'])}"
                lines.append(row_text)

            lines.extend(["", "  Collinearity diagnostics:"])
            lines.append(
                "    Standardized-design condition number = "
                f"{format_number(model['condition_number_standardized_design'])}"
            )
            lines.append("    Term | VIF | Tolerance")
            for factor in model["variance_inflation_factors"]:
                lines.append(
                    f"    {factor['term']} | {format_number(factor['vif'])} | "
                    f"{format_number(factor['tolerance'])}"
                )

            lines.extend(["", "  Residual diagnostics:"])
            residual_summary = model["residual_summary"]
            lines.append(
                "    Residual five-number summary = "
                f"({format_number(residual_summary['minimum'])}, "
                f"{format_number(residual_summary['first_quartile'])}, "
                f"{format_number(residual_summary['median'])}, "
                f"{format_number(residual_summary['third_quartile'])}, "
                f"{format_number(residual_summary['maximum'])})"
            )
            for test in model["residual_normality_tests"]:
                lines.extend(format_test(test, "    "))
            lines.extend(format_test(model["breusch_pagan_test"], "    "))
            lines.append(
                f"    Durbin-Watson = "
                f"{format_number(model['durbin_watson_statistic'])}"
            )
            lines.append(f"    Note: {model['durbin_watson_note']}")
            influence = model["influence_diagnostics"]
            lines.extend(
                [
                    f"    Maximum leverage = "
                    f"{format_number(influence['maximum_leverage'])} "
                    f"(threshold {format_number(influence['leverage_threshold'])})",
                    f"    Maximum |studentized residual| = "
                    f"{format_number(influence['maximum_absolute_studentized_residual'])}",
                    f"    Maximum Cook's distance = "
                    f"{format_number(influence['maximum_cooks_distance'])} "
                    f"(threshold "
                    f"{format_number(influence['cooks_distance_threshold'])})",
                    f"    Flagged cases = {influence['flagged_case_count']}",
                ]
            )
            for case in influence["flagged_cases"][:10]:
                lines.append(
                    f"      Index {format_number(case['source_index'])}: "
                    f"fitted = {format_number(case['fitted'])}, "
                    f"residual = {format_number(case['residual'])}, "
                    f"studentized = "
                    f"{format_number(case['internally_studentized_residual'])}, "
                    f"leverage = {format_number(case['leverage'])}, "
                    f"Cook's D = {format_number(case['cooks_distance'])}"
                )
            if influence["flagged_case_count"] > 10:
                lines.append("      Additional flagged cases are available in JSON output.")
            lines.append("")


def _append_advanced_regressions(
    lines: list[str], results: dict[str, Any]
) -> None:
    groups = (
        ("ROBUST LINEAR REGRESSION", "robust_regression_analyses"),
        ("REGULARIZED LINEAR REGRESSION", "regularized_regression_analyses"),
        ("REGRESSION SPLINES", "regression_spline_analyses"),
        ("SMOOTHING SPLINES", "smoothing_spline_analyses"),
        ("LOESS REGRESSION", "loess_analyses"),
        ("KERNEL REGRESSION", "kernel_regression_analyses"),
        ("ISOTONIC REGRESSION", "isotonic_regression_analyses"),
    )
    for title, key in groups:
        analyses = results.get(key, [])
        if not analyses:
            continue
        lines.extend([title, "-" * len(title)])
        for model in analyses:
            lines.append(model.get("model_name") or model["method"])
            lines.append(
                f"  Complete cases = {model['n_complete_cases']}; "
                f"excluded rows = {model.get('excluded_rows', 0)}"
            )
            if model.get("status") not in {"completed", "completed_with_warnings"}:
                lines.append(
                    f"  Model not run ({model.get('reason', 'unspecified reason')})"
                )
                diagnostics = model.get("matrix_diagnostics")
                if diagnostics:
                    lines.append(
                        f"  Matrix rank = {diagnostics['rank']}/"
                        f"{diagnostics['columns']}; condition number = "
                        f"{format_number(diagnostics.get('condition_number'))}; "
                        f"status = {diagnostics['condition_number_status']}"
                    )
                _append_numerical_status(lines, model)
                lines.append("")
                continue
            lines.extend(
                [
                    f"  R-squared = {format_number(model.get('r_squared'))}",
                    f"  RMSE = {format_number(model.get('root_mean_squared_error'))}; "
                    f"MAE = {format_number(model.get('mean_absolute_error'))}",
                    f"  Effective degrees of freedom = "
                    f"{format_number(model.get('effective_degrees_of_freedom'))}",
                ]
            )
            if key == "robust_regression_analyses":
                lines.extend(
                    [
                        f"  Loss = Huber; tuning constant = "
                        f"{format_number(model['tuning_constant'])}",
                        f"  Scale estimate = {format_number(model.get('scale_estimate'))}; "
                        f"downweighted cases = {model['downweighted_case_count']}; "
                        f"minimum weight = {format_number(model['minimum_weight'])}",
                        f"  Coefficient inference = {model['coefficient_inference']}",
                        "  Coefficients:",
                    ]
                )
                for coefficient in model["coefficients"]:
                    text = (
                        f"    {coefficient['term']}: estimate = "
                        f"{format_number(coefficient['estimate'])}"
                    )
                    if coefficient.get("standard_error") is not None:
                        interval = coefficient["confidence_interval"]
                        text += (
                            f"; SE = {format_number(coefficient['standard_error'])}; "
                            f"z = {format_number(coefficient['z_statistic'])}; "
                            f"p = {format_number(coefficient['p_value'])}; CI = "
                            f"({format_number(interval[0])}, {format_number(interval[1])})"
                        )
                    lines.append(text)
            elif key == "regularized_regression_analyses":
                lines.extend(
                    [
                        f"  Penalty = {model['penalty']}; strength = "
                        f"{format_number(model['penalty_strength'])}; selection = "
                        f"{model['penalty_selection']}",
                        f"  Zero coefficients = {model['zero_coefficient_count']}",
                    ]
                )
                cross_validation = model["cross_validation"]
                if cross_validation.get("status") == "completed":
                    lines.append(
                        f"  Cross-validation = {cross_validation['folds']} folds; "
                        f"selected MSE = "
                        f"{format_number(cross_validation['selected_mean_squared_error'])}"
                    )
                lines.append(f"  Inference note = {model['coefficient_inference']}")
                diagnostics = model["unpenalized_design_diagnostics"]
                lines.append(
                    f"  Unpenalized design rank = {diagnostics['rank']}/"
                    f"{diagnostics['columns']}; condition number = "
                    f"{format_number(diagnostics.get('condition_number'))}; "
                    f"status = {diagnostics['condition_number_status']}"
                )
                lines.append("  Coefficients:")
                for coefficient in model["coefficients"]:
                    lines.append(
                        f"    {coefficient['term']}: estimate = "
                        f"{format_number(coefficient['estimate'])}; standardized = "
                        f"{format_number(coefficient.get('standardized_estimate'))}"
                    )
            elif key == "regression_spline_analyses":
                lines.extend(
                    [
                        f"  Basis = {model['basis']}",
                        "  Interior knots = "
                        + ", ".join(
                            format_number(value) for value in model["interior_knots"]
                        ),
                        f"  Interval = {model['interval_type']}",
                        "  Basis coefficients:",
                    ]
                )
                for coefficient in model["coefficients"]:
                    interval = coefficient["confidence_interval"]
                    lines.append(
                        f"    {coefficient['term']}: estimate = "
                        f"{format_number(coefficient['estimate'])}; SE = "
                        f"{format_number(coefficient['standard_error'])}; p = "
                        f"{format_number(coefficient['p_value'])}; CI = "
                        f"({format_number(interval[0])}, {format_number(interval[1])})"
                    )
            elif key == "smoothing_spline_analyses":
                lines.extend(
                    [
                        f"  Basis = {model['basis']}; roughness penalty = "
                        f"{model['roughness_penalty']}",
                        f"  Smoothing strength = "
                        f"{format_number(model['smoothing_strength'])}; selection = "
                        f"{model['smoothing_parameter_selection']}",
                        f"  GCV score = "
                        f"{format_number(model['generalized_cross_validation_score'])}",
                        f"  Interval = {model['interval_type']}",
                    ]
                )
            elif key == "loess_analyses":
                lines.extend(
                    [
                        f"  Span = {format_number(model['span'])}; local degree = "
                        f"{model['local_polynomial_degree']}; robust iterations = "
                        f"{model['completed_robust_iterations']}",
                        f"  Kernel = {model['kernel']}",
                        f"  Inference note = {model['coefficient_inference']}",
                    ]
                )
            elif key == "kernel_regression_analyses":
                lines.extend(
                    [
                        f"  Kernel = {model['kernel']}; bandwidth = "
                        f"{format_number(model['bandwidth'])}; selection = "
                        f"{model['bandwidth_selection']}",
                        f"  Selected leave-one-out MSE = "
                        f"{format_number(model.get('selected_leave_one_out_mean_squared_error'))}",
                        f"  Inference note = {model['coefficient_inference']}",
                    ]
                )
            else:
                lines.extend(
                    [
                        f"  Direction = {model['selected_direction']}; selection = "
                        f"{model['direction_selection']}",
                        f"  Distinct predictor values = "
                        f"{model['distinct_predictor_values']}; monotone blocks = "
                        f"{model['monotone_block_count']}",
                        f"  Inference note = {model['coefficient_inference']}",
                    ]
                )
            diagnostics = model.get("matrix_diagnostics")
            if diagnostics:
                lines.append(
                    f"  Matrix rank = {diagnostics['rank']}/"
                    f"{diagnostics['columns']}; condition number = "
                    f"{format_number(diagnostics.get('condition_number'))}; "
                    f"status = {diagnostics['condition_number_status']}"
                )
            _append_numerical_status(lines, model)
            lines.append("")


def _append_kernel_density(lines: list[str], results: dict[str, Any]) -> None:
    analyses = results.get("kernel_density_analyses", [])
    if not analyses:
        return
    title = "KERNEL-DENSITY ESTIMATION"
    lines.extend([title, "-" * len(title)])
    for analysis in analyses:
        lines.append(f"Column: {analysis['column']}")
        lines.append(
            f"  Complete cases = {analysis['n_complete_cases']}; "
            f"excluded rows = {analysis['excluded_rows']}"
        )
        if analysis.get("status") not in {"completed", "completed_with_warnings"}:
            lines.append(
                f"  Estimation not run ({analysis.get('reason', 'unspecified reason')})"
            )
            _append_numerical_status(lines, analysis)
            lines.append("")
            continue
        validation = analysis["density_validation"]
        lines.extend(
            [
                f"  Kernel = {analysis['kernel']}; bandwidth = "
                f"{format_number(analysis['bandwidth'])}; selection = "
                f"{analysis['bandwidth_selection']}",
                f"  Scott bandwidth = {format_number(analysis['scott_bandwidth'])}; "
                f"Silverman bandwidth = "
                f"{format_number(analysis['silverman_bandwidth'])}",
                f"  Reported grid = {analysis['grid_size']} points from "
                f"{format_number(validation['grid_lower'])} through "
                f"{format_number(validation['grid_upper'])}",
                f"  Density checks: finite = "
                f"{format_number(validation['all_grid_values_finite'])}; "
                f"nonnegative = "
                f"{format_number(validation['all_grid_densities_nonnegative'])}; "
                f"grid integral = "
                f"{format_number(validation['trapezoidal_integral_over_reported_grid'])}",
                "  The complete density grid and bandwidth search are retained in JSON output.",
            ]
        )
        _append_numerical_status(lines, analysis)
        lines.append("")


def _append_logistic_regressions(
    lines: list[str], results: dict[str, Any]
) -> None:
    if results["binary_logistic_regression_analyses"]:
        lines.extend(["BINARY LOGISTIC REGRESSION", "-" * 26])
        for model in results["binary_logistic_regression_analyses"]:
            lines.append(
                f"{model.get('model_name') or 'Model'}: "
                f"{model['outcome_variable']} = "
                f"f({', '.join(model['predictors'])})"
            )
            lines.append(
                f"  Complete cases = {model['n_complete_cases']}; "
                f"excluded rows = {model['excluded_rows']}"
            )
            for coding in model["categorical_codings"]:
                lines.append(
                    f"  Categorical predictor {coding['predictor']}: "
                    f"reference = {coding['reference_category']}; categories = "
                    f"{', '.join(coding['categories'])}"
                )
            _append_engineered_terms(lines, model)
            if model.get("status") != "completed":
                lines.append(f"  Model not run ({model['reason']})")
                _append_numerical_status(lines, model, indent="    ")
                _append_information_diagnostics(lines, model, indent="    ")
                lines.append("")
                continue
            lines.extend(
                [
                    f"  Event = {model['event_category']}; nonevent = "
                    f"{model['nonevent_category']}",
                    f"  Events = {model['events']}; nonevents = {model['nonevents']}",
                    f"  Log likelihood = {format_number(model['log_likelihood'])}",
                    f"  Likelihood-ratio chi-square = "
                    f"{format_number(model['likelihood_ratio_statistic'])}, "
                    f"df = {model['likelihood_ratio_degrees_of_freedom']}, "
                    f"p = {format_number(model['likelihood_ratio_p_value'])}",
                    f"  McFadden R-squared = "
                    f"{format_number(model['mcfadden_r_squared'])}",
                    f"  Cox-Snell R-squared = "
                    f"{format_number(model['cox_snell_r_squared'])}",
                    f"  Nagelkerke R-squared = "
                    f"{format_number(model['nagelkerke_r_squared'])}",
                    f"  AIC = {format_number(model['aic'])}",
                    f"  BIC = {format_number(model['bic'])}",
                    f"  Decision = {model['decision']}",
                    "",
                    "  Coefficients for event log odds:",
                    "    Term | Estimate | Std. Error | z | p-value | Odds ratio | OR CI",
                ]
            )
            for coefficient in model["coefficients"]:
                odds_interval = coefficient["odds_ratio_confidence_interval"]
                lines.append(
                    f"    {coefficient['term']} | "
                    f"{format_number(coefficient['estimate'])} | "
                    f"{format_number(coefficient['standard_error'])} | "
                    f"{format_number(coefficient['z_statistic'])} | "
                    f"{format_number(coefficient['p_value'])} | "
                    f"{format_number(coefficient['odds_ratio'])} | "
                    f"({format_number(odds_interval[0])}, "
                    f"{format_number(odds_interval[1])})"
                )

            _append_information_diagnostics(lines, model, indent="    ")
            _append_numerical_status(lines, model, indent="    ")

            classification = model["classification"]
            confusion = classification["confusion_matrix"]
            lines.extend(
                [
                    "",
                    f"  Classification at threshold "
                    f"{format_number(classification['threshold'])}:",
                    f"    TN = {confusion['true_negative']}; "
                    f"FP = {confusion['false_positive']}; "
                    f"FN = {confusion['false_negative']}; "
                    f"TP = {confusion['true_positive']}",
                    f"    Accuracy = {format_number(classification['accuracy'])}",
                    f"    Sensitivity = "
                    f"{format_number(classification['sensitivity'])}",
                    f"    Specificity = "
                    f"{format_number(classification['specificity'])}",
                    f"    Precision = {format_number(classification['precision'])}",
                    f"    F1 score = {format_number(classification['f1_score'])}",
                    f"    ROC AUC = {format_number(classification['roc_auc'])}",
                    f"    Log loss = {format_number(classification['log_loss'])}",
                    f"    Brier score = "
                    f"{format_number(classification['brier_score'])}",
                    "",
                    "  Calibration and influence diagnostics:",
                ]
            )
            lines.extend(format_test(model["hosmer_lemeshow_test"], "    "))
            lines.append(
                "    Standardized-design condition number = "
                f"{format_number(model['condition_number_standardized_design'])}"
            )
            lines.append("    Term | VIF | Tolerance")
            for factor in model["variance_inflation_factors"]:
                lines.append(
                    f"    {factor['term']} | {format_number(factor['vif'])} | "
                    f"{format_number(factor['tolerance'])}"
                )
            influence = model["influence_diagnostics"]
            maximum_pearson = influence[
                "maximum_absolute_standardized_pearson_residual"
            ]
            lines.extend(
                [
                    f"    Maximum leverage = "
                    f"{format_number(influence['maximum_leverage'])} "
                    f"(threshold {format_number(influence['leverage_threshold'])})",
                    f"    Maximum |standardized Pearson residual| = "
                    f"{format_number(maximum_pearson)}",
                    f"    Maximum Cook's distance = "
                    f"{format_number(influence['maximum_cooks_distance'])} "
                    f"(threshold "
                    f"{format_number(influence['cooks_distance_threshold'])})",
                    f"    Flagged cases = {influence['flagged_case_count']}",
                ]
            )
            for case in influence["flagged_cases"][:10]:
                lines.append(
                    f"      Index {format_number(case['source_index'])}: "
                    f"probability = "
                    f"{format_number(case['predicted_probability'])}, "
                    f"Pearson residual = "
                    f"{format_number(case['standardized_pearson_residual'])}, "
                    f"leverage = {format_number(case['leverage'])}, "
                    f"Cook's D = {format_number(case['cooks_distance'])}"
                )
            if influence["flagged_case_count"] > 10:
                lines.append("      Additional flagged cases are available in JSON output.")
            for warning in model["assumption_warnings"]:
                lines.append(f"    Warning: {warning}")
            lines.append("")

    if results["multinomial_logistic_regression_analyses"]:
        lines.extend(["MULTINOMIAL LOGISTIC REGRESSION", "-" * 31])
        for model in results["multinomial_logistic_regression_analyses"]:
            lines.append(
                f"{model.get('model_name') or 'Model'}: "
                f"{model['outcome_variable']} = "
                f"f({', '.join(model['predictors'])})"
            )
            lines.append(
                f"  Complete cases = {model['n_complete_cases']}; "
                f"excluded rows = {model['excluded_rows']}"
            )
            for coding in model["categorical_codings"]:
                lines.append(
                    f"  Categorical predictor {coding['predictor']}: "
                    f"reference = {coding['reference_category']}; categories = "
                    f"{', '.join(coding['categories'])}"
                )
            _append_engineered_terms(lines, model)
            if model.get("status") != "completed":
                lines.append(f"  Model not run ({model['reason']})")
                _append_numerical_status(lines, model, indent="    ")
                _append_information_diagnostics(lines, model, indent="    ")
                lines.append("")
                continue
            lines.extend(
                [
                    f"  Outcome reference category = {model['reference_category']}",
                    f"  Outcome counts = "
                    + ", ".join(
                        f"{category}: {count}"
                        for category, count in model["category_counts"].items()
                    ),
                    f"  Log likelihood = {format_number(model['log_likelihood'])}",
                    f"  Likelihood-ratio chi-square = "
                    f"{format_number(model['likelihood_ratio_statistic'])}, "
                    f"df = {model['likelihood_ratio_degrees_of_freedom']}, "
                    f"p = {format_number(model['likelihood_ratio_p_value'])}",
                    f"  McFadden R-squared = "
                    f"{format_number(model['mcfadden_r_squared'])}",
                    f"  AIC = {format_number(model['aic'])}",
                    f"  BIC = {format_number(model['bic'])}",
                    f"  Decision = {model['decision']}",
                ]
            )
            for outcome_category in model["outcome_categories"][1:]:
                lines.extend(
                    [
                        "",
                        f"  Coefficients for {outcome_category} versus "
                        f"{model['reference_category']}:",
                        "    Term | Estimate | Std. Error | z | p-value | RRR | RRR CI",
                    ]
                )
                for coefficient in model["coefficients"]:
                    if coefficient["outcome_category"] != outcome_category:
                        continue
                    ratio_interval = coefficient[
                        "relative_risk_ratio_confidence_interval"
                    ]
                    lines.append(
                        f"    {coefficient['term']} | "
                        f"{format_number(coefficient['estimate'])} | "
                        f"{format_number(coefficient['standard_error'])} | "
                        f"{format_number(coefficient['z_statistic'])} | "
                        f"{format_number(coefficient['p_value'])} | "
                        f"{format_number(coefficient['relative_risk_ratio'])} | "
                        f"({format_number(ratio_interval[0])}, "
                        f"{format_number(ratio_interval[1])})"
                    )

            _append_information_diagnostics(lines, model, indent="    ")
            _append_numerical_status(lines, model, indent="    ")

            classification = model["classification"]
            lines.extend(["", "  Classification:"])
            _append_matrix(
                lines,
                classification["row_categories_actual"],
                classification["column_categories_predicted"],
                classification["confusion_matrix"],
                "Confusion matrix (actual rows, predicted columns)",
            )
            lines.extend(
                [
                    f"    Accuracy = {format_number(classification['accuracy'])}",
                    f"    Macro precision = "
                    f"{format_number(classification['macro_precision'])}",
                    f"    Macro recall = "
                    f"{format_number(classification['macro_recall'])}",
                    f"    Macro F1 = "
                    f"{format_number(classification['macro_f1_score'])}",
                    f"    Log loss = {format_number(classification['log_loss'])}",
                    f"    Multiclass Brier score = "
                    f"{format_number(classification['multiclass_brier_score'])}",
                ]
            )
            for category in classification["per_category"]:
                lines.append(
                    f"    {category['category']}: support = {category['support']}, "
                    f"precision = {format_number(category['precision'])}, "
                    f"recall = {format_number(category['recall'])}, "
                    f"F1 = {format_number(category['f1_score'])}"
                )
            lines.extend(["", "  Collinearity diagnostics:"])
            lines.append(
                "    Standardized-design condition number = "
                f"{format_number(model['condition_number_standardized_design'])}"
            )
            lines.append("    Term | VIF | Tolerance")
            for factor in model["variance_inflation_factors"]:
                lines.append(
                    f"    {factor['term']} | {format_number(factor['vif'])} | "
                    f"{format_number(factor['tolerance'])}"
                )
            for warning in model["assumption_warnings"]:
                lines.append(f"    Warning: {warning}")
            lines.append("")

    if results["model_comparisons"]:
        lines.extend(["REGRESSION MODEL COMPARISONS", "-" * 28])
        for comparison in results["model_comparisons"]:
            lines.append(comparison.get("comparison_name") or "Model comparison")
            lines.append(
                f"  Dependent variable: {comparison['dependent_variable']}"
            )
            lines.append(
                f"  Reduced predictors: {', '.join(comparison['reduced_predictors'])}"
            )
            lines.append(
                f"  Full predictors: {', '.join(comparison['full_predictors'])}"
            )
            lines.append(f"  Common cases = {comparison['n_common_cases']}")
            if comparison.get("status") != "completed":
                lines.append(f"  Comparison not run ({comparison['reason']})")
                lines.append("")
                continue
            reduced = comparison["reduced_model"]
            full = comparison["full_model"]
            lines.extend(
                [
                    "  Metric | Reduced | Full | Full minus reduced",
                    f"  R-squared | {format_number(reduced['r_squared'])} | "
                    f"{format_number(full['r_squared'])} | "
                    f"{format_number(comparison['change_in_r_squared'])}",
                    f"  Adjusted R-squared | "
                    f"{format_number(reduced['adjusted_r_squared'])} | "
                    f"{format_number(full['adjusted_r_squared'])} | "
                    f"{format_number(comparison['change_in_adjusted_r_squared'])}",
                    f"  AIC | {format_number(reduced['aic'])} | "
                    f"{format_number(full['aic'])} | "
                    f"{format_number(comparison['change_in_aic'])}",
                    f"  BIC | {format_number(reduced['bic'])} | "
                    f"{format_number(full['bic'])} | "
                    f"{format_number(comparison['change_in_bic'])}",
                ]
            )
            partial = comparison["partial_f_test"]
            if partial.get("status") == "completed":
                lines.extend(format_test(partial))
            else:
                lines.append(
                    f"  Partial F-test not run ({partial.get('reason')})"
                )
            lines.append("")


def _append_count_offset(lines: list[str], model: dict[str, Any]) -> None:
    if model.get("offset_variable") is not None:
        lines.append(
            f"  Fixed log offset: {model['offset_variable']} "
            "(values supplied on the log scale)"
        )
    if model.get("exposure_variable") is not None:
        lines.append(
            f"  Exposure: {model['exposure_variable']} "
            "(natural logarithm used as a fixed offset)"
        )


def _append_poisson_mean_analyses(
    lines: list[str], results: dict[str, Any]
) -> None:
    analyses = results.get("poisson_mean_analyses", [])
    if not analyses:
        return
    lines.extend(["POISSON MEAN CONFIDENCE INTERVALS", "-" * 33])
    for analysis in analyses:
        interval = analysis["confidence_interval"]
        confidence_percent = 100.0 * analysis["confidence_level"]
        lines.extend(
            [
                f"Observed events = {analysis['events']}",
                f"  Model: {analysis['distribution']}",
                f"  Formula: {analysis['likelihood_formula']}",
                f"  MLE of M = {format_number(analysis['mle_mean'])}",
                f"  Maximized likelihood = "
                f"{format_number(analysis['maximized_likelihood'])}",
                f"  Maximized log-likelihood = "
                f"{format_number(analysis['maximized_log_likelihood'])}",
                f"  Exact {format_number(confidence_percent)}% CI for M = "
                f"({format_number(interval[0])}, "
                f"{format_number(interval[1])})",
                "",
            ]
        )


def _append_poisson_regressions(
    lines: list[str], results: dict[str, Any]
) -> None:
    models = results.get("poisson_regression_analyses", [])
    if not models:
        return
    lines.extend(["POISSON COUNT REGRESSION", "-" * 24])
    for model in models:
        lines.append(
            f"{model.get('model_name') or 'Model'}: "
            f"{model['outcome_variable']} = f({', '.join(model['predictors'])})"
        )
        lines.append(
            f"  Complete cases = {model['n_complete_cases']}; "
            f"excluded rows = {model['excluded_rows']}"
        )
        _append_count_offset(lines, model)
        for coding in model["categorical_codings"]:
            lines.append(
                f"  Categorical predictor {coding['predictor']}: "
                f"reference = {coding['reference_category']}; categories = "
                f"{', '.join(coding['categories'])}"
            )
        _append_engineered_terms(lines, model)
        if model.get("status") != "completed":
            lines.append(f"  Model not run ({model['reason']})")
            _append_numerical_status(lines, model, indent="    ")
            _append_information_diagnostics(lines, model, indent="    ")
            lines.append("")
            continue
        lines.extend(
            [
                f"  Log likelihood = {format_number(model['log_likelihood'])}",
                f"  Likelihood-ratio chi-square = "
                f"{format_number(model['likelihood_ratio_statistic'])}, "
                f"df = {model['likelihood_ratio_degrees_of_freedom']}, "
                f"p = {format_number(model['likelihood_ratio_p_value'])}",
                f"  McFadden R-squared = {format_number(model['mcfadden_r_squared'])}",
                f"  AIC = {format_number(model['aic'])}",
                f"  BIC = {format_number(model['bic'])}",
                f"  Decision = {model['decision']}",
                "",
                "  Coefficients for log expected count:",
                "    Term | Estimate | Std. Error | z | p-value | IRR | IRR CI",
            ]
        )
        for coefficient in model["coefficients"]:
            interval = coefficient[
                "incidence_rate_ratio_confidence_interval"
            ]
            lines.append(
                f"    {coefficient['term']} | "
                f"{format_number(coefficient['estimate'])} | "
                f"{format_number(coefficient['standard_error'])} | "
                f"{format_number(coefficient['z_statistic'])} | "
                f"{format_number(coefficient['p_value'])} | "
                f"{format_number(coefficient['incidence_rate_ratio'])} | "
                f"({format_number(interval[0])}, {format_number(interval[1])})"
            )
        _append_information_diagnostics(lines, model, indent="    ")
        _append_numerical_status(lines, model, indent="    ")
        goodness = model["goodness_of_fit"]
        prediction = model["prediction_metrics"]
        lines.extend(
            [
                "",
                "  Dispersion and goodness of fit:",
                f"    Residual df = {model['residual_degrees_of_freedom']}",
                f"    Deviance = {format_number(model['deviance'])}; "
                f"deviance/df = {format_number(model['deviance_dispersion'])}; "
                f"p = {format_number(goodness['deviance_p_value'])}",
                f"    Pearson chi-square = "
                f"{format_number(model['pearson_chi_square'])}; "
                f"Pearson dispersion = "
                f"{format_number(model['pearson_dispersion'])}; "
                f"p = {format_number(goodness['pearson_p_value'])}",
                f"    Note: {goodness['note']}",
                "",
                "  Count prediction:",
                f"    Mean observed = "
                f"{format_number(prediction['mean_observed_count'])}; "
                f"mean fitted = {format_number(prediction['mean_fitted_count'])}",
                f"    MAE = {format_number(prediction['mean_absolute_error'])}; "
                f"RMSE = {format_number(prediction['root_mean_squared_error'])}",
                f"    Observed zero rate = "
                f"{format_number(prediction['observed_zero_rate'])}; "
                f"mean predicted zero probability = "
                f"{format_number(prediction['mean_predicted_zero_probability'])}",
                "",
                "  Collinearity and influence diagnostics:",
                "    Standardized-design condition number = "
                f"{format_number(model['condition_number_standardized_design'])}",
                "    Term | VIF | Tolerance",
            ]
        )
        for factor in model["variance_inflation_factors"]:
            lines.append(
                f"    {factor['term']} | {format_number(factor['vif'])} | "
                f"{format_number(factor['tolerance'])}"
            )
        influence = model["influence_diagnostics"]
        lines.extend(
            [
                f"    Maximum leverage = "
                f"{format_number(influence['maximum_leverage'])} "
                f"(threshold {format_number(influence['leverage_threshold'])})",
                f"    Maximum |standardized Pearson residual| = "
                f"{format_number(influence['maximum_absolute_standardized_pearson_residual'])}",
                f"    Maximum Cook's distance = "
                f"{format_number(influence['maximum_cooks_distance'])} "
                f"(threshold {format_number(influence['cooks_distance_threshold'])})",
                f"    Flagged cases = {influence['flagged_case_count']}",
            ]
        )
        for case in influence["flagged_cases"][:10]:
            lines.append(
                f"      Index {case['row_index']}: observed = "
                f"{format_number(case['observed_count'])}, fitted = "
                f"{format_number(case['fitted_count'])}, Pearson residual = "
                f"{format_number(case['standardized_pearson_residual'])}, "
                f"leverage = {format_number(case['leverage'])}, "
                f"Cook's D = {format_number(case['cooks_distance'])}"
            )
        if influence["flagged_case_count"] > 10:
            lines.append("      Additional flagged cases are available in JSON output.")
        for warning in model["assumption_warnings"]:
            lines.append(f"    Warning: {warning}")
        lines.append("")


def _append_negative_binomial_regressions(
    lines: list[str], results: dict[str, Any]
) -> None:
    models = results.get("negative_binomial_regression_analyses", [])
    if not models:
        return
    lines.extend(["NEGATIVE-BINOMIAL COUNT REGRESSION", "-" * 34])
    for model in models:
        lines.append(
            f"{model.get('model_name') or 'Model'}: "
            f"{model['outcome_variable']} = f({', '.join(model['predictors'])})"
        )
        lines.append(
            f"  Complete cases = {model['n_complete_cases']}; "
            f"excluded rows = {model['excluded_rows']}"
        )
        _append_count_offset(lines, model)
        for coding in model["categorical_codings"]:
            lines.append(
                f"  Categorical predictor {coding['predictor']}: "
                f"reference = {coding['reference_category']}; categories = "
                f"{', '.join(coding['categories'])}"
            )
        _append_engineered_terms(lines, model)
        if model.get("status") != "completed":
            lines.append(f"  Model not run ({model['reason']})")
            _append_numerical_status(lines, model, indent="    ")
            _append_information_diagnostics(lines, model, indent="    ")
            lines.append("")
            continue
        dispersion_interval = model["dispersion_confidence_interval"]
        lines.extend(
            [
                f"  Variance model: {model['variance_function']}",
                f"  Dispersion parameter = "
                f"{format_number(model['dispersion_parameter'])}; CI = "
                f"{_format_estimation_interval(dispersion_interval)}",
                f"  Negative-binomial size = "
                f"{format_number(model['negative_binomial_size'])}; SE = "
                f"{format_number(model['negative_binomial_size_standard_error'])}",
                f"  Log likelihood = {format_number(model['log_likelihood'])}",
                f"  Likelihood-ratio chi-square = "
                f"{format_number(model['likelihood_ratio_statistic'])}, "
                f"df = {model['likelihood_ratio_degrees_of_freedom']}, "
                f"p = {format_number(model['likelihood_ratio_p_value'])}",
                f"  McFadden R-squared = "
                f"{format_number(model['mcfadden_r_squared'])}",
                f"  AIC = {format_number(model['aic'])}",
                f"  BIC = {format_number(model['bic'])}",
                f"  Decision = {model['decision']}",
                "",
                "  Coefficients for log expected count:",
                "    Term | Estimate | Std. Error | z | p-value | IRR | IRR CI",
            ]
        )
        if model["dispersion_wald_inference"].get("status") != "completed":
            lines.append(
                f"  Dispersion Wald inference = "
                f"{model['dispersion_wald_inference']['status']} "
                f"({model['dispersion_wald_inference']['reason']})"
            )
        for coefficient in model["coefficients"]:
            interval = coefficient[
                "incidence_rate_ratio_confidence_interval"
            ]
            lines.append(
                f"    {coefficient['term']} | "
                f"{format_number(coefficient['estimate'])} | "
                f"{format_number(coefficient['standard_error'])} | "
                f"{format_number(coefficient['z_statistic'])} | "
                f"{format_number(coefficient['p_value'])} | "
                f"{format_number(coefficient['incidence_rate_ratio'])} | "
                f"({format_number(interval[0])}, {format_number(interval[1])})"
            )

        _append_information_diagnostics(lines, model, indent="    ")
        _append_numerical_status(lines, model, indent="    ")

        comparison = model["poisson_comparison"]
        lines.extend(["", "  Poisson comparison:"])
        if comparison.get("status") == "completed":
            lines.extend(
                [
                    f"    Boundary LR statistic = "
                    f"{format_number(comparison['statistic'])}",
                    f"    Mixture chi-square p-value = "
                    f"{format_number(comparison['mixture_chi_square_p_value'])}",
                    f"    Poisson AIC = {format_number(comparison['poisson_aic'])}; "
                    f"negative-binomial AIC = "
                    f"{format_number(comparison['negative_binomial_aic'])}",
                    f"    Poisson Pearson dispersion = "
                    f"{format_number(comparison['poisson_pearson_dispersion'])}",
                    f"    Interpretation: {comparison['interpretation']}",
                    f"    Note: {comparison['note']}",
                ]
            )
        else:
            lines.append(
                f"    Comparison not run ({comparison.get('reason')})"
            )

        goodness = model["goodness_of_fit"]
        prediction = model["prediction_metrics"]
        lines.extend(
            [
                "",
                "  Dispersion and goodness of fit:",
                f"    Residual df = {model['residual_degrees_of_freedom']}",
                f"    Deviance = {format_number(model['deviance'])}; "
                f"deviance/df = {format_number(model['deviance_dispersion'])}; "
                f"p = {format_number(goodness['deviance_p_value'])}",
                f"    Pearson chi-square = "
                f"{format_number(model['pearson_chi_square'])}; "
                f"Pearson dispersion = "
                f"{format_number(model['pearson_dispersion'])}; "
                f"p = {format_number(goodness['pearson_p_value'])}",
                f"    Note: {goodness['note']}",
                "",
                "  Count prediction:",
                f"    Mean observed = "
                f"{format_number(prediction['mean_observed_count'])}; "
                f"mean fitted = {format_number(prediction['mean_fitted_count'])}",
                f"    MAE = {format_number(prediction['mean_absolute_error'])}; "
                f"RMSE = {format_number(prediction['root_mean_squared_error'])}",
                f"    Observed zero rate = "
                f"{format_number(prediction['observed_zero_rate'])}; "
                f"mean predicted zero probability = "
                f"{format_number(prediction['mean_predicted_zero_probability'])}",
                "",
                "  Collinearity and influence diagnostics:",
                "    Standardized-design condition number = "
                f"{format_number(model['condition_number_standardized_design'])}",
                "    Term | VIF | Tolerance",
            ]
        )
        for factor in model["variance_inflation_factors"]:
            lines.append(
                f"    {factor['term']} | {format_number(factor['vif'])} | "
                f"{format_number(factor['tolerance'])}"
            )
        influence = model["influence_diagnostics"]
        lines.extend(
            [
                f"    Maximum leverage = "
                f"{format_number(influence['maximum_leverage'])} "
                f"(threshold {format_number(influence['leverage_threshold'])})",
                f"    Maximum |standardized Pearson residual| = "
                f"{format_number(influence['maximum_absolute_standardized_pearson_residual'])}",
                f"    Maximum Cook's distance = "
                f"{format_number(influence['maximum_cooks_distance'])} "
                f"(threshold {format_number(influence['cooks_distance_threshold'])})",
                f"    Flagged cases = {influence['flagged_case_count']}",
            ]
        )
        for case in influence["flagged_cases"][:10]:
            lines.append(
                f"      Index {case['row_index']}: observed = "
                f"{format_number(case['observed_count'])}, fitted = "
                f"{format_number(case['fitted_count'])}, Pearson residual = "
                f"{format_number(case['standardized_pearson_residual'])}, "
                f"leverage = {format_number(case['leverage'])}, "
                f"Cook's D = {format_number(case['cooks_distance'])}"
            )
        if influence["flagged_case_count"] > 10:
            lines.append("      Additional flagged cases are available in JSON output.")
        for warning in model["assumption_warnings"]:
            lines.append(f"    Warning: {warning}")
        lines.append("")


def _append_factorial_analyses(
    lines: list[str], results: dict[str, Any]
) -> None:
    analyses = results.get("factorial_analyses", [])
    if not analyses:
        return
    lines.extend(["TWO-WAY ANOVA AND ANCOVA", "-" * 25])
    for model in analyses:
        lines.append(
            f"{model.get('model_name') or 'Factorial model'}: "
            f"outcome = {model['outcome_variable']}; factors = "
            f"{model['factor_1']}, {model['factor_2']}"
        )
        if model["covariates"]:
            lines.append(f"  Covariates: {', '.join(model['covariates'])}")
        lines.append(
            f"  Complete cases = {model['n_complete_cases']}; "
            f"excluded rows = {model['excluded_rows']}"
        )
        lines.append(f"  Coding: {model['coding']}")
        if model.get("status") != "completed":
            lines.append(f"  Model not run ({model['reason']})")
            _append_numerical_status(lines, model, indent="    ")
            _append_information_diagnostics(lines, model, indent="    ")
            lines.append("")
            continue
        overall = model["overall_model_test"]
        lines.extend(
            [
                f"  Overall F({overall['degrees_of_freedom'][0]}, "
                f"{overall['degrees_of_freedom'][1]}) = "
                f"{format_number(overall['f_statistic'])}; "
                f"p = {format_number(overall['p_value'])}",
                f"  R-squared = {format_number(model['r_squared'])}; "
                f"adjusted R-squared = "
                f"{format_number(model['adjusted_r_squared'])}",
                "",
                "  Type III effect tests:",
                "    Effect | SS | df | MS | F | p-value | Partial eta-squared",
            ]
        )
        for effect in model["type_iii_effect_tests"]:
            lines.append(
                f"    {effect['effect']} | "
                f"{format_number(effect['sum_of_squares'])} | "
                f"{effect['degrees_of_freedom']} | "
                f"{format_number(effect['mean_square'])} | "
                f"{format_number(effect['f_statistic'])} | "
                f"{format_number(effect['p_value'])} | "
                f"{format_number(effect['partial_eta_squared'])}"
            )
        lines.extend(["", "  Cell descriptives:"])
        for cell in model["cell_descriptives"]:
            lines.append(
                f"    {model['factor_1']}={cell[model['factor_1']]}, "
                f"{model['factor_2']}={cell[model['factor_2']]}: "
                f"n={cell['n']}, mean={format_number(cell['mean'])}, "
                f"SD={format_number(cell['standard_deviation'])}"
            )
        marginal = model["estimated_marginal_means"]
        if marginal["covariates_held_at"]:
            lines.append(
                "  Covariates held at: "
                + ", ".join(
                    f"{name}={format_number(value)}"
                    for name, value in marginal["covariates_held_at"].items()
                )
            )
        for factor_name, factor_result in marginal["factors"].items():
            lines.extend(["", f"  Estimated marginal means for {factor_name}:"])
            for mean in factor_result["marginal_means"]:
                interval = mean["confidence_interval"]
                lines.append(
                    f"    {mean['level']}: {format_number(mean['estimate'])} "
                    f"(SE {format_number(mean['standard_error'])}; CI "
                    f"{format_number(interval[0])}, {format_number(interval[1])})"
                )
            lines.append(
                f"  Adjusted pairwise comparisons ({marginal['pairwise_adjustment']}):"
            )
            for comparison in factor_result["pairwise_comparisons"]:
                lines.append(
                    f"    {comparison['level_1']} - {comparison['level_2']}: "
                    f"difference={format_number(comparison['difference'])}, "
                    f"t={format_number(comparison['t_statistic'])}, "
                    f"raw p={format_number(comparison['p_value'])}, "
                    f"adjusted p={format_number(comparison['adjusted_p_value'])}"
                )
        checks = model["assumption_checks"]
        lines.extend(["", "  Assumption checks:"])
        lines.extend(format_test(checks["levene_test"], "    "))
        lines.extend(format_test(checks["breusch_pagan_test"], "    "))
        slope = checks["homogeneity_of_slopes_test"]
        if slope.get("status") == "completed":
            lines.append(
                f"    Homogeneity-of-slopes F = "
                f"{format_number(slope['f_statistic'])}; "
                f"p = {format_number(slope['p_value'])}"
            )
        lines.append("")


def _append_repeated_measures(
    lines: list[str], results: dict[str, Any]
) -> None:
    analyses = results.get("repeated_measures_analyses", [])
    if not analyses:
        return
    lines.extend(["REPEATED-MEASURES ANOVA", "-" * 24])
    for model in analyses:
        lines.append(
            f"{model.get('model_name') or 'Repeated-measures model'}: "
            f"outcome = {model['outcome_variable']}; within factor = "
            f"{model['within_subject_factor']}; subject = {model['subject_variable']}"
        )
        if model.get("status") != "completed":
            lines.append(f"  Model not run ({model['reason']})")
            lines.append("")
            continue
        lines.extend(
            [
                f"  Complete subjects = {model['complete_subjects']}; "
                f"excluded incomplete subjects = "
                f"{model['excluded_incomplete_subjects']}",
                f"  F({model['degrees_of_freedom'][0]}, "
                f"{model['degrees_of_freedom'][1]}) = "
                f"{format_number(model['f_statistic'])}; "
                f"p = {format_number(model['p_value'])}",
                f"  Partial eta-squared = "
                f"{format_number(model['partial_eta_squared'])}",
            ]
        )
        correction = model["sphericity_correction"]
        lines.append(
            f"  Greenhouse-Geisser epsilon = "
            f"{format_number(correction['greenhouse_geisser_epsilon'])}; "
            f"corrected p = {format_number(correction['corrected_p_value'])}"
        )
        lines.extend(["", "  Estimated marginal means:"])
        for mean in model["estimated_marginal_means"]:
            interval = mean["confidence_interval"]
            lines.append(
                f"    {mean['level']}: {format_number(mean['estimate'])} "
                f"(CI {format_number(interval[0])}, {format_number(interval[1])})"
            )
        lines.append(
            f"  Adjusted paired comparisons ({model['pairwise_adjustment']}):"
        )
        for comparison in model["pairwise_comparisons"]:
            lines.append(
                f"    {comparison['level_1']} - {comparison['level_2']}: "
                f"difference={format_number(comparison['mean_difference'])}, "
                f"t={format_number(comparison['t_statistic'])}, "
                f"adjusted p={format_number(comparison['adjusted_p_value'])}, "
                f"Cohen's dz={format_number(comparison['cohens_dz'])}"
            )
        lines.append("")


def _append_mixed_effects(
    lines: list[str], results: dict[str, Any]
) -> None:
    analyses = results.get("mixed_effects_analyses", [])
    if not analyses:
        return
    lines.extend(["LINEAR MIXED-EFFECTS MODELS", "-" * 28])
    for model in analyses:
        lines.append(
            f"{model.get('model_name') or 'Mixed-effects model'}: "
            f"{model['outcome_variable']} = f({', '.join(model['predictors'])}) "
            f"with random intercept for {model['group_variable']}"
        )
        lines.append(
            f"  Complete cases = {model['n_complete_cases']}; "
            f"groups = {model['group_count']}; estimation = "
            f"{model['estimation_method']}"
        )
        for coding in model["categorical_codings"]:
            lines.append(
                f"  Categorical predictor {coding['predictor']}: "
                f"reference = {coding['reference_category']}"
            )
        _append_engineered_terms(lines, model)
        if model.get("status") != "completed":
            lines.append(f"  Model not run ({model['reason']})")
            _append_numerical_status(lines, model, indent="    ")
            _append_information_diagnostics(lines, model, indent="    ")
            lines.append("")
            continue
        lines.extend(
            [
                "  Fixed effects:",
                "    Term | Estimate | Std. Error | z | p-value | CI",
            ]
        )
        for coefficient in model["coefficients"]:
            interval = coefficient["confidence_interval"]
            lines.append(
                f"    {coefficient['term']} | "
                f"{format_number(coefficient['estimate'])} | "
                f"{format_number(coefficient['standard_error'])} | "
                f"{format_number(coefficient['z_statistic'])} | "
                f"{format_number(coefficient['p_value'])} | "
                f"({format_number(interval[0])}, {format_number(interval[1])})"
            )
        _append_information_diagnostics(
            lines,
            model,
            diagnostics_key="fixed_effect_information_diagnostics",
            type_key="fixed_effect_information_type",
            covariance_type_key="fixed_effect_covariance_type",
            hessian_key=None,
            label="Fixed-effect information matrix",
            indent="    ",
        )
        variance = model["variance_components"]
        lines.extend(
            [
                "",
                "  Variance components:",
                f"    Random-intercept variance = "
                f"{format_number(variance['random_intercept_variance'])}",
                f"    Residual variance = "
                f"{format_number(variance['residual_variance'])}",
                f"    Intraclass correlation = "
                f"{format_number(variance['intraclass_correlation'])}",
                f"  Marginal R-squared = "
                f"{format_number(model['marginal_r_squared'])}; "
                f"conditional R-squared = "
                f"{format_number(model['conditional_r_squared'])}",
                f"  ML AIC = {format_number(model['aic_ml'])}; "
                f"ML BIC = {format_number(model['bic_ml'])}",
            ]
        )
        component_inference = model["variance_component_inference"]
        if component_inference.get("status") == "completed":
            lines.extend(
                [
                    f"    Random-intercept variance CI = "
                    f"{_format_estimation_interval(component_inference['random_intercept_variance_confidence_interval'])}",
                    f"    Residual variance CI = "
                    f"{_format_estimation_interval(component_inference['residual_variance_confidence_interval'])}",
                    f"    Intraclass-correlation CI = "
                    f"{_format_estimation_interval(component_inference['intraclass_correlation_confidence_interval'])}",
                ]
            )
        else:
            lines.append(
                f"    Variance-component Wald inference = "
                f"{component_inference.get('status')} "
                f"({component_inference.get('reason', 'unspecified reason')})"
            )
        _append_information_diagnostics(
            lines,
            model,
            diagnostics_key="variance_component_information_diagnostics",
            type_key="variance_component_information_type",
            covariance_type_key=None,
            hessian_key="variance_component_numerical_hessian_diagnostics",
            label="Variance-component information matrix",
            indent="    ",
        )
        _append_numerical_status(lines, model, indent="    ")
        comparison = model["random_intercept_likelihood_ratio_test"]
        if comparison.get("status") == "completed":
            lines.append(
                f"  Random-intercept boundary LR = "
                f"{format_number(comparison['statistic'])}; mixture p = "
                f"{format_number(comparison['mixture_chi_square_p_value'])}"
            )
            lines.append(f"  Interpretation: {comparison['interpretation']}")
        else:
            lines.append(
                f"  Random-intercept boundary LR not run "
                f"({comparison.get('reason', 'unspecified reason')})"
            )
        for warning in model["assumption_warnings"]:
            lines.append(f"  Warning: {warning}")
        lines.append("")


def _append_casewise_export(
    lines: list[str], results: dict[str, Any]
) -> None:
    if "casewise_prediction_count" not in results:
        return
    lines.extend(["CASEWISE PREDICTION AND RESIDUAL EXPORT", "-" * 39])
    lines.append(
        f"Rows prepared: {results['casewise_prediction_count']}"
    )
    files = results["casewise_export_files"]
    if files.get("predictions"):
        lines.append(f"Prediction file: {files['predictions']}")
    if files.get("residuals"):
        lines.append(f"Residual file: {files['residuals']}")
    lines.append("")


def _append_generated_plots(
    lines: list[str], results: dict[str, Any]
) -> None:
    plots = results.get("generated_plots", [])
    if not plots:
        return
    settings = results.get("plot_settings", {})
    lines.extend(["GENERATED PLOTS", "-" * 15])
    lines.append(
        f"Plots created: {len(plots)}; format = {settings.get('format', 'unknown')}; "
        f"DPI = {settings.get('dpi', 'unknown')}"
    )
    for plot in plots:
        model_text = (
            f"; model = {plot['model_name']}" if plot.get("model_name") else ""
        )
        lines.append(
            f"  {plot['plot_type']}: {plot['title']}{model_text}"
        )
        lines.append(f"    File: {plot['file']}")
    lines.append("")


def _append_matrix(
    lines: list[str],
    row_labels: list[str],
    column_labels: list[str],
    values: list[list[Any]],
    value_label: str,
) -> None:
    lines.append(f"  {value_label}:")
    lines.append("    Row | " + " | ".join(column_labels))
    for row_label, row_values in zip(row_labels, values):
        formatted = " | ".join(format_number(value) for value in row_values)
        lines.append(f"    {row_label} | {formatted}")


def _append_frequency_tables(lines: list[str], results: dict[str, Any]) -> None:
    if not results["frequency_tables"]:
        return
    lines.extend(["FREQUENCY TABLES", "-" * 16])
    for table in results["frequency_tables"]:
        lines.append(f"Column: {table['column']}")
        lines.append(
            f"  Nonmissing = {table['nonmissing']}; missing = {table['missing']}; "
            f"categories = {table['distinct_categories']}"
        )
        lines.append("  Category | Count | Percent | Cumulative percent")
        for category in table["categories"]:
            lines.append(
                f"  {category['category']} | {category['count']} | "
                f"{format_number(category['percentage'])} | "
                f"{format_number(category['cumulative_percentage'])}"
            )
        lines.append("")


def _append_contingency_table(
    lines: list[str], table: dict[str, Any], include_percentages: bool = True
) -> None:
    lines.append(
        f"Rows: {table['row_variable']}; columns: {table['column_variable']}"
    )
    lines.append(
        f"  Complete cases = {table['grand_total']}; "
        f"excluded missing pairs = {table['excluded_missing_pairs']}"
    )
    _append_matrix(
        lines,
        table["row_categories"],
        table["column_categories"],
        table["observed_counts"],
        "Observed counts",
    )
    if include_percentages:
        _append_matrix(
            lines,
            table["row_categories"],
            table["column_categories"],
            table["row_percentages"],
            "Row percentages",
        )


def _append_categorical_tests(lines: list[str], results: dict[str, Any]) -> None:
    if results["contingency_tables"]:
        lines.extend(["CONTINGENCY TABLES", "-" * 18])
        for table in results["contingency_tables"]:
            _append_contingency_table(lines, table)
            lines.append("")

    if results["chi_square_tests"]:
        lines.extend(["CHI-SQUARE TESTS OF INDEPENDENCE", "-" * 32])
        for test in results["chi_square_tests"]:
            _append_contingency_table(lines, test["table"], False)
            if test.get("status") != "completed":
                lines.append(f"  Test not run ({test['reason']})")
                lines.append("")
                continue
            lines.extend(format_test(test))
            lines.append(f"  Cramer's V = {format_number(test['cramers_v'])}")
            _append_matrix(
                lines,
                test["table"]["row_categories"],
                test["table"]["column_categories"],
                test["expected_counts"],
                "Expected counts",
            )
            _append_matrix(
                lines,
                test["table"]["row_categories"],
                test["table"]["column_categories"],
                test["standardized_residuals"],
                "Standardized residuals",
            )
            for warning in test["assumption_warnings"]:
                lines.append(f"  Warning: {warning}")
            lines.append("")

    if results["goodness_of_fit_tests"]:
        lines.extend(["CHI-SQUARE GOODNESS-OF-FIT TESTS", "-" * 32])
        for test in results["goodness_of_fit_tests"]:
            lines.append(f"Column: {test['column']}")
            lines.append(
                f"  Nonmissing = {test['nonmissing']}; missing = {test['missing']}"
            )
            lines.append(
                "  Category | Observed | Expected probability | Expected | Contribution"
            )
            for category in test["categories"]:
                lines.append(
                    f"  {category['category']} | {category['observed_count']} | "
                    f"{format_number(category['expected_probability'])} | "
                    f"{format_number(category['expected_count'])} | "
                    f"{format_number(category['chi_square_contribution'])}"
                )
            lines.extend(format_test(test))
            for warning in test["assumption_warnings"]:
                lines.append(f"  Warning: {warning}")
            lines.append("")

    if results["fisher_exact_tests"]:
        lines.extend(["FISHER'S EXACT TESTS", "-" * 20])
        for test in results["fisher_exact_tests"]:
            _append_contingency_table(lines, test["table"], False)
            if test.get("status") != "completed":
                lines.append(f"  Test not run ({test['reason']})")
            else:
                lines.extend(
                    [
                        f"  Alternative = {test['alternative']}",
                        f"  Odds ratio = {format_number(test['odds_ratio'])}",
                        f"  p-value = {format_number(test['p_value'])}",
                        f"  Decision = {test['decision']}",
                    ]
                )
            lines.append("")


def _format_log_likelihood(value: Any) -> str:
    return "-infinity" if value is None else format_number(value)


def _append_likelihood_details(
    lines: list[str],
    analysis: dict[str, Any],
    indent: str = "  ",
) -> None:
    lines.extend(
        [
            f"{indent}Formula: {analysis['likelihood_formula']}",
            f"{indent}Binomial coefficient = {analysis['binomial_coefficient']}",
            f"{indent}MLE of p = {format_number(analysis['mle_probability'])}",
            f"{indent}Maximized likelihood = "
            f"{format_number(analysis['maximized_likelihood'])}",
            f"{indent}Maximized log-likelihood = "
            f"{format_number(analysis['maximized_log_likelihood'])}",
        ]
    )
    if analysis["evaluations"]:
        lines.append(
            f"{indent}p | likelihood | log-likelihood | relative likelihood"
        )
        for evaluation in analysis["evaluations"]:
            lines.append(
                f"{indent}{format_number(evaluation['probability'])} | "
                f"{format_number(evaluation['likelihood'])} | "
                f"{_format_log_likelihood(evaluation['log_likelihood'])} | "
                f"{format_number(evaluation['relative_likelihood'])}"
            )


def _append_proportion_tests(lines: list[str], results: dict[str, Any]) -> None:
    if results["binomial_likelihood_analyses"]:
        lines.extend(["BINOMIAL LIKELIHOOD ANALYSES", "-" * 29])
        for analysis in results["binomial_likelihood_analyses"]:
            if analysis.get("source") == "aggregate_counts":
                lines.append(
                    f"Aggregate counts: {analysis['successes']} successes "
                    f"in {analysis['n']} trials"
                )
            else:
                lines.append(
                    f"Column: {analysis['column']}; success = "
                    f"{analysis['success_value']}"
                )
            lines.append(
                f"  Successes = {analysis['successes']}; "
                f"failures = {analysis['failures']}; missing = "
                f"{analysis['missing']}"
            )
            if analysis.get("status") != "completed":
                lines.append(f"  Analysis not run ({analysis['reason']})")
            else:
                _append_likelihood_details(lines, analysis)
            lines.append("")

    if results["one_proportion_count_tests"]:
        lines.extend(["AGGREGATE ONE-PROPORTION TESTS", "-" * 30])
        for test in results["one_proportion_count_tests"]:
            lines.append(
                f"Counts: {test['successes']} successes in {test['n']} trials"
            )
            wilson = test["wilson_confidence_interval"]
            exact_interval = test["exact_clopper_pearson_interval"]
            likelihood = test["likelihood_analysis"]
            null_evaluation = likelihood["evaluations"][0]
            lines.extend(
                [
                    f"  Sample proportion = "
                    f"{format_number(test['sample_proportion'])}",
                    f"  Null proportion = "
                    f"{format_number(test['null_proportion'])}",
                    f"  z-score = {format_number(test['z_score'])}",
                    f"  z-test p-value = {format_number(test['z_p_value'])}",
                    f"  Exact binomial p-value = "
                    f"{format_number(test['exact_binomial_p_value'])}",
                    f"  z-test decision = {test['z_test_decision']}",
                    f"  Exact-test decision = {test['exact_test_decision']}",
                    f"  Wilson CI = ({format_number(wilson[0])}, "
                    f"{format_number(wilson[1])})",
                    f"  Exact Clopper-Pearson CI = "
                    f"({format_number(exact_interval[0])}, "
                    f"{format_number(exact_interval[1])})",
                    f"  Likelihood at p0 = "
                    f"{format_number(null_evaluation['likelihood'])}",
                    f"  Log-likelihood at p0 = "
                    f"{_format_log_likelihood(null_evaluation['log_likelihood'])}",
                    f"  MLE of p = "
                    f"{format_number(likelihood['mle_probability'])}",
                    f"  Relative likelihood at p0 = "
                    f"{format_number(null_evaluation['relative_likelihood'])}",
                ]
            )
            lines.append("")

    if results["two_proportion_count_tests"]:
        lines.extend(["AGGREGATE TWO-PROPORTION TESTS", "-" * 30])
        for test in results["two_proportion_count_tests"]:
            for group in test["group_statistics"]:
                interval = group["wilson_confidence_interval"]
                lines.append(
                    f"  {group['group']}: {group['successes']}/{group['n']} = "
                    f"{format_number(group['proportion'])}; Wilson CI = "
                    f"({format_number(interval[0])}, "
                    f"{format_number(interval[1])})"
                )
            if test.get("status") != "completed":
                lines.append(f"  Test not run ({test['reason']})")
                lines.append("")
                continue
            difference_interval = test[
                "confidence_interval_for_risk_difference"
            ]
            lines.extend(
                [
                    f"  Risk difference (sample 1 minus sample 2) = "
                    f"{format_number(test['risk_difference'])}",
                    f"  CI for risk difference = "
                    f"({format_number(difference_interval[0])}, "
                    f"{format_number(difference_interval[1])})",
                    f"  Relative risk = {format_number(test['relative_risk'])}",
                    f"  Odds ratio = {format_number(test['odds_ratio'])}",
                    f"  z-score = {format_number(test['z_score'])}",
                    f"  p-value = {format_number(test['p_value'])}",
                    f"  Decision = {test['decision']}",
                ]
            )
            lines.append("")

    if results["one_proportion_tests"]:
        lines.extend(["ONE-PROPORTION TESTS", "-" * 20])
        for test in results["one_proportion_tests"]:
            lines.append(
                f"Column: {test['column']}; success = {test['success_value']}"
            )
            lines.append(
                f"  Successes = {test['successes']}; failures = {test['failures']}; "
                f"missing = {test['missing']}"
            )
            if test.get("status") != "completed":
                lines.append(f"  Test not run ({test['reason']})")
                lines.append("")
                continue
            wilson = test["wilson_confidence_interval"]
            exact_interval = test["exact_clopper_pearson_interval"]
            likelihood = test["likelihood_analysis"]
            null_evaluation = likelihood["evaluations"][0]
            lines.extend(
                [
                    f"  Sample proportion = {format_number(test['sample_proportion'])}",
                    f"  Null proportion = {format_number(test['null_proportion'])}",
                    f"  z-score = {format_number(test['z_score'])}",
                    f"  z-test p-value = {format_number(test['z_p_value'])}",
                    f"  Exact binomial p-value = "
                    f"{format_number(test['exact_binomial_p_value'])}",
                    f"  z-test decision = {test['z_test_decision']}",
                    f"  Exact-test decision = {test['exact_test_decision']}",
                    f"  Wilson CI = ({format_number(wilson[0])}, "
                    f"{format_number(wilson[1])})",
                    f"  Exact Clopper-Pearson CI = "
                    f"({format_number(exact_interval[0])}, "
                    f"{format_number(exact_interval[1])})",
                    f"  Likelihood at p0 = "
                    f"{format_number(null_evaluation['likelihood'])}",
                    f"  Log-likelihood at p0 = "
                    f"{_format_log_likelihood(null_evaluation['log_likelihood'])}",
                    f"  MLE of p = {format_number(likelihood['mle_probability'])}",
                    f"  Maximized log-likelihood = "
                    f"{format_number(likelihood['maximized_log_likelihood'])}",
                    f"  Relative likelihood at p0 = "
                    f"{format_number(null_evaluation['relative_likelihood'])}",
                ]
            )
            lines.append("")

    if results["two_proportion_tests"]:
        lines.extend(["TWO-PROPORTION TESTS", "-" * 20])
        for test in results["two_proportion_tests"]:
            lines.append(
                f"Groups: {test['group_variable']}; outcome: "
                f"{test['outcome_variable']}; success = {test['success_value']}"
            )
            if test.get("status") != "completed":
                lines.append(f"  Test not run ({test['reason']})")
                lines.append("")
                continue
            for group in test["group_statistics"]:
                interval = group["wilson_confidence_interval"]
                lines.append(
                    f"  {group['group']}: {group['successes']}/{group['n']} = "
                    f"{format_number(group['proportion'])}; Wilson CI = "
                    f"({format_number(interval[0])}, {format_number(interval[1])})"
                )
            difference_interval = test[
                "confidence_interval_for_risk_difference"
            ]
            lines.extend(
                [
                    f"  Risk difference (first minus second) = "
                    f"{format_number(test['risk_difference'])}",
                    f"  CI for risk difference = "
                    f"({format_number(difference_interval[0])}, "
                    f"{format_number(difference_interval[1])})",
                    f"  Relative risk = {format_number(test['relative_risk'])}",
                    f"  Odds ratio = {format_number(test['odds_ratio'])}",
                    f"  z-score = {format_number(test['z_score'])}",
                    f"  p-value = {format_number(test['p_value'])}",
                    f"  Decision = {test['decision']}",
                ]
            )
            lines.append("")


def _append_multivariate_analyses(
    lines: list[str], results: dict[str, Any]
) -> None:
    pca_analyses = results.get("principal_component_analyses", [])
    manova_analyses = results.get("manova_analyses", [])
    discriminant_analyses = results.get("discriminant_analyses", [])
    if not (pca_analyses or manova_analyses or discriminant_analyses):
        return

    if pca_analyses:
        lines.extend(["PRINCIPAL COMPONENT ANALYSIS", "-" * 28])
        for analysis in pca_analyses:
            lines.extend(
                [
                    analysis["analysis_name"],
                    f"  Variables = {', '.join(analysis['variables'])}",
                    f"  Complete observations = {analysis['n']}; rows removed = "
                    f"{analysis['missing_rows_removed']}",
                    f"  Matrix analyzed = {analysis['matrix_analyzed']}; "
                    f"retained components = {analysis['retained_component_count']}",
                    "  Component  Eigenvalue  Explained  Cumulative",
                ]
            )
            for component in analysis["components"]:
                retained = "*" if component["retained"] else " "
                lines.append(
                    f"  {retained}{component['component']:<8} "
                    f"{format_number(component['eigenvalue']):>10}  "
                    f"{format_number(component['explained_variance_ratio']):>9}  "
                    f"{format_number(component['cumulative_explained_variance_ratio']):>10}"
                )
            lines.append("  Variable-component correlations:")
            for loading in analysis["loadings"]:
                correlations = "; ".join(
                    f"PC{index + 1} = "
                    f"{format_number(loading[f'PC{index + 1}_correlation'])}"
                    for index in range(analysis["retained_component_count"])
                )
                lines.append(f"    {loading['variable']}: {correlations}")
            lines.append("")

    if manova_analyses:
        lines.extend(["ONE-WAY MANOVA", "-" * 14])
        for analysis in manova_analyses:
            lines.extend(
                [
                    analysis["analysis_name"],
                    f"  Group = {analysis['group_variable']}; responses = "
                    f"{', '.join(analysis['response_variables'])}",
                    f"  Complete observations = {analysis['n']}; groups = "
                    f"{analysis['group_count']}; rows removed = "
                    f"{analysis['missing_rows_removed']}",
                    f"  H0: {analysis['null_hypothesis']}",
                ]
            )
            for summary in analysis["group_summaries"]:
                mean_text = "; ".join(
                    f"{name} = {format_number(summary['means'][name])}"
                    for name in analysis["response_variables"]
                )
                lines.append(
                    f"  {summary['group']} (n={summary['n']}): {mean_text}"
                )
            lines.append("  Multivariate tests:")
            for test in analysis["multivariate_tests"]:
                lines.append(
                    f"    {test['method']}: statistic = "
                    f"{format_number(test['statistic'])}; approximate F = "
                    f"{format_number(test['f_approximation'])}; df = "
                    f"({format_number(test['degrees_of_freedom_numerator'])}, "
                    f"{format_number(test['degrees_of_freedom_denominator'])}); "
                    f"p = {format_number(test['p_value'])}"
                )
            lines.append("  Follow-up univariate ANOVAs:")
            for test in analysis["follow_up_univariate_anovas"]:
                lines.append(
                    f"    {test['response']}: F = "
                    f"{format_number(test['f_statistic'])}; df = "
                    f"({test['degrees_of_freedom_numerator']}, "
                    f"{test['degrees_of_freedom_denominator']}); p = "
                    f"{format_number(test['p_value'])}; eta-squared = "
                    f"{format_number(test['eta_squared'])}"
                )
            lines.append(f"  Note: {analysis['assumption_note']}")
            lines.append("")

    if discriminant_analyses:
        lines.extend(["LINEAR DISCRIMINANT ANALYSIS", "-" * 28])
        for analysis in discriminant_analyses:
            lines.extend(
                [
                    analysis["analysis_name"],
                    f"  Class = {analysis['class_variable']}; features = "
                    f"{', '.join(analysis['feature_variables'])}",
                    f"  Complete observations = {analysis['n']}; classes = "
                    f"{analysis['class_count']}; rows removed = "
                    f"{analysis['missing_rows_removed']}",
                    f"  Priors = {analysis['prior_method']}; covariance rank = "
                    f"{analysis['pooled_covariance_rank']}/"
                    f"{analysis['feature_count']}",
                ]
            )
            for detail in analysis["class_details"]:
                lines.append(
                    f"  {detail['class']}: n = {detail['n']}; prior = "
                    f"{format_number(detail['prior_probability'])}"
                )
            if analysis["canonical_dimensions"]:
                lines.append("  Canonical dimensions:")
                for dimension in analysis["canonical_dimensions"]:
                    lines.append(
                        f"    {dimension['dimension']}: eigenvalue = "
                        f"{format_number(dimension['eigenvalue'])}; canonical "
                        f"correlation = "
                        f"{format_number(dimension['canonical_correlation'])}; "
                        f"explained discrimination = "
                        f"{format_number(dimension['explained_discrimination_ratio'])}"
                    )
            classification = analysis["classification"]
            lines.append(
                f"  Apparent accuracy = "
                f"{format_number(classification['accuracy'])}; log loss = "
                f"{format_number(classification['log_loss'])}"
            )
            lines.append("  Apparent confusion matrix (rows actual, columns predicted):")
            labels = classification["row_categories_actual"]
            lines.append("    actual\\predicted  " + "  ".join(labels))
            for label, row in zip(labels, classification["confusion_matrix"]):
                lines.append(
                    f"    {label}: " + "  ".join(str(value) for value in row)
                )
            cross_validation = analysis["cross_validation"]
            if cross_validation.get("status") == "completed":
                lines.append(
                    f"  Leave-one-out accuracy = "
                    f"{format_number(cross_validation['accuracy'])}; log loss = "
                    f"{format_number(cross_validation['log_loss'])}"
                )
            else:
                lines.append(
                    f"  Leave-one-out validation not run "
                    f"({cross_validation.get('reason', 'unspecified reason')})"
                )
            lines.append(f"  Note: {analysis['assumption_note']}")
            lines.append("")

    pca_export = results.get("pca_score_export")
    if pca_export:
        lines.append(
            f"PCA scores saved to {pca_export['file']} "
            f"({pca_export['rows']} rows)."
        )
        lines.append("")
    discriminant_export = results.get("discriminant_export")
    if discriminant_export:
        lines.append(
            f"Discriminant results saved to {discriminant_export['file']} "
            f"({discriminant_export['rows']} rows)."
        )
        lines.append("")


def build_text_report(results: dict[str, Any]) -> str:
    metadata = results["metadata"]
    aggregate_sources = {
        "aggregate_counts",
        "summary_data",
        "direct_calculations",
    }
    if metadata.get("analysis_source") in aggregate_sources:
        lines: list[str] = []
    else:
        lines = [
            "STATCLASS STATISTICAL ANALYSIS REPORT",
            "=" * 38,
            f"Program version: {metadata['program_version']}",
            f"Input file: {metadata['input_file']}",
            f"Rows read: {metadata['rows']}",
            f"Numeric columns found: {metadata['numeric_columns_found']}",
            f"Header detected: "
            f"{'yes' if metadata['header_detected'] else 'no'}",
            f"Delimiter: {metadata['delimiter']}",
        ]
        resource = metadata.get("input_resource_preflight")
        if resource:
            lines.append(
                "Input resource preflight: "
                f"{resource['status']}; estimated peak load memory "
                f"{_format_bytes(resource['estimated_peak_load_memory_bytes'])}; "
                f"available {_format_bytes(resource['available_memory_bytes_at_load'])}"
            )
        lines.extend(
            [
                f"Significance level: {format_number(metadata['alpha'])}",
                "",
            ]
        )
    _append_summary(lines, results)
    _append_discrete_estimations(lines, results)
    _append_normality(lines, results)
    _append_transformations(lines, results)
    _append_outlier_diagnostics(lines, results)
    _append_transformed_export(lines, results)
    _append_multivariate_analyses(lines, results)
    _append_resampling(lines, results)
    _append_permutation_tests(lines, results)
    _append_one_sample_tests(lines, results)
    _append_two_sample_tests(lines, results)
    _append_summary_data_tests(lines, results)
    _append_bayesian_analyses(lines, results)
    _append_distribution_calculations(lines, results)
    _append_direct_confidence_intervals(lines, results)
    _append_power_analyses(lines, results)
    _append_anova(lines, results)
    _append_nonparametric_tests(lines, results)
    _append_correlations(lines, results)
    _append_regressions(lines, results)
    _append_multiple_regressions(lines, results)
    _append_advanced_regressions(lines, results)
    _append_kernel_density(lines, results)
    _append_logistic_regressions(lines, results)
    _append_poisson_mean_analyses(lines, results)
    _append_poisson_regressions(lines, results)
    _append_negative_binomial_regressions(lines, results)
    _append_factorial_analyses(lines, results)
    _append_repeated_measures(lines, results)
    _append_mixed_effects(lines, results)
    _append_frequency_tables(lines, results)
    _append_categorical_tests(lines, results)
    _append_proportion_tests(lines, results)
    _append_generated_plots(lines, results)
    _append_casewise_export(lines, results)
    return "\n".join(lines).rstrip() + "\n"
