"""Data transformations, standardization, and univariate outlier diagnostics."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .utils import format_number


class TransformationError(ValueError):
    """Raised when a transformation or diagnostic request is invalid."""


TRANSFORMATION_METHODS = (
    "log",
    "log10",
    "sqrt",
    "reciprocal",
    "power",
    "box-cox",
    "yeo-johnson",
)

STANDARDIZATION_METHODS = (
    "z-score",
    "min-max",
    "robust",
    "center",
)

OUTLIER_METHODS = (
    "z-score",
    "modified-z-score",
    "iqr",
)


def _normalize_method(value: str, choices: tuple[str, ...], label: str) -> str:
    aliases = {
        "ln": "log",
        "natural-log": "log",
        "log-10": "log10",
        "inverse": "reciprocal",
        "boxcox": "box-cox",
        "yeojohnson": "yeo-johnson",
        "z": "z-score",
        "zscore": "z-score",
        "minmax": "min-max",
        "robust-z": "robust",
        "modified-z": "modified-z-score",
        "modified-zscore": "modified-z-score",
        "tukey": "iqr",
    }
    normalized = aliases.get(value.strip().lower().replace("_", "-"), value.strip().lower().replace("_", "-"))
    if normalized not in choices:
        raise TransformationError(
            f"unknown {label} method {value!r}; choose {', '.join(choices)}"
        )
    return normalized


def _numeric_series(series: pd.Series, column_name: str) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce").astype(float)
    numeric = numeric.where(np.isfinite(numeric), np.nan)
    if numeric.notna().sum() == 0:
        raise TransformationError(
            f"column {column_name!r} requires at least one finite numeric value"
        )
    return numeric


def _summary(values: np.ndarray) -> dict[str, float]:
    return {
        "minimum": float(np.min(values)),
        "maximum": float(np.max(values)),
        "mean": float(np.mean(values)),
        "standard_deviation": (
            float(np.std(values, ddof=1)) if values.size > 1 else 0.0
        ),
    }


def transform_series(
    series: pd.Series,
    column_name: str,
    method: str,
    parameter: float | None = None,
) -> tuple[dict[str, Any], pd.Series]:
    """Apply a mathematical transformation and retain missing positions."""
    method = _normalize_method(method, TRANSFORMATION_METHODS, "transformation")
    numeric = _numeric_series(series, column_name)
    valid = numeric.dropna()
    values = valid.to_numpy(dtype=float)
    transformed_parameter: float | None = None
    parameter_source: str | None = None

    if method != "power" and parameter is not None and method not in {
        "box-cox",
        "yeo-johnson",
    }:
        raise TransformationError(f"{method} does not accept a parameter")
    if parameter is not None and not math.isfinite(float(parameter)):
        raise TransformationError("transformation parameter must be finite")

    if method == "log":
        if np.any(values <= 0.0):
            raise TransformationError("log transformation requires values greater than 0")
        transformed = np.log(values)
        formula = "ln(x)"
    elif method == "log10":
        if np.any(values <= 0.0):
            raise TransformationError("log10 transformation requires values greater than 0")
        transformed = np.log10(values)
        formula = "log10(x)"
    elif method == "sqrt":
        if np.any(values < 0.0):
            raise TransformationError("square-root transformation requires values at least 0")
        transformed = np.sqrt(values)
        formula = "sqrt(x)"
    elif method == "reciprocal":
        if np.any(values == 0.0):
            raise TransformationError("reciprocal transformation does not permit zero")
        transformed = 1.0 / values
        formula = "1/x"
    elif method == "power":
        if parameter is None:
            raise TransformationError("power transformation requires an exponent")
        transformed_parameter = float(parameter)
        with np.errstate(all="ignore"):
            transformed = np.power(values, transformed_parameter)
        if not np.all(np.isfinite(transformed)):
            raise TransformationError(
                "power transformation produced nonfinite values; check the data domain and exponent"
            )
        formula = f"x^{format_number(transformed_parameter)}"
        parameter_source = "specified"
    elif method == "box-cox":
        if values.size < 2 or np.ptp(values) == 0.0:
            raise TransformationError(
                "Box-Cox transformation requires at least two different values"
            )
        if np.any(values <= 0.0):
            raise TransformationError("Box-Cox transformation requires values greater than 0")
        if parameter is None:
            transformed, transformed_parameter = scipy_stats.boxcox(values)
            transformed_parameter = float(transformed_parameter)
            parameter_source = "maximum likelihood estimate"
        else:
            transformed_parameter = float(parameter)
            transformed = scipy_stats.boxcox(values, lmbda=transformed_parameter)
            parameter_source = "specified"
        formula = "(x^lambda - 1)/lambda; log(x) when lambda = 0"
    else:
        if values.size < 2 or np.ptp(values) == 0.0:
            raise TransformationError(
                "Yeo-Johnson transformation requires at least two different values"
            )
        if parameter is None:
            transformed, transformed_parameter = scipy_stats.yeojohnson(values)
            transformed_parameter = float(transformed_parameter)
            parameter_source = "maximum likelihood estimate"
        else:
            transformed_parameter = float(parameter)
            transformed = scipy_stats.yeojohnson(values, lmbda=transformed_parameter)
            parameter_source = "specified"
        formula = "Yeo-Johnson piecewise power transformation"

    transformed_series = pd.Series(np.nan, index=numeric.index, dtype=float)
    transformed_series.loc[valid.index] = np.asarray(transformed, dtype=float)
    result = {
        "analysis_type": "transformation",
        "column": column_name,
        "method": method,
        "formula": formula,
        "parameter": transformed_parameter,
        "parameter_source": parameter_source,
        "n": int(valid.size),
        "missing_or_nonfinite": int(numeric.size - valid.size),
        "original_summary": _summary(values),
        "transformed_summary": _summary(np.asarray(transformed, dtype=float)),
        "status": "completed",
    }
    return result, transformed_series


def standardize_series(
    series: pd.Series,
    column_name: str,
    method: str,
) -> tuple[dict[str, Any], pd.Series]:
    """Center or standardize a numeric series."""
    method = _normalize_method(method, STANDARDIZATION_METHODS, "standardization")
    numeric = _numeric_series(series, column_name)
    valid = numeric.dropna()
    values = valid.to_numpy(dtype=float)

    if method == "z-score":
        if values.size < 2:
            raise TransformationError("z-score standardization requires at least two values")
        center = float(np.mean(values))
        scale = float(np.std(values, ddof=1))
        if scale == 0.0:
            raise TransformationError("z-score standardization requires nonzero sample SD")
        standardized = (values - center) / scale
        formula = "(x - sample mean)/sample SD"
    elif method == "min-max":
        center = float(np.min(values))
        scale = float(np.max(values) - np.min(values))
        if scale == 0.0:
            raise TransformationError("min-max standardization requires a nonzero range")
        standardized = (values - center) / scale
        formula = "(x - minimum)/(maximum - minimum)"
    elif method == "robust":
        center = float(np.median(values))
        first_quartile, third_quartile = np.quantile(values, [0.25, 0.75])
        scale = float(third_quartile - first_quartile)
        if scale == 0.0:
            raise TransformationError("robust standardization requires a nonzero IQR")
        standardized = (values - center) / scale
        formula = "(x - median)/IQR"
    else:
        center = float(np.mean(values))
        scale = 1.0
        standardized = values - center
        formula = "x - sample mean"

    standardized_series = pd.Series(np.nan, index=numeric.index, dtype=float)
    standardized_series.loc[valid.index] = standardized
    result = {
        "analysis_type": "standardization",
        "column": column_name,
        "method": method,
        "formula": formula,
        "center": center,
        "scale": scale,
        "n": int(valid.size),
        "missing_or_nonfinite": int(numeric.size - valid.size),
        "original_summary": _summary(values),
        "transformed_summary": _summary(np.asarray(standardized, dtype=float)),
        "status": "completed",
    }
    return result, standardized_series


def outlier_diagnostics(
    series: pd.Series,
    column_name: str,
    method: str,
    threshold: float | None = None,
) -> tuple[dict[str, Any], pd.Series]:
    """Flag univariate outliers using z, modified-z, or Tukey IQR rules."""
    method = _normalize_method(method, OUTLIER_METHODS, "outlier")
    numeric = _numeric_series(series, column_name)
    valid = numeric.dropna()
    values = valid.to_numpy(dtype=float)
    default_thresholds = {
        "z-score": 3.0,
        "modified-z-score": 3.5,
        "iqr": 1.5,
    }
    threshold = default_thresholds[method] if threshold is None else float(threshold)
    if not math.isfinite(threshold) or threshold <= 0.0:
        raise TransformationError("outlier threshold must be positive and finite")

    status = "completed"
    reason: str | None = None
    center: float
    scale: float
    if method == "z-score":
        center = float(np.mean(values))
        scale = float(np.std(values, ddof=1)) if values.size > 1 else 0.0
        if scale == 0.0:
            scores = np.zeros(values.size)
            flagged = np.zeros(values.size, dtype=bool)
            lower_fence = upper_fence = center
            status = "not_run"
            reason = "requires at least two values with nonzero sample SD"
        else:
            signed_scores = (values - center) / scale
            scores = np.abs(signed_scores)
            flagged = scores > threshold
            lower_fence = center - threshold * scale
            upper_fence = center + threshold * scale
        scale_label = "sample standard deviation"
    elif method == "modified-z-score":
        center = float(np.median(values))
        scale = float(np.median(np.abs(values - center)))
        if scale == 0.0:
            scores = np.zeros(values.size)
            flagged = np.zeros(values.size, dtype=bool)
            lower_fence = upper_fence = center
            status = "not_run"
            reason = "requires a nonzero median absolute deviation"
        else:
            signed_scores = 0.6744897501960817 * (values - center) / scale
            scores = np.abs(signed_scores)
            flagged = scores > threshold
            distance = threshold * scale / 0.6744897501960817
            lower_fence = center - distance
            upper_fence = center + distance
        scale_label = "median absolute deviation"
    else:
        first_quartile, third_quartile = np.quantile(values, [0.25, 0.75])
        center = float(np.median(values))
        scale = float(third_quartile - first_quartile)
        lower_fence = float(first_quartile - threshold * scale)
        upper_fence = float(third_quartile + threshold * scale)
        flagged = (values < lower_fence) | (values > upper_fence)
        scores = np.where(
            values < lower_fence,
            (lower_fence - values) / scale if scale > 0.0 else 0.0,
            np.where(
                values > upper_fence,
                (values - upper_fence) / scale if scale > 0.0 else 0.0,
                0.0,
            ),
        )
        if scale == 0.0:
            status = "not_run"
            reason = "requires a nonzero interquartile range"
            flagged = np.zeros(values.size, dtype=bool)
            scores = np.zeros(values.size)
        scale_label = "interquartile range"

    flag_series = pd.Series(False, index=numeric.index, dtype=bool)
    flag_series.loc[valid.index] = flagged
    observations: list[dict[str, Any]] = []
    valid_positions = {index: position + 1 for position, index in enumerate(numeric.index)}
    for array_position in np.flatnonzero(flagged):
        source_index = valid.index[array_position]
        observations.append(
            {
                "row_number": int(valid_positions[source_index]),
                "source_index": (
                    int(source_index)
                    if isinstance(source_index, (int, np.integer))
                    else str(source_index)
                ),
                "value": float(values[array_position]),
                "score": float(scores[array_position]),
            }
        )
    result: dict[str, Any] = {
        "column": column_name,
        "method": method,
        "threshold": threshold,
        "center": center,
        "scale": scale,
        "scale_label": scale_label,
        "lower_fence": float(lower_fence),
        "upper_fence": float(upper_fence),
        "n": int(valid.size),
        "missing_or_nonfinite": int(numeric.size - valid.size),
        "outlier_count": len(observations),
        "outlier_proportion": len(observations) / valid.size,
        "outliers": observations,
        "status": status,
    }
    if reason is not None:
        result["reason"] = reason
    return result, flag_series
