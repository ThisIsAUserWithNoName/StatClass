"""Frequency tables and categorical hypothesis tests."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .data import DataError
from .utils import decision_from_pvalue, finite_or_none


def _label(value: Any) -> str:
    return str(value)


def _complete_pairs(
    first: pd.Series,
    second: pd.Series,
) -> tuple[pd.Series, pd.Series, int]:
    mask = first.notna() & second.notna()
    return first[mask], second[mask], int((~mask).sum())


def frequency_table(series: pd.Series, column_name: str) -> dict[str, Any]:
    valid = series.dropna()
    counts = valid.value_counts(sort=False, dropna=True)
    total = int(valid.size)
    cumulative = 0
    categories: list[dict[str, Any]] = []
    for value, count_value in counts.items():
        count = int(count_value)
        cumulative += count
        proportion = count / total if total else None
        cumulative_proportion = cumulative / total if total else None
        categories.append(
            {
                "category": _label(value),
                "count": count,
                "proportion": finite_or_none(proportion),
                "percentage": finite_or_none(100.0 * proportion) if proportion is not None else None,
                "cumulative_count": cumulative,
                "cumulative_percentage": (
                    finite_or_none(100.0 * cumulative_proportion)
                    if cumulative_proportion is not None
                    else None
                ),
            }
        )
    return {
        "column": column_name,
        "total_rows": int(len(series)),
        "nonmissing": total,
        "missing": int(series.isna().sum()),
        "distinct_categories": len(categories),
        "categories": categories,
    }


def contingency_table(
    row_series: pd.Series,
    column_series: pd.Series,
    row_name: str,
    column_name: str,
) -> dict[str, Any]:
    complete_rows, complete_columns, excluded = _complete_pairs(
        row_series, column_series
    )
    table = pd.crosstab(complete_rows, complete_columns, dropna=True)
    observed = table.to_numpy(dtype=int)
    grand_total = int(observed.sum())
    row_totals = observed.sum(axis=1)
    column_totals = observed.sum(axis=0)

    with np.errstate(divide="ignore", invalid="ignore"):
        row_percentages = np.divide(
            observed * 100.0,
            row_totals[:, None],
            out=np.zeros_like(observed, dtype=float),
            where=row_totals[:, None] != 0,
        )
        column_percentages = np.divide(
            observed * 100.0,
            column_totals[None, :],
            out=np.zeros_like(observed, dtype=float),
            where=column_totals[None, :] != 0,
        )
        overall_percentages = (
            observed * 100.0 / grand_total
            if grand_total
            else np.zeros_like(observed, dtype=float)
        )

    return {
        "row_variable": row_name,
        "column_variable": column_name,
        "row_categories": [_label(value) for value in table.index],
        "column_categories": [_label(value) for value in table.columns],
        "observed_counts": observed.tolist(),
        "row_percentages": row_percentages.tolist(),
        "column_percentages": column_percentages.tolist(),
        "overall_percentages": overall_percentages.tolist(),
        "row_totals": [int(value) for value in row_totals],
        "column_totals": [int(value) for value in column_totals],
        "grand_total": grand_total,
        "excluded_missing_pairs": excluded,
    }


def _expected_count_warnings(expected: np.ndarray) -> list[str]:
    warnings: list[str] = []
    cell_count = expected.size
    below_five = int(np.sum(expected < 5.0))
    if np.any(expected < 1.0):
        warnings.append("At least one expected count is below 1.")
    if cell_count and below_five / cell_count > 0.20:
        warnings.append("More than 20% of expected counts are below 5.")
    return warnings


def chi_square_independence(
    row_series: pd.Series,
    column_series: pd.Series,
    row_name: str,
    column_name: str,
    alpha: float,
) -> dict[str, Any]:
    table = contingency_table(row_series, column_series, row_name, column_name)
    observed = np.asarray(table["observed_counts"], dtype=float)
    result: dict[str, Any] = {
        "method": "Pearson chi-square test of independence",
        "table": table,
    }
    if observed.shape[0] < 2 or observed.shape[1] < 2:
        result.update(
            status="not_run",
            reason="requires at least 2 observed categories in each variable",
        )
        return result

    test = scipy_stats.chi2_contingency(observed, correction=False)
    statistic = float(test.statistic)
    p_value = float(test.pvalue)
    degrees_of_freedom = int(test.dof)
    expected = np.asarray(test.expected_freq, dtype=float)
    standardized_residuals = (observed - expected) / np.sqrt(expected)
    contributions = (observed - expected) ** 2 / expected
    n = float(observed.sum())
    dimension = min(observed.shape[0] - 1, observed.shape[1] - 1)
    cramers_v = math.sqrt(statistic / (n * dimension)) if dimension > 0 else None
    result.update(
        {
            "status": "completed",
            "null_hypothesis": "the two categorical variables are independent",
            "statistic": finite_or_none(statistic),
            "degrees_of_freedom": degrees_of_freedom,
            "p_value": finite_or_none(p_value),
            "expected_counts": expected.tolist(),
            "standardized_residuals": standardized_residuals.tolist(),
            "cell_contributions": contributions.tolist(),
            "cramers_v": finite_or_none(cramers_v),
            "assumption_warnings": _expected_count_warnings(expected),
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result


def chi_square_goodness_of_fit(
    series: pd.Series,
    column_name: str,
    expected_probabilities: list[float],
    alpha: float,
) -> dict[str, Any]:
    frequency = frequency_table(series, column_name)
    observed = np.asarray(
        [category["count"] for category in frequency["categories"]],
        dtype=float,
    )
    category_names = [
        category["category"] for category in frequency["categories"]
    ]
    if observed.size < 2:
        raise DataError("--goodness-of-fit requires at least 2 observed categories")
    if len(expected_probabilities) != observed.size:
        raise DataError(
            "the number of --expected probabilities must match the number of "
            f"observed categories ({observed.size}: {', '.join(category_names)})"
        )
    probabilities = np.asarray(expected_probabilities, dtype=float)
    if not np.all(np.isfinite(probabilities)) or np.any(probabilities <= 0):
        raise DataError("all --expected probabilities must be positive and finite")
    if not math.isclose(float(probabilities.sum()), 1.0, rel_tol=1e-9, abs_tol=1e-9):
        raise DataError("--expected probabilities must sum to 1")

    expected_counts = probabilities * observed.sum()
    test = scipy_stats.chisquare(observed, f_exp=expected_counts)
    statistic = float(test.statistic)
    p_value = float(test.pvalue)
    details = []
    for category, observed_count, probability, expected_count in zip(
        category_names,
        observed,
        probabilities,
        expected_counts,
    ):
        details.append(
            {
                "category": category,
                "observed_count": int(observed_count),
                "expected_probability": float(probability),
                "expected_count": float(expected_count),
                "chi_square_contribution": float(
                    (observed_count - expected_count) ** 2 / expected_count
                ),
            }
        )
    return {
        "method": "Pearson chi-square goodness-of-fit test",
        "status": "completed",
        "column": column_name,
        "nonmissing": frequency["nonmissing"],
        "missing": frequency["missing"],
        "null_hypothesis": "observed category probabilities equal the specified probabilities",
        "categories": details,
        "statistic": finite_or_none(statistic),
        "degrees_of_freedom": int(observed.size - 1),
        "p_value": finite_or_none(p_value),
        "assumption_warnings": _expected_count_warnings(expected_counts),
        "decision": decision_from_pvalue(p_value, alpha),
    }


def fisher_exact_test(
    row_series: pd.Series,
    column_series: pd.Series,
    row_name: str,
    column_name: str,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    table = contingency_table(row_series, column_series, row_name, column_name)
    observed = np.asarray(table["observed_counts"], dtype=int)
    result: dict[str, Any] = {
        "method": "Fisher's exact test",
        "table": table,
        "alternative": alternative,
    }
    if observed.shape != (2, 2):
        result.update(status="not_run", reason="requires an observed 2 by 2 table")
        return result
    test = scipy_stats.fisher_exact(observed, alternative=alternative)
    odds_ratio = float(test.statistic if hasattr(test, "statistic") else test[0])
    p_value = float(test.pvalue if hasattr(test, "pvalue") else test[1])
    result.update(
        {
            "status": "completed",
            "null_hypothesis": "the two binary variables have odds ratio 1",
            "odds_ratio": finite_or_none(odds_ratio),
            "p_value": finite_or_none(p_value),
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result
