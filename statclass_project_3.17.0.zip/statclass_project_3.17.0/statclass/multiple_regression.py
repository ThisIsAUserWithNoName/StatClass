"""Multiple linear regression, diagnostics, and model comparison."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .design_terms import add_engineered_terms
from .descriptives import normality_tests
from .utils import decision_from_pvalue, finite_or_none


def _complete_case_mask(
    frame: pd.DataFrame,
    dependent_name: str,
    predictor_names: list[str],
    categorical_predictors: set[str],
) -> np.ndarray:
    dependent = pd.to_numeric(frame[dependent_name], errors="coerce").to_numpy(
        dtype=float
    )
    mask = np.isfinite(dependent)
    for name in predictor_names:
        if name in categorical_predictors:
            mask &= frame[name].notna().to_numpy()
        else:
            values = pd.to_numeric(frame[name], errors="coerce").to_numpy(
                dtype=float
            )
            mask &= np.isfinite(values)
    return mask


def _prepare_design(
    frame: pd.DataFrame,
    dependent_name: str,
    predictor_names: list[str],
    categorical_predictors: set[str],
    polynomial_terms: dict[str, int] | None = None,
    interactions: list[tuple[str, str]] | None = None,
) -> dict[str, Any]:
    mask = _complete_case_mask(
        frame,
        dependent_name,
        predictor_names,
        categorical_predictors,
    )
    complete = frame.loc[mask]
    response = pd.to_numeric(
        complete[dependent_name], errors="coerce"
    ).to_numpy(dtype=float)
    columns = [np.ones(response.size, dtype=float)]
    terms = ["Intercept"]
    term_predictors: list[str | None] = [None]
    term_types = ["intercept"]
    categorical_codings: list[dict[str, Any]] = []
    predictor_components: dict[str, list[int]] = {}
    invalid_reason = None

    for name in predictor_names:
        if name not in categorical_predictors:
            component_index = len(columns)
            columns.append(
                pd.to_numeric(complete[name], errors="coerce").to_numpy(
                    dtype=float
                )
            )
            terms.append(name)
            term_predictors.append(name)
            term_types.append("numeric")
            predictor_components[name] = [component_index]
            continue

        values = complete[name]
        categories = list(pd.unique(values))
        if len(categories) < 2:
            invalid_reason = (
                f"categorical predictor {name!r} has fewer than 2 observed "
                "categories among complete cases"
            )
            break
        reference = categories[0]
        dummy_terms: list[str] = []
        component_indices: list[int] = []
        for category in categories[1:]:
            term = f"{name}[T.{category}]"
            component_indices.append(len(columns))
            columns.append((values == category).to_numpy(dtype=float))
            terms.append(term)
            term_predictors.append(name)
            term_types.append("categorical_dummy")
            dummy_terms.append(term)
        predictor_components[name] = component_indices
        categorical_codings.append(
            {
                "predictor": name,
                "reference_category": str(reference),
                "categories": [str(category) for category in categories],
                "dummy_terms": dummy_terms,
            }
        )

    engineered = add_engineered_terms(
        columns,
        terms,
        term_predictors,
        term_types,
        predictor_components,
        categorical_predictors,
        polynomial_terms,
        interactions,
    )
    design = (
        np.column_stack(columns)
        if response.size
        else np.empty((0, len(columns)), dtype=float)
    )
    return {
        "mask": mask,
        "complete_frame": complete,
        "response": response,
        "design": design,
        "terms": terms,
        "term_predictors": term_predictors,
        "term_types": term_types,
        "categorical_codings": categorical_codings,
        "polynomial_terms": engineered["polynomial_terms"],
        "interactions": engineered["interactions"],
        "invalid_reason": invalid_reason,
    }


def _residual_summary(residuals: np.ndarray) -> dict[str, Any]:
    return {
        "minimum": finite_or_none(np.min(residuals)),
        "first_quartile": finite_or_none(np.quantile(residuals, 0.25)),
        "median": finite_or_none(np.median(residuals)),
        "third_quartile": finite_or_none(np.quantile(residuals, 0.75)),
        "maximum": finite_or_none(np.max(residuals)),
        "mean": finite_or_none(np.mean(residuals)),
    }


def _variance_inflation_factors(
    design: np.ndarray,
    terms: list[str],
) -> list[dict[str, Any]]:
    factors: list[dict[str, Any]] = []
    for index in range(1, design.shape[1]):
        outcome = design[:, index]
        other_indices = [item for item in range(design.shape[1]) if item != index]
        other_design = design[:, other_indices]
        estimates = np.linalg.lstsq(other_design, outcome, rcond=None)[0]
        residuals = outcome - other_design @ estimates
        total_sum_squares = float(np.sum((outcome - np.mean(outcome)) ** 2))
        residual_sum_squares = float(np.sum(residuals**2))
        r_squared = (
            1.0 - residual_sum_squares / total_sum_squares
            if total_sum_squares > 0
            else 1.0
        )
        tolerance = max(0.0, 1.0 - r_squared)
        vif = 1.0 / tolerance if tolerance > 0 else None
        factors.append(
            {
                "term": terms[index],
                "r_squared_against_other_terms": finite_or_none(r_squared),
                "tolerance": finite_or_none(tolerance),
                "vif": finite_or_none(vif),
            }
        )
    return factors


def _breusch_pagan_test(
    residuals: np.ndarray,
    design: np.ndarray,
    alpha: float,
) -> dict[str, Any]:
    degrees_of_freedom = design.shape[1] - 1
    result: dict[str, Any] = {
        "method": "Breusch-Pagan test",
        "null_hypothesis": "the error variance is constant",
        "degrees_of_freedom": degrees_of_freedom,
    }
    if degrees_of_freedom < 1:
        result.update(status="not_run", reason="requires at least 1 predictor")
        return result
    squared = residuals**2
    total_sum_squares = float(np.sum((squared - np.mean(squared)) ** 2))
    if total_sum_squares <= 0:
        result.update(
            status="not_run", reason="squared residuals have zero variance"
        )
        return result
    estimates = np.linalg.lstsq(design, squared, rcond=None)[0]
    auxiliary_residuals = squared - design @ estimates
    auxiliary_r_squared = 1.0 - float(
        np.sum(auxiliary_residuals**2)
    ) / total_sum_squares
    statistic = design.shape[0] * max(0.0, auxiliary_r_squared)
    p_value = float(scipy_stats.chi2.sf(statistic, degrees_of_freedom))
    result.update(
        {
            "status": "completed",
            "statistic": finite_or_none(statistic),
            "p_value": finite_or_none(p_value),
            "auxiliary_r_squared": finite_or_none(auxiliary_r_squared),
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result


def _influence_diagnostics(
    complete_frame: pd.DataFrame,
    response: np.ndarray,
    fitted: np.ndarray,
    residuals: np.ndarray,
    design: np.ndarray,
    mean_square_error: float,
) -> dict[str, Any]:
    observation_count, parameter_count = design.shape
    inverse_cross_product = np.linalg.pinv(design.T @ design)
    leverage = np.sum((design @ inverse_cross_product) * design, axis=1)
    one_minus_leverage = np.maximum(1.0 - leverage, np.finfo(float).eps)
    internally_studentized = residuals / np.sqrt(
        mean_square_error * one_minus_leverage
    )
    cooks_distance = (
        residuals**2
        / (parameter_count * mean_square_error)
        * leverage
        / one_minus_leverage**2
    )
    leverage_threshold = 2.0 * parameter_count / observation_count
    cooks_threshold = 4.0 / observation_count
    unusual = (
        (leverage > leverage_threshold)
        | (cooks_distance > cooks_threshold)
        | (np.abs(internally_studentized) > 2.0)
    )
    unusual_indices = np.flatnonzero(unusual)
    cases = []
    for position in unusual_indices[:100]:
        source_index = complete_frame.index[position]
        cases.append(
            {
                "source_index": finite_or_none(source_index),
                "observed": finite_or_none(response[position]),
                "fitted": finite_or_none(fitted[position]),
                "residual": finite_or_none(residuals[position]),
                "internally_studentized_residual": finite_or_none(
                    internally_studentized[position]
                ),
                "leverage": finite_or_none(leverage[position]),
                "cooks_distance": finite_or_none(cooks_distance[position]),
            }
        )
    return {
        "leverage_threshold": leverage_threshold,
        "cooks_distance_threshold": cooks_threshold,
        "studentized_residual_threshold": 2.0,
        "maximum_leverage": finite_or_none(np.max(leverage)),
        "maximum_absolute_studentized_residual": finite_or_none(
            np.max(np.abs(internally_studentized))
        ),
        "maximum_cooks_distance": finite_or_none(np.max(cooks_distance)),
        "flagged_case_count": int(unusual_indices.size),
        "flagged_cases_returned": len(cases),
        "flagged_cases_truncated": unusual_indices.size > len(cases),
        "flagged_cases": cases,
    }


def multiple_linear_regression(
    frame: pd.DataFrame,
    dependent_name: str,
    predictor_names: list[str],
    categorical_predictors: set[str],
    alpha: float,
    model_name: str | None = None,
    polynomial_terms: dict[str, int] | None = None,
    interactions: list[tuple[str, str]] | None = None,
) -> dict[str, Any]:
    """Fit an OLS model with numeric and reference-coded categorical terms."""
    prepared = _prepare_design(
        frame,
        dependent_name,
        predictor_names,
        categorical_predictors,
        polynomial_terms,
        interactions,
    )
    response = prepared["response"]
    design = prepared["design"]
    terms = prepared["terms"]
    observation_count = response.size
    parameter_count = design.shape[1]
    result: dict[str, Any] = {
        "method": "ordinary least squares multiple linear regression",
        "model_name": model_name,
        "dependent_variable": dependent_name,
        "predictors": predictor_names,
        "numeric_predictors": [
            name for name in predictor_names if name not in categorical_predictors
        ],
        "categorical_predictors": [
            name for name in predictor_names if name in categorical_predictors
        ],
        "categorical_codings": prepared["categorical_codings"],
        "polynomial_terms": prepared["polynomial_terms"],
        "interactions": prepared["interactions"],
        "total_rows": int(len(frame)),
        "n_complete_cases": int(observation_count),
        "excluded_rows": int(len(frame) - observation_count),
        "parameter_count": int(parameter_count),
        "terms": terms,
    }
    if prepared["invalid_reason"]:
        result.update(status="not_run", reason=prepared["invalid_reason"])
        return result
    if not predictor_names:
        result.update(status="not_run", reason="requires at least 1 predictor")
        return result
    if observation_count <= parameter_count:
        result.update(
            status="not_run",
            reason=(
                "requires more complete observations than estimated parameters "
                f"({observation_count} observations, {parameter_count} parameters)"
            ),
        )
        return result
    design_rank = int(np.linalg.matrix_rank(design))
    if design_rank < parameter_count:
        result.update(
            status="not_run",
            reason=(
                "the design matrix is rank deficient; remove constant or "
                "redundant predictors"
            ),
            design_matrix_rank=design_rank,
        )
        return result

    response_mean = float(np.mean(response))
    total_sum_squares = float(np.sum((response - response_mean) ** 2))
    if total_sum_squares <= 0:
        result.update(status="not_run", reason="the dependent variable is constant")
        return result

    estimates = np.linalg.lstsq(design, response, rcond=None)[0]
    fitted = design @ estimates
    residuals = response - fitted
    residual_sum_squares = max(0.0, float(np.sum(residuals**2)))
    regression_sum_squares = max(0.0, total_sum_squares - residual_sum_squares)
    model_degrees_of_freedom = parameter_count - 1
    residual_degrees_of_freedom = observation_count - parameter_count
    mean_square_error = residual_sum_squares / residual_degrees_of_freedom
    if mean_square_error <= np.finfo(float).eps:
        result.update(
            status="not_run",
            reason="the model has essentially zero residual variance",
        )
        return result

    inverse_cross_product = np.linalg.pinv(design.T @ design)
    covariance = mean_square_error * inverse_cross_product
    standard_errors = np.sqrt(np.maximum(0.0, np.diag(covariance)))
    t_statistics = estimates / standard_errors
    coefficient_p_values = 2.0 * scipy_stats.t.sf(
        np.abs(t_statistics), residual_degrees_of_freedom
    )
    critical = float(
        scipy_stats.t.ppf(1.0 - alpha / 2.0, residual_degrees_of_freedom)
    )
    response_standard_deviation = float(np.std(response, ddof=1))
    coefficients = []
    for index, term in enumerate(terms):
        standardized = None
        if index > 0 and response_standard_deviation > 0:
            predictor_standard_deviation = float(np.std(design[:, index], ddof=1))
            standardized = (
                estimates[index]
                * predictor_standard_deviation
                / response_standard_deviation
            )
        coefficients.append(
            {
                "term": term,
                "predictor": prepared["term_predictors"][index],
                "term_type": prepared["term_types"][index],
                "estimate": finite_or_none(estimates[index]),
                "standard_error": finite_or_none(standard_errors[index]),
                "t_statistic": finite_or_none(t_statistics[index]),
                "p_value": finite_or_none(coefficient_p_values[index]),
                "confidence_interval": [
                    finite_or_none(estimates[index] - critical * standard_errors[index]),
                    finite_or_none(estimates[index] + critical * standard_errors[index]),
                ],
                "standardized_coefficient": finite_or_none(standardized),
            }
        )

    r_squared = 1.0 - residual_sum_squares / total_sum_squares
    adjusted_r_squared = 1.0 - (1.0 - r_squared) * (
        observation_count - 1
    ) / residual_degrees_of_freedom
    model_mean_square = regression_sum_squares / model_degrees_of_freedom
    f_statistic = model_mean_square / mean_square_error
    f_p_value = float(
        scipy_stats.f.sf(
            f_statistic,
            model_degrees_of_freedom,
            residual_degrees_of_freedom,
        )
    )
    root_mean_square_error = math.sqrt(mean_square_error)
    maximum_likelihood_variance = residual_sum_squares / observation_count
    log_likelihood = -0.5 * observation_count * (
        math.log(2.0 * math.pi)
        + 1.0
        + math.log(maximum_likelihood_variance)
    )
    information_criterion_parameter_count = parameter_count + 1
    aic = (
        2.0 * information_criterion_parameter_count - 2.0 * log_likelihood
    )
    bic = (
        information_criterion_parameter_count * math.log(observation_count)
        - 2.0 * log_likelihood
    )
    durbin_watson = float(
        np.sum(np.diff(residuals) ** 2) / residual_sum_squares
    )

    standardized_design = design[:, 1:].copy()
    standardized_design -= np.mean(standardized_design, axis=0)
    standardized_design /= np.std(standardized_design, axis=0, ddof=1)
    condition_number = float(np.linalg.cond(standardized_design))
    influence = _influence_diagnostics(
        prepared["complete_frame"],
        response,
        fitted,
        residuals,
        design,
        mean_square_error,
    )
    mean_variance = np.sum((design @ covariance) * design, axis=1)
    mean_standard_errors = np.sqrt(np.maximum(0.0, mean_variance))
    prediction_standard_errors = np.sqrt(mean_square_error + mean_variance)
    prediction_rows = [
        {
            "model_family": "multiple_linear_regression",
            "model_name": model_name or "Multiple regression model",
            "source_index": str(source_index),
            "outcome_variable": dependent_name,
            "observed": finite_or_none(response[index]),
            "predicted": finite_or_none(fitted[index]),
            "residual": finite_or_none(residuals[index]),
            "mean_ci_lower": finite_or_none(
                fitted[index] - critical * mean_standard_errors[index]
            ),
            "mean_ci_upper": finite_or_none(
                fitted[index] + critical * mean_standard_errors[index]
            ),
            "prediction_interval_lower": finite_or_none(
                fitted[index] - critical * prediction_standard_errors[index]
            ),
            "prediction_interval_upper": finite_or_none(
                fitted[index] + critical * prediction_standard_errors[index]
            ),
        }
        for index, source_index in enumerate(prepared["complete_frame"].index)
    ]
    result.update(
        {
            "status": "completed",
            "design_matrix_rank": design_rank,
            "coefficients": coefficients,
            "r_squared": finite_or_none(r_squared),
            "adjusted_r_squared": finite_or_none(adjusted_r_squared),
            "residual_standard_error": finite_or_none(root_mean_square_error),
            "residual_degrees_of_freedom": int(residual_degrees_of_freedom),
            "f_statistic": finite_or_none(f_statistic),
            "f_degrees_of_freedom_numerator": int(model_degrees_of_freedom),
            "f_degrees_of_freedom_denominator": int(residual_degrees_of_freedom),
            "f_p_value": finite_or_none(f_p_value),
            "decision": decision_from_pvalue(f_p_value, alpha),
            "log_likelihood": finite_or_none(log_likelihood),
            "information_criterion_parameter_count": int(
                information_criterion_parameter_count
            ),
            "aic": finite_or_none(aic),
            "bic": finite_or_none(bic),
            "anova_table": [
                {
                    "source": "Regression",
                    "sum_of_squares": regression_sum_squares,
                    "degrees_of_freedom": int(model_degrees_of_freedom),
                    "mean_square": model_mean_square,
                    "f_statistic": f_statistic,
                    "p_value": f_p_value,
                },
                {
                    "source": "Residual",
                    "sum_of_squares": residual_sum_squares,
                    "degrees_of_freedom": int(residual_degrees_of_freedom),
                    "mean_square": mean_square_error,
                },
                {
                    "source": "Total",
                    "sum_of_squares": total_sum_squares,
                    "degrees_of_freedom": int(observation_count - 1),
                },
            ],
            "residual_summary": _residual_summary(residuals),
            "residual_normality_tests": normality_tests(
                pd.Series(residuals), alpha
            ),
            "breusch_pagan_test": _breusch_pagan_test(
                residuals, design, alpha
            ),
            "durbin_watson_statistic": finite_or_none(durbin_watson),
            "durbin_watson_note": (
                "interpreted in input-row order; primarily useful for ordered data"
            ),
            "condition_number_standardized_design": finite_or_none(
                condition_number
            ),
            "variance_inflation_factors": _variance_inflation_factors(
                design, terms
            ),
            "influence_diagnostics": influence,
            "prediction_rows": prediction_rows,
        }
    )
    return result


def compare_regression_models(
    frame: pd.DataFrame,
    dependent_name: str,
    reduced_predictors: list[str],
    full_predictors: list[str],
    categorical_predictors: set[str],
    alpha: float,
    comparison_name: str | None = None,
    polynomial_terms: dict[str, int] | None = None,
    interactions: list[tuple[str, str]] | None = None,
) -> dict[str, Any]:
    """Compare two models on the same complete cases and test nesting when valid."""
    union_predictors = list(dict.fromkeys(reduced_predictors + full_predictors))
    common_mask = _complete_case_mask(
        frame,
        dependent_name,
        union_predictors,
        categorical_predictors,
    )
    common_frame = frame.loc[common_mask]
    reduced = multiple_linear_regression(
        common_frame,
        dependent_name,
        reduced_predictors,
        categorical_predictors,
        alpha,
        "Reduced model on common cases",
        polynomial_terms,
        interactions,
    )
    full = multiple_linear_regression(
        common_frame,
        dependent_name,
        full_predictors,
        categorical_predictors,
        alpha,
        "Full model on common cases",
        polynomial_terms,
        interactions,
    )
    result: dict[str, Any] = {
        "method": "multiple linear regression model comparison",
        "comparison_name": comparison_name,
        "dependent_variable": dependent_name,
        "reduced_predictors": reduced_predictors,
        "full_predictors": full_predictors,
        "n_common_cases": int(len(common_frame)),
        "nested": set(reduced_predictors).issubset(full_predictors),
        "partial_f_test": {},
    }
    if reduced.get("status") != "completed":
        result.update(
            status="not_run",
            reason=f"reduced model could not be fit: {reduced.get('reason')}",
        )
        return result
    if full.get("status") != "completed":
        result.update(
            status="not_run",
            reason=f"full model could not be fit: {full.get('reason')}",
        )
        return result

    result.update(
        {
            "status": "completed",
            "reduced_model": {
                "parameter_count": reduced["parameter_count"],
                "r_squared": reduced["r_squared"],
                "adjusted_r_squared": reduced["adjusted_r_squared"],
                "aic": reduced["aic"],
                "bic": reduced["bic"],
                "residual_sum_squares": reduced["anova_table"][1][
                    "sum_of_squares"
                ],
            },
            "full_model": {
                "parameter_count": full["parameter_count"],
                "r_squared": full["r_squared"],
                "adjusted_r_squared": full["adjusted_r_squared"],
                "aic": full["aic"],
                "bic": full["bic"],
                "residual_sum_squares": full["anova_table"][1][
                    "sum_of_squares"
                ],
            },
            "change_in_r_squared": full["r_squared"] - reduced["r_squared"],
            "change_in_adjusted_r_squared": (
                full["adjusted_r_squared"] - reduced["adjusted_r_squared"]
            ),
            "change_in_aic": full["aic"] - reduced["aic"],
            "change_in_bic": full["bic"] - reduced["bic"],
        }
    )
    if not result["nested"]:
        result["partial_f_test"] = {
            "status": "not_run",
            "reason": "the reduced predictor set is not a subset of the full set",
        }
        return result

    reduced_terms = set(reduced["terms"])
    full_terms = set(full["terms"])
    if not reduced_terms.issubset(full_terms):
        result["partial_f_test"] = {
            "status": "not_run",
            "reason": "the fitted design matrices are not nested",
        }
        return result
    numerator_df = full["parameter_count"] - reduced["parameter_count"]
    denominator_df = full["residual_degrees_of_freedom"]
    if numerator_df <= 0:
        result["partial_f_test"] = {
            "status": "not_run",
            "reason": "the full model adds no estimable parameters",
        }
        return result

    reduced_sse = result["reduced_model"]["residual_sum_squares"]
    full_sse = result["full_model"]["residual_sum_squares"]
    numerator = max(0.0, (reduced_sse - full_sse) / numerator_df)
    denominator = full_sse / denominator_df
    statistic = numerator / denominator
    p_value = float(scipy_stats.f.sf(statistic, numerator_df, denominator_df))
    result["partial_f_test"] = {
        "method": "partial F-test for nested models",
        "status": "completed",
        "null_hypothesis": "the added terms have coefficients equal to zero",
        "statistic": finite_or_none(statistic),
        "degrees_of_freedom_numerator": int(numerator_df),
        "degrees_of_freedom_denominator": int(denominator_df),
        "p_value": finite_or_none(p_value),
        "decision": decision_from_pvalue(p_value, alpha),
    }
    return result
