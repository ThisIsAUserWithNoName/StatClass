"""Robust, regularized, smooth, monotone, and density estimators.

The procedures in this module are deliberately statistical estimators rather
than a general interpolation or numerical-analysis suite.  Every public
result carries enough status information to distinguish a completed fit from
an unavailable fit or unavailable inference.
"""

from __future__ import annotations

import math
from typing import Any, Callable

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats
from scipy.interpolate import BSpline
from scipy.special import logsumexp

from .utils import finite_or_none


_CONDITION_WARNING = 1.0e10
_CONDITION_FAILURE = 1.0e14
_SQRT_TWO_PI = math.sqrt(2.0 * math.pi)


class AdvancedRegressionError(ValueError):
    """Raised for invalid advanced-estimation settings."""


def _status(
    status: str,
    method: str,
    *,
    iterations: int | None = None,
    converged: bool | None = None,
    inference_available: bool | None = None,
    covariance_available: bool | None = None,
    warnings: list[str] | None = None,
    failure_reason: str | None = None,
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "status": status,
        "method": method,
        "warnings": list(warnings or []),
    }
    if iterations is not None:
        result["iterations"] = int(iterations)
    if converged is not None:
        result["converged"] = bool(converged)
    if inference_available is not None:
        result["inference_available"] = bool(inference_available)
    if covariance_available is not None:
        result["covariance_available"] = bool(covariance_available)
    if failure_reason:
        result["failure_reason"] = failure_reason
    return result


def _matrix_diagnostics(matrix: np.ndarray) -> dict[str, Any]:
    matrix = np.asarray(matrix, dtype=float)
    singular_values = np.linalg.svd(matrix, compute_uv=False)
    maximum = float(singular_values[0]) if singular_values.size else 0.0
    tolerance = (
        np.finfo(float).eps * max(matrix.shape) * maximum if maximum else 0.0
    )
    rank = int(np.sum(singular_values > tolerance))
    minimum = float(singular_values[-1]) if singular_values.size else 0.0
    condition = maximum / minimum if minimum > 0.0 else math.inf
    return {
        "rows": int(matrix.shape[0]),
        "columns": int(matrix.shape[1]),
        "rank": rank,
        "full_column_rank": rank == matrix.shape[1],
        "condition_number": finite_or_none(condition),
        "condition_number_status": (
            "singular"
            if not math.isfinite(condition)
            else "near_singular"
            if condition >= _CONDITION_WARNING
            else "well_conditioned"
        ),
        "singular_values": [finite_or_none(value) for value in singular_values],
    }


def _complete_numeric(
    frame: pd.DataFrame, names: list[str]
) -> tuple[np.ndarray, np.ndarray, pd.Index]:
    arrays = [
        pd.to_numeric(frame[name], errors="coerce").to_numpy(dtype=float)
        for name in names
    ]
    mask = np.ones(len(frame), dtype=bool)
    for values in arrays:
        mask &= np.isfinite(values)
    complete = np.column_stack([values[mask] for values in arrays])
    return complete[:, 0], complete[:, 1:], frame.index[mask]


def _not_run(
    method: str,
    dependent: str | None,
    predictors: list[str],
    observation_count: int,
    reason: str,
    *,
    numerical_method: str,
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "method": method,
        "dependent_variable": dependent,
        "predictors": predictors,
        "n_complete_cases": int(observation_count),
        "status": "not_run",
        "reason": reason,
        "numerical_status": _status(
            "failed",
            numerical_method,
            converged=False,
            inference_available=False,
            covariance_available=False,
            failure_reason=reason,
        ),
    }
    return result


def _fit_metrics(y: np.ndarray, fitted: np.ndarray, effective_df: float) -> dict[str, Any]:
    residuals = y - fitted
    rss = float(np.sum(residuals**2))
    tss = float(np.sum((y - np.mean(y)) ** 2))
    r_squared = 1.0 - rss / tss if tss > 0.0 else None
    denominator = max(float(y.size) - float(effective_df), 1.0)
    return {
        "residual_sum_squares": finite_or_none(rss),
        "root_mean_squared_error": finite_or_none(math.sqrt(rss / y.size)),
        "mean_absolute_error": finite_or_none(np.mean(np.abs(residuals))),
        "r_squared": finite_or_none(r_squared),
        "effective_degrees_of_freedom": finite_or_none(effective_df),
        "residual_standard_error": finite_or_none(math.sqrt(rss / denominator)),
    }


def _prediction_rows(
    family: str,
    name: str,
    outcome: str,
    source_indices: pd.Index,
    y: np.ndarray,
    fitted: np.ndarray,
    lower: np.ndarray | None = None,
    upper: np.ndarray | None = None,
    extra: Callable[[int], dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    residuals = y - fitted
    rows: list[dict[str, Any]] = []
    for index, source_index in enumerate(source_indices):
        row: dict[str, Any] = {
            "model_family": family,
            "model_name": name,
            "source_index": str(source_index),
            "outcome_variable": outcome,
            "observed": finite_or_none(y[index]),
            "predicted": finite_or_none(fitted[index]),
            "residual": finite_or_none(residuals[index]),
        }
        if lower is not None and upper is not None:
            row["mean_ci_lower"] = finite_or_none(lower[index])
            row["mean_ci_upper"] = finite_or_none(upper[index])
        if extra is not None:
            row.update(extra(index))
        rows.append(row)
    return rows


def _coefficient_rows(
    terms: list[str], estimates: np.ndarray, covariance: np.ndarray, alpha: float
) -> list[dict[str, Any]]:
    standard_errors = np.sqrt(np.maximum(np.diag(covariance), 0.0))
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    rows = []
    for term, estimate, standard_error in zip(terms, estimates, standard_errors):
        if standard_error > 0.0:
            statistic = estimate / standard_error
            p_value = float(2.0 * scipy_stats.norm.sf(abs(statistic)))
        else:
            statistic = math.copysign(math.inf, estimate) if estimate else math.nan
            p_value = 0.0 if estimate else math.nan
        rows.append(
            {
                "term": term,
                "estimate": finite_or_none(estimate),
                "standard_error": finite_or_none(standard_error),
                "z_statistic": finite_or_none(statistic),
                "p_value": finite_or_none(p_value),
                "confidence_interval": [
                    finite_or_none(estimate - critical * standard_error),
                    finite_or_none(estimate + critical * standard_error),
                ],
            }
        )
    return rows


def robust_linear_regression(
    frame: pd.DataFrame,
    dependent_name: str,
    predictor_names: list[str],
    alpha: float,
    tuning_constant: float = 1.345,
    max_iterations: int = 100,
    tolerance: float = 1.0e-8,
) -> dict[str, Any]:
    """Fit Huber M-estimation by iteratively reweighted least squares."""
    method = "Huber robust linear regression"
    y, x, source_indices = _complete_numeric(
        frame, [dependent_name, *predictor_names]
    )
    n, p = x.shape
    base = {
        "method": method,
        "model_name": f"Robust: {dependent_name} on {', '.join(predictor_names)}",
        "dependent_variable": dependent_name,
        "predictors": predictor_names,
        "n_complete_cases": int(n),
        "excluded_rows": int(len(frame) - n),
        "loss": "Huber",
        "tuning_constant": tuning_constant,
    }
    if n <= p + 1:
        return {**base, **_not_run(method, dependent_name, predictor_names, n, "requires more complete cases than fitted coefficients", numerical_method="Huber IRLS")}
    scales = np.std(x, axis=0, ddof=0)
    if np.any(scales <= 0.0):
        constant = [name for name, scale in zip(predictor_names, scales) if scale <= 0.0]
        reason = f"constant predictor(s): {', '.join(constant)}"
        return {**base, **_not_run(method, dependent_name, predictor_names, n, reason, numerical_method="Huber IRLS")}
    means = np.mean(x, axis=0)
    standardized = (x - means) / scales
    design = np.column_stack([np.ones(n), standardized])
    diagnostics = _matrix_diagnostics(design)
    if not diagnostics["full_column_rank"]:
        reason = "the robust-regression design matrix is singular"
        return {**base, "matrix_diagnostics": diagnostics, **_not_run(method, dependent_name, predictor_names, n, reason, numerical_method="Huber IRLS")}
    if (diagnostics["condition_number"] or math.inf) >= _CONDITION_FAILURE:
        reason = "the robust-regression design matrix is numerically singular"
        return {**base, "matrix_diagnostics": diagnostics, **_not_run(method, dependent_name, predictor_names, n, reason, numerical_method="Huber IRLS")}

    beta = np.linalg.solve(design.T @ design, design.T @ y)
    converged = False
    warnings: list[str] = []
    weights = np.ones(n)
    scale = math.nan
    for iteration in range(1, max_iterations + 1):
        residuals = y - design @ beta
        median = float(np.median(residuals))
        scale = float(np.median(np.abs(residuals - median)) / 0.6744897501960817)
        if not math.isfinite(scale) or scale <= np.finfo(float).eps:
            scale = float(math.sqrt(np.mean(residuals**2)))
        if not math.isfinite(scale) or scale <= np.finfo(float).eps:
            converged = True
            weights = np.ones(n)
            break
        standardized_residuals = residuals / scale
        absolute = np.abs(standardized_residuals)
        weights = np.ones(n)
        outside = absolute > tuning_constant
        weights[outside] = tuning_constant / absolute[outside]
        weighted_design = design * np.sqrt(weights)[:, None]
        weighted_response = y * np.sqrt(weights)
        weighted_diagnostics = _matrix_diagnostics(weighted_design)
        if not weighted_diagnostics["full_column_rank"]:
            reason = "the weighted design matrix became singular during Huber IRLS"
            return {**base, "matrix_diagnostics": diagnostics, "weighted_matrix_diagnostics": weighted_diagnostics, **_not_run(method, dependent_name, predictor_names, n, reason, numerical_method="Huber IRLS")}
        new_beta = np.linalg.solve(
            weighted_design.T @ weighted_design,
            weighted_design.T @ weighted_response,
        )
        difference = float(np.max(np.abs(new_beta - beta)))
        beta = new_beta
        if difference <= tolerance * (1.0 + float(np.max(np.abs(beta)))):
            converged = True
            break
    else:
        iteration = max_iterations

    fitted = design @ beta
    residuals = y - fitted
    if not converged:
        warnings.append("Huber IRLS reached the iteration limit before convergence")
    if diagnostics["condition_number_status"] == "near_singular":
        warnings.append("the standardized design is approximately singular")

    transform = np.zeros((p + 1, p + 1))
    transform[0, 0] = 1.0
    transform[0, 1:] = -means / scales
    transform[1:, 1:] = np.diag(1.0 / scales)
    original_beta = transform @ beta

    covariance = None
    covariance_reason = None
    if math.isfinite(scale) and scale > 0.0:
        u = residuals / scale
        psi = np.clip(u, -tuning_constant, tuning_constant)
        derivative = (np.abs(u) <= tuning_constant).astype(float)
        a = (design.T * derivative) @ design / n
        b = (design.T * (psi**2)) @ design / n
        a_diagnostics = _matrix_diagnostics(a)
        if a_diagnostics["full_column_rank"] and (
            a_diagnostics["condition_number"] or math.inf
        ) < _CONDITION_FAILURE:
            left = np.linalg.solve(a, b)
            covariance_standardized = (scale**2 / n) * np.linalg.solve(a, left.T).T
            covariance = transform @ covariance_standardized @ transform.T
            covariance = (covariance + covariance.T) / 2.0
        else:
            covariance_reason = "robust sandwich covariance is singular or ill-conditioned"
    else:
        covariance_reason = "the robust residual scale is zero"
    if covariance_reason:
        warnings.append(covariance_reason)

    result = {
        **base,
        "status": (
            "completed" if converged and not warnings else "completed_with_warnings"
        ),
        "converged": converged,
        "iterations": int(iteration),
        "scale_estimate": finite_or_none(scale),
        "matrix_diagnostics": diagnostics,
        "downweighted_case_count": int(np.sum(weights < 1.0 - 1.0e-12)),
        "minimum_weight": finite_or_none(np.min(weights)),
        **_fit_metrics(y, fitted, p + 1.0),
        "coefficient_inference": (
            "Huber sandwich covariance with normal-reference Wald intervals"
            if covariance is not None
            else "unavailable"
        ),
        "coefficients": (
            _coefficient_rows(["Intercept", *predictor_names], original_beta, covariance, alpha)
            if covariance is not None
            else [
                {"term": term, "estimate": finite_or_none(value)}
                for term, value in zip(["Intercept", *predictor_names], original_beta)
            ]
        ),
        "numerical_status": _status(
            "completed" if converged and not warnings else "completed_with_warnings",
            "Huber iteratively reweighted least squares",
            iterations=iteration,
            converged=converged,
            inference_available=covariance is not None,
            covariance_available=covariance is not None,
            warnings=warnings,
        ),
    }
    result["prediction_rows"] = _prediction_rows(
        "robust_linear_regression",
        base["model_name"],
        dependent_name,
        source_indices,
        y,
        fitted,
        extra=lambda index: {"robust_weight": finite_or_none(weights[index])},
    )
    return result


def _soft_threshold(value: float, threshold: float) -> float:
    if value > threshold:
        return value - threshold
    if value < -threshold:
        return value + threshold
    return 0.0


def _standardize_training(
    x: np.ndarray, y: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, float]:
    means = np.mean(x, axis=0)
    scales = np.std(x, axis=0, ddof=0)
    if np.any(scales <= 0.0):
        raise AdvancedRegressionError("regularized regression has a constant predictor")
    y_mean = float(np.mean(y))
    return (x - means) / scales, y - y_mean, means, scales, y_mean


def _penalized_fit(
    x: np.ndarray,
    y: np.ndarray,
    penalty: str,
    penalty_strength: float,
    l1_ratio: float,
    max_iterations: int,
    tolerance: float,
) -> dict[str, Any]:
    standardized, centered_y, means, scales, y_mean = _standardize_training(x, y)
    p = x.shape[1]
    if penalty == "ridge":
        cross_product = standardized.T @ standardized / x.shape[0]
        beta_standardized = np.linalg.solve(
            cross_product + penalty_strength * np.eye(p),
            standardized.T @ centered_y / x.shape[0],
        )
        converged = True
        iterations = 0
    else:
        ratio = 1.0 if penalty == "lasso" else l1_ratio
        beta_standardized = np.zeros(p)
        column_squares = np.mean(standardized**2, axis=0)
        converged = False
        for iterations in range(1, max_iterations + 1):
            maximum_change = 0.0
            for column in range(p):
                partial = centered_y - standardized @ beta_standardized + standardized[:, column] * beta_standardized[column]
                rho = float(np.mean(standardized[:, column] * partial))
                updated = _soft_threshold(rho, penalty_strength * ratio) / (
                    column_squares[column] + penalty_strength * (1.0 - ratio)
                )
                maximum_change = max(maximum_change, abs(updated - beta_standardized[column]))
                beta_standardized[column] = updated
            if maximum_change <= tolerance * (1.0 + float(np.max(np.abs(beta_standardized)))):
                converged = True
                break
    coefficients = beta_standardized / scales
    intercept = y_mean - float(means @ coefficients)
    return {
        "intercept": intercept,
        "coefficients": coefficients,
        "standardized_coefficients": beta_standardized,
        "x_means": means,
        "x_scales": scales,
        "y_mean": y_mean,
        "converged": converged,
        "iterations": iterations,
        "fitted": intercept + x @ coefficients,
    }


def _cross_validation_folds(n: int, folds: int, seed: int) -> np.ndarray:
    generator = np.random.default_rng(seed)
    order = generator.permutation(n)
    assignments = np.empty(n, dtype=int)
    assignments[order] = np.arange(n) % folds
    return assignments


def regularized_linear_regression(
    frame: pd.DataFrame,
    dependent_name: str,
    predictor_names: list[str],
    penalty: str,
    penalty_strength: float | None,
    l1_ratio: float,
    cv_folds: int,
    random_seed: int,
    max_iterations: int = 5000,
    tolerance: float = 1.0e-8,
) -> dict[str, Any]:
    """Fit ridge, lasso, or elastic-net regression with optional CV."""
    method = f"{penalty} regularized linear regression"
    y, x, source_indices = _complete_numeric(frame, [dependent_name, *predictor_names])
    n, p = x.shape
    model_name = f"{penalty.title()}: {dependent_name} on {', '.join(predictor_names)}"
    base = {
        "method": method,
        "model_name": model_name,
        "dependent_variable": dependent_name,
        "predictors": predictor_names,
        "penalty": penalty,
        "elastic_net_l1_ratio": l1_ratio if penalty == "elastic-net" else None,
        "n_complete_cases": int(n),
        "excluded_rows": int(len(frame) - n),
    }
    if n < 5:
        return {**base, **_not_run(method, dependent_name, predictor_names, n, "requires at least 5 complete cases", numerical_method=f"{penalty} fitting")}
    scales = np.std(x, axis=0, ddof=0)
    if np.any(scales <= 0.0):
        constant = [name for name, scale in zip(predictor_names, scales) if scale <= 0.0]
        reason = f"constant predictor(s): {', '.join(constant)}"
        return {**base, **_not_run(method, dependent_name, predictor_names, n, reason, numerical_method=f"{penalty} fitting")}
    unpenalized_diagnostics = _matrix_diagnostics(np.column_stack([np.ones(n), (x - np.mean(x, axis=0)) / scales]))
    warnings: list[str] = []
    if not unpenalized_diagnostics["full_column_rank"]:
        warnings.append(
            "the unpenalized design is rank deficient; the positive penalty "
            "permits fitting, but coefficient attribution depends on the penalty"
        )
    elif unpenalized_diagnostics["condition_number_status"] == "near_singular":
        warnings.append(
            "the unpenalized standardized design is approximately singular; "
            "regularization stabilizes the fitted prediction"
        )
    cv_table: list[dict[str, Any]] = []
    if penalty_strength is None:
        standardized, centered_y, _, _, _ = _standardize_training(x, y)
        if penalty == "ridge":
            candidates = np.logspace(-6.0, 4.0, 41)
        else:
            ratio = 1.0 if penalty == "lasso" else l1_ratio
            maximum = float(np.max(np.abs(standardized.T @ centered_y / n))) / max(ratio, 1.0e-12)
            maximum = max(maximum, 1.0e-8)
            candidates = maximum * np.logspace(0.0, -4.0, 41)
        folds = min(cv_folds, n)
        assignments = _cross_validation_folds(n, folds, random_seed)
        best_score = math.inf
        selected = None
        for candidate in candidates:
            squared_errors: list[float] = []
            fold_converged = True
            for fold in range(folds):
                training = assignments != fold
                validation = ~training
                try:
                    fit = _penalized_fit(
                        x[training], y[training], penalty, float(candidate), l1_ratio, max_iterations, tolerance
                    )
                except (AdvancedRegressionError, np.linalg.LinAlgError):
                    fold_converged = False
                    squared_errors = []
                    break
                fold_converged &= bool(fit["converged"])
                predictions = fit["intercept"] + x[validation] @ fit["coefficients"]
                squared_errors.extend(((y[validation] - predictions) ** 2).tolist())
            score = (
                float(np.mean(squared_errors))
                if squared_errors and fold_converged
                else math.inf
            )
            cv_table.append(
                {
                    "penalty_strength": finite_or_none(candidate),
                    "mean_squared_error": finite_or_none(score),
                    "all_fits_converged": fold_converged,
                }
            )
            if score < best_score:
                best_score = score
                selected = float(candidate)
        if selected is None or not math.isfinite(best_score):
            reason = "cross-validation could not obtain a finite validation error"
            return {**base, "cross_validation": {"status": "failed", "folds": folds, "candidates": cv_table}, **_not_run(method, dependent_name, predictor_names, n, reason, numerical_method=f"{penalty} cross-validation")}
        penalty_strength = selected
        selection = "K-fold cross-validation"
        if selected in {float(candidates[0]), float(candidates[-1])}:
            warnings.append("the selected penalty lies at an edge of the search grid")
        cross_validation = {
            "status": "completed",
            "folds": int(folds),
            "selection_metric": "mean squared prediction error",
            "selected_penalty_strength": finite_or_none(selected),
            "selected_mean_squared_error": finite_or_none(best_score),
            "candidates": cv_table,
        }
    else:
        selection = "user supplied"
        cross_validation = {
            "status": "not_run",
            "reason": "a penalty strength was supplied explicitly",
            "folds": None,
            "candidates": [],
        }
    try:
        fit = _penalized_fit(
            x, y, penalty, float(penalty_strength), l1_ratio, max_iterations, tolerance
        )
    except (AdvancedRegressionError, np.linalg.LinAlgError) as exc:
        reason = f"regularized fitting failed: {exc}"
        return {**base, "cross_validation": cross_validation, **_not_run(method, dependent_name, predictor_names, n, reason, numerical_method=f"{penalty} fitting")}
    if not fit["converged"]:
        warnings.append("coordinate descent reached the iteration limit before convergence")
    fitted = fit["fitted"]
    if penalty == "ridge":
        standardized = (x - fit["x_means"]) / fit["x_scales"]
        gram = standardized.T @ standardized / n
        effective_df = 1.0 + float(np.trace(np.linalg.solve(gram + float(penalty_strength) * np.eye(p), gram)))
    else:
        effective_df = 1.0 + float(np.sum(np.abs(fit["coefficients"]) > 1.0e-10))
    coefficients = [
        {
            "term": "Intercept",
            "estimate": finite_or_none(fit["intercept"]),
            "standardized_estimate": None,
            "penalized": False,
        }
    ]
    coefficients.extend(
        {
            "term": term,
            "estimate": finite_or_none(estimate),
            "standardized_estimate": finite_or_none(standardized_estimate),
            "penalized": True,
        }
        for term, estimate, standardized_estimate in zip(
            predictor_names, fit["coefficients"], fit["standardized_coefficients"]
        )
    )
    result = {
        **base,
        "status": "completed" if fit["converged"] and not warnings else "completed_with_warnings",
        "penalty_strength": finite_or_none(penalty_strength),
        "penalty_selection": selection,
        "cross_validation": cross_validation,
        "unpenalized_design_diagnostics": unpenalized_diagnostics,
        "coefficients": coefficients,
        "zero_coefficient_count": int(np.sum(np.abs(fit["coefficients"]) <= 1.0e-10)),
        "coefficient_inference": "not provided; ordinary OLS standard errors and p-values are invalid after penalization and data-driven tuning",
        **_fit_metrics(y, fitted, effective_df),
        "numerical_status": _status(
            "completed" if fit["converged"] and not warnings else "completed_with_warnings",
            "closed-form penalized solve" if penalty == "ridge" else "cyclic coordinate descent",
            iterations=fit["iterations"],
            converged=fit["converged"],
            inference_available=False,
            covariance_available=False,
            warnings=warnings,
        ),
    }
    result["prediction_rows"] = _prediction_rows(
        "regularized_linear_regression", model_name, dependent_name, source_indices, y, fitted
    )
    return result


def _ols_smoother_result(
    basis: np.ndarray, y: np.ndarray, alpha: float
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, int]:
    cross_product = basis.T @ basis
    beta = np.linalg.solve(cross_product, basis.T @ y)
    fitted = basis @ beta
    residuals = y - fitted
    residual_df = y.size - basis.shape[1]
    variance = float(np.sum(residuals**2)) / residual_df
    covariance = variance * np.linalg.solve(cross_product, np.eye(basis.shape[1]))
    mean_variance = np.sum((basis @ covariance) * basis, axis=1)
    critical = float(scipy_stats.t.ppf(1.0 - alpha / 2.0, residual_df))
    standard_error = np.sqrt(np.maximum(mean_variance, 0.0))
    return beta, fitted, covariance, standard_error, residual_df


def regression_spline(
    dependent: pd.Series,
    independent: pd.Series,
    dependent_name: str,
    independent_name: str,
    alpha: float,
    interior_knots: int,
) -> dict[str, Any]:
    """Fit a cubic regression spline in a truncated-power basis."""
    frame = pd.DataFrame({dependent_name: dependent, independent_name: independent})
    y, matrix, source_indices = _complete_numeric(frame, [dependent_name, independent_name])
    x = matrix[:, 0]
    n = y.size
    method = "cubic regression spline"
    base = {
        "method": method,
        "model_name": f"Regression spline: {dependent_name} on {independent_name}",
        "dependent_variable": dependent_name,
        "independent_variable": independent_name,
        "predictors": [independent_name],
        "n_complete_cases": int(n),
        "excluded_rows": int(len(frame) - n),
        "spline_degree": 3,
        "requested_interior_knots": interior_knots,
    }
    if n < interior_knots + 6:
        return {**base, **_not_run(method, dependent_name, [independent_name], n, "too few complete cases for the requested cubic spline basis", numerical_method="ordinary least squares spline solve")}
    if np.ptp(x) <= 0.0:
        return {**base, **_not_run(method, dependent_name, [independent_name], n, "the independent variable is constant", numerical_method="ordinary least squares spline solve")}
    x_mean = float(np.mean(x))
    x_scale = float(np.std(x, ddof=0))
    z = (x - x_mean) / x_scale
    knot_probabilities = np.linspace(0.0, 1.0, interior_knots + 2)[1:-1]
    knots = np.unique(np.quantile(z, knot_probabilities))
    basis = np.column_stack(
        [np.ones(n), z, z**2, z**3, *[np.maximum(z - knot, 0.0) ** 3 for knot in knots]]
    )
    diagnostics = _matrix_diagnostics(basis)
    if not diagnostics["full_column_rank"] or (diagnostics["condition_number"] or math.inf) >= _CONDITION_FAILURE:
        reason = "the cubic spline basis is singular or numerically singular; use fewer knots or more distinct predictor values"
        return {**base, "matrix_diagnostics": diagnostics, **_not_run(method, dependent_name, [independent_name], n, reason, numerical_method="ordinary least squares spline solve")}
    beta, fitted, covariance, mean_se, residual_df = _ols_smoother_result(basis, y, alpha)
    critical = float(scipy_stats.t.ppf(1.0 - alpha / 2.0, residual_df))
    lower = fitted - critical * mean_se
    upper = fitted + critical * mean_se
    warnings = []
    if diagnostics["condition_number_status"] == "near_singular":
        warnings.append("the spline basis is approximately singular")
    term_names = ["Intercept", "z", "z^2", "z^3", *[f"(z-{knot:.6g})_+^3" for knot in knots]]
    standard_errors = np.sqrt(np.maximum(np.diag(covariance), 0.0))
    coefficient_rows = []
    for term, estimate, se in zip(term_names, beta, standard_errors):
        statistic = estimate / se if se > 0.0 else math.nan
        p_value = float(2.0 * scipy_stats.t.sf(abs(statistic), residual_df)) if math.isfinite(statistic) else None
        coefficient_rows.append(
            {
                "term": term,
                "estimate": finite_or_none(estimate),
                "standard_error": finite_or_none(se),
                "t_statistic": finite_or_none(statistic),
                "p_value": finite_or_none(p_value),
                "confidence_interval": [finite_or_none(estimate - critical * se), finite_or_none(estimate + critical * se)],
            }
        )
    result = {
        **base,
        "status": "completed" if not warnings else "completed_with_warnings",
        "basis": "truncated cubic powers of standardized predictor z",
        "standardization": {"mean": x_mean, "scale": x_scale},
        "interior_knots": [finite_or_none(x_mean + x_scale * knot) for knot in knots],
        "basis_terms": term_names,
        "matrix_diagnostics": diagnostics,
        "coefficients": coefficient_rows,
        "confidence_level": 1.0 - alpha,
        "interval_type": "pointwise confidence interval for the fitted mean",
        **_fit_metrics(y, fitted, basis.shape[1]),
        "degrees_of_freedom_residual": residual_df,
        "numerical_status": _status(
            "completed" if not warnings else "completed_with_warnings",
            "full-rank ordinary least-squares linear solve",
            converged=True,
            inference_available=True,
            covariance_available=True,
            warnings=warnings,
        ),
    }
    result["prediction_rows"] = _prediction_rows(
        "regression_spline", base["model_name"], dependent_name, source_indices, y, fitted, lower, upper
    )
    return result


def _bspline_basis_and_penalty(
    x: np.ndarray, interior_knots: int
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    degree = 3
    lower = float(np.min(x))
    upper = float(np.max(x))
    probabilities = np.linspace(0.0, 1.0, interior_knots + 2)[1:-1]
    knots = np.unique(np.quantile(x, probabilities))
    knots = knots[(knots > lower) & (knots < upper)]
    knot_vector = np.r_[[lower] * (degree + 1), knots, [upper] * (degree + 1)]
    basis = BSpline.design_matrix(x, knot_vector, degree, extrapolate=True).toarray()
    grid = np.linspace(lower, upper, max(301, 30 * basis.shape[1]))
    second_derivatives = np.empty((grid.size, basis.shape[1]))
    for column in range(basis.shape[1]):
        coefficients = np.zeros(basis.shape[1])
        coefficients[column] = 1.0
        second_derivatives[:, column] = BSpline(knot_vector, coefficients, degree).derivative(2)(grid)
    penalty = np.trapezoid(
        second_derivatives[:, :, None] * second_derivatives[:, None, :],
        grid,
        axis=0,
    )
    return basis, penalty, knots, knot_vector


def smoothing_spline(
    dependent: pd.Series,
    independent: pd.Series,
    dependent_name: str,
    independent_name: str,
    alpha: float,
    interior_knots: int,
    smoothing_strength: float | None,
) -> dict[str, Any]:
    """Fit a penalized cubic B-spline, selecting roughness by GCV."""
    frame = pd.DataFrame({dependent_name: dependent, independent_name: independent})
    y, matrix, source_indices = _complete_numeric(frame, [dependent_name, independent_name])
    x = matrix[:, 0]
    n = y.size
    method = "penalized cubic smoothing spline"
    base = {
        "method": method,
        "model_name": f"Smoothing spline: {dependent_name} on {independent_name}",
        "dependent_variable": dependent_name,
        "independent_variable": independent_name,
        "predictors": [independent_name],
        "n_complete_cases": int(n),
        "excluded_rows": int(len(frame) - n),
        "spline_degree": 3,
        "requested_interior_knots": interior_knots,
    }
    if n < 8 or np.unique(x).size < 4:
        return {**base, **_not_run(method, dependent_name, [independent_name], n, "requires at least 8 complete cases and 4 distinct predictor values", numerical_method="penalized B-spline solve")}
    usable_knots = min(interior_knots, max(0, np.unique(x).size - 4), max(0, n - 6))
    try:
        basis, penalty, knots, _ = _bspline_basis_and_penalty(x, usable_knots)
    except (ValueError, np.linalg.LinAlgError) as exc:
        reason = f"could not construct the B-spline basis: {exc}"
        return {**base, **_not_run(method, dependent_name, [independent_name], n, reason, numerical_method="penalized B-spline solve")}
    cross_product = basis.T @ basis
    penalty_trace = float(np.trace(penalty))
    scale = float(np.trace(cross_product)) / penalty_trace if penalty_trace > 0.0 else 1.0
    candidates: list[dict[str, Any]] = []
    if smoothing_strength is None:
        multipliers = np.logspace(-8.0, 8.0, 49)
        strengths = scale * multipliers
        selection = "generalized cross-validation"
    else:
        multipliers = np.asarray([smoothing_strength / scale])
        strengths = np.asarray([smoothing_strength])
        selection = "user supplied"
    best: dict[str, Any] | None = None
    for multiplier, strength in zip(multipliers, strengths):
        system = cross_product + float(strength) * penalty
        try:
            beta = np.linalg.solve(system, basis.T @ y)
            fitted = basis @ beta
            rss = float(np.sum((y - fitted) ** 2))
            effective_df = float(np.trace(np.linalg.solve(system, cross_product)))
            denominator = 1.0 - effective_df / n
            gcv = rss / n / denominator**2 if denominator > 0.0 else math.inf
            condition = _matrix_diagnostics(system)
        except np.linalg.LinAlgError:
            beta = None
            fitted = None
            rss = math.inf
            effective_df = math.nan
            gcv = math.inf
            condition = None
        row = {
            "smoothing_strength": finite_or_none(strength),
            "scaled_multiplier": finite_or_none(multiplier),
            "gcv": finite_or_none(gcv),
            "effective_degrees_of_freedom": finite_or_none(effective_df),
            "system_condition_number": condition["condition_number"] if condition else None,
        }
        candidates.append(row)
        if math.isfinite(gcv) and (best is None or gcv < best["gcv"]):
            best = {
                "strength": float(strength),
                "multiplier": float(multiplier),
                "gcv": gcv,
                "effective_df": effective_df,
                "beta": beta,
                "fitted": fitted,
                "system": system,
                "diagnostics": condition,
            }
    if best is None:
        reason = "no smoothing parameter produced a finite generalized cross-validation score"
        return {**base, "smoothing_parameter_search": candidates, **_not_run(method, dependent_name, [independent_name], n, reason, numerical_method="penalized B-spline GCV")}
    warnings: list[str] = []
    if smoothing_strength is None and best["strength"] in {float(strengths[0]), float(strengths[-1])}:
        warnings.append("the selected smoothing parameter lies at an edge of the GCV search grid")
    if best["diagnostics"]["condition_number_status"] == "near_singular":
        warnings.append("the penalized spline system is approximately singular")
    fitted = best["fitted"]
    residuals = y - fitted
    residual_df = max(n - best["effective_df"], 1.0)
    variance = float(np.sum(residuals**2)) / residual_df
    inverse_times_cross = np.linalg.solve(best["system"], cross_product)
    covariance = variance * inverse_times_cross @ np.linalg.solve(best["system"], np.eye(basis.shape[1]))
    covariance = (covariance + covariance.T) / 2.0
    mean_variance = np.sum((basis @ covariance) * basis, axis=1)
    mean_se = np.sqrt(np.maximum(mean_variance, 0.0))
    critical = float(scipy_stats.t.ppf(1.0 - alpha / 2.0, max(1, int(math.floor(residual_df)))))
    lower = fitted - critical * mean_se
    upper = fitted + critical * mean_se
    result = {
        **base,
        "status": "completed" if not warnings else "completed_with_warnings",
        "basis": "cubic B-spline",
        "roughness_penalty": "integrated squared second derivative",
        "interior_knots": [finite_or_none(value) for value in knots],
        "basis_dimension": int(basis.shape[1]),
        "smoothing_strength": finite_or_none(best["strength"]),
        "scaled_smoothing_multiplier": finite_or_none(best["multiplier"]),
        "smoothing_parameter_selection": selection,
        "generalized_cross_validation_score": finite_or_none(best["gcv"]),
        "smoothing_parameter_search": candidates,
        "matrix_diagnostics": best["diagnostics"],
        "confidence_level": 1.0 - alpha,
        "interval_type": "approximate pointwise confidence interval for the fitted mean",
        **_fit_metrics(y, fitted, best["effective_df"]),
        "numerical_status": _status(
            "completed" if not warnings else "completed_with_warnings",
            "penalized cubic B-spline linear solves with GCV",
            converged=True,
            inference_available=True,
            covariance_available=True,
            warnings=warnings,
        ),
    }
    result["prediction_rows"] = _prediction_rows(
        "smoothing_spline", base["model_name"], dependent_name, source_indices, y, fitted, lower, upper
    )
    return result


def _loess_fit(
    x: np.ndarray,
    y: np.ndarray,
    span: float,
    degree: int,
    robust_weights: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, int]:
    n = x.size
    neighbors = max(degree + 2, int(math.ceil(span * n)))
    fitted = np.empty(n)
    leverage = np.empty(n)
    reduced_degree_count = 0
    for target in range(n):
        distance = np.abs(x - x[target])
        order = np.argsort(distance, kind="mergesort")
        local = order[:neighbors]
        bandwidth = float(distance[local[-1]])
        if bandwidth <= 0.0:
            positive = distance[distance > 0.0]
            if not positive.size:
                raise np.linalg.LinAlgError("all predictor values are identical")
            bandwidth = float(np.min(positive))
            local = np.flatnonzero(distance <= bandwidth)
        scaled = (x[local] - x[target]) / bandwidth
        tricube = np.maximum(1.0 - np.abs(scaled) ** 3, 0.0) ** 3
        weights = tricube * robust_weights[local]
        used_degree = degree
        while used_degree >= 0:
            design = np.column_stack([scaled**power for power in range(used_degree + 1)])
            weighted_design = design * np.sqrt(weights)[:, None]
            diagnostics = _matrix_diagnostics(weighted_design)
            if diagnostics["full_column_rank"] and np.sum(weights > 0.0) > used_degree:
                break
            used_degree -= 1
        if used_degree < 0:
            raise np.linalg.LinAlgError("a local neighborhood has no positive usable weight")
        if used_degree < degree:
            reduced_degree_count += 1
        system = design.T @ (weights[:, None] * design)
        right = design.T @ (weights * y[local])
        beta = np.linalg.solve(system, right)
        fitted[target] = beta[0]
        row = np.linalg.solve(system, np.eye(system.shape[0]))[0] @ (design.T * weights)
        target_locations = np.flatnonzero(local == target)
        leverage[target] = row[target_locations[0]] if target_locations.size else 0.0
    return fitted, leverage, reduced_degree_count


def loess_regression(
    dependent: pd.Series,
    independent: pd.Series,
    dependent_name: str,
    independent_name: str,
    span: float,
    degree: int,
    robust_iterations: int,
) -> dict[str, Any]:
    """Fit one-dimensional LOESS with tricube and optional robust weights."""
    frame = pd.DataFrame({dependent_name: dependent, independent_name: independent})
    y, matrix, source_indices = _complete_numeric(frame, [dependent_name, independent_name])
    x = matrix[:, 0]
    n = y.size
    method = "LOESS local polynomial regression"
    base = {
        "method": method,
        "model_name": f"LOESS: {dependent_name} on {independent_name}",
        "dependent_variable": dependent_name,
        "independent_variable": independent_name,
        "predictors": [independent_name],
        "n_complete_cases": int(n),
        "excluded_rows": int(len(frame) - n),
        "span": span,
        "local_polynomial_degree": degree,
        "requested_robust_iterations": robust_iterations,
    }
    if n < max(5, degree + 3) or np.ptp(x) <= 0.0:
        reason = "requires enough complete cases and a nonconstant independent variable"
        return {**base, **_not_run(method, dependent_name, [independent_name], n, reason, numerical_method="LOESS local weighted least squares")}
    robust_weights = np.ones(n)
    warnings: list[str] = []
    try:
        fitted, leverage, reduced_count = _loess_fit(x, y, span, degree, robust_weights)
        completed_iterations = 0
        for completed_iterations in range(1, robust_iterations + 1):
            residuals = y - fitted
            scale = float(np.median(np.abs(residuals - np.median(residuals))))
            if scale <= np.finfo(float).eps:
                break
            ratio = residuals / (6.0 * scale)
            robust_weights = np.where(np.abs(ratio) < 1.0, (1.0 - ratio**2) ** 2, 0.0)
            fitted, leverage, reduced = _loess_fit(x, y, span, degree, robust_weights)
            reduced_count += reduced
    except np.linalg.LinAlgError as exc:
        reason = f"LOESS local fitting failed: {exc}"
        return {**base, **_not_run(method, dependent_name, [independent_name], n, reason, numerical_method="LOESS local weighted least squares")}
    if reduced_count:
        warnings.append(f"{reduced_count} local fits reduced polynomial degree because the requested local design was singular")
    effective_df = float(np.sum(leverage))
    result = {
        **base,
        "status": "completed" if not warnings else "completed_with_warnings",
        "completed_robust_iterations": int(completed_iterations),
        "kernel": "tricube nearest-neighborhood weights",
        "effective_degrees_of_freedom_note": "trace of the final local smoother diagonal",
        "coefficient_inference": "not applicable to the collection of local fits",
        **_fit_metrics(y, fitted, effective_df),
        "numerical_status": _status(
            "completed" if not warnings else "completed_with_warnings",
            "local weighted least squares with robust bisquare reweighting",
            iterations=completed_iterations,
            converged=True,
            inference_available=False,
            covariance_available=False,
            warnings=warnings,
        ),
    }
    result["prediction_rows"] = _prediction_rows(
        "loess_regression", base["model_name"], dependent_name, source_indices, y, fitted,
        extra=lambda index: {"robust_weight": finite_or_none(robust_weights[index])},
    )
    return result


def kernel_regression(
    dependent: pd.Series,
    independent: pd.Series,
    dependent_name: str,
    independent_name: str,
    bandwidth: float | None,
) -> dict[str, Any]:
    """Fit Gaussian Nadaraya-Watson regression with LOO bandwidth CV."""
    frame = pd.DataFrame({dependent_name: dependent, independent_name: independent})
    y, matrix, source_indices = _complete_numeric(frame, [dependent_name, independent_name])
    x = matrix[:, 0]
    n = y.size
    method = "Gaussian-kernel Nadaraya-Watson regression"
    base = {
        "method": method,
        "model_name": f"Kernel regression: {dependent_name} on {independent_name}",
        "dependent_variable": dependent_name,
        "independent_variable": independent_name,
        "predictors": [independent_name],
        "n_complete_cases": int(n),
        "excluded_rows": int(len(frame) - n),
        "kernel": "Gaussian",
    }
    if n < 5 or np.ptp(x) <= 0.0:
        return {**base, **_not_run(method, dependent_name, [independent_name], n, "requires at least 5 complete cases and a nonconstant independent variable", numerical_method="kernel weighted averages")}
    if n > 5000:
        return {**base, **_not_run(method, dependent_name, [independent_name], n, "kernel regression is limited to 5000 complete cases to bound its O(n^2) calculation", numerical_method="kernel weighted averages")}
    scale = float(np.std(x, ddof=1))
    base_bandwidth = max(1.06 * scale * n ** (-1.0 / 5.0), np.ptp(x) * 1.0e-8)
    differences = x[:, None] - x[None, :]
    candidates: list[dict[str, Any]] = []
    if bandwidth is None:
        strengths = base_bandwidth * np.logspace(-1.5, 1.5, 31)
        best_score = math.inf
        selected = None
        for strength in strengths:
            weights = np.exp(-0.5 * (differences / strength) ** 2)
            np.fill_diagonal(weights, 0.0)
            denominator = np.sum(weights, axis=1)
            valid = denominator > np.finfo(float).tiny
            if np.all(valid):
                predictions = weights @ y / denominator
                score = float(np.mean((y - predictions) ** 2))
            else:
                score = math.inf
            candidates.append({"bandwidth": finite_or_none(strength), "leave_one_out_mean_squared_error": finite_or_none(score), "all_denominators_positive": bool(np.all(valid))})
            if score < best_score:
                best_score = score
                selected = float(strength)
        if selected is None:
            reason = "leave-one-out cross-validation could not produce finite predictions"
            return {**base, "bandwidth_search": candidates, **_not_run(method, dependent_name, [independent_name], n, reason, numerical_method="kernel bandwidth cross-validation")}
        bandwidth = selected
        selection = "leave-one-out cross-validation"
    else:
        selection = "user supplied"
        best_score = None
    weights = np.exp(-0.5 * (differences / bandwidth) ** 2)
    denominator = np.sum(weights, axis=1)
    if np.any(denominator <= np.finfo(float).tiny):
        reason = "the selected bandwidth produced a zero kernel-weight denominator"
        return {**base, **_not_run(method, dependent_name, [independent_name], n, reason, numerical_method="kernel weighted averages")}
    fitted = weights @ y / denominator
    effective_df = float(np.sum(1.0 / denominator))
    warnings = []
    if candidates and bandwidth in {float(strengths[0]), float(strengths[-1])}:
        warnings.append("the selected bandwidth lies at an edge of the cross-validation search grid")
    result = {
        **base,
        "status": "completed" if not warnings else "completed_with_warnings",
        "bandwidth": finite_or_none(bandwidth),
        "bandwidth_selection": selection,
        "selected_leave_one_out_mean_squared_error": finite_or_none(best_score),
        "bandwidth_search": candidates,
        "coefficient_inference": "not applicable to kernel weighted averages",
        **_fit_metrics(y, fitted, effective_df),
        "numerical_status": _status(
            "completed" if not warnings else "completed_with_warnings",
            "Gaussian kernel weighted averages with leave-one-out bandwidth search",
            converged=True,
            inference_available=False,
            covariance_available=False,
            warnings=warnings,
        ),
    }
    result["prediction_rows"] = _prediction_rows(
        "kernel_regression", base["model_name"], dependent_name, source_indices, y, fitted
    )
    return result


def _pava(values: np.ndarray, weights: np.ndarray) -> tuple[np.ndarray, int]:
    levels: list[float] = []
    block_weights: list[float] = []
    starts: list[int] = []
    ends: list[int] = []
    for index, (value, weight) in enumerate(zip(values, weights)):
        levels.append(float(value))
        block_weights.append(float(weight))
        starts.append(index)
        ends.append(index + 1)
        while len(levels) >= 2 and levels[-2] > levels[-1]:
            total_weight = block_weights[-2] + block_weights[-1]
            pooled = (block_weights[-2] * levels[-2] + block_weights[-1] * levels[-1]) / total_weight
            levels[-2:] = [pooled]
            block_weights[-2:] = [total_weight]
            ends[-2:] = [ends[-1]]
            starts.pop()
    fitted = np.empty(values.size)
    for level, start, end in zip(levels, starts, ends):
        fitted[start:end] = level
    return fitted, len(levels)


def isotonic_regression(
    dependent: pd.Series,
    independent: pd.Series,
    dependent_name: str,
    independent_name: str,
    direction: str,
) -> dict[str, Any]:
    """Fit increasing or decreasing least-squares isotonic regression."""
    frame = pd.DataFrame({dependent_name: dependent, independent_name: independent})
    y, matrix, source_indices = _complete_numeric(frame, [dependent_name, independent_name])
    x = matrix[:, 0]
    n = y.size
    method = "least-squares isotonic regression"
    base = {
        "method": method,
        "model_name": f"Isotonic: {dependent_name} on {independent_name}",
        "dependent_variable": dependent_name,
        "independent_variable": independent_name,
        "predictors": [independent_name],
        "n_complete_cases": int(n),
        "excluded_rows": int(len(frame) - n),
        "requested_direction": direction,
    }
    if n < 3 or np.ptp(x) <= 0.0:
        return {**base, **_not_run(method, dependent_name, [independent_name], n, "requires at least 3 complete cases and a nonconstant independent variable", numerical_method="pool-adjacent-violators algorithm")}
    order = np.argsort(x, kind="mergesort")
    sorted_x = x[order]
    sorted_y = y[order]
    unique_x, starts, counts = np.unique(sorted_x, return_index=True, return_counts=True)
    sums = np.add.reduceat(sorted_y, starts)
    means = sums / counts
    increasing_fit, increasing_blocks = _pava(means, counts.astype(float))
    decreasing_negative, decreasing_blocks = _pava(-means, counts.astype(float))
    decreasing_fit = -decreasing_negative
    increasing_rss = float(np.sum(counts * (means - increasing_fit) ** 2))
    decreasing_rss = float(np.sum(counts * (means - decreasing_fit) ** 2))
    if direction == "auto":
        selected = "increasing" if increasing_rss <= decreasing_rss else "decreasing"
    else:
        selected = direction
    unique_fit = increasing_fit if selected == "increasing" else decreasing_fit
    block_count = increasing_blocks if selected == "increasing" else decreasing_blocks
    positions = np.searchsorted(unique_x, x)
    fitted = unique_fit[positions]
    result = {
        **base,
        "status": "completed",
        "selected_direction": selected,
        "direction_selection": "minimum training residual sum of squares" if direction == "auto" else "user supplied",
        "increasing_residual_sum_squares_on_unique_means": finite_or_none(increasing_rss),
        "decreasing_residual_sum_squares_on_unique_means": finite_or_none(decreasing_rss),
        "distinct_predictor_values": int(unique_x.size),
        "monotone_block_count": int(block_count),
        "coefficient_inference": "not applicable to pooled monotone levels",
        **_fit_metrics(y, fitted, float(block_count)),
        "numerical_status": _status(
            "completed",
            "pool-adjacent-violators algorithm",
            iterations=int(unique_x.size - block_count),
            converged=True,
            inference_available=False,
            covariance_available=False,
        ),
    }
    result["prediction_rows"] = _prediction_rows(
        "isotonic_regression", base["model_name"], dependent_name, source_indices, y, fitted
    )
    return result


def kernel_density_estimation(
    series: pd.Series,
    column_name: str,
    bandwidth_method: str,
    grid_size: int,
) -> dict[str, Any]:
    """Estimate a univariate Gaussian KDE with explicit bandwidth diagnostics."""
    values = pd.to_numeric(series, errors="coerce").to_numpy(dtype=float)
    values = values[np.isfinite(values)]
    n = values.size
    method = "Gaussian kernel-density estimation"
    base: dict[str, Any] = {
        "method": method,
        "column": column_name,
        "n_complete_cases": int(n),
        "excluded_rows": int(len(series) - n),
        "kernel": "Gaussian",
        "support": "real line",
        "requested_bandwidth_method": bandwidth_method,
        "grid_size": grid_size,
    }
    if n < 3:
        reason = "kernel-density estimation requires at least 3 finite values"
        return {
            **base,
            "status": "not_run",
            "reason": reason,
            "numerical_status": _status("failed", "Gaussian KDE", converged=False, failure_reason=reason),
        }
    standard_deviation = float(np.std(values, ddof=1))
    if standard_deviation <= 0.0:
        reason = "kernel-density estimation requires nonconstant values"
        return {
            **base,
            "status": "not_run",
            "reason": reason,
            "numerical_status": _status("failed", "Gaussian KDE", converged=False, failure_reason=reason),
        }
    iqr = float(scipy_stats.iqr(values))
    robust_scale = min(standard_deviation, iqr / 1.34) if iqr > 0.0 else standard_deviation
    scott = standard_deviation * n ** (-1.0 / 5.0)
    silverman = 0.9 * robust_scale * n ** (-1.0 / 5.0)
    candidates: list[dict[str, Any]] = []
    warnings: list[str] = []
    if bandwidth_method == "scott":
        bandwidth = scott
        selection = "Scott rule"
        selected_score = None
    elif bandwidth_method == "silverman":
        bandwidth = silverman
        selection = "Silverman robust rule"
        selected_score = None
    else:
        if n > 3000:
            reason = "likelihood cross-validation is limited to 3000 values; select --kde-bandwidth scott or silverman for larger samples"
            return {
                **base,
                "status": "not_run",
                "reason": reason,
                "numerical_status": _status("failed", "KDE likelihood cross-validation", converged=False, failure_reason=reason),
            }
        baseline = max(silverman, np.ptp(values) * 1.0e-8)
        strengths = baseline * np.logspace(-1.5, 1.5, 31)
        differences = values[:, None] - values[None, :]
        best_score = -math.inf
        bandwidth = None
        for strength in strengths:
            log_kernel = -0.5 * (differences / strength) ** 2
            np.fill_diagonal(log_kernel, -math.inf)
            log_density = logsumexp(log_kernel, axis=1) - math.log(n - 1) - math.log(strength * _SQRT_TWO_PI)
            score = float(np.sum(log_density)) if np.all(np.isfinite(log_density)) else -math.inf
            candidates.append({"bandwidth": finite_or_none(strength), "leave_one_out_log_likelihood": finite_or_none(score), "all_log_densities_finite": bool(np.all(np.isfinite(log_density)))})
            if score > best_score:
                best_score = score
                bandwidth = float(strength)
        if bandwidth is None:
            reason = "KDE likelihood cross-validation produced no finite score"
            return {
                **base,
                "status": "not_run",
                "reason": reason,
                "bandwidth_search": candidates,
                "numerical_status": _status("failed", "KDE likelihood cross-validation", converged=False, failure_reason=reason),
            }
        selection = "leave-one-out maximum likelihood cross-validation"
        selected_score = best_score
        if bandwidth in {float(strengths[0]), float(strengths[-1])}:
            warnings.append("the selected bandwidth lies at an edge of the cross-validation search grid")
    lower = float(np.min(values) - 4.0 * bandwidth)
    upper = float(np.max(values) + 4.0 * bandwidth)
    grid = np.linspace(lower, upper, grid_size)
    density = np.mean(
        np.exp(-0.5 * ((grid[:, None] - values[None, :]) / bandwidth) ** 2),
        axis=1,
    ) / (bandwidth * _SQRT_TWO_PI)
    finite = bool(np.all(np.isfinite(density)))
    nonnegative = bool(np.all(density >= 0.0))
    integral = float(np.trapezoid(density, grid))
    if not finite or not nonnegative:
        reason = "the KDE grid contains a nonfinite or negative density"
        return {
            **base,
            "status": "not_run",
            "reason": reason,
            "numerical_status": _status("failed", "Gaussian KDE evaluation", converged=False, failure_reason=reason),
        }
    if abs(integral - 1.0) > 1.0e-3:
        warnings.append("the finite reporting grid captures noticeably less than total unit density")
    return {
        **base,
        "status": "completed" if not warnings else "completed_with_warnings",
        "bandwidth": finite_or_none(bandwidth),
        "bandwidth_selection": selection,
        "scott_bandwidth": finite_or_none(scott),
        "silverman_bandwidth": finite_or_none(silverman),
        "selected_leave_one_out_log_likelihood": finite_or_none(selected_score),
        "bandwidth_search": candidates,
        "density_grid": [
            {"x": finite_or_none(x_value), "density": finite_or_none(density_value)}
            for x_value, density_value in zip(grid, density)
        ],
        "density_validation": {
            "all_grid_values_finite": finite,
            "all_grid_densities_nonnegative": nonnegative,
            "trapezoidal_integral_over_reported_grid": finite_or_none(integral),
            "grid_lower": finite_or_none(lower),
            "grid_upper": finite_or_none(upper),
        },
        "numerical_status": _status(
            "completed" if not warnings else "completed_with_warnings",
            "Gaussian kernel evaluation with bandwidth selection",
            converged=True,
            inference_available=False,
            covariance_available=False,
            warnings=warnings,
        ),
    }
