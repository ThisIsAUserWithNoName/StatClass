"""StatClass: command-line statistical analysis for tabular data."""

__version__ = "3.17.0"
