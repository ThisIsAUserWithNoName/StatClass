"""Poisson regression for nonnegative count outcomes."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd
from scipy import optimize as scipy_optimize
from scipy import special as scipy_special
from scipy import stats as scipy_stats

from .logistic import _condition_number, _prepare_design, _safe_exp
from .multiple_regression import _residual_summary, _variance_inflation_factors
from .numerical import (
    NumericalComputationError,
    covariance_from_information,
    optimizer_convergence_diagnostics,
    statistical_numerical_status,
)
from .utils import decision_from_pvalue, finite_or_none


def poisson_mean_confidence_interval(
    events: int,
    alpha: float = 0.05,
) -> dict[str, Any]:
    """Return an exact two-sided confidence interval for a Poisson mean."""
    lower = (
        0.0
        if events == 0
        else 0.5 * float(scipy_stats.chi2.ppf(alpha / 2.0, 2 * events))
    )
    upper = 0.5 * float(
        scipy_stats.chi2.ppf(
            1.0 - alpha / 2.0,
            2 * (events + 1),
        )
    )
    maximized_log_likelihood = float(scipy_stats.poisson.logpmf(events, events))
    return {
        "method": "exact two-sided Poisson mean confidence interval",
        "source": "aggregate_count",
        "events": events,
        "parameter": "M",
        "distribution": "X ~ Poisson(M)",
        "likelihood_formula": (
            f"L(M) = exp(-M) * M^{events} / {events}!"
        ),
        "mle_mean": float(events),
        "maximized_likelihood": math.exp(maximized_log_likelihood),
        "maximized_log_likelihood": maximized_log_likelihood,
        "confidence_level": 1.0 - alpha,
        "alpha": alpha,
        "confidence_interval": [lower, upper],
        "status": "completed",
    }


def _prepare_count_design(
    frame: pd.DataFrame,
    outcome_name: str,
    predictor_names: list[str],
    categorical_predictors: set[str],
    polynomial_terms: dict[str, int] | None,
    interactions: list[tuple[str, str]] | None,
    offset_name: str | None,
    exposure_name: str | None,
) -> dict[str, Any]:
    """Prepare a common count-model design and its fixed log offset."""
    working = frame.copy()
    working[outcome_name] = pd.to_numeric(
        working[outcome_name], errors="coerce"
    )
    offset_error = None
    source_name = offset_name or exposure_name
    if offset_name is not None and exposure_name is not None:
        offset_error = "specify an offset or an exposure variable, not both"
    if source_name is None:
        offset_values = pd.Series(0.0, index=working.index, dtype=float)
    else:
        source_values = pd.to_numeric(working[source_name], errors="coerce")
        finite = np.isfinite(source_values.to_numpy(dtype=float))
        if exposure_name is not None:
            nonpositive = finite & (source_values.to_numpy(dtype=float) <= 0.0)
            if np.any(nonpositive):
                offset_error = (
                    f"exposure variable {exposure_name!r} must contain only "
                    "positive values among nonmissing observations"
                )
            valid = finite & (source_values.to_numpy(dtype=float) > 0.0)
            offset_values = np.log(source_values.where(valid))
        else:
            valid = finite
            offset_values = source_values.where(valid)
        working.loc[~valid, outcome_name] = np.nan

    prepared = _prepare_design(
        working,
        outcome_name,
        predictor_names,
        categorical_predictors,
        polynomial_terms,
        interactions,
    )
    if source_name is None:
        offset = np.zeros(len(prepared["complete_frame"]), dtype=float)
    else:
        offset = offset_values.to_numpy(dtype=float)[prepared["mask"]]
    prepared.update(
        {
            "offset": offset,
            "offset_name": offset_name,
            "exposure_name": exposure_name,
            "offset_error": offset_error,
        }
    )
    return prepared


def _count_influence(
    complete_frame: pd.DataFrame,
    response: np.ndarray,
    fitted: np.ndarray,
    design: np.ndarray,
    covariance: np.ndarray,
    variance: np.ndarray,
    working_weights: np.ndarray,
) -> dict[str, Any]:
    observation_count, parameter_count = design.shape
    leverage = working_weights * np.sum(
        (design @ covariance) * design, axis=1
    )
    leverage = np.clip(leverage, 0.0, 1.0)
    one_minus_leverage = np.maximum(
        1.0 - leverage, np.finfo(float).eps
    )
    pearson = (response - fitted) / np.sqrt(variance)
    standardized_pearson = pearson / np.sqrt(one_minus_leverage)
    cooks_distance = (
        standardized_pearson**2
        * leverage
        / (parameter_count * one_minus_leverage)
    )
    leverage_threshold = 2.0 * parameter_count / observation_count
    cooks_threshold = 4.0 / observation_count
    unusual = np.flatnonzero(
        (leverage > leverage_threshold)
        | (cooks_distance > cooks_threshold)
        | (np.abs(standardized_pearson) > 3.0)
    )
    ranked = sorted(
        unusual,
        key=lambda index: max(
            cooks_distance[index] / max(cooks_threshold, np.finfo(float).eps),
            leverage[index] / max(leverage_threshold, np.finfo(float).eps),
            abs(standardized_pearson[index]) / 3.0,
        ),
        reverse=True,
    )
    cases = []
    for position in ranked[:20]:
        cases.append(
            {
                "row_index": str(complete_frame.index[position]),
                "observed_count": finite_or_none(response[position]),
                "fitted_count": finite_or_none(fitted[position]),
                "standardized_pearson_residual": finite_or_none(
                    standardized_pearson[position]
                ),
                "leverage": finite_or_none(leverage[position]),
                "cooks_distance": finite_or_none(cooks_distance[position]),
            }
        )
    return {
        "leverage_threshold": leverage_threshold,
        "cooks_distance_threshold": cooks_threshold,
        "maximum_leverage": finite_or_none(np.max(leverage)),
        "maximum_absolute_standardized_pearson_residual": finite_or_none(
            np.max(np.abs(standardized_pearson))
        ),
        "maximum_cooks_distance": finite_or_none(np.max(cooks_distance)),
        "flagged_case_count": int(unusual.size),
        "flagged_cases_returned": len(cases),
        "flagged_cases_truncated": unusual.size > len(cases),
        "flagged_cases": cases,
    }


def poisson_regression(
    frame: pd.DataFrame,
    outcome_name: str,
    predictor_names: list[str],
    categorical_predictors: set[str],
    alpha: float,
    model_name: str | None = None,
    polynomial_terms: dict[str, int] | None = None,
    interactions: list[tuple[str, str]] | None = None,
    offset_name: str | None = None,
    exposure_name: str | None = None,
) -> dict[str, Any]:
    """Fit a log-link Poisson generalized linear model by maximum likelihood."""
    prepared = _prepare_count_design(
        frame,
        outcome_name,
        predictor_names,
        categorical_predictors,
        polynomial_terms,
        interactions,
        offset_name,
        exposure_name,
    )
    response = np.asarray(prepared["outcome"], dtype=float)
    design = prepared["design"]
    offset = prepared["offset"]
    observation_count, parameter_count = design.shape
    result: dict[str, Any] = {
        "method": "Poisson regression with log link",
        "model_name": model_name,
        "outcome_variable": outcome_name,
        "predictors": predictor_names,
        "categorical_predictors": [
            name for name in predictor_names if name in categorical_predictors
        ],
        "categorical_codings": prepared["categorical_codings"],
        "polynomial_terms": prepared["polynomial_terms"],
        "interactions": prepared["interactions"],
        "offset_variable": offset_name,
        "exposure_variable": exposure_name,
        "offset_scale": (
            "log exposure supplied directly"
            if offset_name is not None
            else "natural logarithm of exposure"
            if exposure_name is not None
            else None
        ),
        "total_rows": int(len(frame)),
        "n_complete_cases": int(observation_count),
        "excluded_rows": int(len(frame) - observation_count),
        "parameter_count": int(parameter_count),
        "terms": prepared["terms"],
    }
    if prepared["invalid_reason"]:
        result.update(status="not_run", reason=prepared["invalid_reason"])
        return result
    if prepared["offset_error"]:
        result.update(status="not_run", reason=prepared["offset_error"])
        return result
    if observation_count == 0:
        result.update(status="not_run", reason="no complete numeric observations")
        return result
    if np.any(response < 0) or np.any(~np.isclose(response, np.round(response))):
        result.update(
            status="not_run",
            reason="Poisson regression requires nonnegative integer counts",
        )
        return result
    if float(np.sum(response)) <= 0:
        result.update(
            status="not_run",
            reason="at least one positive outcome count is required",
        )
        return result
    if observation_count <= parameter_count:
        result.update(
            status="not_run",
            reason="requires more observations than estimated parameters",
        )
        return result
    design_rank = int(np.linalg.matrix_rank(design))
    if design_rank < parameter_count:
        result.update(
            status="not_run",
            reason="the design matrix is rank deficient",
            design_matrix_rank=design_rank,
        )
        return result

    initial = np.zeros(parameter_count, dtype=float)
    initial[0] = math.log(float(np.sum(response))) - float(
        scipy_special.logsumexp(offset)
    )

    def objective(estimates: np.ndarray) -> tuple[float, np.ndarray]:
        linear_predictor = offset + design @ estimates
        fitted = np.exp(np.clip(linear_predictor, -700.0, 700.0))
        value = float(
            np.sum(
                fitted
                - response * linear_predictor
                + scipy_special.gammaln(response + 1.0)
            )
        )
        gradient = design.T @ (fitted - response)
        return value, gradient

    optimization = scipy_optimize.minimize(
        lambda estimates: objective(estimates)[0],
        initial,
        jac=lambda estimates: objective(estimates)[1],
        method="L-BFGS-B",
        options={
            "maxiter": 3000,
            "ftol": 1e-15,
            "gtol": 1e-10,
            "maxcor": 30,
            "maxls": 50,
        },
    )
    estimates = np.asarray(optimization.x, dtype=float)
    objective_value, final_gradient = objective(estimates)
    optimization_diagnostics = optimizer_convergence_diagnostics(
        optimization,
        parameters=estimates,
        objective_value=objective_value,
        gradient=final_gradient,
        method="L-BFGS-B",
    )
    gradient_norm = optimization_diagnostics["gradient_infinity_norm"]
    if not optimization_diagnostics["converged"]:
        failure_reason = f"maximum-likelihood optimization failed: {optimization.message}"
        result.update(
            status="not_run",
            reason=failure_reason,
            convergence=optimization_diagnostics,
            numerical_status=statistical_numerical_status(
                optimization=optimization_diagnostics,
                covariance_available=False,
                inference_available=False,
                failure_reason=failure_reason,
            ),
        )
        return result

    linear_predictor = offset + design @ estimates
    fitted = np.exp(np.clip(linear_predictor, -700.0, 700.0))
    information = design.T @ (fitted[:, None] * design)
    try:
        covariance, information_diagnostics = covariance_from_information(
            information
        )
    except NumericalComputationError as exc:
        failure_reason = "the information matrix cannot support covariance inference"
        result.update(
            status="not_run",
            reason=failure_reason,
            convergence=optimization_diagnostics,
            information_matrix_diagnostics=exc.diagnostics,
            numerical_status=statistical_numerical_status(
                optimization=optimization_diagnostics,
                information=exc.diagnostics,
                covariance_available=False,
                inference_available=False,
                failure_reason=failure_reason,
            ),
        )
        return result
    information_rank = int(information_diagnostics["rank"])
    standard_errors = np.sqrt(np.maximum(0.0, np.diag(covariance)))
    z_statistics = estimates / standard_errors
    p_values = 2.0 * scipy_stats.norm.sf(np.abs(z_statistics))
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    coefficients = []
    for index, term in enumerate(prepared["terms"]):
        lower = estimates[index] - critical * standard_errors[index]
        upper = estimates[index] + critical * standard_errors[index]
        coefficients.append(
            {
                "term": term,
                "predictor": prepared["term_predictors"][index],
                "term_type": prepared["term_types"][index],
                "estimate": finite_or_none(estimates[index]),
                "standard_error": finite_or_none(standard_errors[index]),
                "z_statistic": finite_or_none(z_statistics[index]),
                "p_value": finite_or_none(p_values[index]),
                "confidence_interval": [
                    finite_or_none(lower),
                    finite_or_none(upper),
                ],
                "incidence_rate_ratio": _safe_exp(estimates[index]),
                "incidence_rate_ratio_confidence_interval": [
                    _safe_exp(lower),
                    _safe_exp(upper),
                ],
            }
        )

    log_likelihood = -float(objective(estimates)[0])
    null_intercept = math.log(float(np.sum(response))) - float(
        scipy_special.logsumexp(offset)
    )
    null_fitted = np.exp(np.clip(offset + null_intercept, -700.0, 700.0))
    null_log_likelihood = float(
        np.sum(
            response * (offset + null_intercept)
            - null_fitted
            - scipy_special.gammaln(response + 1.0)
        )
    )
    likelihood_ratio = max(0.0, 2.0 * (log_likelihood - null_log_likelihood))
    model_degrees_of_freedom = parameter_count - 1
    likelihood_ratio_p = (
        float(scipy_stats.chi2.sf(likelihood_ratio, model_degrees_of_freedom))
        if model_degrees_of_freedom > 0
        else None
    )
    log_ratio = np.zeros_like(response)
    positive = response > 0
    log_ratio[positive] = response[positive] * np.log(
        response[positive] / fitted[positive]
    )
    deviance_components = 2.0 * (log_ratio - (response - fitted))
    deviance = float(np.sum(np.maximum(0.0, deviance_components)))
    pearson_residuals = (response - fitted) / np.sqrt(fitted)
    pearson_chi_square = float(np.sum(pearson_residuals**2))
    residual_degrees_of_freedom = observation_count - parameter_count
    dispersion = pearson_chi_square / residual_degrees_of_freedom
    deviance_dispersion = deviance / residual_degrees_of_freedom
    deviance_residuals = np.sign(response - fitted) * np.sqrt(
        np.maximum(0.0, deviance_components)
    )
    linear_standard_errors = np.sqrt(
        np.maximum(0.0, np.sum((design @ covariance) * design, axis=1))
    )
    prediction_rows = [
        {
            "model_family": "poisson_regression",
            "model_name": model_name or "Poisson model",
            "source_index": str(source_index),
            "outcome_variable": outcome_name,
            "observed": finite_or_none(response[index]),
            "predicted": finite_or_none(fitted[index]),
            "residual": finite_or_none(response[index] - fitted[index]),
            "pearson_residual": finite_or_none(pearson_residuals[index]),
            "mean_ci_lower": finite_or_none(
                math.exp(
                    max(-745.0, linear_predictor[index] - critical * linear_standard_errors[index])
                )
            ),
            "mean_ci_upper": (
                finite_or_none(
                    math.exp(
                        linear_predictor[index]
                        + critical * linear_standard_errors[index]
                    )
                )
                if linear_predictor[index]
                + critical * linear_standard_errors[index]
                <= 709.0
                else None
            ),
        }
        for index, source_index in enumerate(prepared["complete_frame"].index)
    ]
    warnings = [
        warning
        for warning, condition in (
            (
                "Pearson dispersion is above 1.5; overdispersion may make Poisson standard errors too small. Consider a negative-binomial or robust analysis.",
                dispersion > 1.5,
            ),
            (
                "Pearson dispersion is below 0.5; the counts appear underdispersed relative to a Poisson model.",
                dispersion < 0.5,
            ),
            (
                "At least one coefficient has absolute value above 20; estimates may be unstable.",
                bool(np.max(np.abs(estimates)) > 20),
            ),
            (
                "There are fewer than 10 observed events per estimated parameter.",
                float(np.sum(response)) < 10 * parameter_count,
            ),
        )
        if condition
    ]
    result.update(
        {
            "status": "completed",
            "design_matrix_rank": design_rank,
            "information_matrix_rank": information_rank,
            "observed_information_type": "analytic expected/observed Poisson log-link information",
            "observed_information_matrix": information.tolist(),
            "parameter_covariance_matrix": covariance.tolist(),
            "covariance_type": "model-based inverse analytic information; not sandwich",
            "information_matrix_diagnostics": information_diagnostics,
            "convergence": optimization_diagnostics,
            "numerical_status": statistical_numerical_status(
                optimization=optimization_diagnostics,
                information=information_diagnostics,
                covariance_available=True,
                inference_available=True,
            ),
            "coefficients": coefficients,
            "assumption_warnings": warnings,
            "log_likelihood": log_likelihood,
            "null_log_likelihood": null_log_likelihood,
            "likelihood_ratio_statistic": likelihood_ratio,
            "likelihood_ratio_degrees_of_freedom": model_degrees_of_freedom,
            "likelihood_ratio_p_value": finite_or_none(likelihood_ratio_p),
            "decision": (
                decision_from_pvalue(likelihood_ratio_p, alpha)
                if likelihood_ratio_p is not None
                else "not applicable"
            ),
            "aic": 2.0 * parameter_count - 2.0 * log_likelihood,
            "bic": parameter_count * math.log(observation_count)
            - 2.0 * log_likelihood,
            "mcfadden_r_squared": 1.0 - log_likelihood / null_log_likelihood,
            "residual_degrees_of_freedom": residual_degrees_of_freedom,
            "deviance": deviance,
            "deviance_dispersion": deviance_dispersion,
            "pearson_chi_square": pearson_chi_square,
            "pearson_dispersion": dispersion,
            "goodness_of_fit": {
                "deviance_p_value": float(
                    scipy_stats.chi2.sf(deviance, residual_degrees_of_freedom)
                ),
                "pearson_p_value": float(
                    scipy_stats.chi2.sf(
                        pearson_chi_square, residual_degrees_of_freedom
                    )
                ),
                "note": "Chi-square approximations; small expected counts can reduce their accuracy.",
            },
            "prediction_metrics": {
                "mean_observed_count": finite_or_none(np.mean(response)),
                "mean_fitted_count": finite_or_none(np.mean(fitted)),
                "mean_absolute_error": finite_or_none(
                    np.mean(np.abs(response - fitted))
                ),
                "root_mean_squared_error": finite_or_none(
                    np.sqrt(np.mean((response - fitted) ** 2))
                ),
                "observed_zero_rate": finite_or_none(np.mean(response == 0)),
                "mean_predicted_zero_probability": finite_or_none(
                    np.mean(np.exp(-fitted))
                ),
            },
            "pearson_residual_summary": _residual_summary(pearson_residuals),
            "deviance_residual_summary": _residual_summary(deviance_residuals),
            "condition_number_standardized_design": _condition_number(design),
            "variance_inflation_factors": _variance_inflation_factors(
                design, prepared["terms"]
            ),
            "influence_diagnostics": _count_influence(
                prepared["complete_frame"],
                response,
                fitted,
                design,
                covariance,
                fitted,
                fitted,
            ),
            "prediction_rows": prediction_rows,
        }
    )
    return result
