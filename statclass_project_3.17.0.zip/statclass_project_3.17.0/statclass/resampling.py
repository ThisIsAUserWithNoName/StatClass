"""Bootstrap confidence intervals and permutation tests."""

from __future__ import annotations

import math
from itertools import combinations, permutations, product
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .utils import decision_from_pvalue, finite_or_none


BOOTSTRAP_STATISTICS = ("mean", "median", "standard-deviation")
BOOTSTRAP_INTERVAL_METHODS = ("percentile", "basic", "bca")
PERMUTATION_STATISTICS = ("mean", "median")
PERMUTATION_CORRELATIONS = ("pearson", "spearman")

_MAX_BATCH_ELEMENTS = 2_000_000


def _clean_sample(series: pd.Series) -> np.ndarray:
    values = pd.to_numeric(series, errors="coerce").to_numpy(dtype=float)
    return values[np.isfinite(values)]


def _clean_pairs(
    first: pd.Series, second: pd.Series
) -> tuple[np.ndarray, np.ndarray]:
    first_values = pd.to_numeric(first, errors="coerce").to_numpy(dtype=float)
    second_values = pd.to_numeric(second, errors="coerce").to_numpy(dtype=float)
    mask = np.isfinite(first_values) & np.isfinite(second_values)
    return first_values[mask], second_values[mask]


def _statistic(values: np.ndarray, statistic: str) -> float:
    if statistic == "mean":
        return float(np.mean(values))
    if statistic == "median":
        return float(np.median(values))
    return float(np.std(values, ddof=1))


def _statistic_axis(values: np.ndarray, statistic: str) -> np.ndarray:
    if statistic == "mean":
        return np.mean(values, axis=1)
    if statistic == "median":
        return np.median(values, axis=1)
    return np.std(values, axis=1, ddof=1)


def _batch_size(total_sample_size: int, maximum: int = 2000) -> int:
    return max(1, min(maximum, _MAX_BATCH_ELEMENTS // total_sample_size))


def _bounded_combination_count(
    total: int, selected: int, limit: int
) -> int | None:
    selected = min(selected, total - selected)
    count = 1
    for index in range(1, selected + 1):
        count = count * (total - selected + index) // index
        if count > limit:
            return None
    return count


def _bounded_power_of_two(exponent: int, limit: int) -> int | None:
    if exponent > int(math.log2(limit)):
        return None
    return 2**exponent


def _bounded_factorial(value: int, limit: int) -> int | None:
    count = 1
    for factor in range(2, value + 1):
        count *= factor
        if count > limit:
            return None
    return count


def _bootstrap_distribution_one_sample(
    values: np.ndarray,
    statistic: str,
    resamples: int,
    generator: np.random.Generator,
) -> np.ndarray:
    estimates = np.empty(resamples, dtype=float)
    batch_size = _batch_size(values.size)
    for start in range(0, resamples, batch_size):
        stop = min(resamples, start + batch_size)
        indices = generator.integers(
            0, values.size, size=(stop - start, values.size)
        )
        estimates[start:stop] = _statistic_axis(values[indices], statistic)
    return estimates


def _bootstrap_distribution_difference(
    first: np.ndarray,
    second: np.ndarray,
    statistic: str,
    resamples: int,
    generator: np.random.Generator,
) -> np.ndarray:
    estimates = np.empty(resamples, dtype=float)
    batch_size = _batch_size(first.size + second.size)
    for start in range(0, resamples, batch_size):
        stop = min(resamples, start + batch_size)
        first_indices = generator.integers(
            0, first.size, size=(stop - start, first.size)
        )
        second_indices = generator.integers(
            0, second.size, size=(stop - start, second.size)
        )
        estimates[start:stop] = (
            _statistic_axis(first[first_indices], statistic)
            - _statistic_axis(second[second_indices], statistic)
        )
    return estimates


def _jackknife_one_sample(values: np.ndarray, statistic: str) -> np.ndarray:
    size = values.size
    if statistic == "mean":
        return (float(np.sum(values)) - values) / (size - 1)
    if statistic == "standard-deviation":
        total = float(np.sum(values))
        squared_total = float(np.sum(values**2))
        deleted_total = total - values
        deleted_squared_total = squared_total - values**2
        variance = (
            deleted_squared_total
            - deleted_total**2 / (size - 1)
        ) / (size - 2)
        return np.sqrt(np.maximum(0.0, variance))

    ordered = np.sort(values)
    remaining_size = size - 1
    if remaining_size % 2 == 1:
        middle = remaining_size // 2
        return np.concatenate(
            [
                np.full(middle + 1, ordered[middle + 1]),
                np.full(size - middle - 1, ordered[middle]),
            ]
        )
    lower = remaining_size // 2 - 1
    upper = remaining_size // 2
    jackknife = np.empty(size, dtype=float)
    jackknife[: lower + 1] = (ordered[upper] + ordered[upper + 1]) / 2.0
    jackknife[lower + 1] = (ordered[lower] + ordered[upper + 1]) / 2.0
    jackknife[lower + 2 :] = (ordered[lower] + ordered[upper]) / 2.0
    return jackknife


def _jackknife_difference(
    first: np.ndarray, second: np.ndarray, statistic: str
) -> np.ndarray:
    first_full = _statistic(first, statistic)
    second_full = _statistic(second, statistic)
    first_deleted = _jackknife_one_sample(first, statistic) - second_full
    second_deleted = first_full - _jackknife_one_sample(second, statistic)
    return np.concatenate([first_deleted, second_deleted])


def _bootstrap_interval(
    estimates: np.ndarray,
    observed: float,
    alpha: float,
    requested_method: str,
    jackknife: np.ndarray,
) -> dict[str, Any]:
    lower_probability = alpha / 2.0
    upper_probability = 1.0 - alpha / 2.0
    method_used = requested_method
    bias_correction = None
    acceleration = None
    adjusted_probabilities = [lower_probability, upper_probability]

    if requested_method == "bca" and np.ptp(estimates) > 0.0:
        less = float(np.sum(estimates < observed))
        equal = float(np.sum(estimates == observed))
        proportion = (less + 0.5 * equal) / estimates.size
        proportion = float(
            np.clip(proportion, 1.0 / (2.0 * estimates.size), 1.0 - 1.0 / (2.0 * estimates.size))
        )
        bias_correction = float(scipy_stats.norm.ppf(proportion))
        centered = float(np.mean(jackknife)) - jackknife
        denominator = 6.0 * float(np.sum(centered**2)) ** 1.5
        acceleration = (
            float(np.sum(centered**3)) / denominator
            if denominator > np.finfo(float).eps
            else 0.0
        )
        normal_quantiles = scipy_stats.norm.ppf(
            [lower_probability, upper_probability]
        )
        adjusted = []
        valid = True
        for quantile in normal_quantiles:
            numerator = bias_correction + quantile
            correction_denominator = 1.0 - acceleration * numerator
            if abs(correction_denominator) <= np.finfo(float).eps:
                valid = False
                break
            probability = scipy_stats.norm.cdf(
                bias_correction + numerator / correction_denominator
            )
            adjusted.append(float(probability))
        if valid and 0.0 <= adjusted[0] < adjusted[1] <= 1.0:
            adjusted_probabilities = adjusted
        else:
            method_used = "percentile"
    elif requested_method == "bca":
        method_used = "percentile"

    percentile_interval = np.quantile(
        estimates, [lower_probability, upper_probability]
    )
    if method_used == "basic":
        interval = np.asarray(
            [
                2.0 * observed - percentile_interval[1],
                2.0 * observed - percentile_interval[0],
            ]
        )
    else:
        interval = np.quantile(estimates, adjusted_probabilities)
    return {
        "confidence_interval": [
            finite_or_none(interval[0]),
            finite_or_none(interval[1]),
        ],
        "interval_method_requested": requested_method,
        "interval_method_used": method_used,
        "bca_bias_correction": finite_or_none(bias_correction),
        "bca_acceleration": finite_or_none(acceleration),
        "quantile_probabilities_used": adjusted_probabilities,
    }


def bootstrap_one_sample(
    series: pd.Series,
    column_name: str,
    statistic: str,
    resamples: int,
    alpha: float,
    interval_method: str,
    random_seed: int,
) -> dict[str, Any]:
    """Bootstrap a one-sample statistic with percentile, basic, or BCa limits."""
    values = _clean_sample(series)
    result: dict[str, Any] = {
        "method": "nonparametric bootstrap confidence interval",
        "column": column_name,
        "statistic": statistic,
        "n": int(values.size),
        "missing_or_nonfinite": int(len(series) - values.size),
        "bootstrap_resamples": resamples,
        "random_seed": random_seed,
        "confidence_level": 1.0 - alpha,
    }
    minimum = 3 if statistic == "standard-deviation" else 2
    if values.size < minimum:
        result.update(
            status="not_run",
            reason=f"requires at least {minimum} finite observations",
        )
        return result
    observed = _statistic(values, statistic)
    generator = np.random.default_rng(random_seed)
    estimates = _bootstrap_distribution_one_sample(
        values, statistic, resamples, generator
    )
    jackknife = _jackknife_one_sample(values, statistic)
    interval = _bootstrap_interval(
        estimates, observed, alpha, interval_method, jackknife
    )
    result.update(
        {
            "status": "completed",
            "observed_statistic": finite_or_none(observed),
            "bootstrap_mean": finite_or_none(np.mean(estimates)),
            "bootstrap_standard_error": finite_or_none(
                np.std(estimates, ddof=1)
            ),
            "bootstrap_bias": finite_or_none(np.mean(estimates) - observed),
            **interval,
        }
    )
    return result


def bootstrap_independent_difference(
    first_series: pd.Series,
    second_series: pd.Series,
    first_name: str,
    second_name: str,
    statistic: str,
    resamples: int,
    alpha: float,
    interval_method: str,
    random_seed: int,
) -> dict[str, Any]:
    """Bootstrap the difference between two independent sample statistics."""
    first = _clean_sample(first_series)
    second = _clean_sample(second_series)
    result: dict[str, Any] = {
        "method": "independent-samples nonparametric bootstrap confidence interval",
        "column_1": first_name,
        "column_2": second_name,
        "difference_definition": f"{statistic}({first_name}) - {statistic}({second_name})",
        "statistic": statistic,
        "n_1": int(first.size),
        "n_2": int(second.size),
        "bootstrap_resamples": resamples,
        "random_seed": random_seed,
        "confidence_level": 1.0 - alpha,
    }
    minimum = 3 if statistic == "standard-deviation" else 2
    if first.size < minimum or second.size < minimum:
        result.update(
            status="not_run",
            reason=f"each sample requires at least {minimum} finite observations",
        )
        return result
    observed = _statistic(first, statistic) - _statistic(second, statistic)
    generator = np.random.default_rng(random_seed)
    estimates = _bootstrap_distribution_difference(
        first, second, statistic, resamples, generator
    )
    jackknife = _jackknife_difference(first, second, statistic)
    interval = _bootstrap_interval(
        estimates, observed, alpha, interval_method, jackknife
    )
    result.update(
        {
            "status": "completed",
            "observed_difference": finite_or_none(observed),
            "bootstrap_mean": finite_or_none(np.mean(estimates)),
            "bootstrap_standard_error": finite_or_none(
                np.std(estimates, ddof=1)
            ),
            "bootstrap_bias": finite_or_none(np.mean(estimates) - observed),
            **interval,
        }
    )
    return result


def _extreme_count(
    distribution: np.ndarray, observed: float, alternative: str
) -> int:
    tolerance = 1e-12 * max(1.0, abs(observed))
    if alternative == "greater":
        return int(np.sum(distribution >= observed - tolerance))
    if alternative == "less":
        return int(np.sum(distribution <= observed + tolerance))
    return int(np.sum(np.abs(distribution) >= abs(observed) - tolerance))


def _permutation_result(
    distribution: np.ndarray,
    observed: float,
    alternative: str,
    exact: bool,
    possible_permutations: int | None,
    alpha: float,
) -> dict[str, Any]:
    extreme = _extreme_count(distribution, observed, alternative)
    if exact:
        p_value = extreme / distribution.size
        monte_carlo_standard_error = None
    else:
        p_value = (extreme + 1.0) / (distribution.size + 1.0)
        monte_carlo_standard_error = math.sqrt(
            p_value * (1.0 - p_value) / (distribution.size + 1.0)
        )
    return {
        "observed_statistic": finite_or_none(observed),
        "alternative": alternative,
        "enumeration": "exact" if exact else "monte_carlo",
        "possible_permutations": possible_permutations,
        "possible_permutations_exceed_requested": possible_permutations is None,
        "permutations_performed": int(distribution.size),
        "extreme_permutations": extreme,
        "p_value": finite_or_none(p_value),
        "monte_carlo_standard_error": finite_or_none(
            monte_carlo_standard_error
        ),
        "decision": decision_from_pvalue(p_value, alpha),
        "monte_carlo_note": (
            None
            if exact
            else "The p-value uses the plus-one correction (extreme + 1)/(permutations + 1)."
        ),
    }


def _two_sample_permutation_distribution(
    pooled: np.ndarray,
    first_size: int,
    statistic: str,
    resamples: int,
    generator: np.random.Generator,
    exact: bool,
) -> np.ndarray:
    total_size = pooled.size
    if exact:
        values = np.empty(math.comb(total_size, first_size), dtype=float)
        all_indices = np.arange(total_size)
        for position, selected_tuple in enumerate(
            combinations(range(total_size), first_size)
        ):
            selected = np.asarray(selected_tuple, dtype=int)
            mask = np.ones(total_size, dtype=bool)
            mask[selected] = False
            values[position] = _statistic(pooled[selected], statistic) - _statistic(
                pooled[all_indices[mask]], statistic
            )
        return values
    values = np.empty(resamples, dtype=float)
    batch_size = _batch_size(total_size, maximum=1000)
    for start in range(0, resamples, batch_size):
        stop = min(resamples, start + batch_size)
        order = np.argsort(
            generator.random((stop - start, total_size)), axis=1
        )
        first_values = pooled[order[:, :first_size]]
        second_values = pooled[order[:, first_size:]]
        values[start:stop] = _statistic_axis(
            first_values, statistic
        ) - _statistic_axis(second_values, statistic)
    return values


def permutation_two_sample(
    first_series: pd.Series,
    second_series: pd.Series,
    first_name: str,
    second_name: str,
    statistic: str,
    resamples: int,
    alternative: str,
    alpha: float,
    random_seed: int,
) -> dict[str, Any]:
    """Permutation test for an independent-samples location difference."""
    first = _clean_sample(first_series)
    second = _clean_sample(second_series)
    possible = _bounded_combination_count(
        first.size + second.size, first.size, resamples
    )
    result: dict[str, Any] = {
        "method": "independent-samples permutation test",
        "column_1": first_name,
        "column_2": second_name,
        "statistic": f"difference in {statistic}s",
        "difference_definition": f"{statistic}({first_name}) - {statistic}({second_name})",
        "n_1": int(first.size),
        "n_2": int(second.size),
        "requested_permutations": resamples,
        "random_seed": random_seed,
        "null_hypothesis": "the two group labels are exchangeable",
    }
    if first.size < 2 or second.size < 2:
        result.update(
            status="not_run", reason="each sample requires at least 2 finite observations"
        )
        return result
    observed = _statistic(first, statistic) - _statistic(second, statistic)
    exact = possible is not None
    generator = np.random.default_rng(random_seed)
    distribution = _two_sample_permutation_distribution(
        np.concatenate([first, second]),
        first.size,
        statistic,
        resamples,
        generator,
        exact,
    )
    result.update(
        status="completed",
        **_permutation_result(
            distribution, observed, alternative, exact, possible, alpha
        ),
    )
    return result


def _paired_permutation_distribution(
    differences: np.ndarray,
    statistic: str,
    resamples: int,
    generator: np.random.Generator,
    exact: bool,
) -> np.ndarray:
    if exact:
        return np.asarray(
            [
                _statistic(differences * np.asarray(signs), statistic)
                for signs in product((-1.0, 1.0), repeat=differences.size)
            ],
            dtype=float,
        )
    values = np.empty(resamples, dtype=float)
    batch_size = _batch_size(differences.size)
    for start in range(0, resamples, batch_size):
        stop = min(resamples, start + batch_size)
        signs = generator.choice(
            (-1.0, 1.0), size=(stop - start, differences.size)
        )
        values[start:stop] = _statistic_axis(
            signs * differences, statistic
        )
    return values


def permutation_paired(
    first_series: pd.Series,
    second_series: pd.Series,
    first_name: str,
    second_name: str,
    statistic: str,
    resamples: int,
    alternative: str,
    alpha: float,
    random_seed: int,
) -> dict[str, Any]:
    """Paired sign-flip permutation test for a location difference."""
    first, second = _clean_pairs(first_series, second_series)
    differences = first - second
    possible = _bounded_power_of_two(differences.size, resamples)
    result: dict[str, Any] = {
        "method": "paired sign-flip permutation test",
        "column_1": first_name,
        "column_2": second_name,
        "difference_definition": f"{first_name} - {second_name}",
        "statistic": f"{statistic} paired difference",
        "n_pairs": int(differences.size),
        "requested_permutations": resamples,
        "random_seed": random_seed,
        "null_hypothesis": "the paired differences are sign-exchangeable around zero",
    }
    if differences.size < 2:
        result.update(status="not_run", reason="requires at least 2 complete pairs")
        return result
    observed = _statistic(differences, statistic)
    exact = possible is not None
    generator = np.random.default_rng(random_seed)
    distribution = _paired_permutation_distribution(
        differences, statistic, resamples, generator, exact
    )
    result.update(
        status="completed",
        **_permutation_result(
            distribution, observed, alternative, exact, possible, alpha
        ),
    )
    return result


def _correlation_components(
    first: np.ndarray, second: np.ndarray, method: str
) -> tuple[np.ndarray, np.ndarray]:
    if method == "spearman":
        first = scipy_stats.rankdata(first)
        second = scipy_stats.rankdata(second)
    first_centered = first - np.mean(first)
    second_centered = second - np.mean(second)
    first_norm = float(np.sqrt(np.sum(first_centered**2)))
    second_norm = float(np.sqrt(np.sum(second_centered**2)))
    if first_norm <= np.finfo(float).eps or second_norm <= np.finfo(float).eps:
        raise ValueError("correlation requires both variables to vary")
    return first_centered / first_norm, second_centered / second_norm


def _correlation_permutation_distribution(
    first_standardized: np.ndarray,
    second_standardized: np.ndarray,
    resamples: int,
    generator: np.random.Generator,
    exact: bool,
) -> np.ndarray:
    size = first_standardized.size
    if exact:
        return np.asarray(
            [
                float(first_standardized @ second_standardized[list(order)])
                for order in permutations(range(size))
            ],
            dtype=float,
        )
    values = np.empty(resamples, dtype=float)
    batch_size = _batch_size(size, maximum=1000)
    for start in range(0, resamples, batch_size):
        stop = min(resamples, start + batch_size)
        order = np.argsort(generator.random((stop - start, size)), axis=1)
        values[start:stop] = np.sum(
            first_standardized[None, :] * second_standardized[order], axis=1
        )
    return values


def permutation_correlation(
    first_series: pd.Series,
    second_series: pd.Series,
    first_name: str,
    second_name: str,
    correlation_method: str,
    resamples: int,
    alternative: str,
    alpha: float,
    random_seed: int,
) -> dict[str, Any]:
    """Permutation test for Pearson or Spearman association."""
    first, second = _clean_pairs(first_series, second_series)
    possible = _bounded_factorial(first.size, resamples)
    result: dict[str, Any] = {
        "method": f"{correlation_method.capitalize()} correlation permutation test",
        "column_1": first_name,
        "column_2": second_name,
        "correlation_method": correlation_method,
        "n_pairs": int(first.size),
        "requested_permutations": resamples,
        "random_seed": random_seed,
        "null_hypothesis": "the paired values are exchangeable under no association",
    }
    if first.size < 3:
        result.update(status="not_run", reason="requires at least 3 complete pairs")
        return result
    try:
        first_standardized, second_standardized = _correlation_components(
            first, second, correlation_method
        )
    except ValueError as exc:
        result.update(status="not_run", reason=str(exc))
        return result
    observed = float(first_standardized @ second_standardized)
    exact = possible is not None
    generator = np.random.default_rng(random_seed)
    distribution = _correlation_permutation_distribution(
        first_standardized,
        second_standardized,
        resamples,
        generator,
        exact,
    )
    result.update(
        status="completed",
        **_permutation_result(
            distribution, observed, alternative, exact, possible, alpha
        ),
    )
    return result
