"""Repeated-measures ANOVA and random-intercept linear mixed models."""

from __future__ import annotations

import math
from itertools import combinations
from typing import Any

import numpy as np
import pandas as pd
from scipy import optimize as scipy_optimize
from scipy import stats as scipy_stats

from .descriptives import normality_tests
from .logistic import _prepare_design
from .multiple_regression import _residual_summary
from .nonparametric import adjust_p_values
from .numerical import (
    NumericalComputationError,
    covariance_from_information,
    delta_method_covariance,
    numerical_hessian,
    optimizer_convergence_diagnostics,
    statistical_numerical_status,
)
from .utils import decision_from_pvalue, finite_or_none


def repeated_measures_anova(
    frame: pd.DataFrame,
    subject_name: str,
    outcome_name: str,
    within_factor: str,
    alpha: float,
    adjustment: str = "holm",
    model_name: str | None = None,
) -> dict[str, Any]:
    """Fit a complete-case one-factor repeated-measures ANOVA in long format."""
    working = frame[[subject_name, outcome_name, within_factor]].copy()
    working[outcome_name] = pd.to_numeric(
        working[outcome_name], errors="coerce"
    )
    working = working.dropna()
    levels = list(pd.unique(working[within_factor]))
    subjects_seen = int(working[subject_name].nunique())
    result: dict[str, Any] = {
        "method": "one-factor repeated-measures ANOVA",
        "model_name": model_name,
        "subject_variable": subject_name,
        "outcome_variable": outcome_name,
        "within_subject_factor": within_factor,
        "factor_levels": [str(level) for level in levels],
        "total_rows": int(len(frame)),
        "nonmissing_rows": int(len(working)),
        "subjects_seen": subjects_seen,
    }
    if len(levels) < 2:
        result.update(
            status="not_run",
            reason="the within-subject factor requires at least 2 levels",
        )
        return result
    duplicate_count = int(
        working.duplicated([subject_name, within_factor], keep=False).sum()
    )
    if duplicate_count:
        result.update(
            status="not_run",
            reason="each subject must have at most one observation per within-factor level",
            duplicate_subject_level_rows=duplicate_count,
        )
        return result
    matrix_frame = working.pivot(
        index=subject_name, columns=within_factor, values=outcome_name
    ).reindex(columns=levels)
    complete_matrix = matrix_frame.dropna()
    matrix = complete_matrix.to_numpy(dtype=float)
    subject_count, level_count = matrix.shape
    result.update(
        {
            "complete_subjects": int(subject_count),
            "excluded_incomplete_subjects": int(subjects_seen - subject_count),
        }
    )
    if subject_count < 2:
        result.update(
            status="not_run",
            reason="requires at least 2 subjects observed at every factor level",
        )
        return result
    if np.ptp(matrix) == 0:
        result.update(status="not_run", reason="the outcome is constant")
        return result

    grand_mean = float(np.mean(matrix))
    subject_means = np.mean(matrix, axis=1)
    condition_means = np.mean(matrix, axis=0)
    total_ss = float(np.sum((matrix - grand_mean) ** 2))
    subject_ss = float(
        level_count * np.sum((subject_means - grand_mean) ** 2)
    )
    condition_ss = float(
        subject_count * np.sum((condition_means - grand_mean) ** 2)
    )
    error_ss = max(0.0, total_ss - subject_ss - condition_ss)
    condition_df = level_count - 1
    subject_df = subject_count - 1
    error_df = condition_df * subject_df
    error_mean_square = error_ss / error_df
    if error_mean_square <= np.finfo(float).eps:
        result.update(status="not_run", reason="the within-subject error variance is zero")
        return result
    condition_mean_square = condition_ss / condition_df
    statistic = condition_mean_square / error_mean_square
    p_value = float(scipy_stats.f.sf(statistic, condition_df, error_df))

    covariance = np.cov(matrix, rowvar=False, ddof=1)
    centering = np.eye(level_count) - np.ones((level_count, level_count)) / level_count
    centered_covariance = centering @ covariance @ centering
    epsilon_numerator = float(np.trace(centered_covariance) ** 2)
    epsilon_denominator = float(
        condition_df * np.trace(centered_covariance @ centered_covariance)
    )
    greenhouse_geisser = (
        min(1.0, max(1.0 / condition_df, epsilon_numerator / epsilon_denominator))
        if epsilon_denominator > 0
        else 1.0
    )
    corrected_df_1 = greenhouse_geisser * condition_df
    corrected_df_2 = greenhouse_geisser * error_df
    corrected_p = float(
        scipy_stats.f.sf(statistic, corrected_df_1, corrected_df_2)
    )

    pairwise = []
    raw_p_values = []
    for first_index, second_index in combinations(range(level_count), 2):
        differences = matrix[:, first_index] - matrix[:, second_index]
        mean_difference = float(np.mean(differences))
        difference_standard_deviation = float(
            np.std(differences, ddof=1)
        )
        standard_error = difference_standard_deviation / math.sqrt(
            subject_count
        )
        if standard_error <= np.finfo(float).eps:
            t_statistic = 0.0 if mean_difference == 0.0 else math.copysign(
                math.inf, mean_difference
            )
            raw_p = 1.0 if mean_difference == 0.0 else 0.0
        else:
            t_statistic = mean_difference / standard_error
            raw_p = float(
                2.0 * scipy_stats.t.sf(abs(t_statistic), subject_count - 1)
            )
        raw_p_values.append(raw_p)
        pairwise.append(
            {
                "level_1": str(levels[first_index]),
                "level_2": str(levels[second_index]),
                "mean_difference": mean_difference,
                "standard_error": standard_error,
                "t_statistic": t_statistic,
                "degrees_of_freedom": subject_count - 1,
                "p_value": raw_p,
                "cohens_dz": (
                    mean_difference / difference_standard_deviation
                    if difference_standard_deviation > 0
                    else None
                ),
            }
        )
    adjusted_p_values = adjust_p_values(raw_p_values, adjustment)
    for comparison, adjusted_p in zip(pairwise, adjusted_p_values):
        comparison["adjusted_p_value"] = adjusted_p
        comparison["adjustment"] = adjustment
        comparison["decision"] = decision_from_pvalue(adjusted_p, alpha)

    critical = float(scipy_stats.t.ppf(1.0 - alpha / 2.0, error_df))
    mean_standard_error = math.sqrt(error_mean_square / subject_count)
    marginal_means = [
        {
            "level": str(level),
            "estimate": finite_or_none(condition_means[index]),
            "standard_error": mean_standard_error,
            "confidence_interval": [
                condition_means[index] - critical * mean_standard_error,
                condition_means[index] + critical * mean_standard_error,
            ],
        }
        for index, level in enumerate(levels)
    ]
    fitted = (
        subject_means[:, None] + condition_means[None, :] - grand_mean
    )
    residuals = matrix - fitted
    prediction_rows = []
    for subject_index, subject in enumerate(complete_matrix.index):
        for level_index, level in enumerate(levels):
            prediction_rows.append(
                {
                    "model_family": "repeated_measures_anova",
                    "model_name": model_name or "Repeated-measures model",
                    "source_index": f"{subject}:{level}",
                    "subject": str(subject),
                    "within_level": str(level),
                    "outcome_variable": outcome_name,
                    "observed": finite_or_none(matrix[subject_index, level_index]),
                    "predicted": finite_or_none(fitted[subject_index, level_index]),
                    "residual": finite_or_none(residuals[subject_index, level_index]),
                    "mean_ci_lower": finite_or_none(
                        condition_means[level_index] - critical * mean_standard_error
                    ),
                    "mean_ci_upper": finite_or_none(
                        condition_means[level_index] + critical * mean_standard_error
                    ),
                }
            )

    result.update(
        {
            "status": "completed",
            "anova_table": [
                {
                    "source": within_factor,
                    "sum_of_squares": condition_ss,
                    "degrees_of_freedom": condition_df,
                    "mean_square": condition_mean_square,
                    "f_statistic": statistic,
                    "p_value": p_value,
                },
                {
                    "source": "Subjects",
                    "sum_of_squares": subject_ss,
                    "degrees_of_freedom": subject_df,
                },
                {
                    "source": "Error",
                    "sum_of_squares": error_ss,
                    "degrees_of_freedom": error_df,
                    "mean_square": error_mean_square,
                },
                {
                    "source": "Total",
                    "sum_of_squares": total_ss,
                    "degrees_of_freedom": subject_count * level_count - 1,
                },
            ],
            "f_statistic": statistic,
            "degrees_of_freedom": [condition_df, error_df],
            "p_value": p_value,
            "decision": decision_from_pvalue(p_value, alpha),
            "partial_eta_squared": condition_ss / (condition_ss + error_ss),
            "sphericity_correction": {
                "greenhouse_geisser_epsilon": greenhouse_geisser,
                "corrected_degrees_of_freedom": [corrected_df_1, corrected_df_2],
                "corrected_p_value": corrected_p,
                "corrected_decision": decision_from_pvalue(corrected_p, alpha),
            },
            "estimated_marginal_means": marginal_means,
            "pairwise_comparisons": pairwise,
            "pairwise_adjustment": adjustment,
            "residual_summary": _residual_summary(residuals.ravel()),
            "residual_normality_tests": normality_tests(
                pd.Series(residuals.ravel()), alpha
            ),
            "prediction_rows": prediction_rows,
        }
    )
    return result


def _apply_inverse_covariance(
    values: np.ndarray,
    group_indices: list[np.ndarray],
    residual_variance: float,
    random_intercept_variance: float,
) -> np.ndarray:
    output = np.empty_like(values, dtype=float)
    for indices in group_indices:
        block = values[indices]
        group_size = len(indices)
        correction = random_intercept_variance / (
            residual_variance
            * (residual_variance + group_size * random_intercept_variance)
        )
        output[indices] = block / residual_variance - correction * np.sum(
            block, axis=0
        )
    return output


def _mixed_profile_fit(
    response: np.ndarray,
    design: np.ndarray,
    group_indices: list[np.ndarray],
    reml: bool,
) -> dict[str, Any]:
    observation_count, parameter_count = design.shape
    sample_variance = max(float(np.var(response, ddof=1)), 1e-6)

    def objective(log_variances: np.ndarray) -> float:
        residual_variance = math.exp(float(log_variances[0]))
        random_variance = math.exp(float(log_variances[1]))
        inverse_design = _apply_inverse_covariance(
            design, group_indices, residual_variance, random_variance
        )
        cross_product = design.T @ inverse_design
        if np.linalg.matrix_rank(cross_product) < parameter_count:
            return math.inf
        inverse_response = _apply_inverse_covariance(
            response[:, None],
            group_indices,
            residual_variance,
            random_variance,
        )[:, 0]
        estimates = np.linalg.solve(cross_product, design.T @ inverse_response)
        residuals = response - design @ estimates
        inverse_residuals = _apply_inverse_covariance(
            residuals[:, None],
            group_indices,
            residual_variance,
            random_variance,
        )[:, 0]
        quadratic = float(residuals @ inverse_residuals)
        log_determinant = sum(
            (len(indices) - 1) * math.log(residual_variance)
            + math.log(
                residual_variance + len(indices) * random_variance
            )
            for indices in group_indices
        )
        if reml:
            sign, log_cross_determinant = np.linalg.slogdet(cross_product)
            if sign <= 0:
                return math.inf
            return 0.5 * (
                (observation_count - parameter_count) * math.log(2.0 * math.pi)
                + log_determinant
                + log_cross_determinant
                + quadratic
            )
        return 0.5 * (
            observation_count * math.log(2.0 * math.pi)
            + log_determinant
            + quadratic
        )

    initial = np.log([sample_variance * 0.7, sample_variance * 0.3])
    optimization = scipy_optimize.minimize(
        objective,
        initial,
        method="L-BFGS-B",
        bounds=[(-20.0, 20.0), (-20.0, 20.0)],
        options={"maxiter": 3000, "ftol": 1e-14, "gtol": 1e-8},
    )
    log_variances = np.asarray(optimization.x, dtype=float)
    residual_variance = math.exp(log_variances[0])
    random_variance = math.exp(log_variances[1])
    inverse_design = _apply_inverse_covariance(
        design, group_indices, residual_variance, random_variance
    )
    cross_product = design.T @ inverse_design
    fixed_covariance, fixed_information_diagnostics = covariance_from_information(
        cross_product
    )
    inverse_response = _apply_inverse_covariance(
        response[:, None],
        group_indices,
        residual_variance,
        random_variance,
    )[:, 0]
    estimates = fixed_covariance @ design.T @ inverse_response
    variance_information = None
    variance_optimizer_covariance = None
    variance_transformed_covariance = None
    variance_information_diagnostics = None
    variance_hessian_diagnostics = None
    variance_inference_warning = None
    try:
        variance_information, variance_hessian_diagnostics = numerical_hessian(
            objective, log_variances
        )
        variance_optimizer_covariance, variance_information_diagnostics = (
            covariance_from_information(variance_information)
        )
        residual_sd = math.sqrt(residual_variance)
        random_sd = math.sqrt(random_variance)
        intraclass_correlation = random_variance / (
            random_variance + residual_variance
        )
        icc_derivative = intraclass_correlation * (1.0 - intraclass_correlation)
        variance_jacobian = np.asarray(
            [
                [residual_variance, 0.0],
                [0.0, random_variance],
                [0.5 * residual_sd, 0.0],
                [0.0, 0.5 * random_sd],
                [-icc_derivative, icc_derivative],
            ]
        )
        variance_transformed_covariance = delta_method_covariance(
            variance_optimizer_covariance, variance_jacobian
        )
        if not variance_hessian_diagnostics["step_stable"]:
            variance_inference_warning = (
                "The variance-component Hessian was sensitive to the finite-difference step."
            )
    except NumericalComputationError as exc:
        variance_information_diagnostics = exc.diagnostics or None
        variance_inference_warning = (
            f"Variance-component Hessian inference is unavailable: {exc}."
        )
    return {
        "optimization": optimization,
        "objective": float(objective(log_variances)),
        "residual_variance": residual_variance,
        "random_intercept_variance": random_variance,
        "estimates": estimates,
        "fixed_covariance": fixed_covariance,
        "fixed_information": cross_product,
        "fixed_information_diagnostics": fixed_information_diagnostics,
        "variance_log_parameters": log_variances,
        "variance_information": variance_information,
        "variance_optimizer_covariance": variance_optimizer_covariance,
        "variance_transformed_covariance": variance_transformed_covariance,
        "variance_information_diagnostics": variance_information_diagnostics,
        "variance_hessian_diagnostics": variance_hessian_diagnostics,
        "variance_inference_warning": variance_inference_warning,
    }


def random_intercept_mixed_model(
    frame: pd.DataFrame,
    outcome_name: str,
    group_name: str,
    predictor_names: list[str],
    categorical_predictors: set[str],
    alpha: float,
    estimation_method: str = "reml",
    model_name: str | None = None,
    polynomial_terms: dict[str, int] | None = None,
    interactions: list[tuple[str, str]] | None = None,
) -> dict[str, Any]:
    """Fit a Gaussian linear mixed model with a random group intercept."""
    working = frame.copy()
    working[outcome_name] = pd.to_numeric(
        working[outcome_name], errors="coerce"
    )
    working.loc[working[group_name].isna(), outcome_name] = np.nan
    prepared = _prepare_design(
        working,
        outcome_name,
        predictor_names,
        categorical_predictors,
        polynomial_terms,
        interactions,
    )
    response = np.asarray(prepared["outcome"], dtype=float)
    design = prepared["design"]
    complete = prepared["complete_frame"]
    groups = complete[group_name].to_numpy()
    unique_groups = list(pd.unique(groups))
    group_indices = [
        np.flatnonzero(groups == group) for group in unique_groups
    ]
    observation_count, parameter_count = design.shape
    result: dict[str, Any] = {
        "method": "Gaussian random-intercept linear mixed-effects model",
        "model_name": model_name,
        "outcome_variable": outcome_name,
        "group_variable": group_name,
        "predictors": predictor_names,
        "categorical_predictors": [
            name for name in predictor_names if name in categorical_predictors
        ],
        "categorical_codings": prepared["categorical_codings"],
        "polynomial_terms": prepared["polynomial_terms"],
        "interactions": prepared["interactions"],
        "estimation_method": estimation_method.upper(),
        "total_rows": int(len(frame)),
        "n_complete_cases": observation_count,
        "excluded_rows": int(len(frame) - observation_count),
        "group_count": len(unique_groups),
        "group_sizes": {
            str(group): int(len(indices))
            for group, indices in zip(unique_groups, group_indices)
        },
        "terms": prepared["terms"],
        "parameter_count_fixed": parameter_count,
    }
    if prepared["invalid_reason"]:
        result.update(status="not_run", reason=prepared["invalid_reason"])
        return result
    if observation_count <= parameter_count + 2:
        result.update(
            status="not_run",
            reason="requires more observations than fixed effects and variance parameters",
        )
        return result
    if len(unique_groups) < 2:
        result.update(status="not_run", reason="requires at least 2 groups")
        return result
    if np.linalg.matrix_rank(design) < parameter_count:
        result.update(status="not_run", reason="the fixed-effects design is rank deficient")
        return result
    if np.ptp(response) == 0:
        result.update(status="not_run", reason="the outcome is constant")
        return result

    try:
        fitted_model = _mixed_profile_fit(
            response,
            design,
            group_indices,
            reml=estimation_method == "reml",
        )
    except NumericalComputationError as exc:
        failure_reason = f"mixed-model covariance calculation failed: {exc}"
        result.update(
            status="not_run",
            reason=failure_reason,
            information_matrix_diagnostics=exc.diagnostics,
            numerical_status=statistical_numerical_status(
                information=exc.diagnostics,
                covariance_available=False,
                inference_available=False,
                failure_reason=failure_reason,
            ),
        )
        return result
    optimization = fitted_model["optimization"]
    optimization_diagnostics = optimizer_convergence_diagnostics(
        optimization,
        parameters=optimization.x,
        objective_value=fitted_model["objective"],
        method="L-BFGS-B",
    )
    if not optimization_diagnostics["converged"]:
        failure_reason = f"mixed-model optimization failed: {optimization.message}"
        result.update(
            status="not_run",
            reason=failure_reason,
            convergence=optimization_diagnostics,
            numerical_status=statistical_numerical_status(
                optimization=optimization_diagnostics,
                covariance_available=False,
                inference_available=False,
                failure_reason=failure_reason,
            ),
        )
        return result
    estimates = fitted_model["estimates"]
    fixed_covariance = fitted_model["fixed_covariance"]
    standard_errors = np.sqrt(np.maximum(0.0, np.diag(fixed_covariance)))
    z_statistics = estimates / standard_errors
    p_values = 2.0 * scipy_stats.norm.sf(np.abs(z_statistics))
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    coefficients = [
        {
            "term": term,
            "predictor": prepared["term_predictors"][index],
            "term_type": prepared["term_types"][index],
            "estimate": finite_or_none(estimates[index]),
            "standard_error": finite_or_none(standard_errors[index]),
            "z_statistic": finite_or_none(z_statistics[index]),
            "p_value": finite_or_none(p_values[index]),
            "confidence_interval": [
                finite_or_none(estimates[index] - critical * standard_errors[index]),
                finite_or_none(estimates[index] + critical * standard_errors[index]),
            ],
        }
        for index, term in enumerate(prepared["terms"])
    ]
    residual_variance = fitted_model["residual_variance"]
    random_variance = fitted_model["random_intercept_variance"]
    variance_transformed_covariance = fitted_model[
        "variance_transformed_covariance"
    ]
    variance_optimizer_covariance = fitted_model[
        "variance_optimizer_covariance"
    ]
    variance_boundary = random_variance < 1e-6 * (
        random_variance + residual_variance
    )
    variance_component_inference: dict[str, Any]
    if (
        variance_transformed_covariance is not None
        and variance_optimizer_covariance is not None
        and not variance_boundary
    ):
        transformed_standard_errors = np.sqrt(
            np.maximum(0.0, np.diag(variance_transformed_covariance))
        )
        log_standard_errors = np.sqrt(
            np.maximum(0.0, np.diag(variance_optimizer_covariance))
        )
        variance_component_inference = {
            "status": "completed",
            "parameter_names": [
                "residual_variance",
                "random_intercept_variance",
                "residual_standard_deviation",
                "random_intercept_standard_deviation",
                "intraclass_correlation",
            ],
            "standard_errors": transformed_standard_errors.tolist(),
            "residual_variance_confidence_interval": [
                math.exp(
                    math.log(residual_variance) - critical * log_standard_errors[0]
                ),
                math.exp(
                    math.log(residual_variance) + critical * log_standard_errors[0]
                ),
            ],
            "random_intercept_variance_confidence_interval": [
                math.exp(
                    math.log(random_variance) - critical * log_standard_errors[1]
                ),
                math.exp(
                    math.log(random_variance) + critical * log_standard_errors[1]
                ),
            ],
            "intraclass_correlation_confidence_interval": [
                max(
                    0.0,
                    random_variance / (random_variance + residual_variance)
                    - critical * transformed_standard_errors[4],
                ),
                min(
                    1.0,
                    random_variance / (random_variance + residual_variance)
                    + critical * transformed_standard_errors[4],
                ),
            ],
        }
    elif variance_boundary:
        variance_component_inference = {
            "status": "boundary",
            "reason": (
                "The random-intercept variance is effectively on its zero "
                "boundary, so ordinary two-sided Wald intervals are not reported; "
                "use the boundary likelihood-ratio result."
            ),
        }
    else:
        variance_component_inference = {
            "status": "not_available",
            "reason": fitted_model["variance_inference_warning"],
        }
    fixed_fitted = design @ estimates
    raw_residuals = response - fixed_fitted
    random_effects: dict[str, float] = {}
    conditional_fitted = fixed_fitted.copy()
    for group, indices in zip(unique_groups, group_indices):
        shrinkage = random_variance / (
            residual_variance + len(indices) * random_variance
        )
        random_intercept = shrinkage * float(np.sum(raw_residuals[indices]))
        random_effects[str(group)] = random_intercept
        conditional_fitted[indices] += random_intercept
    conditional_residuals = response - conditional_fitted

    try:
        ml_fit = _mixed_profile_fit(response, design, group_indices, reml=False)
        ml_log_likelihood: float | None = -ml_fit["objective"]
        ml_fit_warning = None
    except NumericalComputationError as exc:
        ml_fit = None
        ml_log_likelihood = None
        ml_fit_warning = (
            "The auxiliary ML fit required for AIC, BIC, and the random-intercept "
            f"likelihood-ratio comparison was unavailable: {exc}."
        )
    ols_estimates = np.linalg.lstsq(design, response, rcond=None)[0]
    ols_residuals = response - design @ ols_estimates
    ols_variance = float(np.sum(ols_residuals**2) / observation_count)
    ols_log_likelihood = -0.5 * observation_count * (
        math.log(2.0 * math.pi * ols_variance) + 1.0
    )
    if ml_log_likelihood is None:
        comparison_statistic = None
        comparison_p = None
    else:
        comparison_statistic = max(
            0.0, 2.0 * (ml_log_likelihood - ols_log_likelihood)
        )
        comparison_p = (
            1.0
            if comparison_statistic <= 1e-12
            else 0.5 * float(scipy_stats.chi2.sf(comparison_statistic, 1))
        )
    fixed_variance = float(np.var(fixed_fitted, ddof=1))
    total_variance = fixed_variance + random_variance + residual_variance
    prediction_variance = np.sum((design @ fixed_covariance) * design, axis=1)
    prediction_rows = [
        {
            "model_family": "mixed_effects",
            "model_name": model_name or "Mixed-effects model",
            "source_index": str(source_index),
            "group": str(groups[position]),
            "outcome_variable": outcome_name,
            "observed": finite_or_none(response[position]),
            "predicted_fixed": finite_or_none(fixed_fitted[position]),
            "predicted": finite_or_none(conditional_fitted[position]),
            "residual": finite_or_none(conditional_residuals[position]),
            "mean_ci_lower": finite_or_none(
                fixed_fitted[position]
                - critical * math.sqrt(max(0.0, prediction_variance[position]))
            ),
            "mean_ci_upper": finite_or_none(
                fixed_fitted[position]
                + critical * math.sqrt(max(0.0, prediction_variance[position]))
            ),
        }
        for position, source_index in enumerate(complete.index)
    ]
    warnings = [
        warning
        for warning, condition in (
            (
                "Fewer than 5 groups are available; random-effect inference may be unreliable.",
                len(unique_groups) < 5,
            ),
            (
                "At least one group has only one observation.",
                min(len(indices) for indices in group_indices) < 2,
            ),
            (
                "The random-intercept variance is near zero; ordinary regression may be sufficient and ordinary Wald intervals are suppressed.",
                variance_boundary,
            ),
            (
                fitted_model["variance_inference_warning"],
                fitted_model["variance_inference_warning"] is not None,
            ),
            (ml_fit_warning, ml_fit_warning is not None),
        )
        if condition
    ]
    result.update(
        {
            "status": "completed",
            "convergence": optimization_diagnostics,
            "coefficients": coefficients,
            "fixed_effect_information_type": "analytic expected/model-based generalized least-squares information",
            "fixed_effect_information_matrix": fitted_model[
                "fixed_information"
            ].tolist(),
            "fixed_effect_covariance_matrix": fixed_covariance.tolist(),
            "fixed_effect_covariance_type": (
                "model-based generalized least-squares covariance; not sandwich"
            ),
            "fixed_effect_information_diagnostics": fitted_model[
                "fixed_information_diagnostics"
            ],
            "variance_components": {
                "random_intercept_variance": random_variance,
                "residual_variance": residual_variance,
                "random_intercept_standard_deviation": math.sqrt(random_variance),
                "residual_standard_deviation": math.sqrt(residual_variance),
                "intraclass_correlation": random_variance
                / (random_variance + residual_variance),
            },
            "variance_component_inference": variance_component_inference,
            "variance_component_information_type": (
                "numerical Hessian of the ML or REML profile objective on log-variance scales"
            ),
            "variance_component_information_matrix": (
                fitted_model["variance_information"].tolist()
                if fitted_model["variance_information"] is not None
                else None
            ),
            "variance_component_optimizer_covariance_matrix": (
                variance_optimizer_covariance.tolist()
                if variance_optimizer_covariance is not None
                else None
            ),
            "variance_component_transformed_covariance_matrix": (
                variance_transformed_covariance.tolist()
                if variance_transformed_covariance is not None
                else None
            ),
            "variance_component_information_diagnostics": fitted_model[
                "variance_information_diagnostics"
            ],
            "variance_component_numerical_hessian_diagnostics": fitted_model[
                "variance_hessian_diagnostics"
            ],
            "numerical_status": statistical_numerical_status(
                optimization=optimization_diagnostics,
                information=fitted_model["fixed_information_diagnostics"],
                differentiation=fitted_model["variance_hessian_diagnostics"],
                covariance_available=True,
                inference_available=(
                    variance_component_inference.get("status") == "completed"
                ),
                boundary=(
                    variance_component_inference.get("reason")
                    if variance_component_inference.get("status") == "boundary"
                    else None
                ),
            ),
            "random_intercepts_blup": random_effects,
            "log_likelihood_or_restricted_log_likelihood": -fitted_model["objective"],
            "ml_log_likelihood": ml_log_likelihood,
            "aic_ml": (
                2.0 * (parameter_count + 2) - 2.0 * ml_log_likelihood
                if ml_log_likelihood is not None
                else None
            ),
            "bic_ml": (
                (parameter_count + 2) * math.log(observation_count)
                - 2.0 * ml_log_likelihood
                if ml_log_likelihood is not None
                else None
            ),
            "random_intercept_likelihood_ratio_test": (
                {
                    "status": "completed",
                    "statistic": comparison_statistic,
                    "mixture_chi_square_p_value": comparison_p,
                    "interpretation": (
                        "the random intercept materially improves fit"
                        if comparison_p is not None and comparison_p < alpha
                        else "insufficient evidence that the random intercept improves fit"
                    ),
                    "note": "The variance null value is on the boundary; the p-value uses a 50:50 point-mass/chi-square mixture.",
                }
                if ml_log_likelihood is not None
                else {
                    "status": "not_run",
                    "reason": ml_fit_warning,
                }
            ),
            "marginal_r_squared": fixed_variance / total_variance,
            "conditional_r_squared": (fixed_variance + random_variance)
            / total_variance,
            "residual_summary": _residual_summary(conditional_residuals),
            "residual_normality_tests": normality_tests(
                pd.Series(conditional_residuals), alpha
            ),
            "assumption_warnings": warnings,
            "prediction_rows": prediction_rows,
        }
    )
    return result
