"""Rank-based nonparametric tests and multiple-comparison procedures."""

from __future__ import annotations

import math
from itertools import combinations
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .data import clean_sample, paired_samples
from .utils import decision_from_pvalue, finite_or_none


P_VALUE_ADJUSTMENTS = ("holm", "bonferroni")


def _sample_summary(sample: np.ndarray, column_name: str) -> dict[str, Any]:
    return {
        "column": column_name,
        "n": int(sample.size),
        "median": finite_or_none(np.median(sample)) if sample.size else None,
        "first_quartile": (
            finite_or_none(np.quantile(sample, 0.25)) if sample.size else None
        ),
        "third_quartile": (
            finite_or_none(np.quantile(sample, 0.75)) if sample.size else None
        ),
    }


def mann_whitney_u_test(
    first: pd.Series,
    second: pd.Series,
    first_name: str,
    second_name: str,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    """Compare two independent samples by ranks."""
    sample_1 = clean_sample(first)
    sample_2 = clean_sample(second)
    n_1, n_2 = sample_1.size, sample_2.size
    result: dict[str, Any] = {
        "method": "Mann-Whitney U test",
        "column_1": first_name,
        "column_2": second_name,
        "alternative": alternative,
        "n_1": int(n_1),
        "n_2": int(n_2),
        "sample_1": _sample_summary(sample_1, first_name),
        "sample_2": _sample_summary(sample_2, second_name),
    }
    if n_1 < 1 or n_2 < 1:
        result.update(
            status="not_run",
            reason="each independent sample requires at least 1 observation",
        )
        return result

    test = scipy_stats.mannwhitneyu(
        sample_1,
        sample_2,
        alternative=alternative,
        method="auto",
    )
    statistic = float(test.statistic)
    p_value = float(test.pvalue)
    common_language_effect = statistic / (n_1 * n_2)
    rank_biserial = 2.0 * common_language_effect - 1.0
    result.update(
        {
            "status": "completed",
            "null_hypothesis": "the two population distributions are equal",
            "statistic": finite_or_none(statistic),
            "p_value": finite_or_none(p_value),
            "median_difference": finite_or_none(
                np.median(sample_1) - np.median(sample_2)
            ),
            "common_language_effect": finite_or_none(common_language_effect),
            "rank_biserial_correlation": finite_or_none(rank_biserial),
            "calculation_method": "auto",
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result


def wilcoxon_signed_rank_test(
    first: pd.Series,
    second: pd.Series,
    first_name: str,
    second_name: str,
    alternative: str,
    alpha: float,
) -> dict[str, Any]:
    """Compare paired samples using signed ranks."""
    sample_1, sample_2 = paired_samples(first, second)
    differences = sample_1 - sample_2
    nonzero = differences[differences != 0]
    result: dict[str, Any] = {
        "method": "Wilcoxon signed-rank test",
        "column_1": first_name,
        "column_2": second_name,
        "difference_definition": f"{first_name} - {second_name}",
        "alternative": alternative,
        "n_pairs": int(differences.size),
        "nonzero_differences": int(nonzero.size),
        "zero_differences": int(differences.size - nonzero.size),
    }
    if differences.size < 1:
        result.update(status="not_run", reason="requires at least 1 complete pair")
        return result
    if nonzero.size == 0:
        result.update(status="not_run", reason="all paired differences are zero")
        return result

    ranks = scipy_stats.rankdata(np.abs(nonzero), method="average")
    positive_rank_sum = float(np.sum(ranks[nonzero > 0]))
    negative_rank_sum = float(np.sum(ranks[nonzero < 0]))
    total_rank_sum = positive_rank_sum + negative_rank_sum
    rank_biserial = (
        (positive_rank_sum - negative_rank_sum) / total_rank_sum
        if total_rank_sum > 0
        else None
    )
    test = scipy_stats.wilcoxon(
        differences,
        zero_method="wilcox",
        alternative=alternative,
        method="auto",
    )
    p_value = float(test.pvalue)
    result.update(
        {
            "status": "completed",
            "null_hypothesis": (
                "the paired-difference distribution is symmetric about zero"
            ),
            "statistic": finite_or_none(test.statistic),
            "p_value": finite_or_none(p_value),
            "median_difference": finite_or_none(np.median(differences)),
            "positive_rank_sum": finite_or_none(positive_rank_sum),
            "negative_rank_sum": finite_or_none(negative_rank_sum),
            "rank_biserial_correlation": finite_or_none(rank_biserial),
            "calculation_method": "auto",
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result


def adjust_p_values(p_values: list[float], method: str) -> list[float]:
    """Adjust a family of p-values by Holm or Bonferroni correction."""
    if method not in P_VALUE_ADJUSTMENTS:
        raise ValueError(f"unsupported p-value adjustment: {method}")
    count = len(p_values)
    if method == "bonferroni":
        return [min(1.0, count * value) for value in p_values]

    order = sorted(range(count), key=p_values.__getitem__)
    adjusted = [0.0] * count
    previous = 0.0
    for rank, original_index in enumerate(order):
        candidate = min(1.0, (count - rank) * p_values[original_index])
        previous = max(previous, candidate)
        adjusted[original_index] = previous
    return adjusted


def _dunn_posthoc(
    samples: list[np.ndarray],
    column_names: list[str],
    adjustment: str,
    alpha: float,
) -> list[dict[str, Any]]:
    counts = [sample.size for sample in samples]
    combined = np.concatenate(samples)
    ranks = scipy_stats.rankdata(combined, method="average")
    total = combined.size

    mean_ranks: list[float] = []
    offset = 0
    for count in counts:
        mean_ranks.append(float(np.mean(ranks[offset : offset + count])))
        offset += count

    _, tie_counts = np.unique(combined, return_counts=True)
    tie_sum = float(np.sum(tie_counts**3 - tie_counts))
    tie_correction = (
        1.0 - tie_sum / (total**3 - total) if total > 1 else 1.0
    )
    variance_base = total * (total + 1.0) * tie_correction / 12.0

    raw_comparisons: list[dict[str, Any]] = []
    raw_p_values: list[float] = []
    for first_index, second_index in combinations(range(len(samples)), 2):
        standard_error = math.sqrt(
            variance_base
            * (1.0 / counts[first_index] + 1.0 / counts[second_index])
        )
        mean_rank_difference = (
            mean_ranks[first_index] - mean_ranks[second_index]
        )
        z_score = mean_rank_difference / standard_error
        raw_p_value = float(2.0 * scipy_stats.norm.sf(abs(z_score)))
        raw_p_values.append(raw_p_value)
        raw_comparisons.append(
            {
                "method": "Dunn post-hoc comparison",
                "column_1": column_names[first_index],
                "column_2": column_names[second_index],
                "mean_rank_1": mean_ranks[first_index],
                "mean_rank_2": mean_ranks[second_index],
                "mean_rank_difference": mean_rank_difference,
                "standard_error": standard_error,
                "z_score": z_score,
                "raw_p_value": raw_p_value,
            }
        )

    adjusted_p_values = adjust_p_values(raw_p_values, adjustment)
    for comparison, adjusted_p_value in zip(
        raw_comparisons, adjusted_p_values
    ):
        comparison.update(
            {
                "p_value_adjustment": adjustment,
                "adjusted_p_value": adjusted_p_value,
                "decision": decision_from_pvalue(adjusted_p_value, alpha),
            }
        )
    return raw_comparisons


def kruskal_wallis_test(
    series_list: list[pd.Series],
    column_names: list[str],
    alpha: float,
    run_posthoc: bool = False,
    posthoc_adjustment: str = "holm",
) -> dict[str, Any]:
    """Compare three or more independent groups by pooled ranks."""
    samples = [clean_sample(series) for series in series_list]
    group_count = len(samples)
    result: dict[str, Any] = {
        "method": "Kruskal-Wallis H test",
        "columns": column_names,
        "group_count": group_count,
        "group_statistics": [
            _sample_summary(sample, name)
            for sample, name in zip(samples, column_names)
        ],
        "posthoc_requested": run_posthoc,
        "posthoc_adjustment": posthoc_adjustment if run_posthoc else None,
        "posthoc_comparisons": [],
    }
    if group_count < 3:
        result.update(
            status="not_run", reason="Kruskal-Wallis requires at least 3 columns"
        )
        return result
    if any(sample.size < 1 for sample in samples):
        result.update(
            status="not_run",
            reason="each independent sample requires at least 1 observation",
        )
        return result

    combined = np.concatenate(samples)
    if np.all(combined == combined[0]):
        result.update(status="not_run", reason="all observations are identical")
        return result

    test = scipy_stats.kruskal(*samples, nan_policy="omit")
    statistic = float(test.statistic)
    p_value = float(test.pvalue)
    total = combined.size
    denominator = total - group_count
    epsilon_squared = (
        max(0.0, (statistic - group_count + 1.0) / denominator)
        if denominator > 0
        else None
    )
    if run_posthoc:
        result["posthoc_comparisons"] = _dunn_posthoc(
            samples,
            column_names,
            posthoc_adjustment,
            alpha,
        )
    result.update(
        {
            "status": "completed",
            "null_hypothesis": "all group distributions are equal",
            "statistic": finite_or_none(statistic),
            "degrees_of_freedom": int(group_count - 1),
            "p_value": finite_or_none(p_value),
            "epsilon_squared": finite_or_none(epsilon_squared),
            "decision": decision_from_pvalue(p_value, alpha),
        }
    )
    return result
