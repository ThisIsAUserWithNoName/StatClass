"""Numerical differentiation and information-matrix utilities.

These routines support statistical estimation.  They are intentionally not a
general-purpose numerical-analysis interface exposed by the command line.
"""

from __future__ import annotations

import math
from collections.abc import Callable
from typing import Any

import numpy as np


class NumericalComputationError(ValueError):
    """Raised when numerical curvature cannot support reliable inference."""

    def __init__(self, message: str, diagnostics: dict[str, Any] | None = None):
        super().__init__(message)
        self.diagnostics = diagnostics or {}


def optimizer_convergence_diagnostics(
    result: Any,
    *,
    parameters: Any | None = None,
    objective_value: float | None = None,
    gradient: Any | None = None,
    gradient_tolerance: float = 1e-5,
    method: str | None = None,
) -> dict[str, Any]:
    """Standardize convergence evidence returned by SciPy optimizers."""
    parameter_array = (
        np.asarray(getattr(result, "x", []), dtype=float)
        if parameters is None
        else np.asarray(parameters, dtype=float)
    )
    parameters_finite = bool(
        parameter_array.size > 0 and np.all(np.isfinite(parameter_array))
    )
    raw_objective = (
        getattr(result, "fun", None)
        if objective_value is None
        else objective_value
    )
    objective = float(raw_objective) if raw_objective is not None else None
    objective_finite = bool(objective is not None and math.isfinite(objective))
    gradient_norm = None
    gradient_finite = None
    stationarity_reached = None
    if gradient is not None:
        gradient_array = np.asarray(gradient, dtype=float)
        gradient_finite = bool(
            gradient_array.size > 0 and np.all(np.isfinite(gradient_array))
        )
        if gradient_finite:
            gradient_norm = float(np.linalg.norm(gradient_array, ord=np.inf))
            stationarity_reached = bool(gradient_norm <= gradient_tolerance)
        else:
            stationarity_reached = False
    reported_success = bool(getattr(result, "success", False))
    converged = bool(
        parameters_finite
        and objective_finite
        and (reported_success or stationarity_reached is True)
    )
    warnings: list[str] = []
    if reported_success and stationarity_reached is False:
        warnings.append(
            "The optimizer reported success, but the remaining gradient exceeds the stationarity tolerance."
        )
    if not reported_success and stationarity_reached is True:
        warnings.append(
            "The optimizer did not report success, but the remaining gradient satisfies the stationarity tolerance."
        )
    if not parameters_finite:
        warnings.append("The optimizer returned a nonfinite parameter value.")
    if not objective_finite:
        warnings.append("The optimizer returned a nonfinite objective value.")
    if gradient_finite is False:
        warnings.append("The optimizer returned a nonfinite gradient.")
    status = (
        "failed"
        if not converged
        else "converged_with_warning"
        if warnings
        else "converged"
    )
    return {
        "status": status,
        "converged": converged,
        "success": converged,
        "method": method,
        "optimizer_reported_success": reported_success,
        "message": str(getattr(result, "message", "not supplied")),
        "iterations": (
            int(getattr(result, "nit"))
            if getattr(result, "nit", None) is not None
            else None
        ),
        "function_evaluations": (
            int(getattr(result, "nfev"))
            if getattr(result, "nfev", None) is not None
            else None
        ),
        "gradient_evaluations": (
            int(getattr(result, "njev"))
            if getattr(result, "njev", None) is not None
            else None
        ),
        "parameters_finite": parameters_finite,
        "objective_value": objective if objective_finite else None,
        "objective_finite": objective_finite,
        "gradient_finite": gradient_finite,
        "gradient_infinity_norm": gradient_norm,
        "gradient_tolerance": gradient_tolerance if gradient is not None else None,
        "stationarity_reached": stationarity_reached,
        "warnings": warnings,
    }


def statistical_numerical_status(
    *,
    optimization: dict[str, Any] | None = None,
    information: dict[str, Any] | None = None,
    differentiation: dict[str, Any] | None = None,
    covariance_available: bool | None = None,
    inference_available: bool | None = None,
    boundary: str | None = None,
    failure_reason: str | None = None,
    additional_warnings: list[str] | None = None,
) -> dict[str, Any]:
    """Combine optimizer, curvature, covariance, and boundary diagnostics."""
    warnings: list[str] = []
    failed = failure_reason is not None
    if optimization is not None:
        warnings.extend(optimization.get("warnings", []))
        failed = failed or not optimization.get("converged", False)
    if information is not None:
        warnings.extend(information.get("warnings", []))
        failed = failed or not information.get("finite", False)
        failed = failed or not information.get("positive_definite", False)
        failed = failed or information.get("near_singular", True)
    if differentiation is not None and not differentiation.get("step_stable", False):
        warnings.append(
            "Numerical derivatives were sensitive to the finite-difference step."
        )
    if covariance_available is False:
        warnings.append("A covariance matrix is unavailable.")
    if inference_available is False:
        warnings.append("Hessian-based Wald inference is unavailable.")
    if boundary is not None:
        warnings.append(boundary)
    if additional_warnings:
        warnings.extend(additional_warnings)
    status = (
        "failed"
        if failed
        else "warning"
        if warnings
        else "completed"
    )
    return {
        "status": status,
        "optimization": optimization,
        "information_matrix": information,
        "numerical_differentiation": differentiation,
        "covariance_available": covariance_available,
        "inference_available": inference_available,
        "boundary": boundary,
        "failure_reason": failure_reason,
        "warnings": list(dict.fromkeys(warnings)),
    }


def _point(values: Any) -> np.ndarray:
    point = np.asarray(values, dtype=float)
    if point.ndim != 1 or point.size == 0 or not np.all(np.isfinite(point)):
        raise NumericalComputationError(
            "the numerical-differentiation point must be a finite one-dimensional vector"
        )
    return point


def _steps(point: np.ndarray, relative_step: float) -> np.ndarray:
    if not math.isfinite(relative_step) or relative_step <= 0.0:
        raise NumericalComputationError("the relative differentiation step must be positive")
    return relative_step * np.maximum(1.0, np.abs(point))


def _scalar_value(function: Callable[[np.ndarray], float], point: np.ndarray) -> float:
    value = float(function(point))
    if not math.isfinite(value):
        raise NumericalComputationError(
            "the objective was nonfinite at a numerical-differentiation point"
        )
    return value


def _gradient_value(
    gradient: Callable[[np.ndarray], Any],
    point: np.ndarray,
) -> np.ndarray:
    value = np.asarray(gradient(point), dtype=float)
    if value.shape != point.shape or not np.all(np.isfinite(value)):
        raise NumericalComputationError(
            "the gradient must return one finite value per parameter"
        )
    return value


def numerical_gradient(
    function: Callable[[np.ndarray], float],
    values: Any,
    relative_step: float | None = None,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Return a central-difference gradient and step-sensitivity diagnostics."""
    point = _point(values)
    base_step = (
        float(np.cbrt(np.finfo(float).eps))
        if relative_step is None
        else float(relative_step)
    )

    def calculate(steps: np.ndarray) -> np.ndarray:
        gradient = np.empty(point.size, dtype=float)
        for index, step in enumerate(steps):
            upper = point.copy()
            lower = point.copy()
            upper[index] += step
            lower[index] -= step
            gradient[index] = (
                _scalar_value(function, upper) - _scalar_value(function, lower)
            ) / (2.0 * step)
        return gradient

    full = calculate(_steps(point, base_step))
    half = calculate(_steps(point, base_step / 2.0))
    sensitivity = float(
        np.linalg.norm(half - full)
        / max(1.0, float(np.linalg.norm(half)))
    )
    return half, {
        "method": "central differences of objective values",
        "relative_step": base_step / 2.0,
        "step_sensitivity_relative_norm": sensitivity,
        "step_stable": sensitivity <= 1e-4,
        "function_evaluations": 4 * point.size,
    }


def _function_value_hessian(
    function: Callable[[np.ndarray], float],
    point: np.ndarray,
    steps: np.ndarray,
) -> np.ndarray:
    dimension = point.size
    hessian = np.zeros((dimension, dimension), dtype=float)
    center = _scalar_value(function, point)
    for first, first_step in enumerate(steps):
        unit_first = np.zeros(dimension, dtype=float)
        unit_first[first] = first_step
        hessian[first, first] = (
            _scalar_value(function, point + unit_first)
            - 2.0 * center
            + _scalar_value(function, point - unit_first)
        ) / first_step**2
        for second in range(first + 1, dimension):
            unit_second = np.zeros(dimension, dtype=float)
            unit_second[second] = steps[second]
            value = (
                _scalar_value(function, point + unit_first + unit_second)
                - _scalar_value(function, point + unit_first - unit_second)
                - _scalar_value(function, point - unit_first + unit_second)
                + _scalar_value(function, point - unit_first - unit_second)
            ) / (4.0 * first_step * steps[second])
            hessian[first, second] = value
            hessian[second, first] = value
    return hessian


def numerical_hessian(
    function: Callable[[np.ndarray], float],
    values: Any,
    relative_step: float | None = None,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Return a central second-difference Hessian of a scalar objective."""
    point = _point(values)
    base_step = (
        float(np.finfo(float).eps ** 0.25)
        if relative_step is None
        else float(relative_step)
    )
    full = _function_value_hessian(function, point, _steps(point, base_step))
    half = _function_value_hessian(function, point, _steps(point, base_step / 2.0))
    half = (half + half.T) / 2.0
    sensitivity = float(
        np.linalg.norm(half - full, ord="fro")
        / max(1.0, float(np.linalg.norm(half, ord="fro")))
    )
    dimension = point.size
    evaluations_per_hessian = 1 + 2 * dimension + 2 * dimension * (dimension - 1)
    return half, {
        "method": "central second differences of objective values",
        "relative_step": base_step / 2.0,
        "step_sensitivity_relative_frobenius_norm": sensitivity,
        "step_stable": sensitivity <= 1e-3,
        "function_evaluations": 2 * evaluations_per_hessian,
    }


def _gradient_hessian(
    gradient: Callable[[np.ndarray], Any],
    point: np.ndarray,
    steps: np.ndarray,
) -> np.ndarray:
    dimension = point.size
    hessian = np.empty((dimension, dimension), dtype=float)
    for index, step in enumerate(steps):
        upper = point.copy()
        lower = point.copy()
        upper[index] += step
        lower[index] -= step
        hessian[:, index] = (
            _gradient_value(gradient, upper) - _gradient_value(gradient, lower)
        ) / (2.0 * step)
    return (hessian + hessian.T) / 2.0


def numerical_hessian_from_gradient(
    gradient: Callable[[np.ndarray], Any],
    values: Any,
    relative_step: float | None = None,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Return a Hessian by central-differencing an available gradient."""
    point = _point(values)
    base_step = (
        float(np.cbrt(np.finfo(float).eps))
        if relative_step is None
        else float(relative_step)
    )
    full = _gradient_hessian(gradient, point, _steps(point, base_step))
    half = _gradient_hessian(gradient, point, _steps(point, base_step / 2.0))
    sensitivity = float(
        np.linalg.norm(half - full, ord="fro")
        / max(1.0, float(np.linalg.norm(half, ord="fro")))
    )
    return half, {
        "method": "central differences of an analytic gradient",
        "relative_step": base_step / 2.0,
        "step_sensitivity_relative_frobenius_norm": sensitivity,
        "step_stable": sensitivity <= 1e-4,
        "gradient_evaluations": 4 * point.size,
    }


def information_matrix_diagnostics(matrix: Any) -> dict[str, Any]:
    """Diagnose a candidate observed or expected information matrix."""
    array = np.asarray(matrix, dtype=float)
    if array.ndim != 2 or array.shape[0] != array.shape[1] or array.shape[0] == 0:
        return {
            "dimension": None,
            "finite": False,
            "square": False,
            "rank": None,
            "positive_definite": False,
            "positive_semidefinite": False,
            "condition_number": None,
            "near_singular": True,
            "warnings": ["The information matrix is not a nonempty square matrix."],
        }
    dimension = array.shape[0]
    if not np.all(np.isfinite(array)):
        return {
            "dimension": dimension,
            "finite": False,
            "square": True,
            "rank": None,
            "positive_definite": False,
            "positive_semidefinite": False,
            "condition_number": None,
            "near_singular": True,
            "warnings": ["The information matrix contains nonfinite values."],
        }
    symmetry_error = float(
        np.linalg.norm(array - array.T, ord="fro")
        / max(1.0, float(np.linalg.norm(array, ord="fro")))
    )
    symmetric = (array + array.T) / 2.0
    eigenvalues = np.linalg.eigvalsh(symmetric)
    scale = max(1.0, float(np.max(np.abs(eigenvalues))))
    tolerance = float(dimension * np.finfo(float).eps * scale)
    rank = int(np.linalg.matrix_rank(symmetric, tol=tolerance))
    minimum = float(eigenvalues[0])
    maximum = float(eigenvalues[-1])
    positive_definite = bool(minimum > tolerance)
    positive_semidefinite = bool(minimum >= -tolerance)
    absolute_eigenvalues = np.abs(eigenvalues)
    smallest_absolute = float(np.min(absolute_eigenvalues))
    condition_number = (
        float(np.max(absolute_eigenvalues) / smallest_absolute)
        if smallest_absolute > tolerance
        else None
    )
    near_singular = bool(
        rank < dimension
        or condition_number is None
        or condition_number > 1e10
    )
    warnings: list[str] = []
    if symmetry_error > 1e-8:
        warnings.append("The information matrix required material symmetrization.")
    if rank < dimension:
        warnings.append("The information matrix is rank deficient.")
    if not positive_semidefinite:
        warnings.append("The information matrix has a negative eigenvalue.")
    elif not positive_definite:
        warnings.append("The information matrix is not strictly positive definite.")
    if condition_number is not None and condition_number > 1e10:
        warnings.append("The information matrix is ill-conditioned.")
    return {
        "dimension": dimension,
        "finite": True,
        "square": True,
        "symmetry_relative_error": symmetry_error,
        "rank": rank,
        "minimum_eigenvalue": minimum,
        "maximum_eigenvalue": maximum,
        "positive_definite": positive_definite,
        "positive_semidefinite": positive_semidefinite,
        "condition_number": condition_number,
        "near_singular": near_singular,
        "rank_tolerance": tolerance,
        "warnings": warnings,
    }


def covariance_from_information(
    matrix: Any,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Invert positive-definite information by a Cholesky-based solve."""
    information = np.asarray(matrix, dtype=float)
    diagnostics = information_matrix_diagnostics(information)
    if (
        not diagnostics.get("finite")
        or not diagnostics.get("positive_definite")
        or diagnostics.get("near_singular")
    ):
        raise NumericalComputationError(
            "the information matrix is not finite, positive definite, and well-conditioned",
            diagnostics,
        )
    symmetric = (information + information.T) / 2.0
    try:
        factor = np.linalg.cholesky(symmetric)
        inverse_factor = np.linalg.solve(factor, np.eye(factor.shape[0]))
        covariance = inverse_factor.T @ inverse_factor
    except np.linalg.LinAlgError as exc:
        raise NumericalComputationError(
            "Cholesky covariance calculation failed",
            diagnostics,
        ) from exc
    covariance = (covariance + covariance.T) / 2.0
    if not np.all(np.isfinite(covariance)) or np.any(np.diag(covariance) <= 0.0):
        raise NumericalComputationError(
            "the information matrix did not produce a valid covariance matrix",
            diagnostics,
        )
    diagnostics = {**diagnostics, "covariance_method": "Cholesky linear solve"}
    return covariance, diagnostics


def delta_method_covariance(covariance: Any, jacobian: Any) -> np.ndarray:
    """Transform a covariance matrix with the multivariate delta method."""
    covariance_array = np.asarray(covariance, dtype=float)
    jacobian_array = np.asarray(jacobian, dtype=float)
    if (
        covariance_array.ndim != 2
        or covariance_array.shape[0] != covariance_array.shape[1]
        or jacobian_array.ndim != 2
        or jacobian_array.shape[1] != covariance_array.shape[0]
        or not np.all(np.isfinite(covariance_array))
        or not np.all(np.isfinite(jacobian_array))
    ):
        raise NumericalComputationError(
            "delta-method covariance requires compatible finite matrices"
        )
    transformed = jacobian_array @ covariance_array @ jacobian_array.T
    transformed = (transformed + transformed.T) / 2.0
    if not np.all(np.isfinite(transformed)):
        raise NumericalComputationError("the transformed covariance is nonfinite")
    return transformed
