"""Ordinary least-squares simple linear regression."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .data import paired_samples
from .utils import decision_from_pvalue, finite_or_none


def _coefficient_result(
    name: str,
    estimate: float,
    standard_error: float,
    degrees_of_freedom: int,
    alpha: float,
) -> dict[str, Any]:
    if standard_error == 0:
        statistic = math.copysign(math.inf, estimate) if estimate != 0 else math.nan
        p_value = 0.0 if estimate != 0 else math.nan
        lower = estimate
        upper = estimate
    else:
        statistic = estimate / standard_error
        p_value = float(
            2.0 * scipy_stats.t.sf(abs(statistic), degrees_of_freedom)
        )
        critical = float(
            scipy_stats.t.ppf(1.0 - alpha / 2.0, degrees_of_freedom)
        )
        lower = estimate - critical * standard_error
        upper = estimate + critical * standard_error
    return {
        "term": name,
        "estimate": finite_or_none(estimate),
        "standard_error": finite_or_none(standard_error),
        "t_statistic": finite_or_none(statistic),
        "p_value": finite_or_none(p_value),
        "confidence_interval": [finite_or_none(lower), finite_or_none(upper)],
    }


def simple_linear_regression(
    dependent: pd.Series,
    independent: pd.Series,
    dependent_name: str,
    independent_name: str,
    alpha: float,
) -> dict[str, Any]:
    dependent_values = dependent.to_numpy(dtype=float)
    independent_values = independent.to_numpy(dtype=float)
    complete_mask = np.isfinite(dependent_values) & np.isfinite(
        independent_values
    )
    source_indices = dependent.index[complete_mask]
    y, x = paired_samples(dependent, independent)
    n = x.size
    result: dict[str, Any] = {
        "method": "ordinary least-squares simple linear regression",
        "dependent_variable": dependent_name,
        "independent_variable": independent_name,
        "n_complete_cases": int(n),
    }
    if n < 3:
        result.update(status="not_run", reason="requires at least 3 complete cases")
        return result
    if np.ptp(x) == 0:
        result.update(
            status="not_run",
            reason="the independent variable is constant",
        )
        return result
    if np.ptp(y) == 0:
        result.update(status="not_run", reason="the dependent variable is constant")
        return result

    x_mean = float(np.mean(x))
    y_mean = float(np.mean(y))
    centered_x = x - x_mean
    centered_y = y - y_mean
    sum_xx = float(np.sum(centered_x**2))
    sum_xy = float(np.sum(centered_x * centered_y))
    slope = sum_xy / sum_xx
    intercept = y_mean - slope * x_mean
    fitted = intercept + slope * x
    residuals = y - fitted

    residual_sum_squares = float(np.sum(residuals**2))
    total_sum_squares = float(np.sum(centered_y**2))
    regression_sum_squares = total_sum_squares - residual_sum_squares
    model_df = 1
    residual_df = n - 2
    residual_mean_square = residual_sum_squares / residual_df
    regression_mean_square = regression_sum_squares
    residual_standard_error = math.sqrt(max(residual_mean_square, 0.0))
    slope_standard_error = math.sqrt(residual_mean_square / sum_xx)
    intercept_standard_error = math.sqrt(
        residual_mean_square * (1.0 / n + x_mean**2 / sum_xx)
    )

    r_squared = 1.0 - residual_sum_squares / total_sum_squares
    adjusted_r_squared = 1.0 - (1.0 - r_squared) * (n - 1.0) / residual_df
    if residual_mean_square == 0:
        f_statistic = math.inf
        f_p_value = 0.0
    else:
        f_statistic = regression_mean_square / residual_mean_square
        f_p_value = float(
            scipy_stats.f.sf(f_statistic, model_df, residual_df)
        )

    coefficients = [
        _coefficient_result(
            "Intercept",
            intercept,
            intercept_standard_error,
            residual_df,
            alpha,
        ),
        _coefficient_result(
            independent_name,
            slope,
            slope_standard_error,
            residual_df,
            alpha,
        ),
    ]
    slope_p_value = coefficients[1]["p_value"]
    decision = (
        decision_from_pvalue(float(slope_p_value), alpha)
        if slope_p_value is not None
        else "No decision"
    )
    critical = float(scipy_stats.t.ppf(1.0 - alpha / 2.0, residual_df))
    mean_standard_errors = np.sqrt(
        residual_mean_square * (1.0 / n + centered_x**2 / sum_xx)
    )
    prediction_standard_errors = np.sqrt(
        residual_mean_square + mean_standard_errors**2
    )
    prediction_rows = [
        {
            "model_family": "simple_linear_regression",
            "model_name": f"{dependent_name} on {independent_name}",
            "source_index": str(source_index),
            "outcome_variable": dependent_name,
            "observed": finite_or_none(y[index]),
            "predicted": finite_or_none(fitted[index]),
            "residual": finite_or_none(residuals[index]),
            "mean_ci_lower": finite_or_none(
                fitted[index] - critical * mean_standard_errors[index]
            ),
            "mean_ci_upper": finite_or_none(
                fitted[index] + critical * mean_standard_errors[index]
            ),
            "prediction_interval_lower": finite_or_none(
                fitted[index] - critical * prediction_standard_errors[index]
            ),
            "prediction_interval_upper": finite_or_none(
                fitted[index] + critical * prediction_standard_errors[index]
            ),
        }
        for index, source_index in enumerate(source_indices)
    ]
    result.update(
        {
            "status": "completed",
            "equation": f"{dependent_name} = intercept + slope * {independent_name}",
            "null_hypothesis": "slope = 0",
            "coefficients": coefficients,
            "r_squared": finite_or_none(r_squared),
            "adjusted_r_squared": finite_or_none(adjusted_r_squared),
            "residual_standard_error": finite_or_none(residual_standard_error),
            "degrees_of_freedom_residual": int(residual_df),
            "f_statistic": finite_or_none(f_statistic),
            "f_degrees_of_freedom": [model_df, int(residual_df)],
            "f_p_value": finite_or_none(f_p_value),
            "anova_table": [
                {
                    "source": "Regression",
                    "sum_of_squares": finite_or_none(regression_sum_squares),
                    "degrees_of_freedom": model_df,
                    "mean_square": finite_or_none(regression_mean_square),
                    "f_statistic": finite_or_none(f_statistic),
                    "p_value": finite_or_none(f_p_value),
                },
                {
                    "source": "Residual",
                    "sum_of_squares": finite_or_none(residual_sum_squares),
                    "degrees_of_freedom": int(residual_df),
                    "mean_square": finite_or_none(residual_mean_square),
                },
                {
                    "source": "Total",
                    "sum_of_squares": finite_or_none(total_sum_squares),
                    "degrees_of_freedom": int(n - 1),
                },
            ],
            "residual_summary": {
                "mean": finite_or_none(np.mean(residuals)),
                "standard_deviation": finite_or_none(
                    np.std(residuals, ddof=1)
                ),
                "minimum": finite_or_none(np.min(residuals)),
                "maximum": finite_or_none(np.max(residuals)),
            },
            "decision": decision,
            "prediction_rows": prediction_rows,
        }
    )
    return result
