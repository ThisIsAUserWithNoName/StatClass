"""Two-way factorial ANOVA, ANCOVA, and estimated marginal means."""

from __future__ import annotations

import math
from itertools import combinations, product
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats as scipy_stats

from .descriptives import normality_tests
from .multiple_regression import _breusch_pagan_test, _residual_summary
from .nonparametric import adjust_p_values
from .utils import decision_from_pvalue, finite_or_none


def _effect_code(
    values: pd.Series, categories: list[Any]
) -> tuple[np.ndarray, list[str]]:
    matrix = np.zeros((len(values), len(categories) - 1), dtype=float)
    reference = categories[-1]
    for index, category in enumerate(categories[:-1]):
        matrix[:, index] = np.where(
            values.to_numpy() == category,
            1.0,
            np.where(values.to_numpy() == reference, -1.0, 0.0),
        )
    return matrix, [str(category) for category in categories[:-1]]


def _effect_row(level: Any, categories: list[Any]) -> np.ndarray:
    if level == categories[-1]:
        return -np.ones(len(categories) - 1, dtype=float)
    return np.asarray(
        [1.0 if level == category else 0.0 for category in categories[:-1]],
        dtype=float,
    )


def _fit_ols(response: np.ndarray, design: np.ndarray) -> dict[str, Any]:
    estimates = np.linalg.lstsq(design, response, rcond=None)[0]
    fitted = design @ estimates
    residuals = response - fitted
    residual_sum_squares = float(np.sum(residuals**2))
    residual_df = response.size - design.shape[1]
    mean_square_error = residual_sum_squares / residual_df
    covariance = mean_square_error * np.linalg.pinv(design.T @ design)
    return {
        "estimates": estimates,
        "fitted": fitted,
        "residuals": residuals,
        "residual_sum_squares": residual_sum_squares,
        "residual_degrees_of_freedom": residual_df,
        "mean_square_error": mean_square_error,
        "covariance": covariance,
    }


def _design_row(
    first_level: Any,
    second_level: Any,
    first_categories: list[Any],
    second_categories: list[Any],
    covariate_count: int,
) -> np.ndarray:
    first = _effect_row(first_level, first_categories)
    second = _effect_row(second_level, second_categories)
    interaction = np.outer(first, second).ravel()
    return np.concatenate(
        [
            np.asarray([1.0]),
            first,
            second,
            interaction,
            np.zeros(covariate_count, dtype=float),
        ]
    )


def _estimate_from_row(
    row: np.ndarray,
    estimates: np.ndarray,
    covariance: np.ndarray,
    residual_df: int,
    alpha: float,
) -> dict[str, Any]:
    estimate = float(row @ estimates)
    standard_error = math.sqrt(max(0.0, float(row @ covariance @ row)))
    critical = float(scipy_stats.t.ppf(1.0 - alpha / 2.0, residual_df))
    return {
        "estimate": finite_or_none(estimate),
        "standard_error": finite_or_none(standard_error),
        "confidence_interval": [
            finite_or_none(estimate - critical * standard_error),
            finite_or_none(estimate + critical * standard_error),
        ],
    }


def _marginal_means(
    first_name: str,
    second_name: str,
    first_categories: list[Any],
    second_categories: list[Any],
    covariate_names: list[str],
    covariate_means: dict[str, float],
    estimates: np.ndarray,
    covariance: np.ndarray,
    residual_df: int,
    alpha: float,
    adjustment: str,
) -> dict[str, Any]:
    cell_rows: dict[tuple[int, int], np.ndarray] = {}
    cells = []
    for first_index, first_level in enumerate(first_categories):
        for second_index, second_level in enumerate(second_categories):
            row = _design_row(
                first_level,
                second_level,
                first_categories,
                second_categories,
                len(covariate_names),
            )
            cell_rows[(first_index, second_index)] = row
            cells.append(
                {
                    first_name: str(first_level),
                    second_name: str(second_level),
                    **_estimate_from_row(
                        row,
                        estimates,
                        covariance,
                        residual_df,
                        alpha,
                    ),
                }
            )

    factor_results: dict[str, Any] = {}
    for factor_name, levels, other_levels, first_factor in (
        (first_name, first_categories, second_categories, True),
        (second_name, second_categories, first_categories, False),
    ):
        rows = []
        means = []
        for level_index, level in enumerate(levels):
            if first_factor:
                row = np.mean(
                    [
                        cell_rows[(level_index, other_index)]
                        for other_index in range(len(other_levels))
                    ],
                    axis=0,
                )
            else:
                row = np.mean(
                    [
                        cell_rows[(other_index, level_index)]
                        for other_index in range(len(other_levels))
                    ],
                    axis=0,
                )
            rows.append(row)
            means.append(
                {
                    "level": str(level),
                    **_estimate_from_row(
                        row,
                        estimates,
                        covariance,
                        residual_df,
                        alpha,
                    ),
                }
            )

        comparisons = []
        raw_p_values = []
        for first_index, second_index in combinations(range(len(levels)), 2):
            contrast = rows[first_index] - rows[second_index]
            difference = float(contrast @ estimates)
            standard_error = math.sqrt(
                max(0.0, float(contrast @ covariance @ contrast))
            )
            statistic = difference / standard_error
            p_value = float(
                2.0 * scipy_stats.t.sf(abs(statistic), residual_df)
            )
            raw_p_values.append(p_value)
            comparisons.append(
                {
                    "level_1": str(levels[first_index]),
                    "level_2": str(levels[second_index]),
                    "difference": finite_or_none(difference),
                    "standard_error": finite_or_none(standard_error),
                    "t_statistic": finite_or_none(statistic),
                    "degrees_of_freedom": residual_df,
                    "p_value": finite_or_none(p_value),
                }
            )
        adjusted = adjust_p_values(raw_p_values, adjustment)
        for comparison, adjusted_p in zip(comparisons, adjusted):
            comparison["adjusted_p_value"] = finite_or_none(adjusted_p)
            comparison["adjustment"] = adjustment
            comparison["decision"] = decision_from_pvalue(adjusted_p, alpha)
        factor_results[factor_name] = {
            "marginal_means": means,
            "pairwise_comparisons": comparisons,
        }

    return {
        "covariates_held_at": {
            name: finite_or_none(covariate_means[name])
            for name in covariate_names
        },
        "weighting": "equal weighting over levels of the other factor",
        "cell_marginal_means": cells,
        "factors": factor_results,
        "pairwise_adjustment": adjustment,
    }


def factorial_anova_ancova(
    frame: pd.DataFrame,
    outcome_name: str,
    first_factor: str,
    second_factor: str,
    covariate_names: list[str],
    alpha: float,
    adjustment: str = "holm",
    model_name: str | None = None,
) -> dict[str, Any]:
    """Fit a two-factor effect-coded ANOVA or ANCOVA with Type III tests."""
    numeric_outcome = pd.to_numeric(frame[outcome_name], errors="coerce")
    mask = np.isfinite(numeric_outcome.to_numpy(dtype=float))
    mask &= frame[first_factor].notna().to_numpy()
    mask &= frame[second_factor].notna().to_numpy()
    numeric_covariates: dict[str, pd.Series] = {}
    for name in covariate_names:
        values = pd.to_numeric(frame[name], errors="coerce")
        numeric_covariates[name] = values
        mask &= np.isfinite(values.to_numpy(dtype=float))
    complete = frame.loc[mask]
    response = numeric_outcome.loc[mask].to_numpy(dtype=float)
    first_categories = list(pd.unique(complete[first_factor]))
    second_categories = list(pd.unique(complete[second_factor]))
    result: dict[str, Any] = {
        "method": (
            "two-way ANCOVA with effect coding and Type III partial F-tests"
            if covariate_names
            else "two-way factorial ANOVA with effect coding and Type III partial F-tests"
        ),
        "model_name": model_name,
        "outcome_variable": outcome_name,
        "factor_1": first_factor,
        "factor_2": second_factor,
        "covariates": covariate_names,
        "total_rows": int(len(frame)),
        "n_complete_cases": int(response.size),
        "excluded_rows": int(len(frame) - response.size),
        "factor_levels": {
            first_factor: [str(value) for value in first_categories],
            second_factor: [str(value) for value in second_categories],
        },
        "coding": "sum-to-zero effect coding; final observed level is omitted",
    }
    if response.size == 0:
        result.update(status="not_run", reason="no complete observations")
        return result
    if len(first_categories) < 2 or len(second_categories) < 2:
        result.update(
            status="not_run",
            reason="each factor requires at least 2 observed levels",
        )
        return result

    first_matrix, first_labels = _effect_code(
        complete[first_factor], first_categories
    )
    second_matrix, second_labels = _effect_code(
        complete[second_factor], second_categories
    )
    interaction = np.column_stack(
        [
            first_matrix[:, first_index] * second_matrix[:, second_index]
            for first_index, second_index in product(
                range(first_matrix.shape[1]), range(second_matrix.shape[1])
            )
        ]
    )
    covariate_means = {
        name: float(np.mean(numeric_covariates[name].loc[mask]))
        for name in covariate_names
    }
    covariate_matrix = (
        np.column_stack(
            [
                numeric_covariates[name].loc[mask].to_numpy(dtype=float)
                - covariate_means[name]
                for name in covariate_names
            ]
        )
        if covariate_names
        else np.empty((response.size, 0), dtype=float)
    )
    design = np.column_stack(
        [
            np.ones(response.size),
            first_matrix,
            second_matrix,
            interaction,
            covariate_matrix,
        ]
    )
    terms = ["Intercept"]
    groups: dict[str, list[int]] = {}
    start = 1
    groups[first_factor] = list(range(start, start + first_matrix.shape[1]))
    terms.extend(
        f"{first_factor}[E.{label}]" for label in first_labels
    )
    start += first_matrix.shape[1]
    groups[second_factor] = list(range(start, start + second_matrix.shape[1]))
    terms.extend(
        f"{second_factor}[E.{label}]" for label in second_labels
    )
    start += second_matrix.shape[1]
    interaction_name = f"{first_factor}:{second_factor}"
    groups[interaction_name] = list(
        range(start, start + interaction.shape[1])
    )
    terms.extend(
        f"{first_factor}[E.{first_label}]:{second_factor}[E.{second_label}]"
        for first_label, second_label in product(first_labels, second_labels)
    )
    start += interaction.shape[1]
    for covariate in covariate_names:
        groups[covariate] = [start]
        terms.append(f"{covariate} (centered)")
        start += 1
    parameter_count = design.shape[1]
    result.update(terms=terms, parameter_count=parameter_count)
    if response.size <= parameter_count:
        result.update(
            status="not_run",
            reason="requires more complete observations than estimated parameters",
        )
        return result
    design_rank = int(np.linalg.matrix_rank(design))
    if design_rank < parameter_count:
        result.update(
            status="not_run",
            reason="the factorial design matrix is rank deficient; check empty cells or redundant covariates",
            design_matrix_rank=design_rank,
        )
        return result
    if np.ptp(response) == 0:
        result.update(status="not_run", reason="the outcome variable is constant")
        return result

    fit = _fit_ols(response, design)
    residual_df = fit["residual_degrees_of_freedom"]
    mean_square_error = fit["mean_square_error"]
    if mean_square_error <= np.finfo(float).eps:
        result.update(status="not_run", reason="the model has zero residual variance")
        return result
    estimates = fit["estimates"]
    covariance = fit["covariance"]
    standard_errors = np.sqrt(np.maximum(0.0, np.diag(covariance)))
    statistics = estimates / standard_errors
    p_values = 2.0 * scipy_stats.t.sf(np.abs(statistics), residual_df)
    critical = float(scipy_stats.t.ppf(1.0 - alpha / 2.0, residual_df))
    coefficients = [
        {
            "term": term,
            "estimate": finite_or_none(estimates[index]),
            "standard_error": finite_or_none(standard_errors[index]),
            "t_statistic": finite_or_none(statistics[index]),
            "p_value": finite_or_none(p_values[index]),
            "confidence_interval": [
                finite_or_none(estimates[index] - critical * standard_errors[index]),
                finite_or_none(estimates[index] + critical * standard_errors[index]),
            ],
        }
        for index, term in enumerate(terms)
    ]

    effect_tests = []
    full_rss = fit["residual_sum_squares"]
    for effect, indices in groups.items():
        reduced = np.delete(design, indices, axis=1)
        reduced_rank = int(np.linalg.matrix_rank(reduced))
        numerator_df = design_rank - reduced_rank
        reduced_fit = _fit_ols(response, reduced)
        effect_ss = max(0.0, reduced_fit["residual_sum_squares"] - full_rss)
        statistic = effect_ss / numerator_df / mean_square_error
        p_value = float(scipy_stats.f.sf(statistic, numerator_df, residual_df))
        effect_tests.append(
            {
                "effect": effect,
                "sum_of_squares": effect_ss,
                "degrees_of_freedom": numerator_df,
                "mean_square": effect_ss / numerator_df,
                "f_statistic": statistic,
                "residual_degrees_of_freedom": residual_df,
                "p_value": p_value,
                "partial_eta_squared": (
                    effect_ss / (effect_ss + full_rss)
                    if effect_ss + full_rss > 0
                    else None
                ),
                "decision": decision_from_pvalue(p_value, alpha),
            }
        )

    response_mean = float(np.mean(response))
    total_ss = float(np.sum((response - response_mean) ** 2))
    regression_ss = total_ss - full_rss
    model_df = parameter_count - 1
    overall_f = regression_ss / model_df / mean_square_error
    overall_p = float(scipy_stats.f.sf(overall_f, model_df, residual_df))
    cell_descriptives = []
    cell_samples = []
    for first_level in first_categories:
        for second_level in second_categories:
            cell_mask = (
                (complete[first_factor] == first_level)
                & (complete[second_factor] == second_level)
            ).to_numpy()
            values = response[cell_mask]
            cell_samples.append(values)
            cell_descriptives.append(
                {
                    first_factor: str(first_level),
                    second_factor: str(second_level),
                    "n": int(values.size),
                    "mean": finite_or_none(np.mean(values)),
                    "standard_deviation": (
                        finite_or_none(np.std(values, ddof=1))
                        if values.size > 1
                        else None
                    ),
                }
            )
    levene = scipy_stats.levene(*cell_samples, center="median")

    slope_test: dict[str, Any] = {"status": "not_applicable"}
    if covariate_names:
        slope_columns = []
        for covariate_index in range(len(covariate_names)):
            covariate = covariate_matrix[:, covariate_index]
            slope_columns.extend(
                [
                    covariate * first_matrix[:, index]
                    for index in range(first_matrix.shape[1])
                ]
            )
            slope_columns.extend(
                [
                    covariate * second_matrix[:, index]
                    for index in range(second_matrix.shape[1])
                ]
            )
        expanded = np.column_stack([design, *slope_columns])
        expanded_rank = int(np.linalg.matrix_rank(expanded))
        numerator_df = expanded_rank - design_rank
        if numerator_df > 0 and response.size > expanded.shape[1]:
            expanded_fit = _fit_ols(response, expanded)
            statistic = (
                (full_rss - expanded_fit["residual_sum_squares"])
                / numerator_df
                / expanded_fit["mean_square_error"]
            )
            p_value = float(
                scipy_stats.f.sf(
                    statistic,
                    numerator_df,
                    expanded_fit["residual_degrees_of_freedom"],
                )
            )
            slope_test = {
                "status": "completed",
                "method": "joint factor-by-covariate homogeneity-of-slopes test",
                "f_statistic": statistic,
                "degrees_of_freedom": [
                    numerator_df,
                    expanded_fit["residual_degrees_of_freedom"],
                ],
                "p_value": p_value,
                "decision": decision_from_pvalue(p_value, alpha),
            }

    mean_variance = np.sum((design @ covariance) * design, axis=1)
    mean_se = np.sqrt(np.maximum(0.0, mean_variance))
    prediction_se = np.sqrt(mean_square_error + mean_variance)
    prediction_rows = []
    for position, source_index in enumerate(complete.index):
        prediction_rows.append(
            {
                "model_family": "ancova" if covariate_names else "two_way_anova",
                "model_name": model_name or "Factorial model",
                "source_index": str(source_index),
                "outcome_variable": outcome_name,
                "observed": finite_or_none(response[position]),
                "predicted": finite_or_none(fit["fitted"][position]),
                "residual": finite_or_none(fit["residuals"][position]),
                "mean_ci_lower": finite_or_none(
                    fit["fitted"][position] - critical * mean_se[position]
                ),
                "mean_ci_upper": finite_or_none(
                    fit["fitted"][position] + critical * mean_se[position]
                ),
                "prediction_interval_lower": finite_or_none(
                    fit["fitted"][position] - critical * prediction_se[position]
                ),
                "prediction_interval_upper": finite_or_none(
                    fit["fitted"][position] + critical * prediction_se[position]
                ),
            }
        )

    result.update(
        {
            "status": "completed",
            "design_matrix_rank": design_rank,
            "coefficients": coefficients,
            "type_iii_effect_tests": effect_tests,
            "overall_model_test": {
                "f_statistic": overall_f,
                "degrees_of_freedom": [model_df, residual_df],
                "p_value": overall_p,
                "decision": decision_from_pvalue(overall_p, alpha),
            },
            "residual_degrees_of_freedom": residual_df,
            "residual_mean_square": mean_square_error,
            "r_squared": 1.0 - full_rss / total_ss,
            "adjusted_r_squared": 1.0
            - (full_rss / residual_df) / (total_ss / (response.size - 1)),
            "cell_descriptives": cell_descriptives,
            "estimated_marginal_means": _marginal_means(
                first_factor,
                second_factor,
                first_categories,
                second_categories,
                covariate_names,
                covariate_means,
                estimates,
                covariance,
                residual_df,
                alpha,
                adjustment,
            ),
            "assumption_checks": {
                "residual_normality_tests": normality_tests(
                    pd.Series(fit["residuals"]), alpha
                ),
                "levene_test": {
                    "method": "Brown-Forsythe Levene test across factor cells",
                    "statistic": finite_or_none(levene.statistic),
                    "p_value": finite_or_none(levene.pvalue),
                    "decision": decision_from_pvalue(float(levene.pvalue), alpha),
                },
                "breusch_pagan_test": _breusch_pagan_test(
                    fit["residuals"], design, alpha
                ),
                "homogeneity_of_slopes_test": slope_test,
            },
            "residual_summary": _residual_summary(fit["residuals"]),
            "prediction_rows": prediction_rows,
        }
    )
    return result
