"""Negative-binomial regression for overdispersed count outcomes."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd
from scipy import optimize as scipy_optimize
from scipy import special as scipy_special
from scipy import stats as scipy_stats

from .logistic import _condition_number, _safe_exp
from .multiple_regression import _residual_summary, _variance_inflation_factors
from .numerical import (
    NumericalComputationError,
    covariance_from_information,
    delta_method_covariance,
    numerical_hessian_from_gradient,
    optimizer_convergence_diagnostics,
    statistical_numerical_status,
)
from .poisson import (
    _count_influence,
    _prepare_count_design,
    poisson_regression,
)
from .utils import decision_from_pvalue, finite_or_none


def _negative_binomial_objective(
    parameters: np.ndarray,
    response: np.ndarray,
    design: np.ndarray,
    offset: np.ndarray,
) -> tuple[float, np.ndarray]:
    coefficient_count = design.shape[1]
    estimates = parameters[:coefficient_count]
    log_dispersion = float(parameters[-1])
    dispersion = math.exp(log_dispersion)
    size = 1.0 / dispersion
    linear_predictor = offset + design @ estimates
    fitted = np.exp(np.clip(linear_predictor, -700.0, 700.0))
    log_size_plus_mean = np.log(size + fitted)
    log_likelihood_terms = (
        scipy_special.gammaln(response + size)
        - scipy_special.gammaln(size)
        - scipy_special.gammaln(response + 1.0)
        + size * (math.log(size) - log_size_plus_mean)
        + response * (linear_predictor - log_size_plus_mean)
    )
    beta_gradient = design.T @ (
        (fitted - response) / (1.0 + dispersion * fitted)
    )
    derivative_by_size = (
        scipy_special.digamma(response + size)
        - scipy_special.digamma(size)
        + math.log(size)
        - log_size_plus_mean
        + 1.0
        - (size + response) / (size + fitted)
    )
    log_dispersion_gradient = size * float(np.sum(derivative_by_size))
    gradient = np.concatenate(
        [beta_gradient, np.asarray([log_dispersion_gradient])]
    )
    return -float(np.sum(log_likelihood_terms)), gradient


def _fit_negative_binomial(
    response: np.ndarray,
    design: np.ndarray,
    offset: np.ndarray,
) -> dict[str, Any]:
    coefficient_count = design.shape[1]
    initial = np.zeros(coefficient_count + 1, dtype=float)
    initial[0] = math.log(float(np.sum(response))) - float(
        scipy_special.logsumexp(offset)
    )
    sample_mean = float(np.mean(response))
    sample_variance = float(np.var(response, ddof=1))
    moment_dispersion = (
        max((sample_variance - sample_mean) / sample_mean**2, 0.05)
        if sample_mean > 0
        else 0.1
    )
    initial[-1] = math.log(min(moment_dispersion, 10.0))
    bounds = [(None, None)] * coefficient_count + [(-12.0, 8.0)]
    optimization = scipy_optimize.minimize(
        lambda values: _negative_binomial_objective(
            values, response, design, offset
        )[0],
        initial,
        jac=lambda values: _negative_binomial_objective(
            values, response, design, offset
        )[1],
        method="L-BFGS-B",
        bounds=bounds,
        options={
            "maxiter": 4000,
            "ftol": 1e-15,
            "gtol": 1e-9,
            "maxcor": 40,
            "maxls": 60,
        },
    )
    parameters = np.asarray(optimization.x, dtype=float)
    objective, gradient = _negative_binomial_objective(
        parameters, response, design, offset
    )
    return {
        "parameters": parameters,
        "negative_log_likelihood": objective,
        "gradient": gradient,
        "optimization": optimization,
    }


def negative_binomial_regression(
    frame: pd.DataFrame,
    outcome_name: str,
    predictor_names: list[str],
    categorical_predictors: set[str],
    alpha: float,
    model_name: str | None = None,
    polynomial_terms: dict[str, int] | None = None,
    interactions: list[tuple[str, str]] | None = None,
    offset_name: str | None = None,
    exposure_name: str | None = None,
) -> dict[str, Any]:
    """Fit an NB2 log-link model with variance mu + dispersion * mu squared."""
    prepared = _prepare_count_design(
        frame,
        outcome_name,
        predictor_names,
        categorical_predictors,
        polynomial_terms,
        interactions,
        offset_name,
        exposure_name,
    )
    response = np.asarray(prepared["outcome"], dtype=float)
    design = prepared["design"]
    offset = prepared["offset"]
    observation_count, coefficient_count = design.shape
    total_parameter_count = coefficient_count + 1
    result: dict[str, Any] = {
        "method": "negative-binomial regression (NB2) with log link",
        "model_name": model_name,
        "outcome_variable": outcome_name,
        "predictors": predictor_names,
        "categorical_predictors": [
            name for name in predictor_names if name in categorical_predictors
        ],
        "categorical_codings": prepared["categorical_codings"],
        "polynomial_terms": prepared["polynomial_terms"],
        "interactions": prepared["interactions"],
        "offset_variable": offset_name,
        "exposure_variable": exposure_name,
        "offset_scale": (
            "log exposure supplied directly"
            if offset_name is not None
            else "natural logarithm of exposure"
            if exposure_name is not None
            else None
        ),
        "variance_function": "Var(Y|X) = mu + dispersion * mu^2",
        "total_rows": int(len(frame)),
        "n_complete_cases": int(observation_count),
        "excluded_rows": int(len(frame) - observation_count),
        "regression_parameter_count": int(coefficient_count),
        "parameter_count": int(total_parameter_count),
        "terms": prepared["terms"],
    }
    if prepared["invalid_reason"]:
        result.update(status="not_run", reason=prepared["invalid_reason"])
        return result
    if prepared["offset_error"]:
        result.update(status="not_run", reason=prepared["offset_error"])
        return result
    if observation_count == 0:
        result.update(status="not_run", reason="no complete numeric observations")
        return result
    if np.any(response < 0) or np.any(~np.isclose(response, np.round(response))):
        result.update(
            status="not_run",
            reason="negative-binomial regression requires nonnegative integer counts",
        )
        return result
    if float(np.sum(response)) <= 0:
        result.update(
            status="not_run",
            reason="at least one positive outcome count is required",
        )
        return result
    if observation_count <= total_parameter_count:
        result.update(
            status="not_run",
            reason="requires more observations than estimated parameters",
        )
        return result
    design_rank = int(np.linalg.matrix_rank(design))
    if design_rank < coefficient_count:
        result.update(
            status="not_run",
            reason="the design matrix is rank deficient",
            design_matrix_rank=design_rank,
        )
        return result

    fitted_model = _fit_negative_binomial(response, design, offset)
    optimization = fitted_model["optimization"]
    parameters = fitted_model["parameters"]
    optimization_diagnostics = optimizer_convergence_diagnostics(
        optimization,
        parameters=parameters,
        objective_value=fitted_model["negative_log_likelihood"],
        gradient=fitted_model["gradient"],
        method="L-BFGS-B",
    )
    gradient_norm = optimization_diagnostics["gradient_infinity_norm"]
    if not optimization_diagnostics["converged"]:
        failure_reason = f"maximum-likelihood optimization failed: {optimization.message}"
        result.update(
            status="not_run",
            reason=failure_reason,
            convergence=optimization_diagnostics,
            numerical_status=statistical_numerical_status(
                optimization=optimization_diagnostics,
                covariance_available=False,
                inference_available=False,
                failure_reason=failure_reason,
            ),
        )
        return result

    estimates = parameters[:coefficient_count]
    log_dispersion = float(parameters[-1])
    dispersion = math.exp(log_dispersion)
    dispersion_boundary = log_dispersion < -10.0
    size = 1.0 / dispersion
    linear_predictor = offset + design @ estimates
    fitted = np.exp(np.clip(linear_predictor, -700.0, 700.0))
    try:
        hessian, numerical_hessian_diagnostics = numerical_hessian_from_gradient(
            lambda values: _negative_binomial_objective(
                values, response, design, offset
            )[1],
            parameters,
        )
        covariance, information_diagnostics = covariance_from_information(hessian)
    except NumericalComputationError as exc:
        failure_reason = f"observed-information covariance calculation failed: {exc}"
        result.update(
            status="not_run",
            reason=failure_reason,
            convergence=optimization_diagnostics,
            information_matrix_diagnostics=exc.diagnostics,
            numerical_status=statistical_numerical_status(
                optimization=optimization_diagnostics,
                information=exc.diagnostics,
                covariance_available=False,
                inference_available=False,
                failure_reason=failure_reason,
            ),
        )
        return result
    information_rank = int(information_diagnostics["rank"])
    covariance_diagonal = np.diag(covariance)
    standard_errors = np.sqrt(covariance_diagonal[:coefficient_count])
    z_statistics = estimates / standard_errors
    p_values = 2.0 * scipy_stats.norm.sf(np.abs(z_statistics))
    critical = float(scipy_stats.norm.ppf(1.0 - alpha / 2.0))
    coefficients = []
    for index, term in enumerate(prepared["terms"]):
        lower = estimates[index] - critical * standard_errors[index]
        upper = estimates[index] + critical * standard_errors[index]
        coefficients.append(
            {
                "term": term,
                "predictor": prepared["term_predictors"][index],
                "term_type": prepared["term_types"][index],
                "estimate": finite_or_none(estimates[index]),
                "standard_error": finite_or_none(standard_errors[index]),
                "z_statistic": finite_or_none(z_statistics[index]),
                "p_value": finite_or_none(p_values[index]),
                "confidence_interval": [
                    finite_or_none(lower),
                    finite_or_none(upper),
                ],
                "incidence_rate_ratio": _safe_exp(estimates[index]),
                "incidence_rate_ratio_confidence_interval": [
                    _safe_exp(lower),
                    _safe_exp(upper),
                ],
            }
        )

    log_likelihood = -float(fitted_model["negative_log_likelihood"])
    null_model = _fit_negative_binomial(
        response, np.ones((observation_count, 1), dtype=float), offset
    )
    null_log_likelihood = -float(null_model["negative_log_likelihood"])
    likelihood_ratio = max(0.0, 2.0 * (log_likelihood - null_log_likelihood))
    model_degrees_of_freedom = coefficient_count - 1
    likelihood_ratio_p = (
        float(scipy_stats.chi2.sf(likelihood_ratio, model_degrees_of_freedom))
        if model_degrees_of_freedom > 0
        else None
    )
    dispersion_standard_error_log = math.sqrt(covariance_diagonal[-1])
    transformation_jacobian = np.zeros(
        (coefficient_count + 2, total_parameter_count), dtype=float
    )
    transformation_jacobian[:coefficient_count, :coefficient_count] = np.eye(
        coefficient_count
    )
    transformation_jacobian[coefficient_count, -1] = dispersion
    transformation_jacobian[coefficient_count + 1, -1] = -size
    transformed_covariance = delta_method_covariance(
        covariance, transformation_jacobian
    )
    dispersion_standard_error = math.sqrt(
        float(transformed_covariance[coefficient_count, coefficient_count])
    )
    size_standard_error = math.sqrt(
        float(transformed_covariance[coefficient_count + 1, coefficient_count + 1])
    )
    dispersion_interval = (
        None
        if dispersion_boundary
        else [
            math.exp(log_dispersion - critical * dispersion_standard_error_log),
            math.exp(log_dispersion + critical * dispersion_standard_error_log),
        ]
    )

    poisson = poisson_regression(
        frame,
        outcome_name,
        predictor_names,
        categorical_predictors,
        alpha,
        "Poisson comparison model",
        polynomial_terms,
        interactions,
        offset_name,
        exposure_name,
    )
    if poisson.get("status") == "completed":
        poisson_comparison_statistic = max(
            0.0, 2.0 * (log_likelihood - poisson["log_likelihood"])
        )
        poisson_comparison_p = (
            1.0
            if poisson_comparison_statistic <= 1e-12
            else 0.5
            * float(scipy_stats.chi2.sf(poisson_comparison_statistic, 1))
        )
        poisson_comparison = {
            "status": "completed",
            "method": "boundary likelihood-ratio comparison of NB2 with Poisson",
            "statistic": poisson_comparison_statistic,
            "mixture_chi_square_p_value": poisson_comparison_p,
            "poisson_log_likelihood": poisson["log_likelihood"],
            "negative_binomial_log_likelihood": log_likelihood,
            "poisson_aic": poisson["aic"],
            "negative_binomial_aic": total_parameter_count * 2.0
            - 2.0 * log_likelihood,
            "poisson_pearson_dispersion": poisson["pearson_dispersion"],
            "interpretation": (
                "negative-binomial dispersion materially improves fit"
                if poisson_comparison_p < alpha
                else "insufficient evidence that negative-binomial dispersion improves fit"
            ),
            "note": "The null value dispersion = 0 is on the boundary, so the p-value uses a 50:50 point-mass/chi-square mixture.",
        }
    else:
        poisson_comparison = {
            "status": "not_run",
            "reason": poisson.get("reason", "Poisson comparison model failed"),
        }

    positive = response > 0
    first_term = np.zeros_like(response)
    first_term[positive] = response[positive] * np.log(
        response[positive] / fitted[positive]
    )
    second_term = (response + size) * np.log(
        (response + size) / (fitted + size)
    )
    deviance_components = 2.0 * (first_term - second_term)
    deviance = float(np.sum(np.maximum(0.0, deviance_components)))
    variance = fitted + dispersion * fitted**2
    pearson_residuals = (response - fitted) / np.sqrt(variance)
    pearson_chi_square = float(np.sum(pearson_residuals**2))
    residual_degrees_of_freedom = observation_count - coefficient_count
    pearson_dispersion = pearson_chi_square / residual_degrees_of_freedom
    deviance_dispersion = deviance / residual_degrees_of_freedom
    deviance_residuals = np.sign(response - fitted) * np.sqrt(
        np.maximum(0.0, deviance_components)
    )
    fixed_covariance = covariance[:coefficient_count, :coefficient_count]
    linear_standard_errors = np.sqrt(
        np.maximum(
            0.0, np.sum((design @ fixed_covariance) * design, axis=1)
        )
    )
    prediction_rows = [
        {
            "model_family": "negative_binomial_regression",
            "model_name": model_name or "Negative-binomial model",
            "source_index": str(source_index),
            "outcome_variable": outcome_name,
            "observed": finite_or_none(response[index]),
            "predicted": finite_or_none(fitted[index]),
            "residual": finite_or_none(response[index] - fitted[index]),
            "pearson_residual": finite_or_none(pearson_residuals[index]),
            "mean_ci_lower": finite_or_none(
                math.exp(
                    max(-745.0, linear_predictor[index] - critical * linear_standard_errors[index])
                )
            ),
            "mean_ci_upper": (
                finite_or_none(
                    math.exp(
                        linear_predictor[index]
                        + critical * linear_standard_errors[index]
                    )
                )
                if linear_predictor[index]
                + critical * linear_standard_errors[index]
                <= 709.0
                else None
            ),
        }
        for index, source_index in enumerate(prepared["complete_frame"].index)
    ]
    warnings = [
        warning
        for warning, condition in (
            (
                "The dispersion estimate is near zero; the negative-binomial model is approaching Poisson regression.",
                dispersion_boundary,
            ),
            (
                "The dispersion estimate is near the optimizer's upper bound; estimates may be unstable.",
                log_dispersion > 7.5,
            ),
            (
                "Pearson dispersion remains above 1.5 after fitting NB2; the variance structure may still be inadequate.",
                pearson_dispersion > 1.5,
            ),
            (
                "At least one coefficient has absolute value above 20; estimates may be unstable.",
                bool(np.max(np.abs(estimates)) > 20),
            ),
            (
                "There are fewer than 10 observed events per regression parameter.",
                float(np.sum(response)) < 10 * coefficient_count,
            ),
            (
                "The numerical Hessian changed materially when its finite-difference step was halved.",
                not numerical_hessian_diagnostics["step_stable"],
            ),
        )
        if condition
    ]
    result.update(
        {
            "status": "completed",
            "design_matrix_rank": design_rank,
            "information_matrix_rank": information_rank,
            "observed_information_type": (
                "numerical Hessian of the negative log-likelihood obtained from the analytic gradient"
            ),
            "observed_information_matrix": hessian.tolist(),
            "optimizer_scale_covariance_matrix": covariance.tolist(),
            "covariance_type": "model-based inverse observed information; not sandwich",
            "information_matrix_diagnostics": information_diagnostics,
            "numerical_hessian_diagnostics": numerical_hessian_diagnostics,
            "transformed_parameter_names": [
                *prepared["terms"],
                "dispersion",
                "negative_binomial_size",
            ],
            "transformed_parameter_covariance_matrix": transformed_covariance.tolist(),
            "convergence": optimization_diagnostics,
            "numerical_status": statistical_numerical_status(
                optimization=optimization_diagnostics,
                information=information_diagnostics,
                differentiation=numerical_hessian_diagnostics,
                covariance_available=True,
                inference_available=not dispersion_boundary,
                boundary=(
                    "Dispersion is effectively on its zero boundary."
                    if dispersion_boundary
                    else None
                ),
            ),
            "coefficients": coefficients,
            "dispersion_parameter": dispersion,
            "dispersion_standard_error_log_scale": dispersion_standard_error_log,
            "dispersion_standard_error": dispersion_standard_error,
            "dispersion_confidence_interval": dispersion_interval,
            "dispersion_wald_inference": (
                {
                    "status": "boundary",
                    "reason": (
                        "Dispersion is effectively on its zero boundary, so an "
                        "ordinary two-sided Wald interval is not reported; use "
                        "the Poisson boundary likelihood-ratio comparison."
                    ),
                }
                if dispersion_boundary
                else {"status": "completed"}
            ),
            "negative_binomial_size": size,
            "negative_binomial_size_standard_error": size_standard_error,
            "assumption_warnings": warnings,
            "log_likelihood": log_likelihood,
            "null_log_likelihood": null_log_likelihood,
            "likelihood_ratio_statistic": likelihood_ratio,
            "likelihood_ratio_degrees_of_freedom": model_degrees_of_freedom,
            "likelihood_ratio_p_value": finite_or_none(likelihood_ratio_p),
            "decision": (
                decision_from_pvalue(likelihood_ratio_p, alpha)
                if likelihood_ratio_p is not None
                else "not applicable"
            ),
            "aic": 2.0 * total_parameter_count - 2.0 * log_likelihood,
            "bic": total_parameter_count * math.log(observation_count)
            - 2.0 * log_likelihood,
            "mcfadden_r_squared": 1.0 - log_likelihood / null_log_likelihood,
            "poisson_comparison": poisson_comparison,
            "residual_degrees_of_freedom": residual_degrees_of_freedom,
            "deviance": deviance,
            "deviance_dispersion": deviance_dispersion,
            "pearson_chi_square": pearson_chi_square,
            "pearson_dispersion": pearson_dispersion,
            "goodness_of_fit": {
                "deviance_p_value": float(
                    scipy_stats.chi2.sf(deviance, residual_degrees_of_freedom)
                ),
                "pearson_p_value": float(
                    scipy_stats.chi2.sf(
                        pearson_chi_square, residual_degrees_of_freedom
                    )
                ),
                "note": "Chi-square approximations; small expected counts can reduce their accuracy.",
            },
            "prediction_metrics": {
                "mean_observed_count": finite_or_none(np.mean(response)),
                "mean_fitted_count": finite_or_none(np.mean(fitted)),
                "mean_absolute_error": finite_or_none(
                    np.mean(np.abs(response - fitted))
                ),
                "root_mean_squared_error": finite_or_none(
                    np.sqrt(np.mean((response - fitted) ** 2))
                ),
                "observed_zero_rate": finite_or_none(np.mean(response == 0)),
                "mean_predicted_zero_probability": finite_or_none(
                    np.mean((size / (size + fitted)) ** size)
                ),
            },
            "pearson_residual_summary": _residual_summary(pearson_residuals),
            "deviance_residual_summary": _residual_summary(deviance_residuals),
            "condition_number_standardized_design": _condition_number(design),
            "variance_inflation_factors": _variance_inflation_factors(
                design, prepared["terms"]
            ),
            "influence_diagnostics": _count_influence(
                prepared["complete_frame"],
                response,
                fitted,
                design,
                covariance[:coefficient_count, :coefficient_count],
                variance,
                fitted / (1.0 + dispersion * fitted),
            ),
            "prediction_rows": prediction_rows,
        }
    )
    return result
