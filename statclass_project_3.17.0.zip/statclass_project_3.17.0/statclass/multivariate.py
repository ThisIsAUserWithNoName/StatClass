"""Principal components, one-way MANOVA, and linear discriminant analysis."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd
from scipy import linalg as scipy_linalg
from scipy import stats as scipy_stats

from .data import DataError
from .utils import decision_from_pvalue, finite_or_none


def _source_index(value: Any) -> int | str:
    if isinstance(value, (np.integer, int)):
        return int(value)
    return str(value)


def _complete_numeric_frame(
    frame: pd.DataFrame,
    column_names: list[str],
) -> pd.DataFrame:
    working = frame[column_names].apply(pd.to_numeric, errors="coerce")
    working = working.replace([np.inf, -np.inf], np.nan).dropna()
    return working


def principal_component_analysis(
    frame: pd.DataFrame,
    variable_names: list[str],
    component_count: int | None = None,
    standardize: bool = True,
    analysis_name: str = "PCA 1",
) -> dict[str, Any]:
    """Fit PCA by singular-value decomposition using complete observations."""
    if len(variable_names) < 2:
        raise DataError("PCA requires at least two numeric variables")
    if len(set(variable_names)) != len(variable_names):
        raise DataError("PCA variables must be different")

    complete = _complete_numeric_frame(frame, variable_names)
    observation_count = int(complete.shape[0])
    variable_count = len(variable_names)
    if observation_count < 2:
        raise DataError("PCA requires at least two complete observations")

    values = complete.to_numpy(dtype=float)
    means = np.mean(values, axis=0)
    standard_deviations = np.std(values, axis=0, ddof=1)
    constant_indices = np.flatnonzero(
        ~np.isfinite(standard_deviations) | (standard_deviations <= 0.0)
    )
    if constant_indices.size:
        constants = ", ".join(variable_names[index] for index in constant_indices)
        raise DataError(f"PCA variables must vary; constant columns: {constants}")

    centered = values - means
    analyzed = centered / standard_deviations if standardize else centered
    _, singular_values, right_vectors = np.linalg.svd(analyzed, full_matrices=False)
    maximum_components = min(variable_count, observation_count - 1)
    if component_count is None:
        retained_components = maximum_components
    else:
        if component_count < 1:
            raise DataError("--pca-components must be a positive integer")
        if component_count > maximum_components:
            raise DataError(
                "--pca-components cannot exceed "
                f"{maximum_components} for this PCA"
            )
        retained_components = component_count

    eigenvectors = right_vectors[:maximum_components].T.copy()
    for component in range(eigenvectors.shape[1]):
        anchor = int(np.argmax(np.abs(eigenvectors[:, component])))
        if eigenvectors[anchor, component] < 0.0:
            eigenvectors[:, component] *= -1.0
    eigenvalues = singular_values[:maximum_components] ** 2 / (observation_count - 1)
    total_variance = float(np.sum(eigenvalues))
    if not math.isfinite(total_variance) or total_variance <= 0.0:
        raise DataError("PCA requires positive total variance")
    explained = eigenvalues / total_variance
    scores = analyzed @ eigenvectors

    correlations = np.empty_like(eigenvectors)
    for variable in range(variable_count):
        for component in range(maximum_components):
            correlations[variable, component] = np.corrcoef(
                values[:, variable], scores[:, component]
            )[0, 1]

    components = []
    cumulative = 0.0
    for index in range(maximum_components):
        cumulative += float(explained[index])
        components.append(
            {
                "component": f"PC{index + 1}",
                "eigenvalue": float(eigenvalues[index]),
                "explained_variance_ratio": float(explained[index]),
                "cumulative_explained_variance_ratio": cumulative,
                "retained": index < retained_components,
            }
        )

    loadings = []
    for variable_index, variable_name in enumerate(variable_names):
        row: dict[str, Any] = {"variable": variable_name}
        for component in range(retained_components):
            row[f"PC{component + 1}_coefficient"] = float(
                eigenvectors[variable_index, component]
            )
            row[f"PC{component + 1}_correlation"] = float(
                correlations[variable_index, component]
            )
        loadings.append(row)

    score_rows = []
    for row_index, source_index in enumerate(complete.index):
        row = {
            "analysis_name": analysis_name,
            "source_index": _source_index(source_index),
        }
        for component in range(retained_components):
            row[f"PC{component + 1}"] = float(scores[row_index, component])
        score_rows.append(row)

    return {
        "analysis_type": "principal_component_analysis",
        "analysis_name": analysis_name,
        "status": "completed",
        "variables": variable_names,
        "n": observation_count,
        "missing_rows_removed": int(frame.shape[0] - observation_count),
        "variable_count": variable_count,
        "standardized": standardize,
        "matrix_analyzed": "correlation" if standardize else "covariance",
        "retained_component_count": retained_components,
        "maximum_component_count": maximum_components,
        "variable_means": {
            name: float(value) for name, value in zip(variable_names, means)
        },
        "variable_standard_deviations": {
            name: float(value)
            for name, value in zip(variable_names, standard_deviations)
        },
        "components": components,
        "loadings": loadings,
        "score_rows": score_rows,
    }


def _manova_statistics(
    roots: np.ndarray,
    response_count: int,
    hypothesis_df: int,
    error_df: int,
    alpha: float,
) -> list[dict[str, Any]]:
    """Return the four common MANOVA statistics and F approximations."""
    p = float(response_count)
    q = float(hypothesis_df)
    s = float(min(response_count, hypothesis_df))
    m = 0.5 * (abs(p - q) - 1.0)
    n = 0.5 * (error_df - p - 1.0)

    pillai = float(np.sum(roots / (1.0 + roots)))
    pillai_tmp_1 = 2.0 * m + s + 1.0
    pillai_tmp_2 = 2.0 * n + s + 1.0
    pillai_f = (
        (pillai_tmp_2 / pillai_tmp_1) * pillai / (s - pillai)
        if pillai < s
        else math.inf
    )
    pillai_df_1 = s * pillai_tmp_1
    pillai_df_2 = s * pillai_tmp_2

    wilks = float(np.prod(1.0 / (1.0 + roots)))
    wilks_tmp_1 = error_df - 0.5 * (p - q + 1.0)
    wilks_tmp_2 = (p * q - 2.0) / 4.0
    denominator = p**2 + q**2 - 5.0
    wilks_power = (
        math.sqrt(((p * q) ** 2 - 4.0) / denominator)
        if denominator > 0.0
        else 1.0
    )
    wilks_df_1 = p * q
    wilks_df_2 = wilks_tmp_1 * wilks_power - 2.0 * wilks_tmp_2
    wilks_f = (
        (wilks ** (-1.0 / wilks_power) - 1.0)
        * wilks_df_2
        / wilks_df_1
    )

    hotelling = float(np.sum(roots))
    hotelling_tmp_1 = 2.0 * m + s + 1.0
    hotelling_tmp_2 = 2.0 * (s * n + 1.0)
    hotelling_df_1 = s * hotelling_tmp_1
    hotelling_df_2 = hotelling_tmp_2
    hotelling_f = (
        hotelling_tmp_2 * hotelling / (s**2 * hotelling_tmp_1)
    )

    roy = float(np.max(roots))
    roy_df_1 = max(p, q)
    roy_df_2 = error_df - roy_df_1 + q
    roy_f = roy_df_2 * roy / roy_df_1

    rows = [
        ("Pillai trace", pillai, pillai_f, pillai_df_1, pillai_df_2),
        ("Wilks lambda", wilks, wilks_f, wilks_df_1, wilks_df_2),
        (
            "Hotelling-Lawley trace",
            hotelling,
            hotelling_f,
            hotelling_df_1,
            hotelling_df_2,
        ),
        ("Roy largest root", roy, roy_f, roy_df_1, roy_df_2),
    ]
    results = []
    for method, statistic, f_value, df_1, df_2 in rows:
        p_value = (
            float(scipy_stats.f.sf(f_value, df_1, df_2))
            if df_1 > 0.0 and df_2 > 0.0 and f_value >= 0.0
            else math.nan
        )
        results.append(
            {
                "method": method,
                "statistic": finite_or_none(statistic),
                "f_approximation": finite_or_none(f_value),
                "degrees_of_freedom_numerator": finite_or_none(df_1),
                "degrees_of_freedom_denominator": finite_or_none(df_2),
                "p_value": finite_or_none(p_value),
                "decision": decision_from_pvalue(p_value, alpha),
            }
        )
    return results


def one_way_manova(
    frame: pd.DataFrame,
    group_name: str,
    response_names: list[str],
    alpha: float,
    analysis_name: str = "MANOVA 1",
) -> dict[str, Any]:
    """Test equality of multivariate group means for one categorical factor."""
    if len(response_names) < 2:
        raise DataError("MANOVA requires at least two numeric response variables")
    if len(set(response_names)) != len(response_names):
        raise DataError("MANOVA response variables must be different")
    if group_name in response_names:
        raise DataError("MANOVA group and response columns must be different")

    working = frame[[group_name, *response_names]].copy()
    for response in response_names:
        working[response] = pd.to_numeric(working[response], errors="coerce")
    response_values = working[response_names].to_numpy(dtype=float)
    usable = working[group_name].notna().to_numpy() & np.all(
        np.isfinite(response_values), axis=1
    )
    working = working.loc[usable].copy()
    if working.empty:
        raise DataError("MANOVA requires complete group and response observations")
    working[group_name] = working[group_name].map(str)
    group_labels = list(pd.unique(working[group_name]))
    group_count = len(group_labels)
    response_count = len(response_names)
    observation_count = int(working.shape[0])
    if group_count < 2:
        raise DataError("MANOVA requires at least two observed groups")
    group_sizes = {
        label: int(np.sum(working[group_name].to_numpy() == label))
        for label in group_labels
    }
    if min(group_sizes.values()) < 2:
        raise DataError("MANOVA requires at least two complete observations per group")

    hypothesis_df = group_count - 1
    error_df = observation_count - group_count
    if error_df < response_count:
        raise DataError(
            "MANOVA needs error degrees of freedom at least as large as the "
            "number of responses"
        )

    values = working[response_names].to_numpy(dtype=float)
    grand_mean = np.mean(values, axis=0)
    error_sscp = np.zeros((response_count, response_count), dtype=float)
    hypothesis_sscp = np.zeros_like(error_sscp)
    group_summaries = []
    for label in group_labels:
        group_values = working.loc[
            working[group_name] == label, response_names
        ].to_numpy(dtype=float)
        mean = np.mean(group_values, axis=0)
        centered = group_values - mean
        error_sscp += centered.T @ centered
        difference = mean - grand_mean
        hypothesis_sscp += group_values.shape[0] * np.outer(difference, difference)
        group_summaries.append(
            {
                "group": label,
                "n": int(group_values.shape[0]),
                "means": {
                    name: float(value) for name, value in zip(response_names, mean)
                },
                "standard_deviations": {
                    name: float(value)
                    for name, value in zip(
                        response_names, np.std(group_values, axis=0, ddof=1)
                    )
                },
            }
        )

    error_rank = int(np.linalg.matrix_rank(error_sscp))
    if error_rank < response_count:
        raise DataError(
            "MANOVA within-group covariance matrix is singular; remove redundant "
            "responses or add observations"
        )
    roots = scipy_linalg.eigvalsh(hypothesis_sscp, error_sscp)
    roots = np.sort(np.maximum(np.real(roots), 0.0))[::-1]
    roots = roots[: min(response_count, hypothesis_df)]
    tests = _manova_statistics(
        roots, response_count, hypothesis_df, error_df, alpha
    )

    univariate_tests = []
    for response_index, response_name in enumerate(response_names):
        samples = [
            working.loc[working[group_name] == label, response_name].to_numpy(
                dtype=float
            )
            for label in group_labels
        ]
        f_result = scipy_stats.f_oneway(*samples)
        between_ss = float(hypothesis_sscp[response_index, response_index])
        total_ss = between_ss + float(error_sscp[response_index, response_index])
        p_value = float(f_result.pvalue)
        univariate_tests.append(
            {
                "response": response_name,
                "f_statistic": float(f_result.statistic),
                "degrees_of_freedom_numerator": hypothesis_df,
                "degrees_of_freedom_denominator": error_df,
                "p_value": p_value,
                "eta_squared": between_ss / total_ss if total_ss > 0.0 else None,
                "decision": decision_from_pvalue(p_value, alpha),
            }
        )

    return {
        "analysis_type": "one_way_manova",
        "analysis_name": analysis_name,
        "status": "completed",
        "group_variable": group_name,
        "response_variables": response_names,
        "n": observation_count,
        "missing_rows_removed": int(frame.shape[0] - observation_count),
        "group_count": group_count,
        "group_labels": group_labels,
        "group_sizes": group_sizes,
        "hypothesis_degrees_of_freedom": hypothesis_df,
        "error_degrees_of_freedom": error_df,
        "grand_means": {
            name: float(value) for name, value in zip(response_names, grand_mean)
        },
        "group_summaries": group_summaries,
        "hypothesis_sscp": hypothesis_sscp.tolist(),
        "error_sscp": error_sscp.tolist(),
        "canonical_roots": roots.tolist(),
        "multivariate_tests": tests,
        "follow_up_univariate_anovas": univariate_tests,
        "null_hypothesis": "all group population mean vectors are equal",
        "assumption_note": (
            "F approximations assume independent observations, multivariate "
            "normality within groups, and comparable covariance matrices."
        ),
    }


def _classification_summary(
    actual: np.ndarray,
    predicted: np.ndarray,
    probabilities: np.ndarray,
    class_labels: list[str],
) -> dict[str, Any]:
    class_count = len(class_labels)
    matrix = np.zeros((class_count, class_count), dtype=int)
    label_to_index = {label: index for index, label in enumerate(class_labels)}
    actual_indices = np.asarray([label_to_index[label] for label in actual])
    predicted_indices = np.asarray([label_to_index[label] for label in predicted])
    for actual_index, predicted_index in zip(actual_indices, predicted_indices):
        matrix[actual_index, predicted_index] += 1

    per_class = []
    for index, label in enumerate(class_labels):
        true_positive = int(matrix[index, index])
        false_positive = int(np.sum(matrix[:, index]) - true_positive)
        false_negative = int(np.sum(matrix[index, :]) - true_positive)
        precision = (
            true_positive / (true_positive + false_positive)
            if true_positive + false_positive
            else 0.0
        )
        recall = (
            true_positive / (true_positive + false_negative)
            if true_positive + false_negative
            else 0.0
        )
        f1 = (
            2.0 * precision * recall / (precision + recall)
            if precision + recall
            else 0.0
        )
        per_class.append(
            {
                "class": label,
                "support": int(np.sum(matrix[index, :])),
                "precision": precision,
                "recall": recall,
                "f1_score": f1,
            }
        )
    observed_probabilities = np.clip(
        probabilities[np.arange(actual_indices.size), actual_indices],
        np.finfo(float).eps,
        1.0,
    )
    return {
        "confusion_matrix": matrix.tolist(),
        "row_categories_actual": class_labels,
        "column_categories_predicted": class_labels,
        "accuracy": float(np.mean(actual_indices == predicted_indices)),
        "log_loss": -float(np.mean(np.log(observed_probabilities))),
        "per_class": per_class,
    }


def _fit_lda(
    values: np.ndarray,
    labels: np.ndarray,
    class_labels: list[str],
    prior_method: str,
) -> dict[str, Any]:
    observation_count, feature_count = values.shape
    class_count = len(class_labels)
    class_means = np.vstack(
        [np.mean(values[labels == label], axis=0) for label in class_labels]
    )
    class_sizes = np.asarray(
        [np.sum(labels == label) for label in class_labels], dtype=float
    )
    priors = (
        np.repeat(1.0 / class_count, class_count)
        if prior_method == "equal"
        else class_sizes / observation_count
    )
    error_sscp = np.zeros((feature_count, feature_count), dtype=float)
    for index, label in enumerate(class_labels):
        centered = values[labels == label] - class_means[index]
        error_sscp += centered.T @ centered
    pooled_covariance = error_sscp / (observation_count - class_count)
    covariance_rank = int(np.linalg.matrix_rank(pooled_covariance))
    inverse_covariance = np.linalg.pinv(pooled_covariance, hermitian=True)
    coefficients = class_means @ inverse_covariance
    intercepts = (
        -0.5 * np.sum(coefficients * class_means, axis=1) + np.log(priors)
    )
    discriminant_scores = values @ coefficients.T + intercepts
    maximum_scores = np.max(discriminant_scores, axis=1, keepdims=True)
    relative = np.exp(discriminant_scores - maximum_scores)
    probabilities = relative / np.sum(relative, axis=1, keepdims=True)
    predicted = np.asarray(
        [class_labels[index] for index in np.argmax(probabilities, axis=1)]
    )
    return {
        "means": class_means,
        "sizes": class_sizes,
        "priors": priors,
        "pooled_covariance": pooled_covariance,
        "covariance_rank": covariance_rank,
        "inverse_covariance": inverse_covariance,
        "coefficients": coefficients,
        "intercepts": intercepts,
        "probabilities": probabilities,
        "predicted": predicted,
    }


def linear_discriminant_analysis(
    frame: pd.DataFrame,
    class_name: str,
    feature_names: list[str],
    prior_method: str = "empirical",
    analysis_name: str = "LDA 1",
) -> dict[str, Any]:
    """Fit Gaussian linear discriminant analysis with leave-one-out validation."""
    if prior_method not in {"empirical", "equal"}:
        raise DataError("discriminant priors must be empirical or equal")
    if len(feature_names) < 2:
        raise DataError("discriminant analysis requires at least two numeric features")
    if len(set(feature_names)) != len(feature_names):
        raise DataError("discriminant features must be different")
    if class_name in feature_names:
        raise DataError("discriminant class and feature columns must be different")

    working = frame[[class_name, *feature_names]].copy()
    for feature in feature_names:
        working[feature] = pd.to_numeric(working[feature], errors="coerce")
    values_all = working[feature_names].to_numpy(dtype=float)
    usable = working[class_name].notna().to_numpy() & np.all(
        np.isfinite(values_all), axis=1
    )
    working = working.loc[usable].copy()
    working[class_name] = working[class_name].map(str)
    observation_count = int(working.shape[0])
    if observation_count == 0:
        raise DataError("discriminant analysis requires complete observations")
    class_labels = list(pd.unique(working[class_name]))
    class_count = len(class_labels)
    feature_count = len(feature_names)
    if class_count < 2:
        raise DataError("discriminant analysis requires at least two classes")
    labels = working[class_name].to_numpy(dtype=str)
    class_sizes = {label: int(np.sum(labels == label)) for label in class_labels}
    if min(class_sizes.values()) < 2:
        raise DataError(
            "discriminant analysis requires at least two complete observations per class"
        )
    if observation_count <= class_count:
        raise DataError("discriminant analysis has no within-class degrees of freedom")
    values = working[feature_names].to_numpy(dtype=float)
    feature_sds = np.std(values, axis=0, ddof=1)
    if np.any(feature_sds <= 0.0):
        constants = ", ".join(
            feature_names[index] for index in np.flatnonzero(feature_sds <= 0.0)
        )
        raise DataError(
            f"discriminant features must vary; constant columns: {constants}"
        )

    fit = _fit_lda(values, labels, class_labels, prior_method)
    classification = _classification_summary(
        labels, fit["predicted"], fit["probabilities"], class_labels
    )

    loo_predicted = []
    loo_probabilities = []
    loo_failure: str | None = None
    for left_out in range(observation_count):
        keep = np.ones(observation_count, dtype=bool)
        keep[left_out] = False
        try:
            fold = _fit_lda(
                values[keep], labels[keep], class_labels, prior_method
            )
            coefficients = fold["coefficients"]
            fold_scores = values[left_out] @ coefficients.T + fold["intercepts"]
            relative = np.exp(fold_scores - np.max(fold_scores))
            probability = relative / np.sum(relative)
            loo_probabilities.append(probability)
            loo_predicted.append(class_labels[int(np.argmax(probability))])
        except (ValueError, np.linalg.LinAlgError) as exc:
            loo_failure = str(exc)
            break
    if loo_failure is None:
        cross_validation: dict[str, Any] = {
            "method": "leave-one-out",
            "status": "completed",
            **_classification_summary(
                labels,
                np.asarray(loo_predicted),
                np.asarray(loo_probabilities),
                class_labels,
            ),
        }
    else:
        cross_validation = {
            "method": "leave-one-out",
            "status": "not_run",
            "reason": loo_failure,
        }

    grand_mean = np.mean(values, axis=0)
    between_sscp = np.zeros((feature_count, feature_count), dtype=float)
    for index, label in enumerate(class_labels):
        difference = fit["means"][index] - grand_mean
        between_sscp += fit["sizes"][index] * np.outer(difference, difference)
    within_degrees_of_freedom = observation_count - class_count
    canonical_matrix = (
        fit["inverse_covariance"] @ between_sscp / within_degrees_of_freedom
    )
    canonical_values, canonical_vectors = np.linalg.eig(canonical_matrix)
    ordering = np.argsort(np.real(canonical_values))[::-1]
    canonical_values = np.maximum(np.real(canonical_values[ordering]), 0.0)
    canonical_vectors = np.real(canonical_vectors[:, ordering])
    dimension_count = min(feature_count, class_count - 1)
    canonical_values = canonical_values[:dimension_count]
    canonical_vectors = canonical_vectors[:, :dimension_count]
    for dimension in range(dimension_count):
        norm = float(np.linalg.norm(canonical_vectors[:, dimension]))
        if norm > 0.0:
            canonical_vectors[:, dimension] /= norm
        anchor = int(np.argmax(np.abs(canonical_vectors[:, dimension])))
        if canonical_vectors[anchor, dimension] < 0.0:
            canonical_vectors[:, dimension] *= -1.0
    canonical_scores = (values - grand_mean) @ canonical_vectors
    total_root = float(np.sum(canonical_values))
    canonical_dimensions = []
    cumulative = 0.0
    for index, root in enumerate(canonical_values):
        proportion = float(root / total_root) if total_root > 0.0 else 0.0
        cumulative += proportion
        canonical_dimensions.append(
            {
                "dimension": f"LD{index + 1}",
                "eigenvalue": float(root),
                "canonical_correlation": float(math.sqrt(root / (1.0 + root))),
                "explained_discrimination_ratio": proportion,
                "cumulative_explained_discrimination_ratio": cumulative,
                "coefficients": {
                    feature: float(canonical_vectors[feature_index, index])
                    for feature_index, feature in enumerate(feature_names)
                },
            }
        )

    score_rows = []
    for row_index, source_index in enumerate(working.index):
        row: dict[str, Any] = {
            "analysis_name": analysis_name,
            "source_index": _source_index(source_index),
            "observed_class": labels[row_index],
            "predicted_class": fit["predicted"][row_index],
            "correct": bool(labels[row_index] == fit["predicted"][row_index]),
        }
        for class_index, label in enumerate(class_labels):
            row[f"posterior_{label}"] = float(
                fit["probabilities"][row_index, class_index]
            )
        for dimension in range(dimension_count):
            row[f"LD{dimension + 1}"] = float(
                canonical_scores[row_index, dimension]
            )
        score_rows.append(row)

    class_details = []
    for index, label in enumerate(class_labels):
        class_details.append(
            {
                "class": label,
                "n": int(fit["sizes"][index]),
                "prior_probability": float(fit["priors"][index]),
                "feature_means": {
                    name: float(value)
                    for name, value in zip(feature_names, fit["means"][index])
                },
                "classification_coefficients": {
                    name: float(value)
                    for name, value in zip(feature_names, fit["coefficients"][index])
                },
                "classification_intercept": float(fit["intercepts"][index]),
            }
        )

    return {
        "analysis_type": "linear_discriminant_analysis",
        "analysis_name": analysis_name,
        "model_name": analysis_name,
        "status": "completed",
        "class_variable": class_name,
        "feature_variables": feature_names,
        "n": observation_count,
        "missing_rows_removed": int(frame.shape[0] - observation_count),
        "class_count": class_count,
        "class_labels": class_labels,
        "class_sizes": class_sizes,
        "prior_method": prior_method,
        "class_details": class_details,
        "pooled_covariance_matrix": fit["pooled_covariance"].tolist(),
        "pooled_covariance_rank": fit["covariance_rank"],
        "feature_count": feature_count,
        "used_generalized_inverse": fit["covariance_rank"] < feature_count,
        "classification": classification,
        "cross_validation": cross_validation,
        "canonical_dimensions": canonical_dimensions,
        "score_rows": score_rows,
        "assumption_note": (
            "LDA assumes independent observations, approximately multivariate "
            "normal features within classes, and a common within-class covariance matrix."
        ),
    }
