# StatClass 3.17.0 Example CSV Collection

This collection contains datasets prepared for the command-line interface in
StatClass 3.17.0. Most are artificial and designed specifically for learning,
software testing, demonstrations, and checking output formats.
`four_column_test.csv` is a lossless format conversion of a user-supplied
numeric test table whose scientific provenance is not specified. None of the
files should be used to draw scientific conclusions without independently
establishing its provenance and suitability.

The `csv` directory contains 17 example datasets. `example_commands.txt`
contains ready-to-copy Bash commands for every file. `csv_catalog.csv` is a
machine-readable index of the collection.

## Running the examples

Unpack both StatClass 3.17.0 and this example collection. From this example
directory, set `STATCLASS_DIR` to the StatClass directory:

```bash
STATCLASS_DIR="/path/to/statclass_project_3.17.0"
python "$STATCLASS_DIR/stats.py" csv/basic_inference_sample.csv
```

To execute every documented example and validate its JSON status in one run:

```bash
python verify_examples.py /path/to/statclass_project_3.17.0
```

The verifier treats the three `error_diagnostics_sample.csv` commands and the
two large-data guard commands for `four_column_test.csv` as intentional warning
or `not_run` demonstrations; an unexpected warning or non-completed status in
any ordinary example fails verification.

StatClass recognizes the first row as column names. The examples use those
names in every command, avoiding column-number ambiguity. Filenames and column
names should be entered exactly as shown.

## Dataset index

| CSV file | Rows | Data layout and principal uses |
|---|---:|---|
| `basic_inference_sample.csv` | 30 | Wide continuous data for summaries, normality, one- and two-sample tests, paired tests, ANOVA, correlation, simple regression, bootstrap, permutation, transformations, outliers, and plots |
| `nonparametric_sample.csv` | 20 | Independent and paired samples for Mann-Whitney, Wilcoxon, Kruskal-Wallis, and Dunn comparisons |
| `categorical_sample.csv` | 60 | Treatment, binary outcome, and color categories for frequency tables, crosstabs, chi-square, Fisher exact, goodness-of-fit, likelihood, and proportion tests |
| `discrete_distribution_sample.csv` | 30 | Columns for every supported discrete-estimation family: Bernoulli, binomial, geometric, Poisson, negative-binomial, discrete-uniform, hypergeometric, beta-binomial, and multinomial |
| `bayesian_sample.csv` | 40 | Binary, count, exposure, and continuous columns for all four conjugate Bayesian column interfaces |
| `regression_sample.csv` | 24 | Continuous outcome with two numeric predictors and one categorical predictor for OLS, model comparison, polynomial terms, and interactions |
| `robust_regularized_sample.csv` | 60 | Moderately correlated numeric predictors plus two intentional response outliers for Huber, ridge, lasso, and elastic-net regression |
| `smooth_estimation_sample.csv` | 60 | One predictor, a nonlinear response, a noisy monotone response, and a bimodal density sample for splines, LOESS, kernel regression, isotonic regression, and KDE |
| `four_column_test.csv` | 20,480 | A tall full-column-rank numeric matrix for loading, summaries, inference, correlation, regression, PCA, exports, plots, and explicit row-limit diagnostics |
| `logistic_sample.csv` | 60 | Binary purchase outcome and three-level risk outcome with numeric and categorical predictors for binary and multinomial logistic regression |
| `count_sample.csv` | 60 | Count outcome, positive exposure, age, and group for Poisson regression |
| `overdispersed_count_sample.csv` | 100 | Overdispersed counts, exposure, its logarithm, numeric predictors, and group for Poisson and NB2 regression |
| `factorial_sample.csv` | 60 | Continuous score, two categorical factors, and baseline covariate for two-way ANOVA, ANCOVA, and estimated marginal means |
| `longitudinal_sample.csv` | 96 | Long-format subject-by-time observations for repeated-measures ANOVA and random-intercept mixed-effects models |
| `multivariate_sample.csv` | 36 | Three groups and four numeric measurements for PCA, MANOVA, and linear discriminant analysis |
| `missing_values_sample.csv` | 20 | Blank and `NA` cells showing per-analysis complete-case removal |
| `error_diagnostics_sample.csv` | 25 | Constant, duplicate, and almost-duplicate predictors for testing explicit singularity, collinearity, and regularization output |

## Important data layouts

Most procedures expect one observation per row and one variable per column.
The wide sample and rank-test files place separate samples in separate columns.
Paired columns, such as `Before` and `After`, must describe the same case on
the same row.

Grouped binomial data use integer successes and integer trials on each row,
with successes between zero and trials. Count outcomes are nonnegative
integers. Exposure columns must be finite and strictly positive.

Categorical values may be text. StatClass detects text predictors and
reference-codes them for supported regression models. A numeric category code
must be named with `--categorical-predictors` if it should be treated as a
factor rather than as a quantitative predictor.

Longitudinal data are in long format: each row is one measurement, a subject
identifier repeats across rows, and the within-subject time variable identifies
the repeated condition. This is not a general time-series dataset; time-series
analysis remains outside the StatClass scope.

Blank cells and ordinary missing markers such as `NA` are treated as missing.
StatClass reports complete cases and excluded rows for the requested model.
It does not replace missing observations silently.

`four_column_test.csv` was converted from a headerless tab-delimited file.
The neutral headers `Series_1` through `Series_4` were added; all 81,920
measurements were preserved exactly to three decimal places, and no missing or
nonfinite values were introduced.

As a matrix, this file has shape $20,480 \times 4$. Its numerical row rank and
column rank are both 4, as they must be equal for every matrix. The raw-matrix
2-norm condition number is approximately 1.788, and centering the columns
retains rank 4 with condition number approximately 1.793. The matrix is not
square and therefore is not itself invertible, but its $4 \times 4$ Gram matrix
has full rank and is invertible in ordinary floating-point arithmetic.

## Numerical-warning examples

`error_diagnostics_sample.csv` is intentionally unsuitable for ordinary
unqualified inference:

- `Constant` has no variation, so simple regression on it is not run.
- `X_Duplicate` is identical to `X`, so the Huber design is singular.
- Ridge regression can fit the duplicated design because of its positive
  penalty, but it reports that the unpenalized design is rank deficient and
  that coefficient attribution depends on the penalty.
- `X_AlmostDuplicate` differs from `X` only near floating-point precision.
  Ordinary OLS therefore displays a huge condition number, unavailable VIFs,
  and enormous opposing coefficients. This is an example of output that
  should be diagnosed, not interpreted substantively.

These cases demonstrate the difference between an ordinary completed result,
a result completed with warnings, and a procedure that is explicitly not run.

The large four-column file also demonstrates deliberate method limits. Kernel
regression reports `not_run` above 5,000 complete cases because its calculation
is quadratic in the row count. Cross-validated KDE reports `not_run` above
3,000 finite values; Scott or Silverman bandwidth selection remains available
and completes on the full file.

Input loading has no arbitrary global row or column cap. Before pandas parses
the table, StatClass first checks a conservative file-size lower bound and then
reports a bounded-sample estimate of peak load memory. It compares the
safety-adjusted requirement with currently available memory. It stops with a
specific resource diagnostic only when that requirement cannot be met; it
never silently loads a truncated subset.

## Full command list

Open `example_commands.txt` for tested examples covering every CSV. The
commands also demonstrate text and JSON reports, prediction and residual
exports, transformed-data exports, and headless plots.
