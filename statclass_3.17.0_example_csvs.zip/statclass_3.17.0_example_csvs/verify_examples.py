#!/usr/bin/env python3
"""Run every command in example_commands.txt against a StatClass project."""

from __future__ import annotations

import argparse
import json
import shlex
import subprocess
import sys
import tempfile
from pathlib import Path


PATH_OPTIONS = {
    "--json",
    "--plot-dir",
    "--save-discriminant",
    "--save-pca-scores",
    "--save-predictions",
    "--save-residuals",
    "--save-transformed",
}


def commands_from_reference(path: Path) -> list[str]:
    lines = path.read_text(encoding="utf-8").splitlines()
    commands: list[str] = []
    index = 0
    while index < len(lines):
        stripped = lines[index].strip()
        if not stripped.startswith("python "):
            index += 1
            continue
        parts: list[str] = []
        while True:
            part = lines[index].strip()
            continued = part.endswith("\\")
            parts.append(part[:-1].rstrip() if continued else part)
            index += 1
            if not continued or index >= len(lines):
                break
        commands.append(" ".join(parts))
    return commands


def prepared_command(
    documented: str,
    stats_script: Path,
    data_dir: Path,
    case_dir: Path,
) -> tuple[list[str], str]:
    tokens = shlex.split(documented)
    sample = Path(tokens[2]).name
    prepared = [sys.executable, str(stats_script), str(data_dir / sample)]
    saw_json = False
    index = 3
    while index < len(tokens):
        token = tokens[index]
        prepared.append(token)
        if token in PATH_OPTIONS and index + 1 < len(tokens):
            filename = "report.json" if token == "--json" else Path(tokens[index + 1]).name
            prepared.append(str(case_dir / filename))
            saw_json = saw_json or token == "--json"
            index += 2
        else:
            index += 1
    if not saw_json:
        prepared.extend(("--json", str(case_dir / "report.json")))
    return prepared, sample


def top_level_statuses(report: dict) -> list[tuple[str, str]]:
    statuses: list[tuple[str, str]] = []
    for section, value in report.items():
        # Automatic normality screening may be inapplicable to constant trial,
        # exposure, or identifier columns. It is not a requested analysis.
        if section == "normality_tests":
            continue
        if isinstance(value, list):
            for index, item in enumerate(value):
                if isinstance(item, dict) and isinstance(item.get("status"), str):
                    statuses.append((f"{section}[{index}]", item["status"]))
        elif isinstance(value, dict):
            for key, items in value.items():
                if not isinstance(items, list):
                    continue
                for index, item in enumerate(items):
                    if isinstance(item, dict) and isinstance(item.get("status"), str):
                        statuses.append((f"{section}.{key}[{index}]", item["status"]))
    return statuses


def expected_diagnostic_statuses(sample: str, statuses: list[tuple[str, str]]) -> bool:
    observed = {path: status for path, status in statuses}
    allowed = {"completed", "completed_with_warnings", "not_run"}
    if sample == "error_diagnostics_sample.csv":
        return bool(observed) and set(observed.values()) <= allowed
    if sample == "four_column_test.csv":
        expected = {
            "kernel_regression_analyses[0]": "not_run",
            "kernel_density_analyses[0]": "not_run",
        }
        return bool(observed) and all(expected.get(path) == status for path, status in observed.items())
    return False


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Execute and validate every documented StatClass example command."
    )
    parser.add_argument(
        "statclass_dir",
        type=Path,
        help="unpacked StatClass project directory containing stats.py",
    )
    parser.add_argument(
        "--keep-output",
        type=Path,
        help="retain reports, exports, and plots in this directory",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_arguments()
    collection_dir = Path(__file__).resolve().parent
    data_dir = collection_dir / "csv"
    stats_script = args.statclass_dir.expanduser().resolve() / "stats.py"
    if not stats_script.is_file():
        print(f"error: stats.py was not found at {stats_script}", file=sys.stderr)
        return 2

    temporary = None
    if args.keep_output:
        audit_root = args.keep_output.expanduser().resolve()
        audit_root.mkdir(parents=True, exist_ok=True)
    else:
        temporary = tempfile.TemporaryDirectory(prefix="statclass-example-verification-")
        audit_root = Path(temporary.name)

    commands = commands_from_reference(collection_dir / "example_commands.txt")
    failures: list[str] = []
    warnings: list[str] = []
    for number, documented in enumerate(commands, start=1):
        case_dir = audit_root / f"case_{number:02d}"
        case_dir.mkdir(parents=True, exist_ok=True)
        prepared, sample = prepared_command(documented, stats_script, data_dir, case_dir)
        completed = subprocess.run(
            prepared,
            cwd=case_dir,
            capture_output=True,
            text=True,
            timeout=300,
            check=False,
        )
        (case_dir / "stdout.txt").write_text(completed.stdout, encoding="utf-8")
        (case_dir / "stderr.txt").write_text(completed.stderr, encoding="utf-8")
        report_path = case_dir / "report.json"
        problem = None
        statuses: list[tuple[str, str]] = []
        if completed.returncode != 0:
            problem = f"process exit {completed.returncode}: {completed.stderr.strip()}"
        elif not report_path.is_file():
            problem = "JSON report was not created"
        else:
            try:
                report = json.loads(report_path.read_text(encoding="utf-8"))
                statuses = top_level_statuses(report)
            except (OSError, json.JSONDecodeError) as exc:
                problem = f"invalid JSON report: {exc}"

        noncompleted = [(path, status) for path, status in statuses if status != "completed"]
        if problem is None and noncompleted:
            if expected_diagnostic_statuses(sample, statuses):
                warnings.append(
                    f"case {number:02d} {sample}: expected diagnostic statuses {noncompleted}"
                )
            else:
                problem = f"unexpected analysis status: {noncompleted}"

        if problem:
            failures.append(f"case {number:02d} {sample}: {problem}\n  {documented}")
            print(f"[{number:02d}/{len(commands):02d}] FAIL {sample}", flush=True)
        else:
            print(f"[{number:02d}/{len(commands):02d}] PASS {sample}", flush=True)

    print(f"\nExecuted {len(commands)} documented commands across {len(list(data_dir.glob('*.csv')))} CSV files.")
    for message in warnings:
        print(f"EXPECTED: {message}")
    if failures:
        print(f"\n{len(failures)} verification failure(s):", file=sys.stderr)
        for failure in failures:
            print(f"- {failure}", file=sys.stderr)
        if temporary is None:
            print(f"Retained output: {audit_root}", file=sys.stderr)
        return 1
    print("All documented examples passed; only intentional diagnostic cases were non-completed.")
    if temporary is None:
        print(f"Retained output: {audit_root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
